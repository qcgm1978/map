(function() {
  'use strict';
  var a;

  a = 0 && (1, 2, 3);

  if (typeof n !== "undefined" && n !== null) {
    ({
      protocol: n[1],
      domain: n[2],
      port: n[3],
      path: n[4],
      query_str: n[5],
      sharp: n[6]
    });
  } else {
    null;
  }

}).call(this);

/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 3/26/13
 * Time: 4:38 PM
 * Use:
 */
require.config({
    baseUrl: 'scripts',
    paths: {
        jquery: '../bower_components/jquery/jquery',
        jqueryMigrate: '../bower_components/jquery-migrate/jquery-migrate',
        jquerymx: '../bower_components/jquerymx/jquerymx',
        tools: "util/tools",
        mapUtil: "util/mapUtil"
    },
    shim: {
        jqueryMigrate: {
            deps: ['jquery']
        },
        jquerymx: {
            deps: ['jquery']
        }
    }
});
require(['tools','mapUtil'], function () {
    var url = location.href,
        addressHandler = new SharedAddressHandler(url);
    url = addressHandler.buildRedirectAddress();
    var handler = new SharedInfoHandler(url);
    handler.verifySharedInfo();
    handler.tryOpenSoftware();
    handler.redirectStartPage();


    function SharedAddressHandler(url) {
        var that = this;
        this.url = _handleLocalUrl(url);
        this.buildRedirectAddress = function () {
            return that.url
                .replace(/navi\.htm/, '')//index.html file name not occurs in formal enviroment
                .replace(/(start\.html)?\?/, "start.html?");

        };
        function _handleLocalUrl(url) {
//todo 测试数据
//    if address is an invalid value, change it a valid value by replacing subversion folder name 'flynavi'
            if (!_verifySharedInfoValidity(url)) {
                var info = '?name=%E8%A5%BF%E5%9B%9B%E7%8E%AF%E4%B8%AD%E8%B7%AF%E8%BE%85%E8%B7%AF&lng=116.309272&lat=39.979194&address=%E7%94%98%E8%82%83%E7%9C%81%E5%BC%A0%E6%8E%96%E5%B8%82%E8%8B%8F%E5%8D%97%E8%A3%95%E5%9B%BA%E6%97%8F%E8%87%AA%E6%B2%BB%E5%8E%BF';
//            the data whose position outside China
//            info = '?name=%E8%A5%BF%E5%9B%9B%E7%8E%AF%E4%B8%AD%E8%B7%AF%E8%BE%85%E8%B7%AF&lng=103.7571334838867&lat=61.98898696899414&address=%E7%94%98%E8%82%83%E7%9C%81%E5%BC%A0%E6%8E%96%E5%B8%82%E8%8B%8F%E5%8D%97%E8%A3%95%E5%9B%BA%E6%97%8F%E8%87%AA%E6%B2%BB%E5%8E%BF';
                return url.replace(/navi\.htm.*/, "start.html" + info);
            }
            return url;
        }

        function _verifySharedInfoValidity(url) {
            return /lng/.test(url) && /lat/.test(url) && /name/.test(url);
        }
    }

    function SharedInfoHandler(url) {
        var publicModel = new PublicModel();
        this.url = url;
        var util_common = new Util.common(),
            that = this;
        this.shareInfo = util_common.parseUrl(this.url);
        function _redirect() {
            location.href = that.url;
        }

        function _verifyInfoVal(shareInfo) {
            return util_common.judgeVal(shareInfo.name) && util_common.judgeVal(shareInfo.lng) && util_common.judgeVal(shareInfo.lat)
        }

        function _isAddressVal(url) {
            return /address\=.+/.exec(url);
        }

        function _tryOpenFlySoftware(appUri) {
            document.location = appUri;
            setTimeout(function () {
                _redirect();
            }, 1000);
        }

        this.verifySharedInfo = function () {
            if (!_verifyInfoVal(this.shareInfo)) {
                //todo 等待产品需求
//                    alert('飞享信息错误');
            }

        };
        this.tryOpenSoftware = function () {

            if (!publicModel.isIOS()) {
                return;
            }
            var addressStr = this.shareInfo.address ? '"address":"' + this.shareInfo.address + '",' : '';
            var infoJson = '{' +
                addressStr +
                '"name":"' +
                this.shareInfo.name +
                '","lng":' +
                this.shareInfo.lng +
                ',"lat":' +
                this.shareInfo.lat +
                '}';
//        todo change to a global variable
            var appStoreUri = encodeURI('Raxtone-Flynavi://' + infoJson);
            _tryOpenFlySoftware(appStoreUri);
        };
        this.redirectStartPage = function () {
            if (publicModel.isIOS()) {
                return;
            }
            _redirect();
        };

    }

});
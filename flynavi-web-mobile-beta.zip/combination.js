
/*!
 * jQuery JavaScript Library v2.0.3
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright 2005, 2013 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2013-07-03T13:30Z
 */
(function( window, undefined ) {

// Can't do this because several apps including ASP.NET trace
// the stack via arguments.caller.callee and Firefox dies if
// you try to trace through "use strict" call chains. (#13335)
// Support: Firefox 18+
//"use strict";
var
	// A central reference to the root jQuery(document)
	rootjQuery,

	// The deferred used on DOM ready
	readyList,

	// Support: IE9
	// For `typeof xmlNode.method` instead of `xmlNode.method !== undefined`
	core_strundefined = typeof undefined,

	// Use the correct document accordingly with window argument (sandbox)
	location = window.location,
	document = window.document,
	docElem = document.documentElement,

	// Map over jQuery in case of overwrite
	_jQuery = window.jQuery,

	// Map over the $ in case of overwrite
	_$ = window.$,

	// [[Class]] -> type pairs
	class2type = {},

	// List of deleted data cache ids, so we can reuse them
	core_deletedIds = [],

	core_version = "2.0.3",

	// Save a reference to some core methods
	core_concat = core_deletedIds.concat,
	core_push = core_deletedIds.push,
	core_slice = core_deletedIds.slice,
	core_indexOf = core_deletedIds.indexOf,
	core_toString = class2type.toString,
	core_hasOwn = class2type.hasOwnProperty,
	core_trim = core_version.trim,

	// Define a local copy of jQuery
	jQuery = function( selector, context ) {
		// The jQuery object is actually just the init constructor 'enhanced'
		return new jQuery.fn.init( selector, context, rootjQuery );
	},

	// Used for matching numbers
	core_pnum = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,

	// Used for splitting on whitespace
	core_rnotwhite = /\S+/g,

	// A simple way to check for HTML strings
	// Prioritize #id over <tag> to avoid XSS via location.hash (#9521)
	// Strict HTML recognition (#11290: must start with <)
	rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,

	// Match a standalone tag
	rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,

	// Matches dashed string for camelizing
	rmsPrefix = /^-ms-/,
	rdashAlpha = /-([\da-z])/gi,

	// Used by jQuery.camelCase as callback to replace()
	fcamelCase = function( all, letter ) {
		return letter.toUpperCase();
	},

	// The ready event handler and self cleanup method
	completed = function() {
		document.removeEventListener( "DOMContentLoaded", completed, false );
		window.removeEventListener( "load", completed, false );
		jQuery.ready();
	};

jQuery.fn = jQuery.prototype = {
	// The current version of jQuery being used
	jquery: core_version,

	constructor: jQuery,
	init: function( selector, context, rootjQuery ) {
		var match, elem;

		// HANDLE: $(""), $(null), $(undefined), $(false)
		if ( !selector ) {
			return this;
		}

		// Handle HTML strings
		if ( typeof selector === "string" ) {
			if ( selector.charAt(0) === "<" && selector.charAt( selector.length - 1 ) === ">" && selector.length >= 3 ) {
				// Assume that strings that start and end with <> are HTML and skip the regex check
				match = [ null, selector, null ];

			} else {
				match = rquickExpr.exec( selector );
			}

			// Match html or make sure no context is specified for #id
			if ( match && (match[1] || !context) ) {

				// HANDLE: $(html) -> $(array)
				if ( match[1] ) {
					context = context instanceof jQuery ? context[0] : context;

					// scripts is true for back-compat
					jQuery.merge( this, jQuery.parseHTML(
						match[1],
						context && context.nodeType ? context.ownerDocument || context : document,
						true
					) );

					// HANDLE: $(html, props)
					if ( rsingleTag.test( match[1] ) && jQuery.isPlainObject( context ) ) {
						for ( match in context ) {
							// Properties of context are called as methods if possible
							if ( jQuery.isFunction( this[ match ] ) ) {
								this[ match ]( context[ match ] );

							// ...and otherwise set as attributes
							} else {
								this.attr( match, context[ match ] );
							}
						}
					}

					return this;

				// HANDLE: $(#id)
				} else {
					elem = document.getElementById( match[2] );

					// Check parentNode to catch when Blackberry 4.6 returns
					// nodes that are no longer in the document #6963
					if ( elem && elem.parentNode ) {
						// Inject the element directly into the jQuery object
						this.length = 1;
						this[0] = elem;
					}

					this.context = document;
					this.selector = selector;
					return this;
				}

			// HANDLE: $(expr, $(...))
			} else if ( !context || context.jquery ) {
				return ( context || rootjQuery ).find( selector );

			// HANDLE: $(expr, context)
			// (which is just equivalent to: $(context).find(expr)
			} else {
				return this.constructor( context ).find( selector );
			}

		// HANDLE: $(DOMElement)
		} else if ( selector.nodeType ) {
			this.context = this[0] = selector;
			this.length = 1;
			return this;

		// HANDLE: $(function)
		// Shortcut for document ready
		} else if ( jQuery.isFunction( selector ) ) {
			return rootjQuery.ready( selector );
		}

		if ( selector.selector !== undefined ) {
			this.selector = selector.selector;
			this.context = selector.context;
		}

		return jQuery.makeArray( selector, this );
	},

	// Start with an empty selector
	selector: "",

	// The default length of a jQuery object is 0
	length: 0,

	toArray: function() {
		return core_slice.call( this );
	},

	// Get the Nth element in the matched element set OR
	// Get the whole matched element set as a clean array
	get: function( num ) {
		return num == null ?

			// Return a 'clean' array
			this.toArray() :

			// Return just the object
			( num < 0 ? this[ this.length + num ] : this[ num ] );
	},

	// Take an array of elements and push it onto the stack
	// (returning the new matched element set)
	pushStack: function( elems ) {

		// Build a new jQuery matched element set
		var ret = jQuery.merge( this.constructor(), elems );

		// Add the old object onto the stack (as a reference)
		ret.prevObject = this;
		ret.context = this.context;

		// Return the newly-formed element set
		return ret;
	},

	// Execute a callback for every element in the matched set.
	// (You can seed the arguments with an array of args, but this is
	// only used internally.)
	each: function( callback, args ) {
		return jQuery.each( this, callback, args );
	},

	ready: function( fn ) {
		// Add the callback
		jQuery.ready.promise().done( fn );

		return this;
	},

	slice: function() {
		return this.pushStack( core_slice.apply( this, arguments ) );
	},

	first: function() {
		return this.eq( 0 );
	},

	last: function() {
		return this.eq( -1 );
	},

	eq: function( i ) {
		var len = this.length,
			j = +i + ( i < 0 ? len : 0 );
		return this.pushStack( j >= 0 && j < len ? [ this[j] ] : [] );
	},

	map: function( callback ) {
		return this.pushStack( jQuery.map(this, function( elem, i ) {
			return callback.call( elem, i, elem );
		}));
	},

	end: function() {
		return this.prevObject || this.constructor(null);
	},

	// For internal use only.
	// Behaves like an Array's method, not like a jQuery method.
	push: core_push,
	sort: [].sort,
	splice: [].splice
};

// Give the init function the jQuery prototype for later instantiation
jQuery.fn.init.prototype = jQuery.fn;

jQuery.extend = jQuery.fn.extend = function() {
	var options, name, src, copy, copyIsArray, clone,
		target = arguments[0] || {},
		i = 1,
		length = arguments.length,
		deep = false;

	// Handle a deep copy situation
	if ( typeof target === "boolean" ) {
		deep = target;
		target = arguments[1] || {};
		// skip the boolean and the target
		i = 2;
	}

	// Handle case when target is a string or something (possible in deep copy)
	if ( typeof target !== "object" && !jQuery.isFunction(target) ) {
		target = {};
	}

	// extend jQuery itself if only one argument is passed
	if ( length === i ) {
		target = this;
		--i;
	}

	for ( ; i < length; i++ ) {
		// Only deal with non-null/undefined values
		if ( (options = arguments[ i ]) != null ) {
			// Extend the base object
			for ( name in options ) {
				src = target[ name ];
				copy = options[ name ];

				// Prevent never-ending loop
				if ( target === copy ) {
					continue;
				}

				// Recurse if we're merging plain objects or arrays
				if ( deep && copy && ( jQuery.isPlainObject(copy) || (copyIsArray = jQuery.isArray(copy)) ) ) {
					if ( copyIsArray ) {
						copyIsArray = false;
						clone = src && jQuery.isArray(src) ? src : [];

					} else {
						clone = src && jQuery.isPlainObject(src) ? src : {};
					}

					// Never move original objects, clone them
					target[ name ] = jQuery.extend( deep, clone, copy );

				// Don't bring in undefined values
				} else if ( copy !== undefined ) {
					target[ name ] = copy;
				}
			}
		}
	}

	// Return the modified object
	return target;
};

jQuery.extend({
	// Unique for each copy of jQuery on the page
	expando: "jQuery" + ( core_version + Math.random() ).replace( /\D/g, "" ),

	noConflict: function( deep ) {
		if ( window.$ === jQuery ) {
			window.$ = _$;
		}

		if ( deep && window.jQuery === jQuery ) {
			window.jQuery = _jQuery;
		}

		return jQuery;
	},

	// Is the DOM ready to be used? Set to true once it occurs.
	isReady: false,

	// A counter to track how many items to wait for before
	// the ready event fires. See #6781
	readyWait: 1,

	// Hold (or release) the ready event
	holdReady: function( hold ) {
		if ( hold ) {
			jQuery.readyWait++;
		} else {
			jQuery.ready( true );
		}
	},

	// Handle when the DOM is ready
	ready: function( wait ) {

		// Abort if there are pending holds or we're already ready
		if ( wait === true ? --jQuery.readyWait : jQuery.isReady ) {
			return;
		}

		// Remember that the DOM is ready
		jQuery.isReady = true;

		// If a normal DOM Ready event fired, decrement, and wait if need be
		if ( wait !== true && --jQuery.readyWait > 0 ) {
			return;
		}

		// If there are functions bound, to execute
		readyList.resolveWith( document, [ jQuery ] );

		// Trigger any bound ready events
		if ( jQuery.fn.trigger ) {
			jQuery( document ).trigger("ready").off("ready");
		}
	},

	// See test/unit/core.js for details concerning isFunction.
	// Since version 1.3, DOM methods and functions like alert
	// aren't supported. They return false on IE (#2968).
	isFunction: function( obj ) {
		return jQuery.type(obj) === "function";
	},

	isArray: Array.isArray,

	isWindow: function( obj ) {
		return obj != null && obj === obj.window;
	},

	isNumeric: function( obj ) {
		return !isNaN( parseFloat(obj) ) && isFinite( obj );
	},

	type: function( obj ) {
		if ( obj == null ) {
			return String( obj );
		}
		// Support: Safari <= 5.1 (functionish RegExp)
		return typeof obj === "object" || typeof obj === "function" ?
			class2type[ core_toString.call(obj) ] || "object" :
			typeof obj;
	},

	isPlainObject: function( obj ) {
		// Not plain objects:
		// - Any object or value whose internal [[Class]] property is not "[object Object]"
		// - DOM nodes
		// - window
		if ( jQuery.type( obj ) !== "object" || obj.nodeType || jQuery.isWindow( obj ) ) {
			return false;
		}

		// Support: Firefox <20
		// The try/catch suppresses exceptions thrown when attempting to access
		// the "constructor" property of certain host objects, ie. |window.location|
		// https://bugzilla.mozilla.org/show_bug.cgi?id=814622
		try {
			if ( obj.constructor &&
					!core_hasOwn.call( obj.constructor.prototype, "isPrototypeOf" ) ) {
				return false;
			}
		} catch ( e ) {
			return false;
		}

		// If the function hasn't returned already, we're confident that
		// |obj| is a plain object, created by {} or constructed with new Object
		return true;
	},

	isEmptyObject: function( obj ) {
		var name;
		for ( name in obj ) {
			return false;
		}
		return true;
	},

	error: function( msg ) {
		throw new Error( msg );
	},

	// data: string of html
	// context (optional): If specified, the fragment will be created in this context, defaults to document
	// keepScripts (optional): If true, will include scripts passed in the html string
	parseHTML: function( data, context, keepScripts ) {
		if ( !data || typeof data !== "string" ) {
			return null;
		}
		if ( typeof context === "boolean" ) {
			keepScripts = context;
			context = false;
		}
		context = context || document;

		var parsed = rsingleTag.exec( data ),
			scripts = !keepScripts && [];

		// Single tag
		if ( parsed ) {
			return [ context.createElement( parsed[1] ) ];
		}

		parsed = jQuery.buildFragment( [ data ], context, scripts );

		if ( scripts ) {
			jQuery( scripts ).remove();
		}

		return jQuery.merge( [], parsed.childNodes );
	},

	parseJSON: JSON.parse,

	// Cross-browser xml parsing
	parseXML: function( data ) {
		var xml, tmp;
		if ( !data || typeof data !== "string" ) {
			return null;
		}

		// Support: IE9
		try {
			tmp = new DOMParser();
			xml = tmp.parseFromString( data , "text/xml" );
		} catch ( e ) {
			xml = undefined;
		}

		if ( !xml || xml.getElementsByTagName( "parsererror" ).length ) {
			jQuery.error( "Invalid XML: " + data );
		}
		return xml;
	},

	noop: function() {},

	// Evaluates a script in a global context
	globalEval: function( code ) {
		var script,
				indirect = eval;

		code = jQuery.trim( code );

		if ( code ) {
			// If the code includes a valid, prologue position
			// strict mode pragma, execute code by injecting a
			// script tag into the document.
			if ( code.indexOf("use strict") === 1 ) {
				script = document.createElement("script");
				script.text = code;
				document.head.appendChild( script ).parentNode.removeChild( script );
			} else {
			// Otherwise, avoid the DOM node creation, insertion
			// and removal by using an indirect global eval
				indirect( code );
			}
		}
	},

	// Convert dashed to camelCase; used by the css and data modules
	// Microsoft forgot to hump their vendor prefix (#9572)
	camelCase: function( string ) {
		return string.replace( rmsPrefix, "ms-" ).replace( rdashAlpha, fcamelCase );
	},

	nodeName: function( elem, name ) {
		return elem.nodeName && elem.nodeName.toLowerCase() === name.toLowerCase();
	},

	// args is for internal usage only
	each: function( obj, callback, args ) {
		var value,
			i = 0,
			length = obj.length,
			isArray = isArraylike( obj );

		if ( args ) {
			if ( isArray ) {
				for ( ; i < length; i++ ) {
					value = callback.apply( obj[ i ], args );

					if ( value === false ) {
						break;
					}
				}
			} else {
				for ( i in obj ) {
					value = callback.apply( obj[ i ], args );

					if ( value === false ) {
						break;
					}
				}
			}

		// A special, fast, case for the most common use of each
		} else {
			if ( isArray ) {
				for ( ; i < length; i++ ) {
					value = callback.call( obj[ i ], i, obj[ i ] );

					if ( value === false ) {
						break;
					}
				}
			} else {
				for ( i in obj ) {
					value = callback.call( obj[ i ], i, obj[ i ] );

					if ( value === false ) {
						break;
					}
				}
			}
		}

		return obj;
	},

	trim: function( text ) {
		return text == null ? "" : core_trim.call( text );
	},

	// results is for internal usage only
	makeArray: function( arr, results ) {
		var ret = results || [];

		if ( arr != null ) {
			if ( isArraylike( Object(arr) ) ) {
				jQuery.merge( ret,
					typeof arr === "string" ?
					[ arr ] : arr
				);
			} else {
				core_push.call( ret, arr );
			}
		}

		return ret;
	},

	inArray: function( elem, arr, i ) {
		return arr == null ? -1 : core_indexOf.call( arr, elem, i );
	},

	merge: function( first, second ) {
		var l = second.length,
			i = first.length,
			j = 0;

		if ( typeof l === "number" ) {
			for ( ; j < l; j++ ) {
				first[ i++ ] = second[ j ];
			}
		} else {
			while ( second[j] !== undefined ) {
				first[ i++ ] = second[ j++ ];
			}
		}

		first.length = i;

		return first;
	},

	grep: function( elems, callback, inv ) {
		var retVal,
			ret = [],
			i = 0,
			length = elems.length;
		inv = !!inv;

		// Go through the array, only saving the items
		// that pass the validator function
		for ( ; i < length; i++ ) {
			retVal = !!callback( elems[ i ], i );
			if ( inv !== retVal ) {
				ret.push( elems[ i ] );
			}
		}

		return ret;
	},

	// arg is for internal usage only
	map: function( elems, callback, arg ) {
		var value,
			i = 0,
			length = elems.length,
			isArray = isArraylike( elems ),
			ret = [];

		// Go through the array, translating each of the items to their
		if ( isArray ) {
			for ( ; i < length; i++ ) {
				value = callback( elems[ i ], i, arg );

				if ( value != null ) {
					ret[ ret.length ] = value;
				}
			}

		// Go through every key on the object,
		} else {
			for ( i in elems ) {
				value = callback( elems[ i ], i, arg );

				if ( value != null ) {
					ret[ ret.length ] = value;
				}
			}
		}

		// Flatten any nested arrays
		return core_concat.apply( [], ret );
	},

	// A global GUID counter for objects
	guid: 1,

	// Bind a function to a context, optionally partially applying any
	// arguments.
	proxy: function( fn, context ) {
		var tmp, args, proxy;

		if ( typeof context === "string" ) {
			tmp = fn[ context ];
			context = fn;
			fn = tmp;
		}

		// Quick check to determine if target is callable, in the spec
		// this throws a TypeError, but we will just return undefined.
		if ( !jQuery.isFunction( fn ) ) {
			return undefined;
		}

		// Simulated bind
		args = core_slice.call( arguments, 2 );
		proxy = function() {
			return fn.apply( context || this, args.concat( core_slice.call( arguments ) ) );
		};

		// Set the guid of unique handler to the same of original handler, so it can be removed
		proxy.guid = fn.guid = fn.guid || jQuery.guid++;

		return proxy;
	},

	// Multifunctional method to get and set values of a collection
	// The value/s can optionally be executed if it's a function
	access: function( elems, fn, key, value, chainable, emptyGet, raw ) {
		var i = 0,
			length = elems.length,
			bulk = key == null;

		// Sets many values
		if ( jQuery.type( key ) === "object" ) {
			chainable = true;
			for ( i in key ) {
				jQuery.access( elems, fn, i, key[i], true, emptyGet, raw );
			}

		// Sets one value
		} else if ( value !== undefined ) {
			chainable = true;

			if ( !jQuery.isFunction( value ) ) {
				raw = true;
			}

			if ( bulk ) {
				// Bulk operations run against the entire set
				if ( raw ) {
					fn.call( elems, value );
					fn = null;

				// ...except when executing function values
				} else {
					bulk = fn;
					fn = function( elem, key, value ) {
						return bulk.call( jQuery( elem ), value );
					};
				}
			}

			if ( fn ) {
				for ( ; i < length; i++ ) {
					fn( elems[i], key, raw ? value : value.call( elems[i], i, fn( elems[i], key ) ) );
				}
			}
		}

		return chainable ?
			elems :

			// Gets
			bulk ?
				fn.call( elems ) :
				length ? fn( elems[0], key ) : emptyGet;
	},

	now: Date.now,

	// A method for quickly swapping in/out CSS properties to get correct calculations.
	// Note: this method belongs to the css module but it's needed here for the support module.
	// If support gets modularized, this method should be moved back to the css module.
	swap: function( elem, options, callback, args ) {
		var ret, name,
			old = {};

		// Remember the old values, and insert the new ones
		for ( name in options ) {
			old[ name ] = elem.style[ name ];
			elem.style[ name ] = options[ name ];
		}

		ret = callback.apply( elem, args || [] );

		// Revert the old values
		for ( name in options ) {
			elem.style[ name ] = old[ name ];
		}

		return ret;
	}
});

jQuery.ready.promise = function( obj ) {
	if ( !readyList ) {

		readyList = jQuery.Deferred();

		// Catch cases where $(document).ready() is called after the browser event has already occurred.
		// we once tried to use readyState "interactive" here, but it caused issues like the one
		// discovered by ChrisS here: http://bugs.jquery.com/ticket/12282#comment:15
		if ( document.readyState === "complete" ) {
			// Handle it asynchronously to allow scripts the opportunity to delay ready
			setTimeout( jQuery.ready );

		} else {

			// Use the handy event callback
			document.addEventListener( "DOMContentLoaded", completed, false );

			// A fallback to window.onload, that will always work
			window.addEventListener( "load", completed, false );
		}
	}
	return readyList.promise( obj );
};

// Populate the class2type map
jQuery.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(i, name) {
	class2type[ "[object " + name + "]" ] = name.toLowerCase();
});

function isArraylike( obj ) {
	var length = obj.length,
		type = jQuery.type( obj );

	if ( jQuery.isWindow( obj ) ) {
		return false;
	}

	if ( obj.nodeType === 1 && length ) {
		return true;
	}

	return type === "array" || type !== "function" &&
		( length === 0 ||
		typeof length === "number" && length > 0 && ( length - 1 ) in obj );
}

// All jQuery objects should point back to these
rootjQuery = jQuery(document);
/*!
 * Sizzle CSS Selector Engine v1.9.4-pre
 * http://sizzlejs.com/
 *
 * Copyright 2013 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2013-06-03
 */
(function( window, undefined ) {

var i,
	support,
	cachedruns,
	Expr,
	getText,
	isXML,
	compile,
	outermostContext,
	sortInput,

	// Local document vars
	setDocument,
	document,
	docElem,
	documentIsHTML,
	rbuggyQSA,
	rbuggyMatches,
	matches,
	contains,

	// Instance-specific data
	expando = "sizzle" + -(new Date()),
	preferredDoc = window.document,
	dirruns = 0,
	done = 0,
	classCache = createCache(),
	tokenCache = createCache(),
	compilerCache = createCache(),
	hasDuplicate = false,
	sortOrder = function( a, b ) {
		if ( a === b ) {
			hasDuplicate = true;
			return 0;
		}
		return 0;
	},

	// General-purpose constants
	strundefined = typeof undefined,
	MAX_NEGATIVE = 1 << 31,

	// Instance methods
	hasOwn = ({}).hasOwnProperty,
	arr = [],
	pop = arr.pop,
	push_native = arr.push,
	push = arr.push,
	slice = arr.slice,
	// Use a stripped-down indexOf if we can't use a native one
	indexOf = arr.indexOf || function( elem ) {
		var i = 0,
			len = this.length;
		for ( ; i < len; i++ ) {
			if ( this[i] === elem ) {
				return i;
			}
		}
		return -1;
	},

	booleans = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",

	// Regular expressions

	// Whitespace characters http://www.w3.org/TR/css3-selectors/#whitespace
	whitespace = "[\\x20\\t\\r\\n\\f]",
	// http://www.w3.org/TR/css3-syntax/#characters
	characterEncoding = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",

	// Loosely modeled on CSS identifier characters
	// An unquoted value should be a CSS identifier http://www.w3.org/TR/css3-selectors/#attribute-selectors
	// Proper syntax: http://www.w3.org/TR/CSS21/syndata.html#value-def-identifier
	identifier = characterEncoding.replace( "w", "w#" ),

	// Acceptable operators http://www.w3.org/TR/selectors/#attribute-selectors
	attributes = "\\[" + whitespace + "*(" + characterEncoding + ")" + whitespace +
		"*(?:([*^$|!~]?=)" + whitespace + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + identifier + ")|)|)" + whitespace + "*\\]",

	// Prefer arguments quoted,
	//   then not containing pseudos/brackets,
	//   then attribute selectors/non-parenthetical expressions,
	//   then anything else
	// These preferences are here to reduce the number of selectors
	//   needing tokenize in the PSEUDO preFilter
	pseudos = ":(" + characterEncoding + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + attributes.replace( 3, 8 ) + ")*)|.*)\\)|)",

	// Leading and non-escaped trailing whitespace, capturing some non-whitespace characters preceding the latter
	rtrim = new RegExp( "^" + whitespace + "+|((?:^|[^\\\\])(?:\\\\.)*)" + whitespace + "+$", "g" ),

	rcomma = new RegExp( "^" + whitespace + "*," + whitespace + "*" ),
	rcombinators = new RegExp( "^" + whitespace + "*([>+~]|" + whitespace + ")" + whitespace + "*" ),

	rsibling = new RegExp( whitespace + "*[+~]" ),
	rattributeQuotes = new RegExp( "=" + whitespace + "*([^\\]'\"]*)" + whitespace + "*\\]", "g" ),

	rpseudo = new RegExp( pseudos ),
	ridentifier = new RegExp( "^" + identifier + "$" ),

	matchExpr = {
		"ID": new RegExp( "^#(" + characterEncoding + ")" ),
		"CLASS": new RegExp( "^\\.(" + characterEncoding + ")" ),
		"TAG": new RegExp( "^(" + characterEncoding.replace( "w", "w*" ) + ")" ),
		"ATTR": new RegExp( "^" + attributes ),
		"PSEUDO": new RegExp( "^" + pseudos ),
		"CHILD": new RegExp( "^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + whitespace +
			"*(even|odd|(([+-]|)(\\d*)n|)" + whitespace + "*(?:([+-]|)" + whitespace +
			"*(\\d+)|))" + whitespace + "*\\)|)", "i" ),
		"bool": new RegExp( "^(?:" + booleans + ")$", "i" ),
		// For use in libraries implementing .is()
		// We use this for POS matching in `select`
		"needsContext": new RegExp( "^" + whitespace + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
			whitespace + "*((?:-\\d)?\\d*)" + whitespace + "*\\)|)(?=[^-]|$)", "i" )
	},

	rnative = /^[^{]+\{\s*\[native \w/,

	// Easily-parseable/retrievable ID or TAG or CLASS selectors
	rquickExpr = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,

	rinputs = /^(?:input|select|textarea|button)$/i,
	rheader = /^h\d$/i,

	rescape = /'|\\/g,

	// CSS escapes http://www.w3.org/TR/CSS21/syndata.html#escaped-characters
	runescape = new RegExp( "\\\\([\\da-f]{1,6}" + whitespace + "?|(" + whitespace + ")|.)", "ig" ),
	funescape = function( _, escaped, escapedWhitespace ) {
		var high = "0x" + escaped - 0x10000;
		// NaN means non-codepoint
		// Support: Firefox
		// Workaround erroneous numeric interpretation of +"0x"
		return high !== high || escapedWhitespace ?
			escaped :
			// BMP codepoint
			high < 0 ?
				String.fromCharCode( high + 0x10000 ) :
				// Supplemental Plane codepoint (surrogate pair)
				String.fromCharCode( high >> 10 | 0xD800, high & 0x3FF | 0xDC00 );
	};

// Optimize for push.apply( _, NodeList )
try {
	push.apply(
		(arr = slice.call( preferredDoc.childNodes )),
		preferredDoc.childNodes
	);
	// Support: Android<4.0
	// Detect silently failing push.apply
	arr[ preferredDoc.childNodes.length ].nodeType;
} catch ( e ) {
	push = { apply: arr.length ?

		// Leverage slice if possible
		function( target, els ) {
			push_native.apply( target, slice.call(els) );
		} :

		// Support: IE<9
		// Otherwise append directly
		function( target, els ) {
			var j = target.length,
				i = 0;
			// Can't trust NodeList.length
			while ( (target[j++] = els[i++]) ) {}
			target.length = j - 1;
		}
	};
}

function Sizzle( selector, context, results, seed ) {
	var match, elem, m, nodeType,
		// QSA vars
		i, groups, old, nid, newContext, newSelector;

	if ( ( context ? context.ownerDocument || context : preferredDoc ) !== document ) {
		setDocument( context );
	}

	context = context || document;
	results = results || [];

	if ( !selector || typeof selector !== "string" ) {
		return results;
	}

	if ( (nodeType = context.nodeType) !== 1 && nodeType !== 9 ) {
		return [];
	}

	if ( documentIsHTML && !seed ) {

		// Shortcuts
		if ( (match = rquickExpr.exec( selector )) ) {
			// Speed-up: Sizzle("#ID")
			if ( (m = match[1]) ) {
				if ( nodeType === 9 ) {
					elem = context.getElementById( m );
					// Check parentNode to catch when Blackberry 4.6 returns
					// nodes that are no longer in the document #6963
					if ( elem && elem.parentNode ) {
						// Handle the case where IE, Opera, and Webkit return items
						// by name instead of ID
						if ( elem.id === m ) {
							results.push( elem );
							return results;
						}
					} else {
						return results;
					}
				} else {
					// Context is not a document
					if ( context.ownerDocument && (elem = context.ownerDocument.getElementById( m )) &&
						contains( context, elem ) && elem.id === m ) {
						results.push( elem );
						return results;
					}
				}

			// Speed-up: Sizzle("TAG")
			} else if ( match[2] ) {
				push.apply( results, context.getElementsByTagName( selector ) );
				return results;

			// Speed-up: Sizzle(".CLASS")
			} else if ( (m = match[3]) && support.getElementsByClassName && context.getElementsByClassName ) {
				push.apply( results, context.getElementsByClassName( m ) );
				return results;
			}
		}

		// QSA path
		if ( support.qsa && (!rbuggyQSA || !rbuggyQSA.test( selector )) ) {
			nid = old = expando;
			newContext = context;
			newSelector = nodeType === 9 && selector;

			// qSA works strangely on Element-rooted queries
			// We can work around this by specifying an extra ID on the root
			// and working up from there (Thanks to Andrew Dupont for the technique)
			// IE 8 doesn't work on object elements
			if ( nodeType === 1 && context.nodeName.toLowerCase() !== "object" ) {
				groups = tokenize( selector );

				if ( (old = context.getAttribute("id")) ) {
					nid = old.replace( rescape, "\\$&" );
				} else {
					context.setAttribute( "id", nid );
				}
				nid = "[id='" + nid + "'] ";

				i = groups.length;
				while ( i-- ) {
					groups[i] = nid + toSelector( groups[i] );
				}
				newContext = rsibling.test( selector ) && context.parentNode || context;
				newSelector = groups.join(",");
			}

			if ( newSelector ) {
				try {
					push.apply( results,
						newContext.querySelectorAll( newSelector )
					);
					return results;
				} catch(qsaError) {
				} finally {
					if ( !old ) {
						context.removeAttribute("id");
					}
				}
			}
		}
	}

	// All others
	return select( selector.replace( rtrim, "$1" ), context, results, seed );
}

/**
 * Create key-value caches of limited size
 * @returns {Function(string, Object)} Returns the Object data after storing it on itself with
 *	property name the (space-suffixed) string and (if the cache is larger than Expr.cacheLength)
 *	deleting the oldest entry
 */
function createCache() {
	var keys = [];

	function cache( key, value ) {
		// Use (key + " ") to avoid collision with native prototype properties (see Issue #157)
		if ( keys.push( key += " " ) > Expr.cacheLength ) {
			// Only keep the most recent entries
			delete cache[ keys.shift() ];
		}
		return (cache[ key ] = value);
	}
	return cache;
}

/**
 * Mark a function for special use by Sizzle
 * @param {Function} fn The function to mark
 */
function markFunction( fn ) {
	fn[ expando ] = true;
	return fn;
}

/**
 * Support testing using an element
 * @param {Function} fn Passed the created div and expects a boolean result
 */
function assert( fn ) {
	var div = document.createElement("div");

	try {
		return !!fn( div );
	} catch (e) {
		return false;
	} finally {
		// Remove from its parent by default
		if ( div.parentNode ) {
			div.parentNode.removeChild( div );
		}
		// release memory in IE
		div = null;
	}
}

/**
 * Adds the same handler for all of the specified attrs
 * @param {String} attrs Pipe-separated list of attributes
 * @param {Function} handler The method that will be applied
 */
function addHandle( attrs, handler ) {
	var arr = attrs.split("|"),
		i = attrs.length;

	while ( i-- ) {
		Expr.attrHandle[ arr[i] ] = handler;
	}
}

/**
 * Checks document order of two siblings
 * @param {Element} a
 * @param {Element} b
 * @returns {Number} Returns less than 0 if a precedes b, greater than 0 if a follows b
 */
function siblingCheck( a, b ) {
	var cur = b && a,
		diff = cur && a.nodeType === 1 && b.nodeType === 1 &&
			( ~b.sourceIndex || MAX_NEGATIVE ) -
			( ~a.sourceIndex || MAX_NEGATIVE );

	// Use IE sourceIndex if available on both nodes
	if ( diff ) {
		return diff;
	}

	// Check if b follows a
	if ( cur ) {
		while ( (cur = cur.nextSibling) ) {
			if ( cur === b ) {
				return -1;
			}
		}
	}

	return a ? 1 : -1;
}

/**
 * Returns a function to use in pseudos for input types
 * @param {String} type
 */
function createInputPseudo( type ) {
	return function( elem ) {
		var name = elem.nodeName.toLowerCase();
		return name === "input" && elem.type === type;
	};
}

/**
 * Returns a function to use in pseudos for buttons
 * @param {String} type
 */
function createButtonPseudo( type ) {
	return function( elem ) {
		var name = elem.nodeName.toLowerCase();
		return (name === "input" || name === "button") && elem.type === type;
	};
}

/**
 * Returns a function to use in pseudos for positionals
 * @param {Function} fn
 */
function createPositionalPseudo( fn ) {
	return markFunction(function( argument ) {
		argument = +argument;
		return markFunction(function( seed, matches ) {
			var j,
				matchIndexes = fn( [], seed.length, argument ),
				i = matchIndexes.length;

			// Match elements found at the specified indexes
			while ( i-- ) {
				if ( seed[ (j = matchIndexes[i]) ] ) {
					seed[j] = !(matches[j] = seed[j]);
				}
			}
		});
	});
}

/**
 * Detect xml
 * @param {Element|Object} elem An element or a document
 */
isXML = Sizzle.isXML = function( elem ) {
	// documentElement is verified for cases where it doesn't yet exist
	// (such as loading iframes in IE - #4833)
	var documentElement = elem && (elem.ownerDocument || elem).documentElement;
	return documentElement ? documentElement.nodeName !== "HTML" : false;
};

// Expose support vars for convenience
support = Sizzle.support = {};

/**
 * Sets document-related variables once based on the current document
 * @param {Element|Object} [doc] An element or document object to use to set the document
 * @returns {Object} Returns the current document
 */
setDocument = Sizzle.setDocument = function( node ) {
	var doc = node ? node.ownerDocument || node : preferredDoc,
		parent = doc.defaultView;

	// If no document and documentElement is available, return
	if ( doc === document || doc.nodeType !== 9 || !doc.documentElement ) {
		return document;
	}

	// Set our document
	document = doc;
	docElem = doc.documentElement;

	// Support tests
	documentIsHTML = !isXML( doc );

	// Support: IE>8
	// If iframe document is assigned to "document" variable and if iframe has been reloaded,
	// IE will throw "permission denied" error when accessing "document" variable, see jQuery #13936
	// IE6-8 do not support the defaultView property so parent will be undefined
	if ( parent && parent.attachEvent && parent !== parent.top ) {
		parent.attachEvent( "onbeforeunload", function() {
			setDocument();
		});
	}

	/* Attributes
	---------------------------------------------------------------------- */

	// Support: IE<8
	// Verify that getAttribute really returns attributes and not properties (excepting IE8 booleans)
	support.attributes = assert(function( div ) {
		div.className = "i";
		return !div.getAttribute("className");
	});

	/* getElement(s)By*
	---------------------------------------------------------------------- */

	// Check if getElementsByTagName("*") returns only elements
	support.getElementsByTagName = assert(function( div ) {
		div.appendChild( doc.createComment("") );
		return !div.getElementsByTagName("*").length;
	});

	// Check if getElementsByClassName can be trusted
	support.getElementsByClassName = assert(function( div ) {
		div.innerHTML = "<div class='a'></div><div class='a i'></div>";

		// Support: Safari<4
		// Catch class over-caching
		div.firstChild.className = "i";
		// Support: Opera<10
		// Catch gEBCN failure to find non-leading classes
		return div.getElementsByClassName("i").length === 2;
	});

	// Support: IE<10
	// Check if getElementById returns elements by name
	// The broken getElementById methods don't pick up programatically-set names,
	// so use a roundabout getElementsByName test
	support.getById = assert(function( div ) {
		docElem.appendChild( div ).id = expando;
		return !doc.getElementsByName || !doc.getElementsByName( expando ).length;
	});

	// ID find and filter
	if ( support.getById ) {
		Expr.find["ID"] = function( id, context ) {
			if ( typeof context.getElementById !== strundefined && documentIsHTML ) {
				var m = context.getElementById( id );
				// Check parentNode to catch when Blackberry 4.6 returns
				// nodes that are no longer in the document #6963
				return m && m.parentNode ? [m] : [];
			}
		};
		Expr.filter["ID"] = function( id ) {
			var attrId = id.replace( runescape, funescape );
			return function( elem ) {
				return elem.getAttribute("id") === attrId;
			};
		};
	} else {
		// Support: IE6/7
		// getElementById is not reliable as a find shortcut
		delete Expr.find["ID"];

		Expr.filter["ID"] =  function( id ) {
			var attrId = id.replace( runescape, funescape );
			return function( elem ) {
				var node = typeof elem.getAttributeNode !== strundefined && elem.getAttributeNode("id");
				return node && node.value === attrId;
			};
		};
	}

	// Tag
	Expr.find["TAG"] = support.getElementsByTagName ?
		function( tag, context ) {
			if ( typeof context.getElementsByTagName !== strundefined ) {
				return context.getElementsByTagName( tag );
			}
		} :
		function( tag, context ) {
			var elem,
				tmp = [],
				i = 0,
				results = context.getElementsByTagName( tag );

			// Filter out possible comments
			if ( tag === "*" ) {
				while ( (elem = results[i++]) ) {
					if ( elem.nodeType === 1 ) {
						tmp.push( elem );
					}
				}

				return tmp;
			}
			return results;
		};

	// Class
	Expr.find["CLASS"] = support.getElementsByClassName && function( className, context ) {
		if ( typeof context.getElementsByClassName !== strundefined && documentIsHTML ) {
			return context.getElementsByClassName( className );
		}
	};

	/* QSA/matchesSelector
	---------------------------------------------------------------------- */

	// QSA and matchesSelector support

	// matchesSelector(:active) reports false when true (IE9/Opera 11.5)
	rbuggyMatches = [];

	// qSa(:focus) reports false when true (Chrome 21)
	// We allow this because of a bug in IE8/9 that throws an error
	// whenever `document.activeElement` is accessed on an iframe
	// So, we allow :focus to pass through QSA all the time to avoid the IE error
	// See http://bugs.jquery.com/ticket/13378
	rbuggyQSA = [];

	if ( (support.qsa = rnative.test( doc.querySelectorAll )) ) {
		// Build QSA regex
		// Regex strategy adopted from Diego Perini
		assert(function( div ) {
			// Select is set to empty string on purpose
			// This is to test IE's treatment of not explicitly
			// setting a boolean content attribute,
			// since its presence should be enough
			// http://bugs.jquery.com/ticket/12359
			div.innerHTML = "<select><option selected=''></option></select>";

			// Support: IE8
			// Boolean attributes and "value" are not treated correctly
			if ( !div.querySelectorAll("[selected]").length ) {
				rbuggyQSA.push( "\\[" + whitespace + "*(?:value|" + booleans + ")" );
			}

			// Webkit/Opera - :checked should return selected option elements
			// http://www.w3.org/TR/2011/REC-css3-selectors-20110929/#checked
			// IE8 throws error here and will not see later tests
			if ( !div.querySelectorAll(":checked").length ) {
				rbuggyQSA.push(":checked");
			}
		});

		assert(function( div ) {

			// Support: Opera 10-12/IE8
			// ^= $= *= and empty values
			// Should not select anything
			// Support: Windows 8 Native Apps
			// The type attribute is restricted during .innerHTML assignment
			var input = doc.createElement("input");
			input.setAttribute( "type", "hidden" );
			div.appendChild( input ).setAttribute( "t", "" );

			if ( div.querySelectorAll("[t^='']").length ) {
				rbuggyQSA.push( "[*^$]=" + whitespace + "*(?:''|\"\")" );
			}

			// FF 3.5 - :enabled/:disabled and hidden elements (hidden elements are still enabled)
			// IE8 throws error here and will not see later tests
			if ( !div.querySelectorAll(":enabled").length ) {
				rbuggyQSA.push( ":enabled", ":disabled" );
			}

			// Opera 10-11 does not throw on post-comma invalid pseudos
			div.querySelectorAll("*,:x");
			rbuggyQSA.push(",.*:");
		});
	}

	if ( (support.matchesSelector = rnative.test( (matches = docElem.webkitMatchesSelector ||
		docElem.mozMatchesSelector ||
		docElem.oMatchesSelector ||
		docElem.msMatchesSelector) )) ) {

		assert(function( div ) {
			// Check to see if it's possible to do matchesSelector
			// on a disconnected node (IE 9)
			support.disconnectedMatch = matches.call( div, "div" );

			// This should fail with an exception
			// Gecko does not error, returns false instead
			matches.call( div, "[s!='']:x" );
			rbuggyMatches.push( "!=", pseudos );
		});
	}

	rbuggyQSA = rbuggyQSA.length && new RegExp( rbuggyQSA.join("|") );
	rbuggyMatches = rbuggyMatches.length && new RegExp( rbuggyMatches.join("|") );

	/* Contains
	---------------------------------------------------------------------- */

	// Element contains another
	// Purposefully does not implement inclusive descendent
	// As in, an element does not contain itself
	contains = rnative.test( docElem.contains ) || docElem.compareDocumentPosition ?
		function( a, b ) {
			var adown = a.nodeType === 9 ? a.documentElement : a,
				bup = b && b.parentNode;
			return a === bup || !!( bup && bup.nodeType === 1 && (
				adown.contains ?
					adown.contains( bup ) :
					a.compareDocumentPosition && a.compareDocumentPosition( bup ) & 16
			));
		} :
		function( a, b ) {
			if ( b ) {
				while ( (b = b.parentNode) ) {
					if ( b === a ) {
						return true;
					}
				}
			}
			return false;
		};

	/* Sorting
	---------------------------------------------------------------------- */

	// Document order sorting
	sortOrder = docElem.compareDocumentPosition ?
	function( a, b ) {

		// Flag for duplicate removal
		if ( a === b ) {
			hasDuplicate = true;
			return 0;
		}

		var compare = b.compareDocumentPosition && a.compareDocumentPosition && a.compareDocumentPosition( b );

		if ( compare ) {
			// Disconnected nodes
			if ( compare & 1 ||
				(!support.sortDetached && b.compareDocumentPosition( a ) === compare) ) {

				// Choose the first element that is related to our preferred document
				if ( a === doc || contains(preferredDoc, a) ) {
					return -1;
				}
				if ( b === doc || contains(preferredDoc, b) ) {
					return 1;
				}

				// Maintain original order
				return sortInput ?
					( indexOf.call( sortInput, a ) - indexOf.call( sortInput, b ) ) :
					0;
			}

			return compare & 4 ? -1 : 1;
		}

		// Not directly comparable, sort on existence of method
		return a.compareDocumentPosition ? -1 : 1;
	} :
	function( a, b ) {
		var cur,
			i = 0,
			aup = a.parentNode,
			bup = b.parentNode,
			ap = [ a ],
			bp = [ b ];

		// Exit early if the nodes are identical
		if ( a === b ) {
			hasDuplicate = true;
			return 0;

		// Parentless nodes are either documents or disconnected
		} else if ( !aup || !bup ) {
			return a === doc ? -1 :
				b === doc ? 1 :
				aup ? -1 :
				bup ? 1 :
				sortInput ?
				( indexOf.call( sortInput, a ) - indexOf.call( sortInput, b ) ) :
				0;

		// If the nodes are siblings, we can do a quick check
		} else if ( aup === bup ) {
			return siblingCheck( a, b );
		}

		// Otherwise we need full lists of their ancestors for comparison
		cur = a;
		while ( (cur = cur.parentNode) ) {
			ap.unshift( cur );
		}
		cur = b;
		while ( (cur = cur.parentNode) ) {
			bp.unshift( cur );
		}

		// Walk down the tree looking for a discrepancy
		while ( ap[i] === bp[i] ) {
			i++;
		}

		return i ?
			// Do a sibling check if the nodes have a common ancestor
			siblingCheck( ap[i], bp[i] ) :

			// Otherwise nodes in our document sort first
			ap[i] === preferredDoc ? -1 :
			bp[i] === preferredDoc ? 1 :
			0;
	};

	return doc;
};

Sizzle.matches = function( expr, elements ) {
	return Sizzle( expr, null, null, elements );
};

Sizzle.matchesSelector = function( elem, expr ) {
	// Set document vars if needed
	if ( ( elem.ownerDocument || elem ) !== document ) {
		setDocument( elem );
	}

	// Make sure that attribute selectors are quoted
	expr = expr.replace( rattributeQuotes, "='$1']" );

	if ( support.matchesSelector && documentIsHTML &&
		( !rbuggyMatches || !rbuggyMatches.test( expr ) ) &&
		( !rbuggyQSA     || !rbuggyQSA.test( expr ) ) ) {

		try {
			var ret = matches.call( elem, expr );

			// IE 9's matchesSelector returns false on disconnected nodes
			if ( ret || support.disconnectedMatch ||
					// As well, disconnected nodes are said to be in a document
					// fragment in IE 9
					elem.document && elem.document.nodeType !== 11 ) {
				return ret;
			}
		} catch(e) {}
	}

	return Sizzle( expr, document, null, [elem] ).length > 0;
};

Sizzle.contains = function( context, elem ) {
	// Set document vars if needed
	if ( ( context.ownerDocument || context ) !== document ) {
		setDocument( context );
	}
	return contains( context, elem );
};

Sizzle.attr = function( elem, name ) {
	// Set document vars if needed
	if ( ( elem.ownerDocument || elem ) !== document ) {
		setDocument( elem );
	}

	var fn = Expr.attrHandle[ name.toLowerCase() ],
		// Don't get fooled by Object.prototype properties (jQuery #13807)
		val = fn && hasOwn.call( Expr.attrHandle, name.toLowerCase() ) ?
			fn( elem, name, !documentIsHTML ) :
			undefined;

	return val === undefined ?
		support.attributes || !documentIsHTML ?
			elem.getAttribute( name ) :
			(val = elem.getAttributeNode(name)) && val.specified ?
				val.value :
				null :
		val;
};

Sizzle.error = function( msg ) {
	throw new Error( "Syntax error, unrecognized expression: " + msg );
};

/**
 * Document sorting and removing duplicates
 * @param {ArrayLike} results
 */
Sizzle.uniqueSort = function( results ) {
	var elem,
		duplicates = [],
		j = 0,
		i = 0;

	// Unless we *know* we can detect duplicates, assume their presence
	hasDuplicate = !support.detectDuplicates;
	sortInput = !support.sortStable && results.slice( 0 );
	results.sort( sortOrder );

	if ( hasDuplicate ) {
		while ( (elem = results[i++]) ) {
			if ( elem === results[ i ] ) {
				j = duplicates.push( i );
			}
		}
		while ( j-- ) {
			results.splice( duplicates[ j ], 1 );
		}
	}

	return results;
};

/**
 * Utility function for retrieving the text value of an array of DOM nodes
 * @param {Array|Element} elem
 */
getText = Sizzle.getText = function( elem ) {
	var node,
		ret = "",
		i = 0,
		nodeType = elem.nodeType;

	if ( !nodeType ) {
		// If no nodeType, this is expected to be an array
		for ( ; (node = elem[i]); i++ ) {
			// Do not traverse comment nodes
			ret += getText( node );
		}
	} else if ( nodeType === 1 || nodeType === 9 || nodeType === 11 ) {
		// Use textContent for elements
		// innerText usage removed for consistency of new lines (see #11153)
		if ( typeof elem.textContent === "string" ) {
			return elem.textContent;
		} else {
			// Traverse its children
			for ( elem = elem.firstChild; elem; elem = elem.nextSibling ) {
				ret += getText( elem );
			}
		}
	} else if ( nodeType === 3 || nodeType === 4 ) {
		return elem.nodeValue;
	}
	// Do not include comment or processing instruction nodes

	return ret;
};

Expr = Sizzle.selectors = {

	// Can be adjusted by the user
	cacheLength: 50,

	createPseudo: markFunction,

	match: matchExpr,

	attrHandle: {},

	find: {},

	relative: {
		">": { dir: "parentNode", first: true },
		" ": { dir: "parentNode" },
		"+": { dir: "previousSibling", first: true },
		"~": { dir: "previousSibling" }
	},

	preFilter: {
		"ATTR": function( match ) {
			match[1] = match[1].replace( runescape, funescape );

			// Move the given value to match[3] whether quoted or unquoted
			match[3] = ( match[4] || match[5] || "" ).replace( runescape, funescape );

			if ( match[2] === "~=" ) {
				match[3] = " " + match[3] + " ";
			}

			return match.slice( 0, 4 );
		},

		"CHILD": function( match ) {
			/* matches from matchExpr["CHILD"]
				1 type (only|nth|...)
				2 what (child|of-type)
				3 argument (even|odd|\d*|\d*n([+-]\d+)?|...)
				4 xn-component of xn+y argument ([+-]?\d*n|)
				5 sign of xn-component
				6 x of xn-component
				7 sign of y-component
				8 y of y-component
			*/
			match[1] = match[1].toLowerCase();

			if ( match[1].slice( 0, 3 ) === "nth" ) {
				// nth-* requires argument
				if ( !match[3] ) {
					Sizzle.error( match[0] );
				}

				// numeric x and y parameters for Expr.filter.CHILD
				// remember that false/true cast respectively to 0/1
				match[4] = +( match[4] ? match[5] + (match[6] || 1) : 2 * ( match[3] === "even" || match[3] === "odd" ) );
				match[5] = +( ( match[7] + match[8] ) || match[3] === "odd" );

			// other types prohibit arguments
			} else if ( match[3] ) {
				Sizzle.error( match[0] );
			}

			return match;
		},

		"PSEUDO": function( match ) {
			var excess,
				unquoted = !match[5] && match[2];

			if ( matchExpr["CHILD"].test( match[0] ) ) {
				return null;
			}

			// Accept quoted arguments as-is
			if ( match[3] && match[4] !== undefined ) {
				match[2] = match[4];

			// Strip excess characters from unquoted arguments
			} else if ( unquoted && rpseudo.test( unquoted ) &&
				// Get excess from tokenize (recursively)
				(excess = tokenize( unquoted, true )) &&
				// advance to the next closing parenthesis
				(excess = unquoted.indexOf( ")", unquoted.length - excess ) - unquoted.length) ) {

				// excess is a negative index
				match[0] = match[0].slice( 0, excess );
				match[2] = unquoted.slice( 0, excess );
			}

			// Return only captures needed by the pseudo filter method (type and argument)
			return match.slice( 0, 3 );
		}
	},

	filter: {

		"TAG": function( nodeNameSelector ) {
			var nodeName = nodeNameSelector.replace( runescape, funescape ).toLowerCase();
			return nodeNameSelector === "*" ?
				function() { return true; } :
				function( elem ) {
					return elem.nodeName && elem.nodeName.toLowerCase() === nodeName;
				};
		},

		"CLASS": function( className ) {
			var pattern = classCache[ className + " " ];

			return pattern ||
				(pattern = new RegExp( "(^|" + whitespace + ")" + className + "(" + whitespace + "|$)" )) &&
				classCache( className, function( elem ) {
					return pattern.test( typeof elem.className === "string" && elem.className || typeof elem.getAttribute !== strundefined && elem.getAttribute("class") || "" );
				});
		},

		"ATTR": function( name, operator, check ) {
			return function( elem ) {
				var result = Sizzle.attr( elem, name );

				if ( result == null ) {
					return operator === "!=";
				}
				if ( !operator ) {
					return true;
				}

				result += "";

				return operator === "=" ? result === check :
					operator === "!=" ? result !== check :
					operator === "^=" ? check && result.indexOf( check ) === 0 :
					operator === "*=" ? check && result.indexOf( check ) > -1 :
					operator === "$=" ? check && result.slice( -check.length ) === check :
					operator === "~=" ? ( " " + result + " " ).indexOf( check ) > -1 :
					operator === "|=" ? result === check || result.slice( 0, check.length + 1 ) === check + "-" :
					false;
			};
		},

		"CHILD": function( type, what, argument, first, last ) {
			var simple = type.slice( 0, 3 ) !== "nth",
				forward = type.slice( -4 ) !== "last",
				ofType = what === "of-type";

			return first === 1 && last === 0 ?

				// Shortcut for :nth-*(n)
				function( elem ) {
					return !!elem.parentNode;
				} :

				function( elem, context, xml ) {
					var cache, outerCache, node, diff, nodeIndex, start,
						dir = simple !== forward ? "nextSibling" : "previousSibling",
						parent = elem.parentNode,
						name = ofType && elem.nodeName.toLowerCase(),
						useCache = !xml && !ofType;

					if ( parent ) {

						// :(first|last|only)-(child|of-type)
						if ( simple ) {
							while ( dir ) {
								node = elem;
								while ( (node = node[ dir ]) ) {
									if ( ofType ? node.nodeName.toLowerCase() === name : node.nodeType === 1 ) {
										return false;
									}
								}
								// Reverse direction for :only-* (if we haven't yet done so)
								start = dir = type === "only" && !start && "nextSibling";
							}
							return true;
						}

						start = [ forward ? parent.firstChild : parent.lastChild ];

						// non-xml :nth-child(...) stores cache data on `parent`
						if ( forward && useCache ) {
							// Seek `elem` from a previously-cached index
							outerCache = parent[ expando ] || (parent[ expando ] = {});
							cache = outerCache[ type ] || [];
							nodeIndex = cache[0] === dirruns && cache[1];
							diff = cache[0] === dirruns && cache[2];
							node = nodeIndex && parent.childNodes[ nodeIndex ];

							while ( (node = ++nodeIndex && node && node[ dir ] ||

								// Fallback to seeking `elem` from the start
								(diff = nodeIndex = 0) || start.pop()) ) {

								// When found, cache indexes on `parent` and break
								if ( node.nodeType === 1 && ++diff && node === elem ) {
									outerCache[ type ] = [ dirruns, nodeIndex, diff ];
									break;
								}
							}

						// Use previously-cached element index if available
						} else if ( useCache && (cache = (elem[ expando ] || (elem[ expando ] = {}))[ type ]) && cache[0] === dirruns ) {
							diff = cache[1];

						// xml :nth-child(...) or :nth-last-child(...) or :nth(-last)?-of-type(...)
						} else {
							// Use the same loop as above to seek `elem` from the start
							while ( (node = ++nodeIndex && node && node[ dir ] ||
								(diff = nodeIndex = 0) || start.pop()) ) {

								if ( ( ofType ? node.nodeName.toLowerCase() === name : node.nodeType === 1 ) && ++diff ) {
									// Cache the index of each encountered element
									if ( useCache ) {
										(node[ expando ] || (node[ expando ] = {}))[ type ] = [ dirruns, diff ];
									}

									if ( node === elem ) {
										break;
									}
								}
							}
						}

						// Incorporate the offset, then check against cycle size
						diff -= last;
						return diff === first || ( diff % first === 0 && diff / first >= 0 );
					}
				};
		},

		"PSEUDO": function( pseudo, argument ) {
			// pseudo-class names are case-insensitive
			// http://www.w3.org/TR/selectors/#pseudo-classes
			// Prioritize by case sensitivity in case custom pseudos are added with uppercase letters
			// Remember that setFilters inherits from pseudos
			var args,
				fn = Expr.pseudos[ pseudo ] || Expr.setFilters[ pseudo.toLowerCase() ] ||
					Sizzle.error( "unsupported pseudo: " + pseudo );

			// The user may use createPseudo to indicate that
			// arguments are needed to create the filter function
			// just as Sizzle does
			if ( fn[ expando ] ) {
				return fn( argument );
			}

			// But maintain support for old signatures
			if ( fn.length > 1 ) {
				args = [ pseudo, pseudo, "", argument ];
				return Expr.setFilters.hasOwnProperty( pseudo.toLowerCase() ) ?
					markFunction(function( seed, matches ) {
						var idx,
							matched = fn( seed, argument ),
							i = matched.length;
						while ( i-- ) {
							idx = indexOf.call( seed, matched[i] );
							seed[ idx ] = !( matches[ idx ] = matched[i] );
						}
					}) :
					function( elem ) {
						return fn( elem, 0, args );
					};
			}

			return fn;
		}
	},

	pseudos: {
		// Potentially complex pseudos
		"not": markFunction(function( selector ) {
			// Trim the selector passed to compile
			// to avoid treating leading and trailing
			// spaces as combinators
			var input = [],
				results = [],
				matcher = compile( selector.replace( rtrim, "$1" ) );

			return matcher[ expando ] ?
				markFunction(function( seed, matches, context, xml ) {
					var elem,
						unmatched = matcher( seed, null, xml, [] ),
						i = seed.length;

					// Match elements unmatched by `matcher`
					while ( i-- ) {
						if ( (elem = unmatched[i]) ) {
							seed[i] = !(matches[i] = elem);
						}
					}
				}) :
				function( elem, context, xml ) {
					input[0] = elem;
					matcher( input, null, xml, results );
					return !results.pop();
				};
		}),

		"has": markFunction(function( selector ) {
			return function( elem ) {
				return Sizzle( selector, elem ).length > 0;
			};
		}),

		"contains": markFunction(function( text ) {
			return function( elem ) {
				return ( elem.textContent || elem.innerText || getText( elem ) ).indexOf( text ) > -1;
			};
		}),

		// "Whether an element is represented by a :lang() selector
		// is based solely on the element's language value
		// being equal to the identifier C,
		// or beginning with the identifier C immediately followed by "-".
		// The matching of C against the element's language value is performed case-insensitively.
		// The identifier C does not have to be a valid language name."
		// http://www.w3.org/TR/selectors/#lang-pseudo
		"lang": markFunction( function( lang ) {
			// lang value must be a valid identifier
			if ( !ridentifier.test(lang || "") ) {
				Sizzle.error( "unsupported lang: " + lang );
			}
			lang = lang.replace( runescape, funescape ).toLowerCase();
			return function( elem ) {
				var elemLang;
				do {
					if ( (elemLang = documentIsHTML ?
						elem.lang :
						elem.getAttribute("xml:lang") || elem.getAttribute("lang")) ) {

						elemLang = elemLang.toLowerCase();
						return elemLang === lang || elemLang.indexOf( lang + "-" ) === 0;
					}
				} while ( (elem = elem.parentNode) && elem.nodeType === 1 );
				return false;
			};
		}),

		// Miscellaneous
		"target": function( elem ) {
			var hash = window.location && window.location.hash;
			return hash && hash.slice( 1 ) === elem.id;
		},

		"root": function( elem ) {
			return elem === docElem;
		},

		"focus": function( elem ) {
			return elem === document.activeElement && (!document.hasFocus || document.hasFocus()) && !!(elem.type || elem.href || ~elem.tabIndex);
		},

		// Boolean properties
		"enabled": function( elem ) {
			return elem.disabled === false;
		},

		"disabled": function( elem ) {
			return elem.disabled === true;
		},

		"checked": function( elem ) {
			// In CSS3, :checked should return both checked and selected elements
			// http://www.w3.org/TR/2011/REC-css3-selectors-20110929/#checked
			var nodeName = elem.nodeName.toLowerCase();
			return (nodeName === "input" && !!elem.checked) || (nodeName === "option" && !!elem.selected);
		},

		"selected": function( elem ) {
			// Accessing this property makes selected-by-default
			// options in Safari work properly
			if ( elem.parentNode ) {
				elem.parentNode.selectedIndex;
			}

			return elem.selected === true;
		},

		// Contents
		"empty": function( elem ) {
			// http://www.w3.org/TR/selectors/#empty-pseudo
			// :empty is only affected by element nodes and content nodes(including text(3), cdata(4)),
			//   not comment, processing instructions, or others
			// Thanks to Diego Perini for the nodeName shortcut
			//   Greater than "@" means alpha characters (specifically not starting with "#" or "?")
			for ( elem = elem.firstChild; elem; elem = elem.nextSibling ) {
				if ( elem.nodeName > "@" || elem.nodeType === 3 || elem.nodeType === 4 ) {
					return false;
				}
			}
			return true;
		},

		"parent": function( elem ) {
			return !Expr.pseudos["empty"]( elem );
		},

		// Element/input types
		"header": function( elem ) {
			return rheader.test( elem.nodeName );
		},

		"input": function( elem ) {
			return rinputs.test( elem.nodeName );
		},

		"button": function( elem ) {
			var name = elem.nodeName.toLowerCase();
			return name === "input" && elem.type === "button" || name === "button";
		},

		"text": function( elem ) {
			var attr;
			// IE6 and 7 will map elem.type to 'text' for new HTML5 types (search, etc)
			// use getAttribute instead to test this case
			return elem.nodeName.toLowerCase() === "input" &&
				elem.type === "text" &&
				( (attr = elem.getAttribute("type")) == null || attr.toLowerCase() === elem.type );
		},

		// Position-in-collection
		"first": createPositionalPseudo(function() {
			return [ 0 ];
		}),

		"last": createPositionalPseudo(function( matchIndexes, length ) {
			return [ length - 1 ];
		}),

		"eq": createPositionalPseudo(function( matchIndexes, length, argument ) {
			return [ argument < 0 ? argument + length : argument ];
		}),

		"even": createPositionalPseudo(function( matchIndexes, length ) {
			var i = 0;
			for ( ; i < length; i += 2 ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		}),

		"odd": createPositionalPseudo(function( matchIndexes, length ) {
			var i = 1;
			for ( ; i < length; i += 2 ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		}),

		"lt": createPositionalPseudo(function( matchIndexes, length, argument ) {
			var i = argument < 0 ? argument + length : argument;
			for ( ; --i >= 0; ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		}),

		"gt": createPositionalPseudo(function( matchIndexes, length, argument ) {
			var i = argument < 0 ? argument + length : argument;
			for ( ; ++i < length; ) {
				matchIndexes.push( i );
			}
			return matchIndexes;
		})
	}
};

Expr.pseudos["nth"] = Expr.pseudos["eq"];

// Add button/input type pseudos
for ( i in { radio: true, checkbox: true, file: true, password: true, image: true } ) {
	Expr.pseudos[ i ] = createInputPseudo( i );
}
for ( i in { submit: true, reset: true } ) {
	Expr.pseudos[ i ] = createButtonPseudo( i );
}

// Easy API for creating new setFilters
function setFilters() {}
setFilters.prototype = Expr.filters = Expr.pseudos;
Expr.setFilters = new setFilters();

function tokenize( selector, parseOnly ) {
	var matched, match, tokens, type,
		soFar, groups, preFilters,
		cached = tokenCache[ selector + " " ];

	if ( cached ) {
		return parseOnly ? 0 : cached.slice( 0 );
	}

	soFar = selector;
	groups = [];
	preFilters = Expr.preFilter;

	while ( soFar ) {

		// Comma and first run
		if ( !matched || (match = rcomma.exec( soFar )) ) {
			if ( match ) {
				// Don't consume trailing commas as valid
				soFar = soFar.slice( match[0].length ) || soFar;
			}
			groups.push( tokens = [] );
		}

		matched = false;

		// Combinators
		if ( (match = rcombinators.exec( soFar )) ) {
			matched = match.shift();
			tokens.push({
				value: matched,
				// Cast descendant combinators to space
				type: match[0].replace( rtrim, " " )
			});
			soFar = soFar.slice( matched.length );
		}

		// Filters
		for ( type in Expr.filter ) {
			if ( (match = matchExpr[ type ].exec( soFar )) && (!preFilters[ type ] ||
				(match = preFilters[ type ]( match ))) ) {
				matched = match.shift();
				tokens.push({
					value: matched,
					type: type,
					matches: match
				});
				soFar = soFar.slice( matched.length );
			}
		}

		if ( !matched ) {
			break;
		}
	}

	// Return the length of the invalid excess
	// if we're just parsing
	// Otherwise, throw an error or return tokens
	return parseOnly ?
		soFar.length :
		soFar ?
			Sizzle.error( selector ) :
			// Cache the tokens
			tokenCache( selector, groups ).slice( 0 );
}

function toSelector( tokens ) {
	var i = 0,
		len = tokens.length,
		selector = "";
	for ( ; i < len; i++ ) {
		selector += tokens[i].value;
	}
	return selector;
}

function addCombinator( matcher, combinator, base ) {
	var dir = combinator.dir,
		checkNonElements = base && dir === "parentNode",
		doneName = done++;

	return combinator.first ?
		// Check against closest ancestor/preceding element
		function( elem, context, xml ) {
			while ( (elem = elem[ dir ]) ) {
				if ( elem.nodeType === 1 || checkNonElements ) {
					return matcher( elem, context, xml );
				}
			}
		} :

		// Check against all ancestor/preceding elements
		function( elem, context, xml ) {
			var data, cache, outerCache,
				dirkey = dirruns + " " + doneName;

			// We can't set arbitrary data on XML nodes, so they don't benefit from dir caching
			if ( xml ) {
				while ( (elem = elem[ dir ]) ) {
					if ( elem.nodeType === 1 || checkNonElements ) {
						if ( matcher( elem, context, xml ) ) {
							return true;
						}
					}
				}
			} else {
				while ( (elem = elem[ dir ]) ) {
					if ( elem.nodeType === 1 || checkNonElements ) {
						outerCache = elem[ expando ] || (elem[ expando ] = {});
						if ( (cache = outerCache[ dir ]) && cache[0] === dirkey ) {
							if ( (data = cache[1]) === true || data === cachedruns ) {
								return data === true;
							}
						} else {
							cache = outerCache[ dir ] = [ dirkey ];
							cache[1] = matcher( elem, context, xml ) || cachedruns;
							if ( cache[1] === true ) {
								return true;
							}
						}
					}
				}
			}
		};
}

function elementMatcher( matchers ) {
	return matchers.length > 1 ?
		function( elem, context, xml ) {
			var i = matchers.length;
			while ( i-- ) {
				if ( !matchers[i]( elem, context, xml ) ) {
					return false;
				}
			}
			return true;
		} :
		matchers[0];
}

function condense( unmatched, map, filter, context, xml ) {
	var elem,
		newUnmatched = [],
		i = 0,
		len = unmatched.length,
		mapped = map != null;

	for ( ; i < len; i++ ) {
		if ( (elem = unmatched[i]) ) {
			if ( !filter || filter( elem, context, xml ) ) {
				newUnmatched.push( elem );
				if ( mapped ) {
					map.push( i );
				}
			}
		}
	}

	return newUnmatched;
}

function setMatcher( preFilter, selector, matcher, postFilter, postFinder, postSelector ) {
	if ( postFilter && !postFilter[ expando ] ) {
		postFilter = setMatcher( postFilter );
	}
	if ( postFinder && !postFinder[ expando ] ) {
		postFinder = setMatcher( postFinder, postSelector );
	}
	return markFunction(function( seed, results, context, xml ) {
		var temp, i, elem,
			preMap = [],
			postMap = [],
			preexisting = results.length,

			// Get initial elements from seed or context
			elems = seed || multipleContexts( selector || "*", context.nodeType ? [ context ] : context, [] ),

			// Prefilter to get matcher input, preserving a map for seed-results synchronization
			matcherIn = preFilter && ( seed || !selector ) ?
				condense( elems, preMap, preFilter, context, xml ) :
				elems,

			matcherOut = matcher ?
				// If we have a postFinder, or filtered seed, or non-seed postFilter or preexisting results,
				postFinder || ( seed ? preFilter : preexisting || postFilter ) ?

					// ...intermediate processing is necessary
					[] :

					// ...otherwise use results directly
					results :
				matcherIn;

		// Find primary matches
		if ( matcher ) {
			matcher( matcherIn, matcherOut, context, xml );
		}

		// Apply postFilter
		if ( postFilter ) {
			temp = condense( matcherOut, postMap );
			postFilter( temp, [], context, xml );

			// Un-match failing elements by moving them back to matcherIn
			i = temp.length;
			while ( i-- ) {
				if ( (elem = temp[i]) ) {
					matcherOut[ postMap[i] ] = !(matcherIn[ postMap[i] ] = elem);
				}
			}
		}

		if ( seed ) {
			if ( postFinder || preFilter ) {
				if ( postFinder ) {
					// Get the final matcherOut by condensing this intermediate into postFinder contexts
					temp = [];
					i = matcherOut.length;
					while ( i-- ) {
						if ( (elem = matcherOut[i]) ) {
							// Restore matcherIn since elem is not yet a final match
							temp.push( (matcherIn[i] = elem) );
						}
					}
					postFinder( null, (matcherOut = []), temp, xml );
				}

				// Move matched elements from seed to results to keep them synchronized
				i = matcherOut.length;
				while ( i-- ) {
					if ( (elem = matcherOut[i]) &&
						(temp = postFinder ? indexOf.call( seed, elem ) : preMap[i]) > -1 ) {

						seed[temp] = !(results[temp] = elem);
					}
				}
			}

		// Add elements to results, through postFinder if defined
		} else {
			matcherOut = condense(
				matcherOut === results ?
					matcherOut.splice( preexisting, matcherOut.length ) :
					matcherOut
			);
			if ( postFinder ) {
				postFinder( null, results, matcherOut, xml );
			} else {
				push.apply( results, matcherOut );
			}
		}
	});
}

function matcherFromTokens( tokens ) {
	var checkContext, matcher, j,
		len = tokens.length,
		leadingRelative = Expr.relative[ tokens[0].type ],
		implicitRelative = leadingRelative || Expr.relative[" "],
		i = leadingRelative ? 1 : 0,

		// The foundational matcher ensures that elements are reachable from top-level context(s)
		matchContext = addCombinator( function( elem ) {
			return elem === checkContext;
		}, implicitRelative, true ),
		matchAnyContext = addCombinator( function( elem ) {
			return indexOf.call( checkContext, elem ) > -1;
		}, implicitRelative, true ),
		matchers = [ function( elem, context, xml ) {
			return ( !leadingRelative && ( xml || context !== outermostContext ) ) || (
				(checkContext = context).nodeType ?
					matchContext( elem, context, xml ) :
					matchAnyContext( elem, context, xml ) );
		} ];

	for ( ; i < len; i++ ) {
		if ( (matcher = Expr.relative[ tokens[i].type ]) ) {
			matchers = [ addCombinator(elementMatcher( matchers ), matcher) ];
		} else {
			matcher = Expr.filter[ tokens[i].type ].apply( null, tokens[i].matches );

			// Return special upon seeing a positional matcher
			if ( matcher[ expando ] ) {
				// Find the next relative operator (if any) for proper handling
				j = ++i;
				for ( ; j < len; j++ ) {
					if ( Expr.relative[ tokens[j].type ] ) {
						break;
					}
				}
				return setMatcher(
					i > 1 && elementMatcher( matchers ),
					i > 1 && toSelector(
						// If the preceding token was a descendant combinator, insert an implicit any-element `*`
						tokens.slice( 0, i - 1 ).concat({ value: tokens[ i - 2 ].type === " " ? "*" : "" })
					).replace( rtrim, "$1" ),
					matcher,
					i < j && matcherFromTokens( tokens.slice( i, j ) ),
					j < len && matcherFromTokens( (tokens = tokens.slice( j )) ),
					j < len && toSelector( tokens )
				);
			}
			matchers.push( matcher );
		}
	}

	return elementMatcher( matchers );
}

function matcherFromGroupMatchers( elementMatchers, setMatchers ) {
	// A counter to specify which element is currently being matched
	var matcherCachedRuns = 0,
		bySet = setMatchers.length > 0,
		byElement = elementMatchers.length > 0,
		superMatcher = function( seed, context, xml, results, expandContext ) {
			var elem, j, matcher,
				setMatched = [],
				matchedCount = 0,
				i = "0",
				unmatched = seed && [],
				outermost = expandContext != null,
				contextBackup = outermostContext,
				// We must always have either seed elements or context
				elems = seed || byElement && Expr.find["TAG"]( "*", expandContext && context.parentNode || context ),
				// Use integer dirruns iff this is the outermost matcher
				dirrunsUnique = (dirruns += contextBackup == null ? 1 : Math.random() || 0.1);

			if ( outermost ) {
				outermostContext = context !== document && context;
				cachedruns = matcherCachedRuns;
			}

			// Add elements passing elementMatchers directly to results
			// Keep `i` a string if there are no elements so `matchedCount` will be "00" below
			for ( ; (elem = elems[i]) != null; i++ ) {
				if ( byElement && elem ) {
					j = 0;
					while ( (matcher = elementMatchers[j++]) ) {
						if ( matcher( elem, context, xml ) ) {
							results.push( elem );
							break;
						}
					}
					if ( outermost ) {
						dirruns = dirrunsUnique;
						cachedruns = ++matcherCachedRuns;
					}
				}

				// Track unmatched elements for set filters
				if ( bySet ) {
					// They will have gone through all possible matchers
					if ( (elem = !matcher && elem) ) {
						matchedCount--;
					}

					// Lengthen the array for every element, matched or not
					if ( seed ) {
						unmatched.push( elem );
					}
				}
			}

			// Apply set filters to unmatched elements
			matchedCount += i;
			if ( bySet && i !== matchedCount ) {
				j = 0;
				while ( (matcher = setMatchers[j++]) ) {
					matcher( unmatched, setMatched, context, xml );
				}

				if ( seed ) {
					// Reintegrate element matches to eliminate the need for sorting
					if ( matchedCount > 0 ) {
						while ( i-- ) {
							if ( !(unmatched[i] || setMatched[i]) ) {
								setMatched[i] = pop.call( results );
							}
						}
					}

					// Discard index placeholder values to get only actual matches
					setMatched = condense( setMatched );
				}

				// Add matches to results
				push.apply( results, setMatched );

				// Seedless set matches succeeding multiple successful matchers stipulate sorting
				if ( outermost && !seed && setMatched.length > 0 &&
					( matchedCount + setMatchers.length ) > 1 ) {

					Sizzle.uniqueSort( results );
				}
			}

			// Override manipulation of globals by nested matchers
			if ( outermost ) {
				dirruns = dirrunsUnique;
				outermostContext = contextBackup;
			}

			return unmatched;
		};

	return bySet ?
		markFunction( superMatcher ) :
		superMatcher;
}

compile = Sizzle.compile = function( selector, group /* Internal Use Only */ ) {
	var i,
		setMatchers = [],
		elementMatchers = [],
		cached = compilerCache[ selector + " " ];

	if ( !cached ) {
		// Generate a function of recursive functions that can be used to check each element
		if ( !group ) {
			group = tokenize( selector );
		}
		i = group.length;
		while ( i-- ) {
			cached = matcherFromTokens( group[i] );
			if ( cached[ expando ] ) {
				setMatchers.push( cached );
			} else {
				elementMatchers.push( cached );
			}
		}

		// Cache the compiled function
		cached = compilerCache( selector, matcherFromGroupMatchers( elementMatchers, setMatchers ) );
	}
	return cached;
};

function multipleContexts( selector, contexts, results ) {
	var i = 0,
		len = contexts.length;
	for ( ; i < len; i++ ) {
		Sizzle( selector, contexts[i], results );
	}
	return results;
}

function select( selector, context, results, seed ) {
	var i, tokens, token, type, find,
		match = tokenize( selector );

	if ( !seed ) {
		// Try to minimize operations if there is only one group
		if ( match.length === 1 ) {

			// Take a shortcut and set the context if the root selector is an ID
			tokens = match[0] = match[0].slice( 0 );
			if ( tokens.length > 2 && (token = tokens[0]).type === "ID" &&
					support.getById && context.nodeType === 9 && documentIsHTML &&
					Expr.relative[ tokens[1].type ] ) {

				context = ( Expr.find["ID"]( token.matches[0].replace(runescape, funescape), context ) || [] )[0];
				if ( !context ) {
					return results;
				}
				selector = selector.slice( tokens.shift().value.length );
			}

			// Fetch a seed set for right-to-left matching
			i = matchExpr["needsContext"].test( selector ) ? 0 : tokens.length;
			while ( i-- ) {
				token = tokens[i];

				// Abort if we hit a combinator
				if ( Expr.relative[ (type = token.type) ] ) {
					break;
				}
				if ( (find = Expr.find[ type ]) ) {
					// Search, expanding context for leading sibling combinators
					if ( (seed = find(
						token.matches[0].replace( runescape, funescape ),
						rsibling.test( tokens[0].type ) && context.parentNode || context
					)) ) {

						// If seed is empty or no tokens remain, we can return early
						tokens.splice( i, 1 );
						selector = seed.length && toSelector( tokens );
						if ( !selector ) {
							push.apply( results, seed );
							return results;
						}

						break;
					}
				}
			}
		}
	}

	// Compile and execute a filtering function
	// Provide `match` to avoid retokenization if we modified the selector above
	compile( selector, match )(
		seed,
		context,
		!documentIsHTML,
		results,
		rsibling.test( selector )
	);
	return results;
}

// One-time assignments

// Sort stability
support.sortStable = expando.split("").sort( sortOrder ).join("") === expando;

// Support: Chrome<14
// Always assume duplicates if they aren't passed to the comparison function
support.detectDuplicates = hasDuplicate;

// Initialize against the default document
setDocument();

// Support: Webkit<537.32 - Safari 6.0.3/Chrome 25 (fixed in Chrome 27)
// Detached nodes confoundingly follow *each other*
support.sortDetached = assert(function( div1 ) {
	// Should return 1, but returns 4 (following)
	return div1.compareDocumentPosition( document.createElement("div") ) & 1;
});

// Support: IE<8
// Prevent attribute/property "interpolation"
// http://msdn.microsoft.com/en-us/library/ms536429%28VS.85%29.aspx
if ( !assert(function( div ) {
	div.innerHTML = "<a href='#'></a>";
	return div.firstChild.getAttribute("href") === "#" ;
}) ) {
	addHandle( "type|href|height|width", function( elem, name, isXML ) {
		if ( !isXML ) {
			return elem.getAttribute( name, name.toLowerCase() === "type" ? 1 : 2 );
		}
	});
}

// Support: IE<9
// Use defaultValue in place of getAttribute("value")
if ( !support.attributes || !assert(function( div ) {
	div.innerHTML = "<input/>";
	div.firstChild.setAttribute( "value", "" );
	return div.firstChild.getAttribute( "value" ) === "";
}) ) {
	addHandle( "value", function( elem, name, isXML ) {
		if ( !isXML && elem.nodeName.toLowerCase() === "input" ) {
			return elem.defaultValue;
		}
	});
}

// Support: IE<9
// Use getAttributeNode to fetch booleans when getAttribute lies
if ( !assert(function( div ) {
	return div.getAttribute("disabled") == null;
}) ) {
	addHandle( booleans, function( elem, name, isXML ) {
		var val;
		if ( !isXML ) {
			return (val = elem.getAttributeNode( name )) && val.specified ?
				val.value :
				elem[ name ] === true ? name.toLowerCase() : null;
		}
	});
}

jQuery.find = Sizzle;
jQuery.expr = Sizzle.selectors;
jQuery.expr[":"] = jQuery.expr.pseudos;
jQuery.unique = Sizzle.uniqueSort;
jQuery.text = Sizzle.getText;
jQuery.isXMLDoc = Sizzle.isXML;
jQuery.contains = Sizzle.contains;


})( window );
// String to Object options format cache
var optionsCache = {};

// Convert String-formatted options into Object-formatted ones and store in cache
function createOptions( options ) {
	var object = optionsCache[ options ] = {};
	jQuery.each( options.match( core_rnotwhite ) || [], function( _, flag ) {
		object[ flag ] = true;
	});
	return object;
}

/*
 * Create a callback list using the following parameters:
 *
 *	options: an optional list of space-separated options that will change how
 *			the callback list behaves or a more traditional option object
 *
 * By default a callback list will act like an event callback list and can be
 * "fired" multiple times.
 *
 * Possible options:
 *
 *	once:			will ensure the callback list can only be fired once (like a Deferred)
 *
 *	memory:			will keep track of previous values and will call any callback added
 *					after the list has been fired right away with the latest "memorized"
 *					values (like a Deferred)
 *
 *	unique:			will ensure a callback can only be added once (no duplicate in the list)
 *
 *	stopOnFalse:	interrupt callings when a callback returns false
 *
 */
jQuery.Callbacks = function( options ) {

	// Convert options from String-formatted to Object-formatted if needed
	// (we check in cache first)
	options = typeof options === "string" ?
		( optionsCache[ options ] || createOptions( options ) ) :
		jQuery.extend( {}, options );

	var // Last fire value (for non-forgettable lists)
		memory,
		// Flag to know if list was already fired
		fired,
		// Flag to know if list is currently firing
		firing,
		// First callback to fire (used internally by add and fireWith)
		firingStart,
		// End of the loop when firing
		firingLength,
		// Index of currently firing callback (modified by remove if needed)
		firingIndex,
		// Actual callback list
		list = [],
		// Stack of fire calls for repeatable lists
		stack = !options.once && [],
		// Fire callbacks
		fire = function( data ) {
			memory = options.memory && data;
			fired = true;
			firingIndex = firingStart || 0;
			firingStart = 0;
			firingLength = list.length;
			firing = true;
			for ( ; list && firingIndex < firingLength; firingIndex++ ) {
				if ( list[ firingIndex ].apply( data[ 0 ], data[ 1 ] ) === false && options.stopOnFalse ) {
					memory = false; // To prevent further calls using add
					break;
				}
			}
			firing = false;
			if ( list ) {
				if ( stack ) {
					if ( stack.length ) {
						fire( stack.shift() );
					}
				} else if ( memory ) {
					list = [];
				} else {
					self.disable();
				}
			}
		},
		// Actual Callbacks object
		self = {
			// Add a callback or a collection of callbacks to the list
			add: function() {
				if ( list ) {
					// First, we save the current length
					var start = list.length;
					(function add( args ) {
						jQuery.each( args, function( _, arg ) {
							var type = jQuery.type( arg );
							if ( type === "function" ) {
								if ( !options.unique || !self.has( arg ) ) {
									list.push( arg );
								}
							} else if ( arg && arg.length && type !== "string" ) {
								// Inspect recursively
								add( arg );
							}
						});
					})( arguments );
					// Do we need to add the callbacks to the
					// current firing batch?
					if ( firing ) {
						firingLength = list.length;
					// With memory, if we're not firing then
					// we should call right away
					} else if ( memory ) {
						firingStart = start;
						fire( memory );
					}
				}
				return this;
			},
			// Remove a callback from the list
			remove: function() {
				if ( list ) {
					jQuery.each( arguments, function( _, arg ) {
						var index;
						while( ( index = jQuery.inArray( arg, list, index ) ) > -1 ) {
							list.splice( index, 1 );
							// Handle firing indexes
							if ( firing ) {
								if ( index <= firingLength ) {
									firingLength--;
								}
								if ( index <= firingIndex ) {
									firingIndex--;
								}
							}
						}
					});
				}
				return this;
			},
			// Check if a given callback is in the list.
			// If no argument is given, return whether or not list has callbacks attached.
			has: function( fn ) {
				return fn ? jQuery.inArray( fn, list ) > -1 : !!( list && list.length );
			},
			// Remove all callbacks from the list
			empty: function() {
				list = [];
				firingLength = 0;
				return this;
			},
			// Have the list do nothing anymore
			disable: function() {
				list = stack = memory = undefined;
				return this;
			},
			// Is it disabled?
			disabled: function() {
				return !list;
			},
			// Lock the list in its current state
			lock: function() {
				stack = undefined;
				if ( !memory ) {
					self.disable();
				}
				return this;
			},
			// Is it locked?
			locked: function() {
				return !stack;
			},
			// Call all callbacks with the given context and arguments
			fireWith: function( context, args ) {
				if ( list && ( !fired || stack ) ) {
					args = args || [];
					args = [ context, args.slice ? args.slice() : args ];
					if ( firing ) {
						stack.push( args );
					} else {
						fire( args );
					}
				}
				return this;
			},
			// Call all the callbacks with the given arguments
			fire: function() {
				self.fireWith( this, arguments );
				return this;
			},
			// To know if the callbacks have already been called at least once
			fired: function() {
				return !!fired;
			}
		};

	return self;
};
jQuery.extend({

	Deferred: function( func ) {
		var tuples = [
				// action, add listener, listener list, final state
				[ "resolve", "done", jQuery.Callbacks("once memory"), "resolved" ],
				[ "reject", "fail", jQuery.Callbacks("once memory"), "rejected" ],
				[ "notify", "progress", jQuery.Callbacks("memory") ]
			],
			state = "pending",
			promise = {
				state: function() {
					return state;
				},
				always: function() {
					deferred.done( arguments ).fail( arguments );
					return this;
				},
				then: function( /* fnDone, fnFail, fnProgress */ ) {
					var fns = arguments;
					return jQuery.Deferred(function( newDefer ) {
						jQuery.each( tuples, function( i, tuple ) {
							var action = tuple[ 0 ],
								fn = jQuery.isFunction( fns[ i ] ) && fns[ i ];
							// deferred[ done | fail | progress ] for forwarding actions to newDefer
							deferred[ tuple[1] ](function() {
								var returned = fn && fn.apply( this, arguments );
								if ( returned && jQuery.isFunction( returned.promise ) ) {
									returned.promise()
										.done( newDefer.resolve )
										.fail( newDefer.reject )
										.progress( newDefer.notify );
								} else {
									newDefer[ action + "With" ]( this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments );
								}
							});
						});
						fns = null;
					}).promise();
				},
				// Get a promise for this deferred
				// If obj is provided, the promise aspect is added to the object
				promise: function( obj ) {
					return obj != null ? jQuery.extend( obj, promise ) : promise;
				}
			},
			deferred = {};

		// Keep pipe for back-compat
		promise.pipe = promise.then;

		// Add list-specific methods
		jQuery.each( tuples, function( i, tuple ) {
			var list = tuple[ 2 ],
				stateString = tuple[ 3 ];

			// promise[ done | fail | progress ] = list.add
			promise[ tuple[1] ] = list.add;

			// Handle state
			if ( stateString ) {
				list.add(function() {
					// state = [ resolved | rejected ]
					state = stateString;

				// [ reject_list | resolve_list ].disable; progress_list.lock
				}, tuples[ i ^ 1 ][ 2 ].disable, tuples[ 2 ][ 2 ].lock );
			}

			// deferred[ resolve | reject | notify ]
			deferred[ tuple[0] ] = function() {
				deferred[ tuple[0] + "With" ]( this === deferred ? promise : this, arguments );
				return this;
			};
			deferred[ tuple[0] + "With" ] = list.fireWith;
		});

		// Make the deferred a promise
		promise.promise( deferred );

		// Call given func if any
		if ( func ) {
			func.call( deferred, deferred );
		}

		// All done!
		return deferred;
	},

	// Deferred helper
	when: function( subordinate /* , ..., subordinateN */ ) {
		var i = 0,
			resolveValues = core_slice.call( arguments ),
			length = resolveValues.length,

			// the count of uncompleted subordinates
			remaining = length !== 1 || ( subordinate && jQuery.isFunction( subordinate.promise ) ) ? length : 0,

			// the master Deferred. If resolveValues consist of only a single Deferred, just use that.
			deferred = remaining === 1 ? subordinate : jQuery.Deferred(),

			// Update function for both resolve and progress values
			updateFunc = function( i, contexts, values ) {
				return function( value ) {
					contexts[ i ] = this;
					values[ i ] = arguments.length > 1 ? core_slice.call( arguments ) : value;
					if( values === progressValues ) {
						deferred.notifyWith( contexts, values );
					} else if ( !( --remaining ) ) {
						deferred.resolveWith( contexts, values );
					}
				};
			},

			progressValues, progressContexts, resolveContexts;

		// add listeners to Deferred subordinates; treat others as resolved
		if ( length > 1 ) {
			progressValues = new Array( length );
			progressContexts = new Array( length );
			resolveContexts = new Array( length );
			for ( ; i < length; i++ ) {
				if ( resolveValues[ i ] && jQuery.isFunction( resolveValues[ i ].promise ) ) {
					resolveValues[ i ].promise()
						.done( updateFunc( i, resolveContexts, resolveValues ) )
						.fail( deferred.reject )
						.progress( updateFunc( i, progressContexts, progressValues ) );
				} else {
					--remaining;
				}
			}
		}

		// if we're not waiting on anything, resolve the master
		if ( !remaining ) {
			deferred.resolveWith( resolveContexts, resolveValues );
		}

		return deferred.promise();
	}
});
jQuery.support = (function( support ) {
	var input = document.createElement("input"),
		fragment = document.createDocumentFragment(),
		div = document.createElement("div"),
		select = document.createElement("select"),
		opt = select.appendChild( document.createElement("option") );

	// Finish early in limited environments
	if ( !input.type ) {
		return support;
	}

	input.type = "checkbox";

	// Support: Safari 5.1, iOS 5.1, Android 4.x, Android 2.3
	// Check the default checkbox/radio value ("" on old WebKit; "on" elsewhere)
	support.checkOn = input.value !== "";

	// Must access the parent to make an option select properly
	// Support: IE9, IE10
	support.optSelected = opt.selected;

	// Will be defined later
	support.reliableMarginRight = true;
	support.boxSizingReliable = true;
	support.pixelPosition = false;

	// Make sure checked status is properly cloned
	// Support: IE9, IE10
	input.checked = true;
	support.noCloneChecked = input.cloneNode( true ).checked;

	// Make sure that the options inside disabled selects aren't marked as disabled
	// (WebKit marks them as disabled)
	select.disabled = true;
	support.optDisabled = !opt.disabled;

	// Check if an input maintains its value after becoming a radio
	// Support: IE9, IE10
	input = document.createElement("input");
	input.value = "t";
	input.type = "radio";
	support.radioValue = input.value === "t";

	// #11217 - WebKit loses check when the name is after the checked attribute
	input.setAttribute( "checked", "t" );
	input.setAttribute( "name", "t" );

	fragment.appendChild( input );

	// Support: Safari 5.1, Android 4.x, Android 2.3
	// old WebKit doesn't clone checked state correctly in fragments
	support.checkClone = fragment.cloneNode( true ).cloneNode( true ).lastChild.checked;

	// Support: Firefox, Chrome, Safari
	// Beware of CSP restrictions (https://developer.mozilla.org/en/Security/CSP)
	support.focusinBubbles = "onfocusin" in window;

	div.style.backgroundClip = "content-box";
	div.cloneNode( true ).style.backgroundClip = "";
	support.clearCloneStyle = div.style.backgroundClip === "content-box";

	// Run tests that need a body at doc ready
	jQuery(function() {
		var container, marginDiv,
			// Support: Firefox, Android 2.3 (Prefixed box-sizing versions).
			divReset = "padding:0;margin:0;border:0;display:block;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box",
			body = document.getElementsByTagName("body")[ 0 ];

		if ( !body ) {
			// Return for frameset docs that don't have a body
			return;
		}

		container = document.createElement("div");
		container.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px";

		// Check box-sizing and margin behavior.
		body.appendChild( container ).appendChild( div );
		div.innerHTML = "";
		// Support: Firefox, Android 2.3 (Prefixed box-sizing versions).
		div.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%";

		// Workaround failing boxSizing test due to offsetWidth returning wrong value
		// with some non-1 values of body zoom, ticket #13543
		jQuery.swap( body, body.style.zoom != null ? { zoom: 1 } : {}, function() {
			support.boxSizing = div.offsetWidth === 4;
		});

		// Use window.getComputedStyle because jsdom on node.js will break without it.
		if ( window.getComputedStyle ) {
			support.pixelPosition = ( window.getComputedStyle( div, null ) || {} ).top !== "1%";
			support.boxSizingReliable = ( window.getComputedStyle( div, null ) || { width: "4px" } ).width === "4px";

			// Support: Android 2.3
			// Check if div with explicit width and no margin-right incorrectly
			// gets computed margin-right based on width of container. (#3333)
			// WebKit Bug 13343 - getComputedStyle returns wrong value for margin-right
			marginDiv = div.appendChild( document.createElement("div") );
			marginDiv.style.cssText = div.style.cssText = divReset;
			marginDiv.style.marginRight = marginDiv.style.width = "0";
			div.style.width = "1px";

			support.reliableMarginRight =
				!parseFloat( ( window.getComputedStyle( marginDiv, null ) || {} ).marginRight );
		}

		body.removeChild( container );
	});

	return support;
})( {} );

/*
	Implementation Summary

	1. Enforce API surface and semantic compatibility with 1.9.x branch
	2. Improve the module's maintainability by reducing the storage
		paths to a single mechanism.
	3. Use the same single mechanism to support "private" and "user" data.
	4. _Never_ expose "private" data to user code (TODO: Drop _data, _removeData)
	5. Avoid exposing implementation details on user objects (eg. expando properties)
	6. Provide a clear path for implementation upgrade to WeakMap in 2014
*/
var data_user, data_priv,
	rbrace = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/,
	rmultiDash = /([A-Z])/g;

function Data() {
	// Support: Android < 4,
	// Old WebKit does not have Object.preventExtensions/freeze method,
	// return new empty object instead with no [[set]] accessor
	Object.defineProperty( this.cache = {}, 0, {
		get: function() {
			return {};
		}
	});

	this.expando = jQuery.expando + Math.random();
}

Data.uid = 1;

Data.accepts = function( owner ) {
	// Accepts only:
	//  - Node
	//    - Node.ELEMENT_NODE
	//    - Node.DOCUMENT_NODE
	//  - Object
	//    - Any
	return owner.nodeType ?
		owner.nodeType === 1 || owner.nodeType === 9 : true;
};

Data.prototype = {
	key: function( owner ) {
		// We can accept data for non-element nodes in modern browsers,
		// but we should not, see #8335.
		// Always return the key for a frozen object.
		if ( !Data.accepts( owner ) ) {
			return 0;
		}

		var descriptor = {},
			// Check if the owner object already has a cache key
			unlock = owner[ this.expando ];

		// If not, create one
		if ( !unlock ) {
			unlock = Data.uid++;

			// Secure it in a non-enumerable, non-writable property
			try {
				descriptor[ this.expando ] = { value: unlock };
				Object.defineProperties( owner, descriptor );

			// Support: Android < 4
			// Fallback to a less secure definition
			} catch ( e ) {
				descriptor[ this.expando ] = unlock;
				jQuery.extend( owner, descriptor );
			}
		}

		// Ensure the cache object
		if ( !this.cache[ unlock ] ) {
			this.cache[ unlock ] = {};
		}

		return unlock;
	},
	set: function( owner, data, value ) {
		var prop,
			// There may be an unlock assigned to this node,
			// if there is no entry for this "owner", create one inline
			// and set the unlock as though an owner entry had always existed
			unlock = this.key( owner ),
			cache = this.cache[ unlock ];

		// Handle: [ owner, key, value ] args
		if ( typeof data === "string" ) {
			cache[ data ] = value;

		// Handle: [ owner, { properties } ] args
		} else {
			// Fresh assignments by object are shallow copied
			if ( jQuery.isEmptyObject( cache ) ) {
				jQuery.extend( this.cache[ unlock ], data );
			// Otherwise, copy the properties one-by-one to the cache object
			} else {
				for ( prop in data ) {
					cache[ prop ] = data[ prop ];
				}
			}
		}
		return cache;
	},
	get: function( owner, key ) {
		// Either a valid cache is found, or will be created.
		// New caches will be created and the unlock returned,
		// allowing direct access to the newly created
		// empty data object. A valid owner object must be provided.
		var cache = this.cache[ this.key( owner ) ];

		return key === undefined ?
			cache : cache[ key ];
	},
	access: function( owner, key, value ) {
		var stored;
		// In cases where either:
		//
		//   1. No key was specified
		//   2. A string key was specified, but no value provided
		//
		// Take the "read" path and allow the get method to determine
		// which value to return, respectively either:
		//
		//   1. The entire cache object
		//   2. The data stored at the key
		//
		if ( key === undefined ||
				((key && typeof key === "string") && value === undefined) ) {

			stored = this.get( owner, key );

			return stored !== undefined ?
				stored : this.get( owner, jQuery.camelCase(key) );
		}

		// [*]When the key is not a string, or both a key and value
		// are specified, set or extend (existing objects) with either:
		//
		//   1. An object of properties
		//   2. A key and value
		//
		this.set( owner, key, value );

		// Since the "set" path can have two possible entry points
		// return the expected data based on which path was taken[*]
		return value !== undefined ? value : key;
	},
	remove: function( owner, key ) {
		var i, name, camel,
			unlock = this.key( owner ),
			cache = this.cache[ unlock ];

		if ( key === undefined ) {
			this.cache[ unlock ] = {};

		} else {
			// Support array or space separated string of keys
			if ( jQuery.isArray( key ) ) {
				// If "name" is an array of keys...
				// When data is initially created, via ("key", "val") signature,
				// keys will be converted to camelCase.
				// Since there is no way to tell _how_ a key was added, remove
				// both plain key and camelCase key. #12786
				// This will only penalize the array argument path.
				name = key.concat( key.map( jQuery.camelCase ) );
			} else {
				camel = jQuery.camelCase( key );
				// Try the string as a key before any manipulation
				if ( key in cache ) {
					name = [ key, camel ];
				} else {
					// If a key with the spaces exists, use it.
					// Otherwise, create an array by matching non-whitespace
					name = camel;
					name = name in cache ?
						[ name ] : ( name.match( core_rnotwhite ) || [] );
				}
			}

			i = name.length;
			while ( i-- ) {
				delete cache[ name[ i ] ];
			}
		}
	},
	hasData: function( owner ) {
		return !jQuery.isEmptyObject(
			this.cache[ owner[ this.expando ] ] || {}
		);
	},
	discard: function( owner ) {
		if ( owner[ this.expando ] ) {
			delete this.cache[ owner[ this.expando ] ];
		}
	}
};

// These may be used throughout the jQuery core codebase
data_user = new Data();
data_priv = new Data();


jQuery.extend({
	acceptData: Data.accepts,

	hasData: function( elem ) {
		return data_user.hasData( elem ) || data_priv.hasData( elem );
	},

	data: function( elem, name, data ) {
		return data_user.access( elem, name, data );
	},

	removeData: function( elem, name ) {
		data_user.remove( elem, name );
	},

	// TODO: Now that all calls to _data and _removeData have been replaced
	// with direct calls to data_priv methods, these can be deprecated.
	_data: function( elem, name, data ) {
		return data_priv.access( elem, name, data );
	},

	_removeData: function( elem, name ) {
		data_priv.remove( elem, name );
	}
});

jQuery.fn.extend({
	data: function( key, value ) {
		var attrs, name,
			elem = this[ 0 ],
			i = 0,
			data = null;

		// Gets all values
		if ( key === undefined ) {
			if ( this.length ) {
				data = data_user.get( elem );

				if ( elem.nodeType === 1 && !data_priv.get( elem, "hasDataAttrs" ) ) {
					attrs = elem.attributes;
					for ( ; i < attrs.length; i++ ) {
						name = attrs[ i ].name;

						if ( name.indexOf( "data-" ) === 0 ) {
							name = jQuery.camelCase( name.slice(5) );
							dataAttr( elem, name, data[ name ] );
						}
					}
					data_priv.set( elem, "hasDataAttrs", true );
				}
			}

			return data;
		}

		// Sets multiple values
		if ( typeof key === "object" ) {
			return this.each(function() {
				data_user.set( this, key );
			});
		}

		return jQuery.access( this, function( value ) {
			var data,
				camelKey = jQuery.camelCase( key );

			// The calling jQuery object (element matches) is not empty
			// (and therefore has an element appears at this[ 0 ]) and the
			// `value` parameter was not undefined. An empty jQuery object
			// will result in `undefined` for elem = this[ 0 ] which will
			// throw an exception if an attempt to read a data cache is made.
			if ( elem && value === undefined ) {
				// Attempt to get data from the cache
				// with the key as-is
				data = data_user.get( elem, key );
				if ( data !== undefined ) {
					return data;
				}

				// Attempt to get data from the cache
				// with the key camelized
				data = data_user.get( elem, camelKey );
				if ( data !== undefined ) {
					return data;
				}

				// Attempt to "discover" the data in
				// HTML5 custom data-* attrs
				data = dataAttr( elem, camelKey, undefined );
				if ( data !== undefined ) {
					return data;
				}

				// We tried really hard, but the data doesn't exist.
				return;
			}

			// Set the data...
			this.each(function() {
				// First, attempt to store a copy or reference of any
				// data that might've been store with a camelCased key.
				var data = data_user.get( this, camelKey );

				// For HTML5 data-* attribute interop, we have to
				// store property names with dashes in a camelCase form.
				// This might not apply to all properties...*
				data_user.set( this, camelKey, value );

				// *... In the case of properties that might _actually_
				// have dashes, we need to also store a copy of that
				// unchanged property.
				if ( key.indexOf("-") !== -1 && data !== undefined ) {
					data_user.set( this, key, value );
				}
			});
		}, null, value, arguments.length > 1, null, true );
	},

	removeData: function( key ) {
		return this.each(function() {
			data_user.remove( this, key );
		});
	}
});

function dataAttr( elem, key, data ) {
	var name;

	// If nothing was found internally, try to fetch any
	// data from the HTML5 data-* attribute
	if ( data === undefined && elem.nodeType === 1 ) {
		name = "data-" + key.replace( rmultiDash, "-$1" ).toLowerCase();
		data = elem.getAttribute( name );

		if ( typeof data === "string" ) {
			try {
				data = data === "true" ? true :
					data === "false" ? false :
					data === "null" ? null :
					// Only convert to a number if it doesn't change the string
					+data + "" === data ? +data :
					rbrace.test( data ) ? JSON.parse( data ) :
					data;
			} catch( e ) {}

			// Make sure we set the data so it isn't changed later
			data_user.set( elem, key, data );
		} else {
			data = undefined;
		}
	}
	return data;
}
jQuery.extend({
	queue: function( elem, type, data ) {
		var queue;

		if ( elem ) {
			type = ( type || "fx" ) + "queue";
			queue = data_priv.get( elem, type );

			// Speed up dequeue by getting out quickly if this is just a lookup
			if ( data ) {
				if ( !queue || jQuery.isArray( data ) ) {
					queue = data_priv.access( elem, type, jQuery.makeArray(data) );
				} else {
					queue.push( data );
				}
			}
			return queue || [];
		}
	},

	dequeue: function( elem, type ) {
		type = type || "fx";

		var queue = jQuery.queue( elem, type ),
			startLength = queue.length,
			fn = queue.shift(),
			hooks = jQuery._queueHooks( elem, type ),
			next = function() {
				jQuery.dequeue( elem, type );
			};

		// If the fx queue is dequeued, always remove the progress sentinel
		if ( fn === "inprogress" ) {
			fn = queue.shift();
			startLength--;
		}

		if ( fn ) {

			// Add a progress sentinel to prevent the fx queue from being
			// automatically dequeued
			if ( type === "fx" ) {
				queue.unshift( "inprogress" );
			}

			// clear up the last queue stop function
			delete hooks.stop;
			fn.call( elem, next, hooks );
		}

		if ( !startLength && hooks ) {
			hooks.empty.fire();
		}
	},

	// not intended for public consumption - generates a queueHooks object, or returns the current one
	_queueHooks: function( elem, type ) {
		var key = type + "queueHooks";
		return data_priv.get( elem, key ) || data_priv.access( elem, key, {
			empty: jQuery.Callbacks("once memory").add(function() {
				data_priv.remove( elem, [ type + "queue", key ] );
			})
		});
	}
});

jQuery.fn.extend({
	queue: function( type, data ) {
		var setter = 2;

		if ( typeof type !== "string" ) {
			data = type;
			type = "fx";
			setter--;
		}

		if ( arguments.length < setter ) {
			return jQuery.queue( this[0], type );
		}

		return data === undefined ?
			this :
			this.each(function() {
				var queue = jQuery.queue( this, type, data );

				// ensure a hooks for this queue
				jQuery._queueHooks( this, type );

				if ( type === "fx" && queue[0] !== "inprogress" ) {
					jQuery.dequeue( this, type );
				}
			});
	},
	dequeue: function( type ) {
		return this.each(function() {
			jQuery.dequeue( this, type );
		});
	},
	// Based off of the plugin by Clint Helfers, with permission.
	// http://blindsignals.com/index.php/2009/07/jquery-delay/
	delay: function( time, type ) {
		time = jQuery.fx ? jQuery.fx.speeds[ time ] || time : time;
		type = type || "fx";

		return this.queue( type, function( next, hooks ) {
			var timeout = setTimeout( next, time );
			hooks.stop = function() {
				clearTimeout( timeout );
			};
		});
	},
	clearQueue: function( type ) {
		return this.queue( type || "fx", [] );
	},
	// Get a promise resolved when queues of a certain type
	// are emptied (fx is the type by default)
	promise: function( type, obj ) {
		var tmp,
			count = 1,
			defer = jQuery.Deferred(),
			elements = this,
			i = this.length,
			resolve = function() {
				if ( !( --count ) ) {
					defer.resolveWith( elements, [ elements ] );
				}
			};

		if ( typeof type !== "string" ) {
			obj = type;
			type = undefined;
		}
		type = type || "fx";

		while( i-- ) {
			tmp = data_priv.get( elements[ i ], type + "queueHooks" );
			if ( tmp && tmp.empty ) {
				count++;
				tmp.empty.add( resolve );
			}
		}
		resolve();
		return defer.promise( obj );
	}
});
var nodeHook, boolHook,
	rclass = /[\t\r\n\f]/g,
	rreturn = /\r/g,
	rfocusable = /^(?:input|select|textarea|button)$/i;

jQuery.fn.extend({
	attr: function( name, value ) {
		return jQuery.access( this, jQuery.attr, name, value, arguments.length > 1 );
	},

	removeAttr: function( name ) {
		return this.each(function() {
			jQuery.removeAttr( this, name );
		});
	},

	prop: function( name, value ) {
		return jQuery.access( this, jQuery.prop, name, value, arguments.length > 1 );
	},

	removeProp: function( name ) {
		return this.each(function() {
			delete this[ jQuery.propFix[ name ] || name ];
		});
	},

	addClass: function( value ) {
		var classes, elem, cur, clazz, j,
			i = 0,
			len = this.length,
			proceed = typeof value === "string" && value;

		if ( jQuery.isFunction( value ) ) {
			return this.each(function( j ) {
				jQuery( this ).addClass( value.call( this, j, this.className ) );
			});
		}

		if ( proceed ) {
			// The disjunction here is for better compressibility (see removeClass)
			classes = ( value || "" ).match( core_rnotwhite ) || [];

			for ( ; i < len; i++ ) {
				elem = this[ i ];
				cur = elem.nodeType === 1 && ( elem.className ?
					( " " + elem.className + " " ).replace( rclass, " " ) :
					" "
				);

				if ( cur ) {
					j = 0;
					while ( (clazz = classes[j++]) ) {
						if ( cur.indexOf( " " + clazz + " " ) < 0 ) {
							cur += clazz + " ";
						}
					}
					elem.className = jQuery.trim( cur );

				}
			}
		}

		return this;
	},

	removeClass: function( value ) {
		var classes, elem, cur, clazz, j,
			i = 0,
			len = this.length,
			proceed = arguments.length === 0 || typeof value === "string" && value;

		if ( jQuery.isFunction( value ) ) {
			return this.each(function( j ) {
				jQuery( this ).removeClass( value.call( this, j, this.className ) );
			});
		}
		if ( proceed ) {
			classes = ( value || "" ).match( core_rnotwhite ) || [];

			for ( ; i < len; i++ ) {
				elem = this[ i ];
				// This expression is here for better compressibility (see addClass)
				cur = elem.nodeType === 1 && ( elem.className ?
					( " " + elem.className + " " ).replace( rclass, " " ) :
					""
				);

				if ( cur ) {
					j = 0;
					while ( (clazz = classes[j++]) ) {
						// Remove *all* instances
						while ( cur.indexOf( " " + clazz + " " ) >= 0 ) {
							cur = cur.replace( " " + clazz + " ", " " );
						}
					}
					elem.className = value ? jQuery.trim( cur ) : "";
				}
			}
		}

		return this;
	},

	toggleClass: function( value, stateVal ) {
		var type = typeof value;

		if ( typeof stateVal === "boolean" && type === "string" ) {
			return stateVal ? this.addClass( value ) : this.removeClass( value );
		}

		if ( jQuery.isFunction( value ) ) {
			return this.each(function( i ) {
				jQuery( this ).toggleClass( value.call(this, i, this.className, stateVal), stateVal );
			});
		}

		return this.each(function() {
			if ( type === "string" ) {
				// toggle individual class names
				var className,
					i = 0,
					self = jQuery( this ),
					classNames = value.match( core_rnotwhite ) || [];

				while ( (className = classNames[ i++ ]) ) {
					// check each className given, space separated list
					if ( self.hasClass( className ) ) {
						self.removeClass( className );
					} else {
						self.addClass( className );
					}
				}

			// Toggle whole class name
			} else if ( type === core_strundefined || type === "boolean" ) {
				if ( this.className ) {
					// store className if set
					data_priv.set( this, "__className__", this.className );
				}

				// If the element has a class name or if we're passed "false",
				// then remove the whole classname (if there was one, the above saved it).
				// Otherwise bring back whatever was previously saved (if anything),
				// falling back to the empty string if nothing was stored.
				this.className = this.className || value === false ? "" : data_priv.get( this, "__className__" ) || "";
			}
		});
	},

	hasClass: function( selector ) {
		var className = " " + selector + " ",
			i = 0,
			l = this.length;
		for ( ; i < l; i++ ) {
			if ( this[i].nodeType === 1 && (" " + this[i].className + " ").replace(rclass, " ").indexOf( className ) >= 0 ) {
				return true;
			}
		}

		return false;
	},

	val: function( value ) {
		var hooks, ret, isFunction,
			elem = this[0];

		if ( !arguments.length ) {
			if ( elem ) {
				hooks = jQuery.valHooks[ elem.type ] || jQuery.valHooks[ elem.nodeName.toLowerCase() ];

				if ( hooks && "get" in hooks && (ret = hooks.get( elem, "value" )) !== undefined ) {
					return ret;
				}

				ret = elem.value;

				return typeof ret === "string" ?
					// handle most common string cases
					ret.replace(rreturn, "") :
					// handle cases where value is null/undef or number
					ret == null ? "" : ret;
			}

			return;
		}

		isFunction = jQuery.isFunction( value );

		return this.each(function( i ) {
			var val;

			if ( this.nodeType !== 1 ) {
				return;
			}

			if ( isFunction ) {
				val = value.call( this, i, jQuery( this ).val() );
			} else {
				val = value;
			}

			// Treat null/undefined as ""; convert numbers to string
			if ( val == null ) {
				val = "";
			} else if ( typeof val === "number" ) {
				val += "";
			} else if ( jQuery.isArray( val ) ) {
				val = jQuery.map(val, function ( value ) {
					return value == null ? "" : value + "";
				});
			}

			hooks = jQuery.valHooks[ this.type ] || jQuery.valHooks[ this.nodeName.toLowerCase() ];

			// If set returns undefined, fall back to normal setting
			if ( !hooks || !("set" in hooks) || hooks.set( this, val, "value" ) === undefined ) {
				this.value = val;
			}
		});
	}
});

jQuery.extend({
	valHooks: {
		option: {
			get: function( elem ) {
				// attributes.value is undefined in Blackberry 4.7 but
				// uses .value. See #6932
				var val = elem.attributes.value;
				return !val || val.specified ? elem.value : elem.text;
			}
		},
		select: {
			get: function( elem ) {
				var value, option,
					options = elem.options,
					index = elem.selectedIndex,
					one = elem.type === "select-one" || index < 0,
					values = one ? null : [],
					max = one ? index + 1 : options.length,
					i = index < 0 ?
						max :
						one ? index : 0;

				// Loop through all the selected options
				for ( ; i < max; i++ ) {
					option = options[ i ];

					// IE6-9 doesn't update selected after form reset (#2551)
					if ( ( option.selected || i === index ) &&
							// Don't return options that are disabled or in a disabled optgroup
							( jQuery.support.optDisabled ? !option.disabled : option.getAttribute("disabled") === null ) &&
							( !option.parentNode.disabled || !jQuery.nodeName( option.parentNode, "optgroup" ) ) ) {

						// Get the specific value for the option
						value = jQuery( option ).val();

						// We don't need an array for one selects
						if ( one ) {
							return value;
						}

						// Multi-Selects return an array
						values.push( value );
					}
				}

				return values;
			},

			set: function( elem, value ) {
				var optionSet, option,
					options = elem.options,
					values = jQuery.makeArray( value ),
					i = options.length;

				while ( i-- ) {
					option = options[ i ];
					if ( (option.selected = jQuery.inArray( jQuery(option).val(), values ) >= 0) ) {
						optionSet = true;
					}
				}

				// force browsers to behave consistently when non-matching value is set
				if ( !optionSet ) {
					elem.selectedIndex = -1;
				}
				return values;
			}
		}
	},

	attr: function( elem, name, value ) {
		var hooks, ret,
			nType = elem.nodeType;

		// don't get/set attributes on text, comment and attribute nodes
		if ( !elem || nType === 3 || nType === 8 || nType === 2 ) {
			return;
		}

		// Fallback to prop when attributes are not supported
		if ( typeof elem.getAttribute === core_strundefined ) {
			return jQuery.prop( elem, name, value );
		}

		// All attributes are lowercase
		// Grab necessary hook if one is defined
		if ( nType !== 1 || !jQuery.isXMLDoc( elem ) ) {
			name = name.toLowerCase();
			hooks = jQuery.attrHooks[ name ] ||
				( jQuery.expr.match.bool.test( name ) ? boolHook : nodeHook );
		}

		if ( value !== undefined ) {

			if ( value === null ) {
				jQuery.removeAttr( elem, name );

			} else if ( hooks && "set" in hooks && (ret = hooks.set( elem, value, name )) !== undefined ) {
				return ret;

			} else {
				elem.setAttribute( name, value + "" );
				return value;
			}

		} else if ( hooks && "get" in hooks && (ret = hooks.get( elem, name )) !== null ) {
			return ret;

		} else {
			ret = jQuery.find.attr( elem, name );

			// Non-existent attributes return null, we normalize to undefined
			return ret == null ?
				undefined :
				ret;
		}
	},

	removeAttr: function( elem, value ) {
		var name, propName,
			i = 0,
			attrNames = value && value.match( core_rnotwhite );

		if ( attrNames && elem.nodeType === 1 ) {
			while ( (name = attrNames[i++]) ) {
				propName = jQuery.propFix[ name ] || name;

				// Boolean attributes get special treatment (#10870)
				if ( jQuery.expr.match.bool.test( name ) ) {
					// Set corresponding property to false
					elem[ propName ] = false;
				}

				elem.removeAttribute( name );
			}
		}
	},

	attrHooks: {
		type: {
			set: function( elem, value ) {
				if ( !jQuery.support.radioValue && value === "radio" && jQuery.nodeName(elem, "input") ) {
					// Setting the type on a radio button after the value resets the value in IE6-9
					// Reset value to default in case type is set after value during creation
					var val = elem.value;
					elem.setAttribute( "type", value );
					if ( val ) {
						elem.value = val;
					}
					return value;
				}
			}
		}
	},

	propFix: {
		"for": "htmlFor",
		"class": "className"
	},

	prop: function( elem, name, value ) {
		var ret, hooks, notxml,
			nType = elem.nodeType;

		// don't get/set properties on text, comment and attribute nodes
		if ( !elem || nType === 3 || nType === 8 || nType === 2 ) {
			return;
		}

		notxml = nType !== 1 || !jQuery.isXMLDoc( elem );

		if ( notxml ) {
			// Fix name and attach hooks
			name = jQuery.propFix[ name ] || name;
			hooks = jQuery.propHooks[ name ];
		}

		if ( value !== undefined ) {
			return hooks && "set" in hooks && (ret = hooks.set( elem, value, name )) !== undefined ?
				ret :
				( elem[ name ] = value );

		} else {
			return hooks && "get" in hooks && (ret = hooks.get( elem, name )) !== null ?
				ret :
				elem[ name ];
		}
	},

	propHooks: {
		tabIndex: {
			get: function( elem ) {
				return elem.hasAttribute( "tabindex" ) || rfocusable.test( elem.nodeName ) || elem.href ?
					elem.tabIndex :
					-1;
			}
		}
	}
});

// Hooks for boolean attributes
boolHook = {
	set: function( elem, value, name ) {
		if ( value === false ) {
			// Remove boolean attributes when set to false
			jQuery.removeAttr( elem, name );
		} else {
			elem.setAttribute( name, name );
		}
		return name;
	}
};
jQuery.each( jQuery.expr.match.bool.source.match( /\w+/g ), function( i, name ) {
	var getter = jQuery.expr.attrHandle[ name ] || jQuery.find.attr;

	jQuery.expr.attrHandle[ name ] = function( elem, name, isXML ) {
		var fn = jQuery.expr.attrHandle[ name ],
			ret = isXML ?
				undefined :
				/* jshint eqeqeq: false */
				// Temporarily disable this handler to check existence
				(jQuery.expr.attrHandle[ name ] = undefined) !=
					getter( elem, name, isXML ) ?

					name.toLowerCase() :
					null;

		// Restore handler
		jQuery.expr.attrHandle[ name ] = fn;

		return ret;
	};
});

// Support: IE9+
// Selectedness for an option in an optgroup can be inaccurate
if ( !jQuery.support.optSelected ) {
	jQuery.propHooks.selected = {
		get: function( elem ) {
			var parent = elem.parentNode;
			if ( parent && parent.parentNode ) {
				parent.parentNode.selectedIndex;
			}
			return null;
		}
	};
}

jQuery.each([
	"tabIndex",
	"readOnly",
	"maxLength",
	"cellSpacing",
	"cellPadding",
	"rowSpan",
	"colSpan",
	"useMap",
	"frameBorder",
	"contentEditable"
], function() {
	jQuery.propFix[ this.toLowerCase() ] = this;
});

// Radios and checkboxes getter/setter
jQuery.each([ "radio", "checkbox" ], function() {
	jQuery.valHooks[ this ] = {
		set: function( elem, value ) {
			if ( jQuery.isArray( value ) ) {
				return ( elem.checked = jQuery.inArray( jQuery(elem).val(), value ) >= 0 );
			}
		}
	};
	if ( !jQuery.support.checkOn ) {
		jQuery.valHooks[ this ].get = function( elem ) {
			// Support: Webkit
			// "" is returned instead of "on" if a value isn't specified
			return elem.getAttribute("value") === null ? "on" : elem.value;
		};
	}
});
var rkeyEvent = /^key/,
	rmouseEvent = /^(?:mouse|contextmenu)|click/,
	rfocusMorph = /^(?:focusinfocus|focusoutblur)$/,
	rtypenamespace = /^([^.]*)(?:\.(.+)|)$/;

function returnTrue() {
	return true;
}

function returnFalse() {
	return false;
}

function safeActiveElement() {
	try {
		return document.activeElement;
	} catch ( err ) { }
}

/*
 * Helper functions for managing events -- not part of the public interface.
 * Props to Dean Edwards' addEvent library for many of the ideas.
 */
jQuery.event = {

	global: {},

	add: function( elem, types, handler, data, selector ) {

		var handleObjIn, eventHandle, tmp,
			events, t, handleObj,
			special, handlers, type, namespaces, origType,
			elemData = data_priv.get( elem );

		// Don't attach events to noData or text/comment nodes (but allow plain objects)
		if ( !elemData ) {
			return;
		}

		// Caller can pass in an object of custom data in lieu of the handler
		if ( handler.handler ) {
			handleObjIn = handler;
			handler = handleObjIn.handler;
			selector = handleObjIn.selector;
		}

		// Make sure that the handler has a unique ID, used to find/remove it later
		if ( !handler.guid ) {
			handler.guid = jQuery.guid++;
		}

		// Init the element's event structure and main handler, if this is the first
		if ( !(events = elemData.events) ) {
			events = elemData.events = {};
		}
		if ( !(eventHandle = elemData.handle) ) {
			eventHandle = elemData.handle = function( e ) {
				// Discard the second event of a jQuery.event.trigger() and
				// when an event is called after a page has unloaded
				return typeof jQuery !== core_strundefined && (!e || jQuery.event.triggered !== e.type) ?
					jQuery.event.dispatch.apply( eventHandle.elem, arguments ) :
					undefined;
			};
			// Add elem as a property of the handle fn to prevent a memory leak with IE non-native events
			eventHandle.elem = elem;
		}

		// Handle multiple events separated by a space
		types = ( types || "" ).match( core_rnotwhite ) || [""];
		t = types.length;
		while ( t-- ) {
			tmp = rtypenamespace.exec( types[t] ) || [];
			type = origType = tmp[1];
			namespaces = ( tmp[2] || "" ).split( "." ).sort();

			// There *must* be a type, no attaching namespace-only handlers
			if ( !type ) {
				continue;
			}

			// If event changes its type, use the special event handlers for the changed type
			special = jQuery.event.special[ type ] || {};

			// If selector defined, determine special event api type, otherwise given type
			type = ( selector ? special.delegateType : special.bindType ) || type;

			// Update special based on newly reset type
			special = jQuery.event.special[ type ] || {};

			// handleObj is passed to all event handlers
			handleObj = jQuery.extend({
				type: type,
				origType: origType,
				data: data,
				handler: handler,
				guid: handler.guid,
				selector: selector,
				needsContext: selector && jQuery.expr.match.needsContext.test( selector ),
				namespace: namespaces.join(".")
			}, handleObjIn );

			// Init the event handler queue if we're the first
			if ( !(handlers = events[ type ]) ) {
				handlers = events[ type ] = [];
				handlers.delegateCount = 0;

				// Only use addEventListener if the special events handler returns false
				if ( !special.setup || special.setup.call( elem, data, namespaces, eventHandle ) === false ) {
					if ( elem.addEventListener ) {
						elem.addEventListener( type, eventHandle, false );
					}
				}
			}

			if ( special.add ) {
				special.add.call( elem, handleObj );

				if ( !handleObj.handler.guid ) {
					handleObj.handler.guid = handler.guid;
				}
			}

			// Add to the element's handler list, delegates in front
			if ( selector ) {
				handlers.splice( handlers.delegateCount++, 0, handleObj );
			} else {
				handlers.push( handleObj );
			}

			// Keep track of which events have ever been used, for event optimization
			jQuery.event.global[ type ] = true;
		}

		// Nullify elem to prevent memory leaks in IE
		elem = null;
	},

	// Detach an event or set of events from an element
	remove: function( elem, types, handler, selector, mappedTypes ) {

		var j, origCount, tmp,
			events, t, handleObj,
			special, handlers, type, namespaces, origType,
			elemData = data_priv.hasData( elem ) && data_priv.get( elem );

		if ( !elemData || !(events = elemData.events) ) {
			return;
		}

		// Once for each type.namespace in types; type may be omitted
		types = ( types || "" ).match( core_rnotwhite ) || [""];
		t = types.length;
		while ( t-- ) {
			tmp = rtypenamespace.exec( types[t] ) || [];
			type = origType = tmp[1];
			namespaces = ( tmp[2] || "" ).split( "." ).sort();

			// Unbind all events (on this namespace, if provided) for the element
			if ( !type ) {
				for ( type in events ) {
					jQuery.event.remove( elem, type + types[ t ], handler, selector, true );
				}
				continue;
			}

			special = jQuery.event.special[ type ] || {};
			type = ( selector ? special.delegateType : special.bindType ) || type;
			handlers = events[ type ] || [];
			tmp = tmp[2] && new RegExp( "(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)" );

			// Remove matching events
			origCount = j = handlers.length;
			while ( j-- ) {
				handleObj = handlers[ j ];

				if ( ( mappedTypes || origType === handleObj.origType ) &&
					( !handler || handler.guid === handleObj.guid ) &&
					( !tmp || tmp.test( handleObj.namespace ) ) &&
					( !selector || selector === handleObj.selector || selector === "**" && handleObj.selector ) ) {
					handlers.splice( j, 1 );

					if ( handleObj.selector ) {
						handlers.delegateCount--;
					}
					if ( special.remove ) {
						special.remove.call( elem, handleObj );
					}
				}
			}

			// Remove generic event handler if we removed something and no more handlers exist
			// (avoids potential for endless recursion during removal of special event handlers)
			if ( origCount && !handlers.length ) {
				if ( !special.teardown || special.teardown.call( elem, namespaces, elemData.handle ) === false ) {
					jQuery.removeEvent( elem, type, elemData.handle );
				}

				delete events[ type ];
			}
		}

		// Remove the expando if it's no longer used
		if ( jQuery.isEmptyObject( events ) ) {
			delete elemData.handle;
			data_priv.remove( elem, "events" );
		}
	},

	trigger: function( event, data, elem, onlyHandlers ) {

		var i, cur, tmp, bubbleType, ontype, handle, special,
			eventPath = [ elem || document ],
			type = core_hasOwn.call( event, "type" ) ? event.type : event,
			namespaces = core_hasOwn.call( event, "namespace" ) ? event.namespace.split(".") : [];

		cur = tmp = elem = elem || document;

		// Don't do events on text and comment nodes
		if ( elem.nodeType === 3 || elem.nodeType === 8 ) {
			return;
		}

		// focus/blur morphs to focusin/out; ensure we're not firing them right now
		if ( rfocusMorph.test( type + jQuery.event.triggered ) ) {
			return;
		}

		if ( type.indexOf(".") >= 0 ) {
			// Namespaced trigger; create a regexp to match event type in handle()
			namespaces = type.split(".");
			type = namespaces.shift();
			namespaces.sort();
		}
		ontype = type.indexOf(":") < 0 && "on" + type;

		// Caller can pass in a jQuery.Event object, Object, or just an event type string
		event = event[ jQuery.expando ] ?
			event :
			new jQuery.Event( type, typeof event === "object" && event );

		// Trigger bitmask: & 1 for native handlers; & 2 for jQuery (always true)
		event.isTrigger = onlyHandlers ? 2 : 3;
		event.namespace = namespaces.join(".");
		event.namespace_re = event.namespace ?
			new RegExp( "(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)" ) :
			null;

		// Clean up the event in case it is being reused
		event.result = undefined;
		if ( !event.target ) {
			event.target = elem;
		}

		// Clone any incoming data and prepend the event, creating the handler arg list
		data = data == null ?
			[ event ] :
			jQuery.makeArray( data, [ event ] );

		// Allow special events to draw outside the lines
		special = jQuery.event.special[ type ] || {};
		if ( !onlyHandlers && special.trigger && special.trigger.apply( elem, data ) === false ) {
			return;
		}

		// Determine event propagation path in advance, per W3C events spec (#9951)
		// Bubble up to document, then to window; watch for a global ownerDocument var (#9724)
		if ( !onlyHandlers && !special.noBubble && !jQuery.isWindow( elem ) ) {

			bubbleType = special.delegateType || type;
			if ( !rfocusMorph.test( bubbleType + type ) ) {
				cur = cur.parentNode;
			}
			for ( ; cur; cur = cur.parentNode ) {
				eventPath.push( cur );
				tmp = cur;
			}

			// Only add window if we got to document (e.g., not plain obj or detached DOM)
			if ( tmp === (elem.ownerDocument || document) ) {
				eventPath.push( tmp.defaultView || tmp.parentWindow || window );
			}
		}

		// Fire handlers on the event path
		i = 0;
		while ( (cur = eventPath[i++]) && !event.isPropagationStopped() ) {

			event.type = i > 1 ?
				bubbleType :
				special.bindType || type;

			// jQuery handler
			handle = ( data_priv.get( cur, "events" ) || {} )[ event.type ] && data_priv.get( cur, "handle" );
			if ( handle ) {
				handle.apply( cur, data );
			}

			// Native handler
			handle = ontype && cur[ ontype ];
			if ( handle && jQuery.acceptData( cur ) && handle.apply && handle.apply( cur, data ) === false ) {
				event.preventDefault();
			}
		}
		event.type = type;

		// If nobody prevented the default action, do it now
		if ( !onlyHandlers && !event.isDefaultPrevented() ) {

			if ( (!special._default || special._default.apply( eventPath.pop(), data ) === false) &&
				jQuery.acceptData( elem ) ) {

				// Call a native DOM method on the target with the same name name as the event.
				// Don't do default actions on window, that's where global variables be (#6170)
				if ( ontype && jQuery.isFunction( elem[ type ] ) && !jQuery.isWindow( elem ) ) {

					// Don't re-trigger an onFOO event when we call its FOO() method
					tmp = elem[ ontype ];

					if ( tmp ) {
						elem[ ontype ] = null;
					}

					// Prevent re-triggering of the same event, since we already bubbled it above
					jQuery.event.triggered = type;
					elem[ type ]();
					jQuery.event.triggered = undefined;

					if ( tmp ) {
						elem[ ontype ] = tmp;
					}
				}
			}
		}

		return event.result;
	},

	dispatch: function( event ) {

		// Make a writable jQuery.Event from the native event object
		event = jQuery.event.fix( event );

		var i, j, ret, matched, handleObj,
			handlerQueue = [],
			args = core_slice.call( arguments ),
			handlers = ( data_priv.get( this, "events" ) || {} )[ event.type ] || [],
			special = jQuery.event.special[ event.type ] || {};

		// Use the fix-ed jQuery.Event rather than the (read-only) native event
		args[0] = event;
		event.delegateTarget = this;

		// Call the preDispatch hook for the mapped type, and let it bail if desired
		if ( special.preDispatch && special.preDispatch.call( this, event ) === false ) {
			return;
		}

		// Determine handlers
		handlerQueue = jQuery.event.handlers.call( this, event, handlers );

		// Run delegates first; they may want to stop propagation beneath us
		i = 0;
		while ( (matched = handlerQueue[ i++ ]) && !event.isPropagationStopped() ) {
			event.currentTarget = matched.elem;

			j = 0;
			while ( (handleObj = matched.handlers[ j++ ]) && !event.isImmediatePropagationStopped() ) {

				// Triggered event must either 1) have no namespace, or
				// 2) have namespace(s) a subset or equal to those in the bound event (both can have no namespace).
				if ( !event.namespace_re || event.namespace_re.test( handleObj.namespace ) ) {

					event.handleObj = handleObj;
					event.data = handleObj.data;

					ret = ( (jQuery.event.special[ handleObj.origType ] || {}).handle || handleObj.handler )
							.apply( matched.elem, args );

					if ( ret !== undefined ) {
						if ( (event.result = ret) === false ) {
							event.preventDefault();
							event.stopPropagation();
						}
					}
				}
			}
		}

		// Call the postDispatch hook for the mapped type
		if ( special.postDispatch ) {
			special.postDispatch.call( this, event );
		}

		return event.result;
	},

	handlers: function( event, handlers ) {
		var i, matches, sel, handleObj,
			handlerQueue = [],
			delegateCount = handlers.delegateCount,
			cur = event.target;

		// Find delegate handlers
		// Black-hole SVG <use> instance trees (#13180)
		// Avoid non-left-click bubbling in Firefox (#3861)
		if ( delegateCount && cur.nodeType && (!event.button || event.type !== "click") ) {

			for ( ; cur !== this; cur = cur.parentNode || this ) {

				// Don't process clicks on disabled elements (#6911, #8165, #11382, #11764)
				if ( cur.disabled !== true || event.type !== "click" ) {
					matches = [];
					for ( i = 0; i < delegateCount; i++ ) {
						handleObj = handlers[ i ];

						// Don't conflict with Object.prototype properties (#13203)
						sel = handleObj.selector + " ";

						if ( matches[ sel ] === undefined ) {
							matches[ sel ] = handleObj.needsContext ?
								jQuery( sel, this ).index( cur ) >= 0 :
								jQuery.find( sel, this, null, [ cur ] ).length;
						}
						if ( matches[ sel ] ) {
							matches.push( handleObj );
						}
					}
					if ( matches.length ) {
						handlerQueue.push({ elem: cur, handlers: matches });
					}
				}
			}
		}

		// Add the remaining (directly-bound) handlers
		if ( delegateCount < handlers.length ) {
			handlerQueue.push({ elem: this, handlers: handlers.slice( delegateCount ) });
		}

		return handlerQueue;
	},

	// Includes some event props shared by KeyEvent and MouseEvent
	props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),

	fixHooks: {},

	keyHooks: {
		props: "char charCode key keyCode".split(" "),
		filter: function( event, original ) {

			// Add which for key events
			if ( event.which == null ) {
				event.which = original.charCode != null ? original.charCode : original.keyCode;
			}

			return event;
		}
	},

	mouseHooks: {
		props: "button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
		filter: function( event, original ) {
			var eventDoc, doc, body,
				button = original.button;

			// Calculate pageX/Y if missing and clientX/Y available
			if ( event.pageX == null && original.clientX != null ) {
				eventDoc = event.target.ownerDocument || document;
				doc = eventDoc.documentElement;
				body = eventDoc.body;

				event.pageX = original.clientX + ( doc && doc.scrollLeft || body && body.scrollLeft || 0 ) - ( doc && doc.clientLeft || body && body.clientLeft || 0 );
				event.pageY = original.clientY + ( doc && doc.scrollTop  || body && body.scrollTop  || 0 ) - ( doc && doc.clientTop  || body && body.clientTop  || 0 );
			}

			// Add which for click: 1 === left; 2 === middle; 3 === right
			// Note: button is not normalized, so don't use it
			if ( !event.which && button !== undefined ) {
				event.which = ( button & 1 ? 1 : ( button & 2 ? 3 : ( button & 4 ? 2 : 0 ) ) );
			}

			return event;
		}
	},

	fix: function( event ) {
		if ( event[ jQuery.expando ] ) {
			return event;
		}

		// Create a writable copy of the event object and normalize some properties
		var i, prop, copy,
			type = event.type,
			originalEvent = event,
			fixHook = this.fixHooks[ type ];

		if ( !fixHook ) {
			this.fixHooks[ type ] = fixHook =
				rmouseEvent.test( type ) ? this.mouseHooks :
				rkeyEvent.test( type ) ? this.keyHooks :
				{};
		}
		copy = fixHook.props ? this.props.concat( fixHook.props ) : this.props;

		event = new jQuery.Event( originalEvent );

		i = copy.length;
		while ( i-- ) {
			prop = copy[ i ];
			event[ prop ] = originalEvent[ prop ];
		}

		// Support: Cordova 2.5 (WebKit) (#13255)
		// All events should have a target; Cordova deviceready doesn't
		if ( !event.target ) {
			event.target = document;
		}

		// Support: Safari 6.0+, Chrome < 28
		// Target should not be a text node (#504, #13143)
		if ( event.target.nodeType === 3 ) {
			event.target = event.target.parentNode;
		}

		return fixHook.filter? fixHook.filter( event, originalEvent ) : event;
	},

	special: {
		load: {
			// Prevent triggered image.load events from bubbling to window.load
			noBubble: true
		},
		focus: {
			// Fire native event if possible so blur/focus sequence is correct
			trigger: function() {
				if ( this !== safeActiveElement() && this.focus ) {
					this.focus();
					return false;
				}
			},
			delegateType: "focusin"
		},
		blur: {
			trigger: function() {
				if ( this === safeActiveElement() && this.blur ) {
					this.blur();
					return false;
				}
			},
			delegateType: "focusout"
		},
		click: {
			// For checkbox, fire native event so checked state will be right
			trigger: function() {
				if ( this.type === "checkbox" && this.click && jQuery.nodeName( this, "input" ) ) {
					this.click();
					return false;
				}
			},

			// For cross-browser consistency, don't fire native .click() on links
			_default: function( event ) {
				return jQuery.nodeName( event.target, "a" );
			}
		},

		beforeunload: {
			postDispatch: function( event ) {

				// Support: Firefox 20+
				// Firefox doesn't alert if the returnValue field is not set.
				if ( event.result !== undefined ) {
					event.originalEvent.returnValue = event.result;
				}
			}
		}
	},

	simulate: function( type, elem, event, bubble ) {
		// Piggyback on a donor event to simulate a different one.
		// Fake originalEvent to avoid donor's stopPropagation, but if the
		// simulated event prevents default then we do the same on the donor.
		var e = jQuery.extend(
			new jQuery.Event(),
			event,
			{
				type: type,
				isSimulated: true,
				originalEvent: {}
			}
		);
		if ( bubble ) {
			jQuery.event.trigger( e, null, elem );
		} else {
			jQuery.event.dispatch.call( elem, e );
		}
		if ( e.isDefaultPrevented() ) {
			event.preventDefault();
		}
	}
};

jQuery.removeEvent = function( elem, type, handle ) {
	if ( elem.removeEventListener ) {
		elem.removeEventListener( type, handle, false );
	}
};

jQuery.Event = function( src, props ) {
	// Allow instantiation without the 'new' keyword
	if ( !(this instanceof jQuery.Event) ) {
		return new jQuery.Event( src, props );
	}

	// Event object
	if ( src && src.type ) {
		this.originalEvent = src;
		this.type = src.type;

		// Events bubbling up the document may have been marked as prevented
		// by a handler lower down the tree; reflect the correct value.
		this.isDefaultPrevented = ( src.defaultPrevented ||
			src.getPreventDefault && src.getPreventDefault() ) ? returnTrue : returnFalse;

	// Event type
	} else {
		this.type = src;
	}

	// Put explicitly provided properties onto the event object
	if ( props ) {
		jQuery.extend( this, props );
	}

	// Create a timestamp if incoming event doesn't have one
	this.timeStamp = src && src.timeStamp || jQuery.now();

	// Mark it as fixed
	this[ jQuery.expando ] = true;
};

// jQuery.Event is based on DOM3 Events as specified by the ECMAScript Language Binding
// http://www.w3.org/TR/2003/WD-DOM-Level-3-Events-20030331/ecma-script-binding.html
jQuery.Event.prototype = {
	isDefaultPrevented: returnFalse,
	isPropagationStopped: returnFalse,
	isImmediatePropagationStopped: returnFalse,

	preventDefault: function() {
		var e = this.originalEvent;

		this.isDefaultPrevented = returnTrue;

		if ( e && e.preventDefault ) {
			e.preventDefault();
		}
	},
	stopPropagation: function() {
		var e = this.originalEvent;

		this.isPropagationStopped = returnTrue;

		if ( e && e.stopPropagation ) {
			e.stopPropagation();
		}
	},
	stopImmediatePropagation: function() {
		this.isImmediatePropagationStopped = returnTrue;
		this.stopPropagation();
	}
};

// Create mouseenter/leave events using mouseover/out and event-time checks
// Support: Chrome 15+
jQuery.each({
	mouseenter: "mouseover",
	mouseleave: "mouseout"
}, function( orig, fix ) {
	jQuery.event.special[ orig ] = {
		delegateType: fix,
		bindType: fix,

		handle: function( event ) {
			var ret,
				target = this,
				related = event.relatedTarget,
				handleObj = event.handleObj;

			// For mousenter/leave call the handler if related is outside the target.
			// NB: No relatedTarget if the mouse left/entered the browser window
			if ( !related || (related !== target && !jQuery.contains( target, related )) ) {
				event.type = handleObj.origType;
				ret = handleObj.handler.apply( this, arguments );
				event.type = fix;
			}
			return ret;
		}
	};
});

// Create "bubbling" focus and blur events
// Support: Firefox, Chrome, Safari
if ( !jQuery.support.focusinBubbles ) {
	jQuery.each({ focus: "focusin", blur: "focusout" }, function( orig, fix ) {

		// Attach a single capturing handler while someone wants focusin/focusout
		var attaches = 0,
			handler = function( event ) {
				jQuery.event.simulate( fix, event.target, jQuery.event.fix( event ), true );
			};

		jQuery.event.special[ fix ] = {
			setup: function() {
				if ( attaches++ === 0 ) {
					document.addEventListener( orig, handler, true );
				}
			},
			teardown: function() {
				if ( --attaches === 0 ) {
					document.removeEventListener( orig, handler, true );
				}
			}
		};
	});
}

jQuery.fn.extend({

	on: function( types, selector, data, fn, /*INTERNAL*/ one ) {
		var origFn, type;

		// Types can be a map of types/handlers
		if ( typeof types === "object" ) {
			// ( types-Object, selector, data )
			if ( typeof selector !== "string" ) {
				// ( types-Object, data )
				data = data || selector;
				selector = undefined;
			}
			for ( type in types ) {
				this.on( type, selector, data, types[ type ], one );
			}
			return this;
		}

		if ( data == null && fn == null ) {
			// ( types, fn )
			fn = selector;
			data = selector = undefined;
		} else if ( fn == null ) {
			if ( typeof selector === "string" ) {
				// ( types, selector, fn )
				fn = data;
				data = undefined;
			} else {
				// ( types, data, fn )
				fn = data;
				data = selector;
				selector = undefined;
			}
		}
		if ( fn === false ) {
			fn = returnFalse;
		} else if ( !fn ) {
			return this;
		}

		if ( one === 1 ) {
			origFn = fn;
			fn = function( event ) {
				// Can use an empty set, since event contains the info
				jQuery().off( event );
				return origFn.apply( this, arguments );
			};
			// Use same guid so caller can remove using origFn
			fn.guid = origFn.guid || ( origFn.guid = jQuery.guid++ );
		}
		return this.each( function() {
			jQuery.event.add( this, types, fn, data, selector );
		});
	},
	one: function( types, selector, data, fn ) {
		return this.on( types, selector, data, fn, 1 );
	},
	off: function( types, selector, fn ) {
		var handleObj, type;
		if ( types && types.preventDefault && types.handleObj ) {
			// ( event )  dispatched jQuery.Event
			handleObj = types.handleObj;
			jQuery( types.delegateTarget ).off(
				handleObj.namespace ? handleObj.origType + "." + handleObj.namespace : handleObj.origType,
				handleObj.selector,
				handleObj.handler
			);
			return this;
		}
		if ( typeof types === "object" ) {
			// ( types-object [, selector] )
			for ( type in types ) {
				this.off( type, selector, types[ type ] );
			}
			return this;
		}
		if ( selector === false || typeof selector === "function" ) {
			// ( types [, fn] )
			fn = selector;
			selector = undefined;
		}
		if ( fn === false ) {
			fn = returnFalse;
		}
		return this.each(function() {
			jQuery.event.remove( this, types, fn, selector );
		});
	},

	trigger: function( type, data ) {
		return this.each(function() {
			jQuery.event.trigger( type, data, this );
		});
	},
	triggerHandler: function( type, data ) {
		var elem = this[0];
		if ( elem ) {
			return jQuery.event.trigger( type, data, elem, true );
		}
	}
});
var isSimple = /^.[^:#\[\.,]*$/,
	rparentsprev = /^(?:parents|prev(?:Until|All))/,
	rneedsContext = jQuery.expr.match.needsContext,
	// methods guaranteed to produce a unique set when starting from a unique set
	guaranteedUnique = {
		children: true,
		contents: true,
		next: true,
		prev: true
	};

jQuery.fn.extend({
	find: function( selector ) {
		var i,
			ret = [],
			self = this,
			len = self.length;

		if ( typeof selector !== "string" ) {
			return this.pushStack( jQuery( selector ).filter(function() {
				for ( i = 0; i < len; i++ ) {
					if ( jQuery.contains( self[ i ], this ) ) {
						return true;
					}
				}
			}) );
		}

		for ( i = 0; i < len; i++ ) {
			jQuery.find( selector, self[ i ], ret );
		}

		// Needed because $( selector, context ) becomes $( context ).find( selector )
		ret = this.pushStack( len > 1 ? jQuery.unique( ret ) : ret );
		ret.selector = this.selector ? this.selector + " " + selector : selector;
		return ret;
	},

	has: function( target ) {
		var targets = jQuery( target, this ),
			l = targets.length;

		return this.filter(function() {
			var i = 0;
			for ( ; i < l; i++ ) {
				if ( jQuery.contains( this, targets[i] ) ) {
					return true;
				}
			}
		});
	},

	not: function( selector ) {
		return this.pushStack( winnow(this, selector || [], true) );
	},

	filter: function( selector ) {
		return this.pushStack( winnow(this, selector || [], false) );
	},

	is: function( selector ) {
		return !!winnow(
			this,

			// If this is a positional/relative selector, check membership in the returned set
			// so $("p:first").is("p:last") won't return true for a doc with two "p".
			typeof selector === "string" && rneedsContext.test( selector ) ?
				jQuery( selector ) :
				selector || [],
			false
		).length;
	},

	closest: function( selectors, context ) {
		var cur,
			i = 0,
			l = this.length,
			matched = [],
			pos = ( rneedsContext.test( selectors ) || typeof selectors !== "string" ) ?
				jQuery( selectors, context || this.context ) :
				0;

		for ( ; i < l; i++ ) {
			for ( cur = this[i]; cur && cur !== context; cur = cur.parentNode ) {
				// Always skip document fragments
				if ( cur.nodeType < 11 && (pos ?
					pos.index(cur) > -1 :

					// Don't pass non-elements to Sizzle
					cur.nodeType === 1 &&
						jQuery.find.matchesSelector(cur, selectors)) ) {

					cur = matched.push( cur );
					break;
				}
			}
		}

		return this.pushStack( matched.length > 1 ? jQuery.unique( matched ) : matched );
	},

	// Determine the position of an element within
	// the matched set of elements
	index: function( elem ) {

		// No argument, return index in parent
		if ( !elem ) {
			return ( this[ 0 ] && this[ 0 ].parentNode ) ? this.first().prevAll().length : -1;
		}

		// index in selector
		if ( typeof elem === "string" ) {
			return core_indexOf.call( jQuery( elem ), this[ 0 ] );
		}

		// Locate the position of the desired element
		return core_indexOf.call( this,

			// If it receives a jQuery object, the first element is used
			elem.jquery ? elem[ 0 ] : elem
		);
	},

	add: function( selector, context ) {
		var set = typeof selector === "string" ?
				jQuery( selector, context ) :
				jQuery.makeArray( selector && selector.nodeType ? [ selector ] : selector ),
			all = jQuery.merge( this.get(), set );

		return this.pushStack( jQuery.unique(all) );
	},

	addBack: function( selector ) {
		return this.add( selector == null ?
			this.prevObject : this.prevObject.filter(selector)
		);
	}
});

function sibling( cur, dir ) {
	while ( (cur = cur[dir]) && cur.nodeType !== 1 ) {}

	return cur;
}

jQuery.each({
	parent: function( elem ) {
		var parent = elem.parentNode;
		return parent && parent.nodeType !== 11 ? parent : null;
	},
	parents: function( elem ) {
		return jQuery.dir( elem, "parentNode" );
	},
	parentsUntil: function( elem, i, until ) {
		return jQuery.dir( elem, "parentNode", until );
	},
	next: function( elem ) {
		return sibling( elem, "nextSibling" );
	},
	prev: function( elem ) {
		return sibling( elem, "previousSibling" );
	},
	nextAll: function( elem ) {
		return jQuery.dir( elem, "nextSibling" );
	},
	prevAll: function( elem ) {
		return jQuery.dir( elem, "previousSibling" );
	},
	nextUntil: function( elem, i, until ) {
		return jQuery.dir( elem, "nextSibling", until );
	},
	prevUntil: function( elem, i, until ) {
		return jQuery.dir( elem, "previousSibling", until );
	},
	siblings: function( elem ) {
		return jQuery.sibling( ( elem.parentNode || {} ).firstChild, elem );
	},
	children: function( elem ) {
		return jQuery.sibling( elem.firstChild );
	},
	contents: function( elem ) {
		return elem.contentDocument || jQuery.merge( [], elem.childNodes );
	}
}, function( name, fn ) {
	jQuery.fn[ name ] = function( until, selector ) {
		var matched = jQuery.map( this, fn, until );

		if ( name.slice( -5 ) !== "Until" ) {
			selector = until;
		}

		if ( selector && typeof selector === "string" ) {
			matched = jQuery.filter( selector, matched );
		}

		if ( this.length > 1 ) {
			// Remove duplicates
			if ( !guaranteedUnique[ name ] ) {
				jQuery.unique( matched );
			}

			// Reverse order for parents* and prev-derivatives
			if ( rparentsprev.test( name ) ) {
				matched.reverse();
			}
		}

		return this.pushStack( matched );
	};
});

jQuery.extend({
	filter: function( expr, elems, not ) {
		var elem = elems[ 0 ];

		if ( not ) {
			expr = ":not(" + expr + ")";
		}

		return elems.length === 1 && elem.nodeType === 1 ?
			jQuery.find.matchesSelector( elem, expr ) ? [ elem ] : [] :
			jQuery.find.matches( expr, jQuery.grep( elems, function( elem ) {
				return elem.nodeType === 1;
			}));
	},

	dir: function( elem, dir, until ) {
		var matched = [],
			truncate = until !== undefined;

		while ( (elem = elem[ dir ]) && elem.nodeType !== 9 ) {
			if ( elem.nodeType === 1 ) {
				if ( truncate && jQuery( elem ).is( until ) ) {
					break;
				}
				matched.push( elem );
			}
		}
		return matched;
	},

	sibling: function( n, elem ) {
		var matched = [];

		for ( ; n; n = n.nextSibling ) {
			if ( n.nodeType === 1 && n !== elem ) {
				matched.push( n );
			}
		}

		return matched;
	}
});

// Implement the identical functionality for filter and not
function winnow( elements, qualifier, not ) {
	if ( jQuery.isFunction( qualifier ) ) {
		return jQuery.grep( elements, function( elem, i ) {
			/* jshint -W018 */
			return !!qualifier.call( elem, i, elem ) !== not;
		});

	}

	if ( qualifier.nodeType ) {
		return jQuery.grep( elements, function( elem ) {
			return ( elem === qualifier ) !== not;
		});

	}

	if ( typeof qualifier === "string" ) {
		if ( isSimple.test( qualifier ) ) {
			return jQuery.filter( qualifier, elements, not );
		}

		qualifier = jQuery.filter( qualifier, elements );
	}

	return jQuery.grep( elements, function( elem ) {
		return ( core_indexOf.call( qualifier, elem ) >= 0 ) !== not;
	});
}
var rxhtmlTag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
	rtagName = /<([\w:]+)/,
	rhtml = /<|&#?\w+;/,
	rnoInnerhtml = /<(?:script|style|link)/i,
	manipulation_rcheckableType = /^(?:checkbox|radio)$/i,
	// checked="checked" or checked
	rchecked = /checked\s*(?:[^=]|=\s*.checked.)/i,
	rscriptType = /^$|\/(?:java|ecma)script/i,
	rscriptTypeMasked = /^true\/(.*)/,
	rcleanScript = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,

	// We have to close these tags to support XHTML (#13200)
	wrapMap = {

		// Support: IE 9
		option: [ 1, "<select multiple='multiple'>", "</select>" ],

		thead: [ 1, "<table>", "</table>" ],
		col: [ 2, "<table><colgroup>", "</colgroup></table>" ],
		tr: [ 2, "<table><tbody>", "</tbody></table>" ],
		td: [ 3, "<table><tbody><tr>", "</tr></tbody></table>" ],

		_default: [ 0, "", "" ]
	};

// Support: IE 9
wrapMap.optgroup = wrapMap.option;

wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead;
wrapMap.th = wrapMap.td;

jQuery.fn.extend({
	text: function( value ) {
		return jQuery.access( this, function( value ) {
			return value === undefined ?
				jQuery.text( this ) :
				this.empty().append( ( this[ 0 ] && this[ 0 ].ownerDocument || document ).createTextNode( value ) );
		}, null, value, arguments.length );
	},

	append: function() {
		return this.domManip( arguments, function( elem ) {
			if ( this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9 ) {
				var target = manipulationTarget( this, elem );
				target.appendChild( elem );
			}
		});
	},

	prepend: function() {
		return this.domManip( arguments, function( elem ) {
			if ( this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9 ) {
				var target = manipulationTarget( this, elem );
				target.insertBefore( elem, target.firstChild );
			}
		});
	},

	before: function() {
		return this.domManip( arguments, function( elem ) {
			if ( this.parentNode ) {
				this.parentNode.insertBefore( elem, this );
			}
		});
	},

	after: function() {
		return this.domManip( arguments, function( elem ) {
			if ( this.parentNode ) {
				this.parentNode.insertBefore( elem, this.nextSibling );
			}
		});
	},

	// keepData is for internal use only--do not document
	remove: function( selector, keepData ) {
		var elem,
			elems = selector ? jQuery.filter( selector, this ) : this,
			i = 0;

		for ( ; (elem = elems[i]) != null; i++ ) {
			if ( !keepData && elem.nodeType === 1 ) {
				jQuery.cleanData( getAll( elem ) );
			}

			if ( elem.parentNode ) {
				if ( keepData && jQuery.contains( elem.ownerDocument, elem ) ) {
					setGlobalEval( getAll( elem, "script" ) );
				}
				elem.parentNode.removeChild( elem );
			}
		}

		return this;
	},

	empty: function() {
		var elem,
			i = 0;

		for ( ; (elem = this[i]) != null; i++ ) {
			if ( elem.nodeType === 1 ) {

				// Prevent memory leaks
				jQuery.cleanData( getAll( elem, false ) );

				// Remove any remaining nodes
				elem.textContent = "";
			}
		}

		return this;
	},

	clone: function( dataAndEvents, deepDataAndEvents ) {
		dataAndEvents = dataAndEvents == null ? false : dataAndEvents;
		deepDataAndEvents = deepDataAndEvents == null ? dataAndEvents : deepDataAndEvents;

		return this.map( function () {
			return jQuery.clone( this, dataAndEvents, deepDataAndEvents );
		});
	},

	html: function( value ) {
		return jQuery.access( this, function( value ) {
			var elem = this[ 0 ] || {},
				i = 0,
				l = this.length;

			if ( value === undefined && elem.nodeType === 1 ) {
				return elem.innerHTML;
			}

			// See if we can take a shortcut and just use innerHTML
			if ( typeof value === "string" && !rnoInnerhtml.test( value ) &&
				!wrapMap[ ( rtagName.exec( value ) || [ "", "" ] )[ 1 ].toLowerCase() ] ) {

				value = value.replace( rxhtmlTag, "<$1></$2>" );

				try {
					for ( ; i < l; i++ ) {
						elem = this[ i ] || {};

						// Remove element nodes and prevent memory leaks
						if ( elem.nodeType === 1 ) {
							jQuery.cleanData( getAll( elem, false ) );
							elem.innerHTML = value;
						}
					}

					elem = 0;

				// If using innerHTML throws an exception, use the fallback method
				} catch( e ) {}
			}

			if ( elem ) {
				this.empty().append( value );
			}
		}, null, value, arguments.length );
	},

	replaceWith: function() {
		var
			// Snapshot the DOM in case .domManip sweeps something relevant into its fragment
			args = jQuery.map( this, function( elem ) {
				return [ elem.nextSibling, elem.parentNode ];
			}),
			i = 0;

		// Make the changes, replacing each context element with the new content
		this.domManip( arguments, function( elem ) {
			var next = args[ i++ ],
				parent = args[ i++ ];

			if ( parent ) {
				// Don't use the snapshot next if it has moved (#13810)
				if ( next && next.parentNode !== parent ) {
					next = this.nextSibling;
				}
				jQuery( this ).remove();
				parent.insertBefore( elem, next );
			}
		// Allow new content to include elements from the context set
		}, true );

		// Force removal if there was no new content (e.g., from empty arguments)
		return i ? this : this.remove();
	},

	detach: function( selector ) {
		return this.remove( selector, true );
	},

	domManip: function( args, callback, allowIntersection ) {

		// Flatten any nested arrays
		args = core_concat.apply( [], args );

		var fragment, first, scripts, hasScripts, node, doc,
			i = 0,
			l = this.length,
			set = this,
			iNoClone = l - 1,
			value = args[ 0 ],
			isFunction = jQuery.isFunction( value );

		// We can't cloneNode fragments that contain checked, in WebKit
		if ( isFunction || !( l <= 1 || typeof value !== "string" || jQuery.support.checkClone || !rchecked.test( value ) ) ) {
			return this.each(function( index ) {
				var self = set.eq( index );
				if ( isFunction ) {
					args[ 0 ] = value.call( this, index, self.html() );
				}
				self.domManip( args, callback, allowIntersection );
			});
		}

		if ( l ) {
			fragment = jQuery.buildFragment( args, this[ 0 ].ownerDocument, false, !allowIntersection && this );
			first = fragment.firstChild;

			if ( fragment.childNodes.length === 1 ) {
				fragment = first;
			}

			if ( first ) {
				scripts = jQuery.map( getAll( fragment, "script" ), disableScript );
				hasScripts = scripts.length;

				// Use the original fragment for the last item instead of the first because it can end up
				// being emptied incorrectly in certain situations (#8070).
				for ( ; i < l; i++ ) {
					node = fragment;

					if ( i !== iNoClone ) {
						node = jQuery.clone( node, true, true );

						// Keep references to cloned scripts for later restoration
						if ( hasScripts ) {
							// Support: QtWebKit
							// jQuery.merge because core_push.apply(_, arraylike) throws
							jQuery.merge( scripts, getAll( node, "script" ) );
						}
					}

					callback.call( this[ i ], node, i );
				}

				if ( hasScripts ) {
					doc = scripts[ scripts.length - 1 ].ownerDocument;

					// Reenable scripts
					jQuery.map( scripts, restoreScript );

					// Evaluate executable scripts on first document insertion
					for ( i = 0; i < hasScripts; i++ ) {
						node = scripts[ i ];
						if ( rscriptType.test( node.type || "" ) &&
							!data_priv.access( node, "globalEval" ) && jQuery.contains( doc, node ) ) {

							if ( node.src ) {
								// Hope ajax is available...
								jQuery._evalUrl( node.src );
							} else {
								jQuery.globalEval( node.textContent.replace( rcleanScript, "" ) );
							}
						}
					}
				}
			}
		}

		return this;
	}
});

jQuery.each({
	appendTo: "append",
	prependTo: "prepend",
	insertBefore: "before",
	insertAfter: "after",
	replaceAll: "replaceWith"
}, function( name, original ) {
	jQuery.fn[ name ] = function( selector ) {
		var elems,
			ret = [],
			insert = jQuery( selector ),
			last = insert.length - 1,
			i = 0;

		for ( ; i <= last; i++ ) {
			elems = i === last ? this : this.clone( true );
			jQuery( insert[ i ] )[ original ]( elems );

			// Support: QtWebKit
			// .get() because core_push.apply(_, arraylike) throws
			core_push.apply( ret, elems.get() );
		}

		return this.pushStack( ret );
	};
});

jQuery.extend({
	clone: function( elem, dataAndEvents, deepDataAndEvents ) {
		var i, l, srcElements, destElements,
			clone = elem.cloneNode( true ),
			inPage = jQuery.contains( elem.ownerDocument, elem );

		// Support: IE >= 9
		// Fix Cloning issues
		if ( !jQuery.support.noCloneChecked && ( elem.nodeType === 1 || elem.nodeType === 11 ) && !jQuery.isXMLDoc( elem ) ) {

			// We eschew Sizzle here for performance reasons: http://jsperf.com/getall-vs-sizzle/2
			destElements = getAll( clone );
			srcElements = getAll( elem );

			for ( i = 0, l = srcElements.length; i < l; i++ ) {
				fixInput( srcElements[ i ], destElements[ i ] );
			}
		}

		// Copy the events from the original to the clone
		if ( dataAndEvents ) {
			if ( deepDataAndEvents ) {
				srcElements = srcElements || getAll( elem );
				destElements = destElements || getAll( clone );

				for ( i = 0, l = srcElements.length; i < l; i++ ) {
					cloneCopyEvent( srcElements[ i ], destElements[ i ] );
				}
			} else {
				cloneCopyEvent( elem, clone );
			}
		}

		// Preserve script evaluation history
		destElements = getAll( clone, "script" );
		if ( destElements.length > 0 ) {
			setGlobalEval( destElements, !inPage && getAll( elem, "script" ) );
		}

		// Return the cloned set
		return clone;
	},

	buildFragment: function( elems, context, scripts, selection ) {
		var elem, tmp, tag, wrap, contains, j,
			i = 0,
			l = elems.length,
			fragment = context.createDocumentFragment(),
			nodes = [];

		for ( ; i < l; i++ ) {
			elem = elems[ i ];

			if ( elem || elem === 0 ) {

				// Add nodes directly
				if ( jQuery.type( elem ) === "object" ) {
					// Support: QtWebKit
					// jQuery.merge because core_push.apply(_, arraylike) throws
					jQuery.merge( nodes, elem.nodeType ? [ elem ] : elem );

				// Convert non-html into a text node
				} else if ( !rhtml.test( elem ) ) {
					nodes.push( context.createTextNode( elem ) );

				// Convert html into DOM nodes
				} else {
					tmp = tmp || fragment.appendChild( context.createElement("div") );

					// Deserialize a standard representation
					tag = ( rtagName.exec( elem ) || ["", ""] )[ 1 ].toLowerCase();
					wrap = wrapMap[ tag ] || wrapMap._default;
					tmp.innerHTML = wrap[ 1 ] + elem.replace( rxhtmlTag, "<$1></$2>" ) + wrap[ 2 ];

					// Descend through wrappers to the right content
					j = wrap[ 0 ];
					while ( j-- ) {
						tmp = tmp.lastChild;
					}

					// Support: QtWebKit
					// jQuery.merge because core_push.apply(_, arraylike) throws
					jQuery.merge( nodes, tmp.childNodes );

					// Remember the top-level container
					tmp = fragment.firstChild;

					// Fixes #12346
					// Support: Webkit, IE
					tmp.textContent = "";
				}
			}
		}

		// Remove wrapper from fragment
		fragment.textContent = "";

		i = 0;
		while ( (elem = nodes[ i++ ]) ) {

			// #4087 - If origin and destination elements are the same, and this is
			// that element, do not do anything
			if ( selection && jQuery.inArray( elem, selection ) !== -1 ) {
				continue;
			}

			contains = jQuery.contains( elem.ownerDocument, elem );

			// Append to fragment
			tmp = getAll( fragment.appendChild( elem ), "script" );

			// Preserve script evaluation history
			if ( contains ) {
				setGlobalEval( tmp );
			}

			// Capture executables
			if ( scripts ) {
				j = 0;
				while ( (elem = tmp[ j++ ]) ) {
					if ( rscriptType.test( elem.type || "" ) ) {
						scripts.push( elem );
					}
				}
			}
		}

		return fragment;
	},

	cleanData: function( elems ) {
		var data, elem, events, type, key, j,
			special = jQuery.event.special,
			i = 0;

		for ( ; (elem = elems[ i ]) !== undefined; i++ ) {
			if ( Data.accepts( elem ) ) {
				key = elem[ data_priv.expando ];

				if ( key && (data = data_priv.cache[ key ]) ) {
					events = Object.keys( data.events || {} );
					if ( events.length ) {
						for ( j = 0; (type = events[j]) !== undefined; j++ ) {
							if ( special[ type ] ) {
								jQuery.event.remove( elem, type );

							// This is a shortcut to avoid jQuery.event.remove's overhead
							} else {
								jQuery.removeEvent( elem, type, data.handle );
							}
						}
					}
					if ( data_priv.cache[ key ] ) {
						// Discard any remaining `private` data
						delete data_priv.cache[ key ];
					}
				}
			}
			// Discard any remaining `user` data
			delete data_user.cache[ elem[ data_user.expando ] ];
		}
	},

	_evalUrl: function( url ) {
		return jQuery.ajax({
			url: url,
			type: "GET",
			dataType: "script",
			async: false,
			global: false,
			"throws": true
		});
	}
});

// Support: 1.x compatibility
// Manipulating tables requires a tbody
function manipulationTarget( elem, content ) {
	return jQuery.nodeName( elem, "table" ) &&
		jQuery.nodeName( content.nodeType === 1 ? content : content.firstChild, "tr" ) ?

		elem.getElementsByTagName("tbody")[0] ||
			elem.appendChild( elem.ownerDocument.createElement("tbody") ) :
		elem;
}

// Replace/restore the type attribute of script elements for safe DOM manipulation
function disableScript( elem ) {
	elem.type = (elem.getAttribute("type") !== null) + "/" + elem.type;
	return elem;
}
function restoreScript( elem ) {
	var match = rscriptTypeMasked.exec( elem.type );

	if ( match ) {
		elem.type = match[ 1 ];
	} else {
		elem.removeAttribute("type");
	}

	return elem;
}

// Mark scripts as having already been evaluated
function setGlobalEval( elems, refElements ) {
	var l = elems.length,
		i = 0;

	for ( ; i < l; i++ ) {
		data_priv.set(
			elems[ i ], "globalEval", !refElements || data_priv.get( refElements[ i ], "globalEval" )
		);
	}
}

function cloneCopyEvent( src, dest ) {
	var i, l, type, pdataOld, pdataCur, udataOld, udataCur, events;

	if ( dest.nodeType !== 1 ) {
		return;
	}

	// 1. Copy private data: events, handlers, etc.
	if ( data_priv.hasData( src ) ) {
		pdataOld = data_priv.access( src );
		pdataCur = data_priv.set( dest, pdataOld );
		events = pdataOld.events;

		if ( events ) {
			delete pdataCur.handle;
			pdataCur.events = {};

			for ( type in events ) {
				for ( i = 0, l = events[ type ].length; i < l; i++ ) {
					jQuery.event.add( dest, type, events[ type ][ i ] );
				}
			}
		}
	}

	// 2. Copy user data
	if ( data_user.hasData( src ) ) {
		udataOld = data_user.access( src );
		udataCur = jQuery.extend( {}, udataOld );

		data_user.set( dest, udataCur );
	}
}


function getAll( context, tag ) {
	var ret = context.getElementsByTagName ? context.getElementsByTagName( tag || "*" ) :
			context.querySelectorAll ? context.querySelectorAll( tag || "*" ) :
			[];

	return tag === undefined || tag && jQuery.nodeName( context, tag ) ?
		jQuery.merge( [ context ], ret ) :
		ret;
}

// Support: IE >= 9
function fixInput( src, dest ) {
	var nodeName = dest.nodeName.toLowerCase();

	// Fails to persist the checked state of a cloned checkbox or radio button.
	if ( nodeName === "input" && manipulation_rcheckableType.test( src.type ) ) {
		dest.checked = src.checked;

	// Fails to return the selected option to the default selected state when cloning options
	} else if ( nodeName === "input" || nodeName === "textarea" ) {
		dest.defaultValue = src.defaultValue;
	}
}
jQuery.fn.extend({
	wrapAll: function( html ) {
		var wrap;

		if ( jQuery.isFunction( html ) ) {
			return this.each(function( i ) {
				jQuery( this ).wrapAll( html.call(this, i) );
			});
		}

		if ( this[ 0 ] ) {

			// The elements to wrap the target around
			wrap = jQuery( html, this[ 0 ].ownerDocument ).eq( 0 ).clone( true );

			if ( this[ 0 ].parentNode ) {
				wrap.insertBefore( this[ 0 ] );
			}

			wrap.map(function() {
				var elem = this;

				while ( elem.firstElementChild ) {
					elem = elem.firstElementChild;
				}

				return elem;
			}).append( this );
		}

		return this;
	},

	wrapInner: function( html ) {
		if ( jQuery.isFunction( html ) ) {
			return this.each(function( i ) {
				jQuery( this ).wrapInner( html.call(this, i) );
			});
		}

		return this.each(function() {
			var self = jQuery( this ),
				contents = self.contents();

			if ( contents.length ) {
				contents.wrapAll( html );

			} else {
				self.append( html );
			}
		});
	},

	wrap: function( html ) {
		var isFunction = jQuery.isFunction( html );

		return this.each(function( i ) {
			jQuery( this ).wrapAll( isFunction ? html.call(this, i) : html );
		});
	},

	unwrap: function() {
		return this.parent().each(function() {
			if ( !jQuery.nodeName( this, "body" ) ) {
				jQuery( this ).replaceWith( this.childNodes );
			}
		}).end();
	}
});
var curCSS, iframe,
	// swappable if display is none or starts with table except "table", "table-cell", or "table-caption"
	// see here for display values: https://developer.mozilla.org/en-US/docs/CSS/display
	rdisplayswap = /^(none|table(?!-c[ea]).+)/,
	rmargin = /^margin/,
	rnumsplit = new RegExp( "^(" + core_pnum + ")(.*)$", "i" ),
	rnumnonpx = new RegExp( "^(" + core_pnum + ")(?!px)[a-z%]+$", "i" ),
	rrelNum = new RegExp( "^([+-])=(" + core_pnum + ")", "i" ),
	elemdisplay = { BODY: "block" },

	cssShow = { position: "absolute", visibility: "hidden", display: "block" },
	cssNormalTransform = {
		letterSpacing: 0,
		fontWeight: 400
	},

	cssExpand = [ "Top", "Right", "Bottom", "Left" ],
	cssPrefixes = [ "Webkit", "O", "Moz", "ms" ];

// return a css property mapped to a potentially vendor prefixed property
function vendorPropName( style, name ) {

	// shortcut for names that are not vendor prefixed
	if ( name in style ) {
		return name;
	}

	// check for vendor prefixed names
	var capName = name.charAt(0).toUpperCase() + name.slice(1),
		origName = name,
		i = cssPrefixes.length;

	while ( i-- ) {
		name = cssPrefixes[ i ] + capName;
		if ( name in style ) {
			return name;
		}
	}

	return origName;
}

function isHidden( elem, el ) {
	// isHidden might be called from jQuery#filter function;
	// in that case, element will be second argument
	elem = el || elem;
	return jQuery.css( elem, "display" ) === "none" || !jQuery.contains( elem.ownerDocument, elem );
}

// NOTE: we've included the "window" in window.getComputedStyle
// because jsdom on node.js will break without it.
function getStyles( elem ) {
	return window.getComputedStyle( elem, null );
}

function showHide( elements, show ) {
	var display, elem, hidden,
		values = [],
		index = 0,
		length = elements.length;

	for ( ; index < length; index++ ) {
		elem = elements[ index ];
		if ( !elem.style ) {
			continue;
		}

		values[ index ] = data_priv.get( elem, "olddisplay" );
		display = elem.style.display;
		if ( show ) {
			// Reset the inline display of this element to learn if it is
			// being hidden by cascaded rules or not
			if ( !values[ index ] && display === "none" ) {
				elem.style.display = "";
			}

			// Set elements which have been overridden with display: none
			// in a stylesheet to whatever the default browser style is
			// for such an element
			if ( elem.style.display === "" && isHidden( elem ) ) {
				values[ index ] = data_priv.access( elem, "olddisplay", css_defaultDisplay(elem.nodeName) );
			}
		} else {

			if ( !values[ index ] ) {
				hidden = isHidden( elem );

				if ( display && display !== "none" || !hidden ) {
					data_priv.set( elem, "olddisplay", hidden ? display : jQuery.css(elem, "display") );
				}
			}
		}
	}

	// Set the display of most of the elements in a second loop
	// to avoid the constant reflow
	for ( index = 0; index < length; index++ ) {
		elem = elements[ index ];
		if ( !elem.style ) {
			continue;
		}
		if ( !show || elem.style.display === "none" || elem.style.display === "" ) {
			elem.style.display = show ? values[ index ] || "" : "none";
		}
	}

	return elements;
}

jQuery.fn.extend({
	css: function( name, value ) {
		return jQuery.access( this, function( elem, name, value ) {
			var styles, len,
				map = {},
				i = 0;

			if ( jQuery.isArray( name ) ) {
				styles = getStyles( elem );
				len = name.length;

				for ( ; i < len; i++ ) {
					map[ name[ i ] ] = jQuery.css( elem, name[ i ], false, styles );
				}

				return map;
			}

			return value !== undefined ?
				jQuery.style( elem, name, value ) :
				jQuery.css( elem, name );
		}, name, value, arguments.length > 1 );
	},
	show: function() {
		return showHide( this, true );
	},
	hide: function() {
		return showHide( this );
	},
	toggle: function( state ) {
		if ( typeof state === "boolean" ) {
			return state ? this.show() : this.hide();
		}

		return this.each(function() {
			if ( isHidden( this ) ) {
				jQuery( this ).show();
			} else {
				jQuery( this ).hide();
			}
		});
	}
});

jQuery.extend({
	// Add in style property hooks for overriding the default
	// behavior of getting and setting a style property
	cssHooks: {
		opacity: {
			get: function( elem, computed ) {
				if ( computed ) {
					// We should always get a number back from opacity
					var ret = curCSS( elem, "opacity" );
					return ret === "" ? "1" : ret;
				}
			}
		}
	},

	// Don't automatically add "px" to these possibly-unitless properties
	cssNumber: {
		"columnCount": true,
		"fillOpacity": true,
		"fontWeight": true,
		"lineHeight": true,
		"opacity": true,
		"order": true,
		"orphans": true,
		"widows": true,
		"zIndex": true,
		"zoom": true
	},

	// Add in properties whose names you wish to fix before
	// setting or getting the value
	cssProps: {
		// normalize float css property
		"float": "cssFloat"
	},

	// Get and set the style property on a DOM Node
	style: function( elem, name, value, extra ) {
		// Don't set styles on text and comment nodes
		if ( !elem || elem.nodeType === 3 || elem.nodeType === 8 || !elem.style ) {
			return;
		}

		// Make sure that we're working with the right name
		var ret, type, hooks,
			origName = jQuery.camelCase( name ),
			style = elem.style;

		name = jQuery.cssProps[ origName ] || ( jQuery.cssProps[ origName ] = vendorPropName( style, origName ) );

		// gets hook for the prefixed version
		// followed by the unprefixed version
		hooks = jQuery.cssHooks[ name ] || jQuery.cssHooks[ origName ];

		// Check if we're setting a value
		if ( value !== undefined ) {
			type = typeof value;

			// convert relative number strings (+= or -=) to relative numbers. #7345
			if ( type === "string" && (ret = rrelNum.exec( value )) ) {
				value = ( ret[1] + 1 ) * ret[2] + parseFloat( jQuery.css( elem, name ) );
				// Fixes bug #9237
				type = "number";
			}

			// Make sure that NaN and null values aren't set. See: #7116
			if ( value == null || type === "number" && isNaN( value ) ) {
				return;
			}

			// If a number was passed in, add 'px' to the (except for certain CSS properties)
			if ( type === "number" && !jQuery.cssNumber[ origName ] ) {
				value += "px";
			}

			// Fixes #8908, it can be done more correctly by specifying setters in cssHooks,
			// but it would mean to define eight (for every problematic property) identical functions
			if ( !jQuery.support.clearCloneStyle && value === "" && name.indexOf("background") === 0 ) {
				style[ name ] = "inherit";
			}

			// If a hook was provided, use that value, otherwise just set the specified value
			if ( !hooks || !("set" in hooks) || (value = hooks.set( elem, value, extra )) !== undefined ) {
				style[ name ] = value;
			}

		} else {
			// If a hook was provided get the non-computed value from there
			if ( hooks && "get" in hooks && (ret = hooks.get( elem, false, extra )) !== undefined ) {
				return ret;
			}

			// Otherwise just get the value from the style object
			return style[ name ];
		}
	},

	css: function( elem, name, extra, styles ) {
		var val, num, hooks,
			origName = jQuery.camelCase( name );

		// Make sure that we're working with the right name
		name = jQuery.cssProps[ origName ] || ( jQuery.cssProps[ origName ] = vendorPropName( elem.style, origName ) );

		// gets hook for the prefixed version
		// followed by the unprefixed version
		hooks = jQuery.cssHooks[ name ] || jQuery.cssHooks[ origName ];

		// If a hook was provided get the computed value from there
		if ( hooks && "get" in hooks ) {
			val = hooks.get( elem, true, extra );
		}

		// Otherwise, if a way to get the computed value exists, use that
		if ( val === undefined ) {
			val = curCSS( elem, name, styles );
		}

		//convert "normal" to computed value
		if ( val === "normal" && name in cssNormalTransform ) {
			val = cssNormalTransform[ name ];
		}

		// Return, converting to number if forced or a qualifier was provided and val looks numeric
		if ( extra === "" || extra ) {
			num = parseFloat( val );
			return extra === true || jQuery.isNumeric( num ) ? num || 0 : val;
		}
		return val;
	}
});

curCSS = function( elem, name, _computed ) {
	var width, minWidth, maxWidth,
		computed = _computed || getStyles( elem ),

		// Support: IE9
		// getPropertyValue is only needed for .css('filter') in IE9, see #12537
		ret = computed ? computed.getPropertyValue( name ) || computed[ name ] : undefined,
		style = elem.style;

	if ( computed ) {

		if ( ret === "" && !jQuery.contains( elem.ownerDocument, elem ) ) {
			ret = jQuery.style( elem, name );
		}

		// Support: Safari 5.1
		// A tribute to the "awesome hack by Dean Edwards"
		// Safari 5.1.7 (at least) returns percentage for a larger set of values, but width seems to be reliably pixels
		// this is against the CSSOM draft spec: http://dev.w3.org/csswg/cssom/#resolved-values
		if ( rnumnonpx.test( ret ) && rmargin.test( name ) ) {

			// Remember the original values
			width = style.width;
			minWidth = style.minWidth;
			maxWidth = style.maxWidth;

			// Put in the new values to get a computed value out
			style.minWidth = style.maxWidth = style.width = ret;
			ret = computed.width;

			// Revert the changed values
			style.width = width;
			style.minWidth = minWidth;
			style.maxWidth = maxWidth;
		}
	}

	return ret;
};


function setPositiveNumber( elem, value, subtract ) {
	var matches = rnumsplit.exec( value );
	return matches ?
		// Guard against undefined "subtract", e.g., when used as in cssHooks
		Math.max( 0, matches[ 1 ] - ( subtract || 0 ) ) + ( matches[ 2 ] || "px" ) :
		value;
}

function augmentWidthOrHeight( elem, name, extra, isBorderBox, styles ) {
	var i = extra === ( isBorderBox ? "border" : "content" ) ?
		// If we already have the right measurement, avoid augmentation
		4 :
		// Otherwise initialize for horizontal or vertical properties
		name === "width" ? 1 : 0,

		val = 0;

	for ( ; i < 4; i += 2 ) {
		// both box models exclude margin, so add it if we want it
		if ( extra === "margin" ) {
			val += jQuery.css( elem, extra + cssExpand[ i ], true, styles );
		}

		if ( isBorderBox ) {
			// border-box includes padding, so remove it if we want content
			if ( extra === "content" ) {
				val -= jQuery.css( elem, "padding" + cssExpand[ i ], true, styles );
			}

			// at this point, extra isn't border nor margin, so remove border
			if ( extra !== "margin" ) {
				val -= jQuery.css( elem, "border" + cssExpand[ i ] + "Width", true, styles );
			}
		} else {
			// at this point, extra isn't content, so add padding
			val += jQuery.css( elem, "padding" + cssExpand[ i ], true, styles );

			// at this point, extra isn't content nor padding, so add border
			if ( extra !== "padding" ) {
				val += jQuery.css( elem, "border" + cssExpand[ i ] + "Width", true, styles );
			}
		}
	}

	return val;
}

function getWidthOrHeight( elem, name, extra ) {

	// Start with offset property, which is equivalent to the border-box value
	var valueIsBorderBox = true,
		val = name === "width" ? elem.offsetWidth : elem.offsetHeight,
		styles = getStyles( elem ),
		isBorderBox = jQuery.support.boxSizing && jQuery.css( elem, "boxSizing", false, styles ) === "border-box";

	// some non-html elements return undefined for offsetWidth, so check for null/undefined
	// svg - https://bugzilla.mozilla.org/show_bug.cgi?id=649285
	// MathML - https://bugzilla.mozilla.org/show_bug.cgi?id=491668
	if ( val <= 0 || val == null ) {
		// Fall back to computed then uncomputed css if necessary
		val = curCSS( elem, name, styles );
		if ( val < 0 || val == null ) {
			val = elem.style[ name ];
		}

		// Computed unit is not pixels. Stop here and return.
		if ( rnumnonpx.test(val) ) {
			return val;
		}

		// we need the check for style in case a browser which returns unreliable values
		// for getComputedStyle silently falls back to the reliable elem.style
		valueIsBorderBox = isBorderBox && ( jQuery.support.boxSizingReliable || val === elem.style[ name ] );

		// Normalize "", auto, and prepare for extra
		val = parseFloat( val ) || 0;
	}

	// use the active box-sizing model to add/subtract irrelevant styles
	return ( val +
		augmentWidthOrHeight(
			elem,
			name,
			extra || ( isBorderBox ? "border" : "content" ),
			valueIsBorderBox,
			styles
		)
	) + "px";
}

// Try to determine the default display value of an element
function css_defaultDisplay( nodeName ) {
	var doc = document,
		display = elemdisplay[ nodeName ];

	if ( !display ) {
		display = actualDisplay( nodeName, doc );

		// If the simple way fails, read from inside an iframe
		if ( display === "none" || !display ) {
			// Use the already-created iframe if possible
			iframe = ( iframe ||
				jQuery("<iframe frameborder='0' width='0' height='0'/>")
				.css( "cssText", "display:block !important" )
			).appendTo( doc.documentElement );

			// Always write a new HTML skeleton so Webkit and Firefox don't choke on reuse
			doc = ( iframe[0].contentWindow || iframe[0].contentDocument ).document;
			doc.write("<!doctype html><html><body>");
			doc.close();

			display = actualDisplay( nodeName, doc );
			iframe.detach();
		}

		// Store the correct default display
		elemdisplay[ nodeName ] = display;
	}

	return display;
}

// Called ONLY from within css_defaultDisplay
function actualDisplay( name, doc ) {
	var elem = jQuery( doc.createElement( name ) ).appendTo( doc.body ),
		display = jQuery.css( elem[0], "display" );
	elem.remove();
	return display;
}

jQuery.each([ "height", "width" ], function( i, name ) {
	jQuery.cssHooks[ name ] = {
		get: function( elem, computed, extra ) {
			if ( computed ) {
				// certain elements can have dimension info if we invisibly show them
				// however, it must have a current display style that would benefit from this
				return elem.offsetWidth === 0 && rdisplayswap.test( jQuery.css( elem, "display" ) ) ?
					jQuery.swap( elem, cssShow, function() {
						return getWidthOrHeight( elem, name, extra );
					}) :
					getWidthOrHeight( elem, name, extra );
			}
		},

		set: function( elem, value, extra ) {
			var styles = extra && getStyles( elem );
			return setPositiveNumber( elem, value, extra ?
				augmentWidthOrHeight(
					elem,
					name,
					extra,
					jQuery.support.boxSizing && jQuery.css( elem, "boxSizing", false, styles ) === "border-box",
					styles
				) : 0
			);
		}
	};
});

// These hooks cannot be added until DOM ready because the support test
// for it is not run until after DOM ready
jQuery(function() {
	// Support: Android 2.3
	if ( !jQuery.support.reliableMarginRight ) {
		jQuery.cssHooks.marginRight = {
			get: function( elem, computed ) {
				if ( computed ) {
					// Support: Android 2.3
					// WebKit Bug 13343 - getComputedStyle returns wrong value for margin-right
					// Work around by temporarily setting element display to inline-block
					return jQuery.swap( elem, { "display": "inline-block" },
						curCSS, [ elem, "marginRight" ] );
				}
			}
		};
	}

	// Webkit bug: https://bugs.webkit.org/show_bug.cgi?id=29084
	// getComputedStyle returns percent when specified for top/left/bottom/right
	// rather than make the css module depend on the offset module, we just check for it here
	if ( !jQuery.support.pixelPosition && jQuery.fn.position ) {
		jQuery.each( [ "top", "left" ], function( i, prop ) {
			jQuery.cssHooks[ prop ] = {
				get: function( elem, computed ) {
					if ( computed ) {
						computed = curCSS( elem, prop );
						// if curCSS returns percentage, fallback to offset
						return rnumnonpx.test( computed ) ?
							jQuery( elem ).position()[ prop ] + "px" :
							computed;
					}
				}
			};
		});
	}

});

if ( jQuery.expr && jQuery.expr.filters ) {
	jQuery.expr.filters.hidden = function( elem ) {
		// Support: Opera <= 12.12
		// Opera reports offsetWidths and offsetHeights less than zero on some elements
		return elem.offsetWidth <= 0 && elem.offsetHeight <= 0;
	};

	jQuery.expr.filters.visible = function( elem ) {
		return !jQuery.expr.filters.hidden( elem );
	};
}

// These hooks are used by animate to expand properties
jQuery.each({
	margin: "",
	padding: "",
	border: "Width"
}, function( prefix, suffix ) {
	jQuery.cssHooks[ prefix + suffix ] = {
		expand: function( value ) {
			var i = 0,
				expanded = {},

				// assumes a single number if not a string
				parts = typeof value === "string" ? value.split(" ") : [ value ];

			for ( ; i < 4; i++ ) {
				expanded[ prefix + cssExpand[ i ] + suffix ] =
					parts[ i ] || parts[ i - 2 ] || parts[ 0 ];
			}

			return expanded;
		}
	};

	if ( !rmargin.test( prefix ) ) {
		jQuery.cssHooks[ prefix + suffix ].set = setPositiveNumber;
	}
});
var r20 = /%20/g,
	rbracket = /\[\]$/,
	rCRLF = /\r?\n/g,
	rsubmitterTypes = /^(?:submit|button|image|reset|file)$/i,
	rsubmittable = /^(?:input|select|textarea|keygen)/i;

jQuery.fn.extend({
	serialize: function() {
		return jQuery.param( this.serializeArray() );
	},
	serializeArray: function() {
		return this.map(function(){
			// Can add propHook for "elements" to filter or add form elements
			var elements = jQuery.prop( this, "elements" );
			return elements ? jQuery.makeArray( elements ) : this;
		})
		.filter(function(){
			var type = this.type;
			// Use .is(":disabled") so that fieldset[disabled] works
			return this.name && !jQuery( this ).is( ":disabled" ) &&
				rsubmittable.test( this.nodeName ) && !rsubmitterTypes.test( type ) &&
				( this.checked || !manipulation_rcheckableType.test( type ) );
		})
		.map(function( i, elem ){
			var val = jQuery( this ).val();

			return val == null ?
				null :
				jQuery.isArray( val ) ?
					jQuery.map( val, function( val ){
						return { name: elem.name, value: val.replace( rCRLF, "\r\n" ) };
					}) :
					{ name: elem.name, value: val.replace( rCRLF, "\r\n" ) };
		}).get();
	}
});

//Serialize an array of form elements or a set of
//key/values into a query string
jQuery.param = function( a, traditional ) {
	var prefix,
		s = [],
		add = function( key, value ) {
			// If value is a function, invoke it and return its value
			value = jQuery.isFunction( value ) ? value() : ( value == null ? "" : value );
			s[ s.length ] = encodeURIComponent( key ) + "=" + encodeURIComponent( value );
		};

	// Set traditional to true for jQuery <= 1.3.2 behavior.
	if ( traditional === undefined ) {
		traditional = jQuery.ajaxSettings && jQuery.ajaxSettings.traditional;
	}

	// If an array was passed in, assume that it is an array of form elements.
	if ( jQuery.isArray( a ) || ( a.jquery && !jQuery.isPlainObject( a ) ) ) {
		// Serialize the form elements
		jQuery.each( a, function() {
			add( this.name, this.value );
		});

	} else {
		// If traditional, encode the "old" way (the way 1.3.2 or older
		// did it), otherwise encode params recursively.
		for ( prefix in a ) {
			buildParams( prefix, a[ prefix ], traditional, add );
		}
	}

	// Return the resulting serialization
	return s.join( "&" ).replace( r20, "+" );
};

function buildParams( prefix, obj, traditional, add ) {
	var name;

	if ( jQuery.isArray( obj ) ) {
		// Serialize array item.
		jQuery.each( obj, function( i, v ) {
			if ( traditional || rbracket.test( prefix ) ) {
				// Treat each array item as a scalar.
				add( prefix, v );

			} else {
				// Item is non-scalar (array or object), encode its numeric index.
				buildParams( prefix + "[" + ( typeof v === "object" ? i : "" ) + "]", v, traditional, add );
			}
		});

	} else if ( !traditional && jQuery.type( obj ) === "object" ) {
		// Serialize object item.
		for ( name in obj ) {
			buildParams( prefix + "[" + name + "]", obj[ name ], traditional, add );
		}

	} else {
		// Serialize scalar item.
		add( prefix, obj );
	}
}
jQuery.each( ("blur focus focusin focusout load resize scroll unload click dblclick " +
	"mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave " +
	"change select submit keydown keypress keyup error contextmenu").split(" "), function( i, name ) {

	// Handle event binding
	jQuery.fn[ name ] = function( data, fn ) {
		return arguments.length > 0 ?
			this.on( name, null, data, fn ) :
			this.trigger( name );
	};
});

jQuery.fn.extend({
	hover: function( fnOver, fnOut ) {
		return this.mouseenter( fnOver ).mouseleave( fnOut || fnOver );
	},

	bind: function( types, data, fn ) {
		return this.on( types, null, data, fn );
	},
	unbind: function( types, fn ) {
		return this.off( types, null, fn );
	},

	delegate: function( selector, types, data, fn ) {
		return this.on( types, selector, data, fn );
	},
	undelegate: function( selector, types, fn ) {
		// ( namespace ) or ( selector, types [, fn] )
		return arguments.length === 1 ? this.off( selector, "**" ) : this.off( types, selector || "**", fn );
	}
});
var
	// Document location
	ajaxLocParts,
	ajaxLocation,

	ajax_nonce = jQuery.now(),

	ajax_rquery = /\?/,
	rhash = /#.*$/,
	rts = /([?&])_=[^&]*/,
	rheaders = /^(.*?):[ \t]*([^\r\n]*)$/mg,
	// #7653, #8125, #8152: local protocol detection
	rlocalProtocol = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
	rnoContent = /^(?:GET|HEAD)$/,
	rprotocol = /^\/\//,
	rurl = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,

	// Keep a copy of the old load method
	_load = jQuery.fn.load,

	/* Prefilters
	 * 1) They are useful to introduce custom dataTypes (see ajax/jsonp.js for an example)
	 * 2) These are called:
	 *    - BEFORE asking for a transport
	 *    - AFTER param serialization (s.data is a string if s.processData is true)
	 * 3) key is the dataType
	 * 4) the catchall symbol "*" can be used
	 * 5) execution will start with transport dataType and THEN continue down to "*" if needed
	 */
	prefilters = {},

	/* Transports bindings
	 * 1) key is the dataType
	 * 2) the catchall symbol "*" can be used
	 * 3) selection will start with transport dataType and THEN go to "*" if needed
	 */
	transports = {},

	// Avoid comment-prolog char sequence (#10098); must appease lint and evade compression
	allTypes = "*/".concat("*");

// #8138, IE may throw an exception when accessing
// a field from window.location if document.domain has been set
try {
	ajaxLocation = location.href;
} catch( e ) {
	// Use the href attribute of an A element
	// since IE will modify it given document.location
	ajaxLocation = document.createElement( "a" );
	ajaxLocation.href = "";
	ajaxLocation = ajaxLocation.href;
}

// Segment location into parts
ajaxLocParts = rurl.exec( ajaxLocation.toLowerCase() ) || [];

// Base "constructor" for jQuery.ajaxPrefilter and jQuery.ajaxTransport
function addToPrefiltersOrTransports( structure ) {

	// dataTypeExpression is optional and defaults to "*"
	return function( dataTypeExpression, func ) {

		if ( typeof dataTypeExpression !== "string" ) {
			func = dataTypeExpression;
			dataTypeExpression = "*";
		}

		var dataType,
			i = 0,
			dataTypes = dataTypeExpression.toLowerCase().match( core_rnotwhite ) || [];

		if ( jQuery.isFunction( func ) ) {
			// For each dataType in the dataTypeExpression
			while ( (dataType = dataTypes[i++]) ) {
				// Prepend if requested
				if ( dataType[0] === "+" ) {
					dataType = dataType.slice( 1 ) || "*";
					(structure[ dataType ] = structure[ dataType ] || []).unshift( func );

				// Otherwise append
				} else {
					(structure[ dataType ] = structure[ dataType ] || []).push( func );
				}
			}
		}
	};
}

// Base inspection function for prefilters and transports
function inspectPrefiltersOrTransports( structure, options, originalOptions, jqXHR ) {

	var inspected = {},
		seekingTransport = ( structure === transports );

	function inspect( dataType ) {
		var selected;
		inspected[ dataType ] = true;
		jQuery.each( structure[ dataType ] || [], function( _, prefilterOrFactory ) {
			var dataTypeOrTransport = prefilterOrFactory( options, originalOptions, jqXHR );
			if( typeof dataTypeOrTransport === "string" && !seekingTransport && !inspected[ dataTypeOrTransport ] ) {
				options.dataTypes.unshift( dataTypeOrTransport );
				inspect( dataTypeOrTransport );
				return false;
			} else if ( seekingTransport ) {
				return !( selected = dataTypeOrTransport );
			}
		});
		return selected;
	}

	return inspect( options.dataTypes[ 0 ] ) || !inspected[ "*" ] && inspect( "*" );
}

// A special extend for ajax options
// that takes "flat" options (not to be deep extended)
// Fixes #9887
function ajaxExtend( target, src ) {
	var key, deep,
		flatOptions = jQuery.ajaxSettings.flatOptions || {};

	for ( key in src ) {
		if ( src[ key ] !== undefined ) {
			( flatOptions[ key ] ? target : ( deep || (deep = {}) ) )[ key ] = src[ key ];
		}
	}
	if ( deep ) {
		jQuery.extend( true, target, deep );
	}

	return target;
}

jQuery.fn.load = function( url, params, callback ) {
	if ( typeof url !== "string" && _load ) {
		return _load.apply( this, arguments );
	}

	var selector, type, response,
		self = this,
		off = url.indexOf(" ");

	if ( off >= 0 ) {
		selector = url.slice( off );
		url = url.slice( 0, off );
	}

	// If it's a function
	if ( jQuery.isFunction( params ) ) {

		// We assume that it's the callback
		callback = params;
		params = undefined;

	// Otherwise, build a param string
	} else if ( params && typeof params === "object" ) {
		type = "POST";
	}

	// If we have elements to modify, make the request
	if ( self.length > 0 ) {
		jQuery.ajax({
			url: url,

			// if "type" variable is undefined, then "GET" method will be used
			type: type,
			dataType: "html",
			data: params
		}).done(function( responseText ) {

			// Save response for use in complete callback
			response = arguments;

			self.html( selector ?

				// If a selector was specified, locate the right elements in a dummy div
				// Exclude scripts to avoid IE 'Permission Denied' errors
				jQuery("<div>").append( jQuery.parseHTML( responseText ) ).find( selector ) :

				// Otherwise use the full result
				responseText );

		}).complete( callback && function( jqXHR, status ) {
			self.each( callback, response || [ jqXHR.responseText, status, jqXHR ] );
		});
	}

	return this;
};

// Attach a bunch of functions for handling common AJAX events
jQuery.each( [ "ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend" ], function( i, type ){
	jQuery.fn[ type ] = function( fn ){
		return this.on( type, fn );
	};
});

jQuery.extend({

	// Counter for holding the number of active queries
	active: 0,

	// Last-Modified header cache for next request
	lastModified: {},
	etag: {},

	ajaxSettings: {
		url: ajaxLocation,
		type: "GET",
		isLocal: rlocalProtocol.test( ajaxLocParts[ 1 ] ),
		global: true,
		processData: true,
		async: true,
		contentType: "application/x-www-form-urlencoded; charset=UTF-8",
		/*
		timeout: 0,
		data: null,
		dataType: null,
		username: null,
		password: null,
		cache: null,
		throws: false,
		traditional: false,
		headers: {},
		*/

		accepts: {
			"*": allTypes,
			text: "text/plain",
			html: "text/html",
			xml: "application/xml, text/xml",
			json: "application/json, text/javascript"
		},

		contents: {
			xml: /xml/,
			html: /html/,
			json: /json/
		},

		responseFields: {
			xml: "responseXML",
			text: "responseText",
			json: "responseJSON"
		},

		// Data converters
		// Keys separate source (or catchall "*") and destination types with a single space
		converters: {

			// Convert anything to text
			"* text": String,

			// Text to html (true = no transformation)
			"text html": true,

			// Evaluate text as a json expression
			"text json": jQuery.parseJSON,

			// Parse text as xml
			"text xml": jQuery.parseXML
		},

		// For options that shouldn't be deep extended:
		// you can add your own custom options here if
		// and when you create one that shouldn't be
		// deep extended (see ajaxExtend)
		flatOptions: {
			url: true,
			context: true
		}
	},

	// Creates a full fledged settings object into target
	// with both ajaxSettings and settings fields.
	// If target is omitted, writes into ajaxSettings.
	ajaxSetup: function( target, settings ) {
		return settings ?

			// Building a settings object
			ajaxExtend( ajaxExtend( target, jQuery.ajaxSettings ), settings ) :

			// Extending ajaxSettings
			ajaxExtend( jQuery.ajaxSettings, target );
	},

	ajaxPrefilter: addToPrefiltersOrTransports( prefilters ),
	ajaxTransport: addToPrefiltersOrTransports( transports ),

	// Main method
	ajax: function( url, options ) {

		// If url is an object, simulate pre-1.5 signature
		if ( typeof url === "object" ) {
			options = url;
			url = undefined;
		}

		// Force options to be an object
		options = options || {};

		var transport,
			// URL without anti-cache param
			cacheURL,
			// Response headers
			responseHeadersString,
			responseHeaders,
			// timeout handle
			timeoutTimer,
			// Cross-domain detection vars
			parts,
			// To know if global events are to be dispatched
			fireGlobals,
			// Loop variable
			i,
			// Create the final options object
			s = jQuery.ajaxSetup( {}, options ),
			// Callbacks context
			callbackContext = s.context || s,
			// Context for global events is callbackContext if it is a DOM node or jQuery collection
			globalEventContext = s.context && ( callbackContext.nodeType || callbackContext.jquery ) ?
				jQuery( callbackContext ) :
				jQuery.event,
			// Deferreds
			deferred = jQuery.Deferred(),
			completeDeferred = jQuery.Callbacks("once memory"),
			// Status-dependent callbacks
			statusCode = s.statusCode || {},
			// Headers (they are sent all at once)
			requestHeaders = {},
			requestHeadersNames = {},
			// The jqXHR state
			state = 0,
			// Default abort message
			strAbort = "canceled",
			// Fake xhr
			jqXHR = {
				readyState: 0,

				// Builds headers hashtable if needed
				getResponseHeader: function( key ) {
					var match;
					if ( state === 2 ) {
						if ( !responseHeaders ) {
							responseHeaders = {};
							while ( (match = rheaders.exec( responseHeadersString )) ) {
								responseHeaders[ match[1].toLowerCase() ] = match[ 2 ];
							}
						}
						match = responseHeaders[ key.toLowerCase() ];
					}
					return match == null ? null : match;
				},

				// Raw string
				getAllResponseHeaders: function() {
					return state === 2 ? responseHeadersString : null;
				},

				// Caches the header
				setRequestHeader: function( name, value ) {
					var lname = name.toLowerCase();
					if ( !state ) {
						name = requestHeadersNames[ lname ] = requestHeadersNames[ lname ] || name;
						requestHeaders[ name ] = value;
					}
					return this;
				},

				// Overrides response content-type header
				overrideMimeType: function( type ) {
					if ( !state ) {
						s.mimeType = type;
					}
					return this;
				},

				// Status-dependent callbacks
				statusCode: function( map ) {
					var code;
					if ( map ) {
						if ( state < 2 ) {
							for ( code in map ) {
								// Lazy-add the new callback in a way that preserves old ones
								statusCode[ code ] = [ statusCode[ code ], map[ code ] ];
							}
						} else {
							// Execute the appropriate callbacks
							jqXHR.always( map[ jqXHR.status ] );
						}
					}
					return this;
				},

				// Cancel the request
				abort: function( statusText ) {
					var finalText = statusText || strAbort;
					if ( transport ) {
						transport.abort( finalText );
					}
					done( 0, finalText );
					return this;
				}
			};

		// Attach deferreds
		deferred.promise( jqXHR ).complete = completeDeferred.add;
		jqXHR.success = jqXHR.done;
		jqXHR.error = jqXHR.fail;

		// Remove hash character (#7531: and string promotion)
		// Add protocol if not provided (prefilters might expect it)
		// Handle falsy url in the settings object (#10093: consistency with old signature)
		// We also use the url parameter if available
		s.url = ( ( url || s.url || ajaxLocation ) + "" ).replace( rhash, "" )
			.replace( rprotocol, ajaxLocParts[ 1 ] + "//" );

		// Alias method option to type as per ticket #12004
		s.type = options.method || options.type || s.method || s.type;

		// Extract dataTypes list
		s.dataTypes = jQuery.trim( s.dataType || "*" ).toLowerCase().match( core_rnotwhite ) || [""];

		// A cross-domain request is in order when we have a protocol:host:port mismatch
		if ( s.crossDomain == null ) {
			parts = rurl.exec( s.url.toLowerCase() );
			s.crossDomain = !!( parts &&
				( parts[ 1 ] !== ajaxLocParts[ 1 ] || parts[ 2 ] !== ajaxLocParts[ 2 ] ||
					( parts[ 3 ] || ( parts[ 1 ] === "http:" ? "80" : "443" ) ) !==
						( ajaxLocParts[ 3 ] || ( ajaxLocParts[ 1 ] === "http:" ? "80" : "443" ) ) )
			);
		}

		// Convert data if not already a string
		if ( s.data && s.processData && typeof s.data !== "string" ) {
			s.data = jQuery.param( s.data, s.traditional );
		}

		// Apply prefilters
		inspectPrefiltersOrTransports( prefilters, s, options, jqXHR );

		// If request was aborted inside a prefilter, stop there
		if ( state === 2 ) {
			return jqXHR;
		}

		// We can fire global events as of now if asked to
		fireGlobals = s.global;

		// Watch for a new set of requests
		if ( fireGlobals && jQuery.active++ === 0 ) {
			jQuery.event.trigger("ajaxStart");
		}

		// Uppercase the type
		s.type = s.type.toUpperCase();

		// Determine if request has content
		s.hasContent = !rnoContent.test( s.type );

		// Save the URL in case we're toying with the If-Modified-Since
		// and/or If-None-Match header later on
		cacheURL = s.url;

		// More options handling for requests with no content
		if ( !s.hasContent ) {

			// If data is available, append data to url
			if ( s.data ) {
				cacheURL = ( s.url += ( ajax_rquery.test( cacheURL ) ? "&" : "?" ) + s.data );
				// #9682: remove data so that it's not used in an eventual retry
				delete s.data;
			}

			// Add anti-cache in url if needed
			if ( s.cache === false ) {
				s.url = rts.test( cacheURL ) ?

					// If there is already a '_' parameter, set its value
					cacheURL.replace( rts, "$1_=" + ajax_nonce++ ) :

					// Otherwise add one to the end
					cacheURL + ( ajax_rquery.test( cacheURL ) ? "&" : "?" ) + "_=" + ajax_nonce++;
			}
		}

		// Set the If-Modified-Since and/or If-None-Match header, if in ifModified mode.
		if ( s.ifModified ) {
			if ( jQuery.lastModified[ cacheURL ] ) {
				jqXHR.setRequestHeader( "If-Modified-Since", jQuery.lastModified[ cacheURL ] );
			}
			if ( jQuery.etag[ cacheURL ] ) {
				jqXHR.setRequestHeader( "If-None-Match", jQuery.etag[ cacheURL ] );
			}
		}

		// Set the correct header, if data is being sent
		if ( s.data && s.hasContent && s.contentType !== false || options.contentType ) {
			jqXHR.setRequestHeader( "Content-Type", s.contentType );
		}

		// Set the Accepts header for the server, depending on the dataType
		jqXHR.setRequestHeader(
			"Accept",
			s.dataTypes[ 0 ] && s.accepts[ s.dataTypes[0] ] ?
				s.accepts[ s.dataTypes[0] ] + ( s.dataTypes[ 0 ] !== "*" ? ", " + allTypes + "; q=0.01" : "" ) :
				s.accepts[ "*" ]
		);

		// Check for headers option
		for ( i in s.headers ) {
			jqXHR.setRequestHeader( i, s.headers[ i ] );
		}

		// Allow custom headers/mimetypes and early abort
		if ( s.beforeSend && ( s.beforeSend.call( callbackContext, jqXHR, s ) === false || state === 2 ) ) {
			// Abort if not done already and return
			return jqXHR.abort();
		}

		// aborting is no longer a cancellation
		strAbort = "abort";

		// Install callbacks on deferreds
		for ( i in { success: 1, error: 1, complete: 1 } ) {
			jqXHR[ i ]( s[ i ] );
		}

		// Get transport
		transport = inspectPrefiltersOrTransports( transports, s, options, jqXHR );

		// If no transport, we auto-abort
		if ( !transport ) {
			done( -1, "No Transport" );
		} else {
			jqXHR.readyState = 1;

			// Send global event
			if ( fireGlobals ) {
				globalEventContext.trigger( "ajaxSend", [ jqXHR, s ] );
			}
			// Timeout
			if ( s.async && s.timeout > 0 ) {
				timeoutTimer = setTimeout(function() {
					jqXHR.abort("timeout");
				}, s.timeout );
			}

			try {
				state = 1;
				transport.send( requestHeaders, done );
			} catch ( e ) {
				// Propagate exception as error if not done
				if ( state < 2 ) {
					done( -1, e );
				// Simply rethrow otherwise
				} else {
					throw e;
				}
			}
		}

		// Callback for when everything is done
		function done( status, nativeStatusText, responses, headers ) {
			var isSuccess, success, error, response, modified,
				statusText = nativeStatusText;

			// Called once
			if ( state === 2 ) {
				return;
			}

			// State is "done" now
			state = 2;

			// Clear timeout if it exists
			if ( timeoutTimer ) {
				clearTimeout( timeoutTimer );
			}

			// Dereference transport for early garbage collection
			// (no matter how long the jqXHR object will be used)
			transport = undefined;

			// Cache response headers
			responseHeadersString = headers || "";

			// Set readyState
			jqXHR.readyState = status > 0 ? 4 : 0;

			// Determine if successful
			isSuccess = status >= 200 && status < 300 || status === 304;

			// Get response data
			if ( responses ) {
				response = ajaxHandleResponses( s, jqXHR, responses );
			}

			// Convert no matter what (that way responseXXX fields are always set)
			response = ajaxConvert( s, response, jqXHR, isSuccess );

			// If successful, handle type chaining
			if ( isSuccess ) {

				// Set the If-Modified-Since and/or If-None-Match header, if in ifModified mode.
				if ( s.ifModified ) {
					modified = jqXHR.getResponseHeader("Last-Modified");
					if ( modified ) {
						jQuery.lastModified[ cacheURL ] = modified;
					}
					modified = jqXHR.getResponseHeader("etag");
					if ( modified ) {
						jQuery.etag[ cacheURL ] = modified;
					}
				}

				// if no content
				if ( status === 204 || s.type === "HEAD" ) {
					statusText = "nocontent";

				// if not modified
				} else if ( status === 304 ) {
					statusText = "notmodified";

				// If we have data, let's convert it
				} else {
					statusText = response.state;
					success = response.data;
					error = response.error;
					isSuccess = !error;
				}
			} else {
				// We extract error from statusText
				// then normalize statusText and status for non-aborts
				error = statusText;
				if ( status || !statusText ) {
					statusText = "error";
					if ( status < 0 ) {
						status = 0;
					}
				}
			}

			// Set data for the fake xhr object
			jqXHR.status = status;
			jqXHR.statusText = ( nativeStatusText || statusText ) + "";

			// Success/Error
			if ( isSuccess ) {
				deferred.resolveWith( callbackContext, [ success, statusText, jqXHR ] );
			} else {
				deferred.rejectWith( callbackContext, [ jqXHR, statusText, error ] );
			}

			// Status-dependent callbacks
			jqXHR.statusCode( statusCode );
			statusCode = undefined;

			if ( fireGlobals ) {
				globalEventContext.trigger( isSuccess ? "ajaxSuccess" : "ajaxError",
					[ jqXHR, s, isSuccess ? success : error ] );
			}

			// Complete
			completeDeferred.fireWith( callbackContext, [ jqXHR, statusText ] );

			if ( fireGlobals ) {
				globalEventContext.trigger( "ajaxComplete", [ jqXHR, s ] );
				// Handle the global AJAX counter
				if ( !( --jQuery.active ) ) {
					jQuery.event.trigger("ajaxStop");
				}
			}
		}

		return jqXHR;
	},

	getJSON: function( url, data, callback ) {
		return jQuery.get( url, data, callback, "json" );
	},

	getScript: function( url, callback ) {
		return jQuery.get( url, undefined, callback, "script" );
	}
});

jQuery.each( [ "get", "post" ], function( i, method ) {
	jQuery[ method ] = function( url, data, callback, type ) {
		// shift arguments if data argument was omitted
		if ( jQuery.isFunction( data ) ) {
			type = type || callback;
			callback = data;
			data = undefined;
		}

		return jQuery.ajax({
			url: url,
			type: method,
			dataType: type,
			data: data,
			success: callback
		});
	};
});

/* Handles responses to an ajax request:
 * - finds the right dataType (mediates between content-type and expected dataType)
 * - returns the corresponding response
 */
function ajaxHandleResponses( s, jqXHR, responses ) {

	var ct, type, finalDataType, firstDataType,
		contents = s.contents,
		dataTypes = s.dataTypes;

	// Remove auto dataType and get content-type in the process
	while( dataTypes[ 0 ] === "*" ) {
		dataTypes.shift();
		if ( ct === undefined ) {
			ct = s.mimeType || jqXHR.getResponseHeader("Content-Type");
		}
	}

	// Check if we're dealing with a known content-type
	if ( ct ) {
		for ( type in contents ) {
			if ( contents[ type ] && contents[ type ].test( ct ) ) {
				dataTypes.unshift( type );
				break;
			}
		}
	}

	// Check to see if we have a response for the expected dataType
	if ( dataTypes[ 0 ] in responses ) {
		finalDataType = dataTypes[ 0 ];
	} else {
		// Try convertible dataTypes
		for ( type in responses ) {
			if ( !dataTypes[ 0 ] || s.converters[ type + " " + dataTypes[0] ] ) {
				finalDataType = type;
				break;
			}
			if ( !firstDataType ) {
				firstDataType = type;
			}
		}
		// Or just use first one
		finalDataType = finalDataType || firstDataType;
	}

	// If we found a dataType
	// We add the dataType to the list if needed
	// and return the corresponding response
	if ( finalDataType ) {
		if ( finalDataType !== dataTypes[ 0 ] ) {
			dataTypes.unshift( finalDataType );
		}
		return responses[ finalDataType ];
	}
}

/* Chain conversions given the request and the original response
 * Also sets the responseXXX fields on the jqXHR instance
 */
function ajaxConvert( s, response, jqXHR, isSuccess ) {
	var conv2, current, conv, tmp, prev,
		converters = {},
		// Work with a copy of dataTypes in case we need to modify it for conversion
		dataTypes = s.dataTypes.slice();

	// Create converters map with lowercased keys
	if ( dataTypes[ 1 ] ) {
		for ( conv in s.converters ) {
			converters[ conv.toLowerCase() ] = s.converters[ conv ];
		}
	}

	current = dataTypes.shift();

	// Convert to each sequential dataType
	while ( current ) {

		if ( s.responseFields[ current ] ) {
			jqXHR[ s.responseFields[ current ] ] = response;
		}

		// Apply the dataFilter if provided
		if ( !prev && isSuccess && s.dataFilter ) {
			response = s.dataFilter( response, s.dataType );
		}

		prev = current;
		current = dataTypes.shift();

		if ( current ) {

		// There's only work to do if current dataType is non-auto
			if ( current === "*" ) {

				current = prev;

			// Convert response if prev dataType is non-auto and differs from current
			} else if ( prev !== "*" && prev !== current ) {

				// Seek a direct converter
				conv = converters[ prev + " " + current ] || converters[ "* " + current ];

				// If none found, seek a pair
				if ( !conv ) {
					for ( conv2 in converters ) {

						// If conv2 outputs current
						tmp = conv2.split( " " );
						if ( tmp[ 1 ] === current ) {

							// If prev can be converted to accepted input
							conv = converters[ prev + " " + tmp[ 0 ] ] ||
								converters[ "* " + tmp[ 0 ] ];
							if ( conv ) {
								// Condense equivalence converters
								if ( conv === true ) {
									conv = converters[ conv2 ];

								// Otherwise, insert the intermediate dataType
								} else if ( converters[ conv2 ] !== true ) {
									current = tmp[ 0 ];
									dataTypes.unshift( tmp[ 1 ] );
								}
								break;
							}
						}
					}
				}

				// Apply converter (if not an equivalence)
				if ( conv !== true ) {

					// Unless errors are allowed to bubble, catch and return them
					if ( conv && s[ "throws" ] ) {
						response = conv( response );
					} else {
						try {
							response = conv( response );
						} catch ( e ) {
							return { state: "parsererror", error: conv ? e : "No conversion from " + prev + " to " + current };
						}
					}
				}
			}
		}
	}

	return { state: "success", data: response };
}
// Install script dataType
jQuery.ajaxSetup({
	accepts: {
		script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
	},
	contents: {
		script: /(?:java|ecma)script/
	},
	converters: {
		"text script": function( text ) {
			jQuery.globalEval( text );
			return text;
		}
	}
});

// Handle cache's special case and crossDomain
jQuery.ajaxPrefilter( "script", function( s ) {
	if ( s.cache === undefined ) {
		s.cache = false;
	}
	if ( s.crossDomain ) {
		s.type = "GET";
	}
});

// Bind script tag hack transport
jQuery.ajaxTransport( "script", function( s ) {
	// This transport only deals with cross domain requests
	if ( s.crossDomain ) {
		var script, callback;
		return {
			send: function( _, complete ) {
				script = jQuery("<script>").prop({
					async: true,
					charset: s.scriptCharset,
					src: s.url
				}).on(
					"load error",
					callback = function( evt ) {
						script.remove();
						callback = null;
						if ( evt ) {
							complete( evt.type === "error" ? 404 : 200, evt.type );
						}
					}
				);
				document.head.appendChild( script[ 0 ] );
			},
			abort: function() {
				if ( callback ) {
					callback();
				}
			}
		};
	}
});
var oldCallbacks = [],
	rjsonp = /(=)\?(?=&|$)|\?\?/;

// Default jsonp settings
jQuery.ajaxSetup({
	jsonp: "callback",
	jsonpCallback: function() {
		var callback = oldCallbacks.pop() || ( jQuery.expando + "_" + ( ajax_nonce++ ) );
		this[ callback ] = true;
		return callback;
	}
});

// Detect, normalize options and install callbacks for jsonp requests
jQuery.ajaxPrefilter( "json jsonp", function( s, originalSettings, jqXHR ) {

	var callbackName, overwritten, responseContainer,
		jsonProp = s.jsonp !== false && ( rjsonp.test( s.url ) ?
			"url" :
			typeof s.data === "string" && !( s.contentType || "" ).indexOf("application/x-www-form-urlencoded") && rjsonp.test( s.data ) && "data"
		);

	// Handle iff the expected data type is "jsonp" or we have a parameter to set
	if ( jsonProp || s.dataTypes[ 0 ] === "jsonp" ) {

		// Get callback name, remembering preexisting value associated with it
		callbackName = s.jsonpCallback = jQuery.isFunction( s.jsonpCallback ) ?
			s.jsonpCallback() :
			s.jsonpCallback;

		// Insert callback into url or form data
		if ( jsonProp ) {
			s[ jsonProp ] = s[ jsonProp ].replace( rjsonp, "$1" + callbackName );
		} else if ( s.jsonp !== false ) {
			s.url += ( ajax_rquery.test( s.url ) ? "&" : "?" ) + s.jsonp + "=" + callbackName;
		}

		// Use data converter to retrieve json after script execution
		s.converters["script json"] = function() {
			if ( !responseContainer ) {
				jQuery.error( callbackName + " was not called" );
			}
			return responseContainer[ 0 ];
		};

		// force json dataType
		s.dataTypes[ 0 ] = "json";

		// Install callback
		overwritten = window[ callbackName ];
		window[ callbackName ] = function() {
			responseContainer = arguments;
		};

		// Clean-up function (fires after converters)
		jqXHR.always(function() {
			// Restore preexisting value
			window[ callbackName ] = overwritten;

			// Save back as free
			if ( s[ callbackName ] ) {
				// make sure that re-using the options doesn't screw things around
				s.jsonpCallback = originalSettings.jsonpCallback;

				// save the callback name for future use
				oldCallbacks.push( callbackName );
			}

			// Call if it was a function and we have a response
			if ( responseContainer && jQuery.isFunction( overwritten ) ) {
				overwritten( responseContainer[ 0 ] );
			}

			responseContainer = overwritten = undefined;
		});

		// Delegate to script
		return "script";
	}
});
jQuery.ajaxSettings.xhr = function() {
	try {
		return new XMLHttpRequest();
	} catch( e ) {}
};

var xhrSupported = jQuery.ajaxSettings.xhr(),
	xhrSuccessStatus = {
		// file protocol always yields status code 0, assume 200
		0: 200,
		// Support: IE9
		// #1450: sometimes IE returns 1223 when it should be 204
		1223: 204
	},
	// Support: IE9
	// We need to keep track of outbound xhr and abort them manually
	// because IE is not smart enough to do it all by itself
	xhrId = 0,
	xhrCallbacks = {};

if ( window.ActiveXObject ) {
	jQuery( window ).on( "unload", function() {
		for( var key in xhrCallbacks ) {
			xhrCallbacks[ key ]();
		}
		xhrCallbacks = undefined;
	});
}

jQuery.support.cors = !!xhrSupported && ( "withCredentials" in xhrSupported );
jQuery.support.ajax = xhrSupported = !!xhrSupported;

jQuery.ajaxTransport(function( options ) {
	var callback;
	// Cross domain only allowed if supported through XMLHttpRequest
	if ( jQuery.support.cors || xhrSupported && !options.crossDomain ) {
		return {
			send: function( headers, complete ) {
				var i, id,
					xhr = options.xhr();
				xhr.open( options.type, options.url, options.async, options.username, options.password );
				// Apply custom fields if provided
				if ( options.xhrFields ) {
					for ( i in options.xhrFields ) {
						xhr[ i ] = options.xhrFields[ i ];
					}
				}
				// Override mime type if needed
				if ( options.mimeType && xhr.overrideMimeType ) {
					xhr.overrideMimeType( options.mimeType );
				}
				// X-Requested-With header
				// For cross-domain requests, seeing as conditions for a preflight are
				// akin to a jigsaw puzzle, we simply never set it to be sure.
				// (it can always be set on a per-request basis or even using ajaxSetup)
				// For same-domain requests, won't change header if already provided.
				if ( !options.crossDomain && !headers["X-Requested-With"] ) {
					headers["X-Requested-With"] = "XMLHttpRequest";
				}
				// Set headers
				for ( i in headers ) {
					xhr.setRequestHeader( i, headers[ i ] );
				}
				// Callback
				callback = function( type ) {
					return function() {
						if ( callback ) {
							delete xhrCallbacks[ id ];
							callback = xhr.onload = xhr.onerror = null;
							if ( type === "abort" ) {
								xhr.abort();
							} else if ( type === "error" ) {
								complete(
									// file protocol always yields status 0, assume 404
									xhr.status || 404,
									xhr.statusText
								);
							} else {
								complete(
									xhrSuccessStatus[ xhr.status ] || xhr.status,
									xhr.statusText,
									// Support: IE9
									// #11426: When requesting binary data, IE9 will throw an exception
									// on any attempt to access responseText
									typeof xhr.responseText === "string" ? {
										text: xhr.responseText
									} : undefined,
									xhr.getAllResponseHeaders()
								);
							}
						}
					};
				};
				// Listen to events
				xhr.onload = callback();
				xhr.onerror = callback("error");
				// Create the abort callback
				callback = xhrCallbacks[( id = xhrId++ )] = callback("abort");
				// Do send the request
				// This may raise an exception which is actually
				// handled in jQuery.ajax (so no try/catch here)
				xhr.send( options.hasContent && options.data || null );
			},
			abort: function() {
				if ( callback ) {
					callback();
				}
			}
		};
	}
});
var fxNow, timerId,
	rfxtypes = /^(?:toggle|show|hide)$/,
	rfxnum = new RegExp( "^(?:([+-])=|)(" + core_pnum + ")([a-z%]*)$", "i" ),
	rrun = /queueHooks$/,
	animationPrefilters = [ defaultPrefilter ],
	tweeners = {
		"*": [function( prop, value ) {
			var tween = this.createTween( prop, value ),
				target = tween.cur(),
				parts = rfxnum.exec( value ),
				unit = parts && parts[ 3 ] || ( jQuery.cssNumber[ prop ] ? "" : "px" ),

				// Starting value computation is required for potential unit mismatches
				start = ( jQuery.cssNumber[ prop ] || unit !== "px" && +target ) &&
					rfxnum.exec( jQuery.css( tween.elem, prop ) ),
				scale = 1,
				maxIterations = 20;

			if ( start && start[ 3 ] !== unit ) {
				// Trust units reported by jQuery.css
				unit = unit || start[ 3 ];

				// Make sure we update the tween properties later on
				parts = parts || [];

				// Iteratively approximate from a nonzero starting point
				start = +target || 1;

				do {
					// If previous iteration zeroed out, double until we get *something*
					// Use a string for doubling factor so we don't accidentally see scale as unchanged below
					scale = scale || ".5";

					// Adjust and apply
					start = start / scale;
					jQuery.style( tween.elem, prop, start + unit );

				// Update scale, tolerating zero or NaN from tween.cur()
				// And breaking the loop if scale is unchanged or perfect, or if we've just had enough
				} while ( scale !== (scale = tween.cur() / target) && scale !== 1 && --maxIterations );
			}

			// Update tween properties
			if ( parts ) {
				start = tween.start = +start || +target || 0;
				tween.unit = unit;
				// If a +=/-= token was provided, we're doing a relative animation
				tween.end = parts[ 1 ] ?
					start + ( parts[ 1 ] + 1 ) * parts[ 2 ] :
					+parts[ 2 ];
			}

			return tween;
		}]
	};

// Animations created synchronously will run synchronously
function createFxNow() {
	setTimeout(function() {
		fxNow = undefined;
	});
	return ( fxNow = jQuery.now() );
}

function createTween( value, prop, animation ) {
	var tween,
		collection = ( tweeners[ prop ] || [] ).concat( tweeners[ "*" ] ),
		index = 0,
		length = collection.length;
	for ( ; index < length; index++ ) {
		if ( (tween = collection[ index ].call( animation, prop, value )) ) {

			// we're done with this property
			return tween;
		}
	}
}

function Animation( elem, properties, options ) {
	var result,
		stopped,
		index = 0,
		length = animationPrefilters.length,
		deferred = jQuery.Deferred().always( function() {
			// don't match elem in the :animated selector
			delete tick.elem;
		}),
		tick = function() {
			if ( stopped ) {
				return false;
			}
			var currentTime = fxNow || createFxNow(),
				remaining = Math.max( 0, animation.startTime + animation.duration - currentTime ),
				// archaic crash bug won't allow us to use 1 - ( 0.5 || 0 ) (#12497)
				temp = remaining / animation.duration || 0,
				percent = 1 - temp,
				index = 0,
				length = animation.tweens.length;

			for ( ; index < length ; index++ ) {
				animation.tweens[ index ].run( percent );
			}

			deferred.notifyWith( elem, [ animation, percent, remaining ]);

			if ( percent < 1 && length ) {
				return remaining;
			} else {
				deferred.resolveWith( elem, [ animation ] );
				return false;
			}
		},
		animation = deferred.promise({
			elem: elem,
			props: jQuery.extend( {}, properties ),
			opts: jQuery.extend( true, { specialEasing: {} }, options ),
			originalProperties: properties,
			originalOptions: options,
			startTime: fxNow || createFxNow(),
			duration: options.duration,
			tweens: [],
			createTween: function( prop, end ) {
				var tween = jQuery.Tween( elem, animation.opts, prop, end,
						animation.opts.specialEasing[ prop ] || animation.opts.easing );
				animation.tweens.push( tween );
				return tween;
			},
			stop: function( gotoEnd ) {
				var index = 0,
					// if we are going to the end, we want to run all the tweens
					// otherwise we skip this part
					length = gotoEnd ? animation.tweens.length : 0;
				if ( stopped ) {
					return this;
				}
				stopped = true;
				for ( ; index < length ; index++ ) {
					animation.tweens[ index ].run( 1 );
				}

				// resolve when we played the last frame
				// otherwise, reject
				if ( gotoEnd ) {
					deferred.resolveWith( elem, [ animation, gotoEnd ] );
				} else {
					deferred.rejectWith( elem, [ animation, gotoEnd ] );
				}
				return this;
			}
		}),
		props = animation.props;

	propFilter( props, animation.opts.specialEasing );

	for ( ; index < length ; index++ ) {
		result = animationPrefilters[ index ].call( animation, elem, props, animation.opts );
		if ( result ) {
			return result;
		}
	}

	jQuery.map( props, createTween, animation );

	if ( jQuery.isFunction( animation.opts.start ) ) {
		animation.opts.start.call( elem, animation );
	}

	jQuery.fx.timer(
		jQuery.extend( tick, {
			elem: elem,
			anim: animation,
			queue: animation.opts.queue
		})
	);

	// attach callbacks from options
	return animation.progress( animation.opts.progress )
		.done( animation.opts.done, animation.opts.complete )
		.fail( animation.opts.fail )
		.always( animation.opts.always );
}

function propFilter( props, specialEasing ) {
	var index, name, easing, value, hooks;

	// camelCase, specialEasing and expand cssHook pass
	for ( index in props ) {
		name = jQuery.camelCase( index );
		easing = specialEasing[ name ];
		value = props[ index ];
		if ( jQuery.isArray( value ) ) {
			easing = value[ 1 ];
			value = props[ index ] = value[ 0 ];
		}

		if ( index !== name ) {
			props[ name ] = value;
			delete props[ index ];
		}

		hooks = jQuery.cssHooks[ name ];
		if ( hooks && "expand" in hooks ) {
			value = hooks.expand( value );
			delete props[ name ];

			// not quite $.extend, this wont overwrite keys already present.
			// also - reusing 'index' from above because we have the correct "name"
			for ( index in value ) {
				if ( !( index in props ) ) {
					props[ index ] = value[ index ];
					specialEasing[ index ] = easing;
				}
			}
		} else {
			specialEasing[ name ] = easing;
		}
	}
}

jQuery.Animation = jQuery.extend( Animation, {

	tweener: function( props, callback ) {
		if ( jQuery.isFunction( props ) ) {
			callback = props;
			props = [ "*" ];
		} else {
			props = props.split(" ");
		}

		var prop,
			index = 0,
			length = props.length;

		for ( ; index < length ; index++ ) {
			prop = props[ index ];
			tweeners[ prop ] = tweeners[ prop ] || [];
			tweeners[ prop ].unshift( callback );
		}
	},

	prefilter: function( callback, prepend ) {
		if ( prepend ) {
			animationPrefilters.unshift( callback );
		} else {
			animationPrefilters.push( callback );
		}
	}
});

function defaultPrefilter( elem, props, opts ) {
	/* jshint validthis: true */
	var prop, value, toggle, tween, hooks, oldfire,
		anim = this,
		orig = {},
		style = elem.style,
		hidden = elem.nodeType && isHidden( elem ),
		dataShow = data_priv.get( elem, "fxshow" );

	// handle queue: false promises
	if ( !opts.queue ) {
		hooks = jQuery._queueHooks( elem, "fx" );
		if ( hooks.unqueued == null ) {
			hooks.unqueued = 0;
			oldfire = hooks.empty.fire;
			hooks.empty.fire = function() {
				if ( !hooks.unqueued ) {
					oldfire();
				}
			};
		}
		hooks.unqueued++;

		anim.always(function() {
			// doing this makes sure that the complete handler will be called
			// before this completes
			anim.always(function() {
				hooks.unqueued--;
				if ( !jQuery.queue( elem, "fx" ).length ) {
					hooks.empty.fire();
				}
			});
		});
	}

	// height/width overflow pass
	if ( elem.nodeType === 1 && ( "height" in props || "width" in props ) ) {
		// Make sure that nothing sneaks out
		// Record all 3 overflow attributes because IE9-10 do not
		// change the overflow attribute when overflowX and
		// overflowY are set to the same value
		opts.overflow = [ style.overflow, style.overflowX, style.overflowY ];

		// Set display property to inline-block for height/width
		// animations on inline elements that are having width/height animated
		if ( jQuery.css( elem, "display" ) === "inline" &&
				jQuery.css( elem, "float" ) === "none" ) {

			style.display = "inline-block";
		}
	}

	if ( opts.overflow ) {
		style.overflow = "hidden";
		anim.always(function() {
			style.overflow = opts.overflow[ 0 ];
			style.overflowX = opts.overflow[ 1 ];
			style.overflowY = opts.overflow[ 2 ];
		});
	}


	// show/hide pass
	for ( prop in props ) {
		value = props[ prop ];
		if ( rfxtypes.exec( value ) ) {
			delete props[ prop ];
			toggle = toggle || value === "toggle";
			if ( value === ( hidden ? "hide" : "show" ) ) {

				// If there is dataShow left over from a stopped hide or show and we are going to proceed with show, we should pretend to be hidden
				if ( value === "show" && dataShow && dataShow[ prop ] !== undefined ) {
					hidden = true;
				} else {
					continue;
				}
			}
			orig[ prop ] = dataShow && dataShow[ prop ] || jQuery.style( elem, prop );
		}
	}

	if ( !jQuery.isEmptyObject( orig ) ) {
		if ( dataShow ) {
			if ( "hidden" in dataShow ) {
				hidden = dataShow.hidden;
			}
		} else {
			dataShow = data_priv.access( elem, "fxshow", {} );
		}

		// store state if its toggle - enables .stop().toggle() to "reverse"
		if ( toggle ) {
			dataShow.hidden = !hidden;
		}
		if ( hidden ) {
			jQuery( elem ).show();
		} else {
			anim.done(function() {
				jQuery( elem ).hide();
			});
		}
		anim.done(function() {
			var prop;

			data_priv.remove( elem, "fxshow" );
			for ( prop in orig ) {
				jQuery.style( elem, prop, orig[ prop ] );
			}
		});
		for ( prop in orig ) {
			tween = createTween( hidden ? dataShow[ prop ] : 0, prop, anim );

			if ( !( prop in dataShow ) ) {
				dataShow[ prop ] = tween.start;
				if ( hidden ) {
					tween.end = tween.start;
					tween.start = prop === "width" || prop === "height" ? 1 : 0;
				}
			}
		}
	}
}

function Tween( elem, options, prop, end, easing ) {
	return new Tween.prototype.init( elem, options, prop, end, easing );
}
jQuery.Tween = Tween;

Tween.prototype = {
	constructor: Tween,
	init: function( elem, options, prop, end, easing, unit ) {
		this.elem = elem;
		this.prop = prop;
		this.easing = easing || "swing";
		this.options = options;
		this.start = this.now = this.cur();
		this.end = end;
		this.unit = unit || ( jQuery.cssNumber[ prop ] ? "" : "px" );
	},
	cur: function() {
		var hooks = Tween.propHooks[ this.prop ];

		return hooks && hooks.get ?
			hooks.get( this ) :
			Tween.propHooks._default.get( this );
	},
	run: function( percent ) {
		var eased,
			hooks = Tween.propHooks[ this.prop ];

		if ( this.options.duration ) {
			this.pos = eased = jQuery.easing[ this.easing ](
				percent, this.options.duration * percent, 0, 1, this.options.duration
			);
		} else {
			this.pos = eased = percent;
		}
		this.now = ( this.end - this.start ) * eased + this.start;

		if ( this.options.step ) {
			this.options.step.call( this.elem, this.now, this );
		}

		if ( hooks && hooks.set ) {
			hooks.set( this );
		} else {
			Tween.propHooks._default.set( this );
		}
		return this;
	}
};

Tween.prototype.init.prototype = Tween.prototype;

Tween.propHooks = {
	_default: {
		get: function( tween ) {
			var result;

			if ( tween.elem[ tween.prop ] != null &&
				(!tween.elem.style || tween.elem.style[ tween.prop ] == null) ) {
				return tween.elem[ tween.prop ];
			}

			// passing an empty string as a 3rd parameter to .css will automatically
			// attempt a parseFloat and fallback to a string if the parse fails
			// so, simple values such as "10px" are parsed to Float.
			// complex values such as "rotate(1rad)" are returned as is.
			result = jQuery.css( tween.elem, tween.prop, "" );
			// Empty strings, null, undefined and "auto" are converted to 0.
			return !result || result === "auto" ? 0 : result;
		},
		set: function( tween ) {
			// use step hook for back compat - use cssHook if its there - use .style if its
			// available and use plain properties where available
			if ( jQuery.fx.step[ tween.prop ] ) {
				jQuery.fx.step[ tween.prop ]( tween );
			} else if ( tween.elem.style && ( tween.elem.style[ jQuery.cssProps[ tween.prop ] ] != null || jQuery.cssHooks[ tween.prop ] ) ) {
				jQuery.style( tween.elem, tween.prop, tween.now + tween.unit );
			} else {
				tween.elem[ tween.prop ] = tween.now;
			}
		}
	}
};

// Support: IE9
// Panic based approach to setting things on disconnected nodes

Tween.propHooks.scrollTop = Tween.propHooks.scrollLeft = {
	set: function( tween ) {
		if ( tween.elem.nodeType && tween.elem.parentNode ) {
			tween.elem[ tween.prop ] = tween.now;
		}
	}
};

jQuery.each([ "toggle", "show", "hide" ], function( i, name ) {
	var cssFn = jQuery.fn[ name ];
	jQuery.fn[ name ] = function( speed, easing, callback ) {
		return speed == null || typeof speed === "boolean" ?
			cssFn.apply( this, arguments ) :
			this.animate( genFx( name, true ), speed, easing, callback );
	};
});

jQuery.fn.extend({
	fadeTo: function( speed, to, easing, callback ) {

		// show any hidden elements after setting opacity to 0
		return this.filter( isHidden ).css( "opacity", 0 ).show()

			// animate to the value specified
			.end().animate({ opacity: to }, speed, easing, callback );
	},
	animate: function( prop, speed, easing, callback ) {
		var empty = jQuery.isEmptyObject( prop ),
			optall = jQuery.speed( speed, easing, callback ),
			doAnimation = function() {
				// Operate on a copy of prop so per-property easing won't be lost
				var anim = Animation( this, jQuery.extend( {}, prop ), optall );

				// Empty animations, or finishing resolves immediately
				if ( empty || data_priv.get( this, "finish" ) ) {
					anim.stop( true );
				}
			};
			doAnimation.finish = doAnimation;

		return empty || optall.queue === false ?
			this.each( doAnimation ) :
			this.queue( optall.queue, doAnimation );
	},
	stop: function( type, clearQueue, gotoEnd ) {
		var stopQueue = function( hooks ) {
			var stop = hooks.stop;
			delete hooks.stop;
			stop( gotoEnd );
		};

		if ( typeof type !== "string" ) {
			gotoEnd = clearQueue;
			clearQueue = type;
			type = undefined;
		}
		if ( clearQueue && type !== false ) {
			this.queue( type || "fx", [] );
		}

		return this.each(function() {
			var dequeue = true,
				index = type != null && type + "queueHooks",
				timers = jQuery.timers,
				data = data_priv.get( this );

			if ( index ) {
				if ( data[ index ] && data[ index ].stop ) {
					stopQueue( data[ index ] );
				}
			} else {
				for ( index in data ) {
					if ( data[ index ] && data[ index ].stop && rrun.test( index ) ) {
						stopQueue( data[ index ] );
					}
				}
			}

			for ( index = timers.length; index--; ) {
				if ( timers[ index ].elem === this && (type == null || timers[ index ].queue === type) ) {
					timers[ index ].anim.stop( gotoEnd );
					dequeue = false;
					timers.splice( index, 1 );
				}
			}

			// start the next in the queue if the last step wasn't forced
			// timers currently will call their complete callbacks, which will dequeue
			// but only if they were gotoEnd
			if ( dequeue || !gotoEnd ) {
				jQuery.dequeue( this, type );
			}
		});
	},
	finish: function( type ) {
		if ( type !== false ) {
			type = type || "fx";
		}
		return this.each(function() {
			var index,
				data = data_priv.get( this ),
				queue = data[ type + "queue" ],
				hooks = data[ type + "queueHooks" ],
				timers = jQuery.timers,
				length = queue ? queue.length : 0;

			// enable finishing flag on private data
			data.finish = true;

			// empty the queue first
			jQuery.queue( this, type, [] );

			if ( hooks && hooks.stop ) {
				hooks.stop.call( this, true );
			}

			// look for any active animations, and finish them
			for ( index = timers.length; index--; ) {
				if ( timers[ index ].elem === this && timers[ index ].queue === type ) {
					timers[ index ].anim.stop( true );
					timers.splice( index, 1 );
				}
			}

			// look for any animations in the old queue and finish them
			for ( index = 0; index < length; index++ ) {
				if ( queue[ index ] && queue[ index ].finish ) {
					queue[ index ].finish.call( this );
				}
			}

			// turn off finishing flag
			delete data.finish;
		});
	}
});

// Generate parameters to create a standard animation
function genFx( type, includeWidth ) {
	var which,
		attrs = { height: type },
		i = 0;

	// if we include width, step value is 1 to do all cssExpand values,
	// if we don't include width, step value is 2 to skip over Left and Right
	includeWidth = includeWidth? 1 : 0;
	for( ; i < 4 ; i += 2 - includeWidth ) {
		which = cssExpand[ i ];
		attrs[ "margin" + which ] = attrs[ "padding" + which ] = type;
	}

	if ( includeWidth ) {
		attrs.opacity = attrs.width = type;
	}

	return attrs;
}

// Generate shortcuts for custom animations
jQuery.each({
	slideDown: genFx("show"),
	slideUp: genFx("hide"),
	slideToggle: genFx("toggle"),
	fadeIn: { opacity: "show" },
	fadeOut: { opacity: "hide" },
	fadeToggle: { opacity: "toggle" }
}, function( name, props ) {
	jQuery.fn[ name ] = function( speed, easing, callback ) {
		return this.animate( props, speed, easing, callback );
	};
});

jQuery.speed = function( speed, easing, fn ) {
	var opt = speed && typeof speed === "object" ? jQuery.extend( {}, speed ) : {
		complete: fn || !fn && easing ||
			jQuery.isFunction( speed ) && speed,
		duration: speed,
		easing: fn && easing || easing && !jQuery.isFunction( easing ) && easing
	};

	opt.duration = jQuery.fx.off ? 0 : typeof opt.duration === "number" ? opt.duration :
		opt.duration in jQuery.fx.speeds ? jQuery.fx.speeds[ opt.duration ] : jQuery.fx.speeds._default;

	// normalize opt.queue - true/undefined/null -> "fx"
	if ( opt.queue == null || opt.queue === true ) {
		opt.queue = "fx";
	}

	// Queueing
	opt.old = opt.complete;

	opt.complete = function() {
		if ( jQuery.isFunction( opt.old ) ) {
			opt.old.call( this );
		}

		if ( opt.queue ) {
			jQuery.dequeue( this, opt.queue );
		}
	};

	return opt;
};

jQuery.easing = {
	linear: function( p ) {
		return p;
	},
	swing: function( p ) {
		return 0.5 - Math.cos( p*Math.PI ) / 2;
	}
};

jQuery.timers = [];
jQuery.fx = Tween.prototype.init;
jQuery.fx.tick = function() {
	var timer,
		timers = jQuery.timers,
		i = 0;

	fxNow = jQuery.now();

	for ( ; i < timers.length; i++ ) {
		timer = timers[ i ];
		// Checks the timer has not already been removed
		if ( !timer() && timers[ i ] === timer ) {
			timers.splice( i--, 1 );
		}
	}

	if ( !timers.length ) {
		jQuery.fx.stop();
	}
	fxNow = undefined;
};

jQuery.fx.timer = function( timer ) {
	if ( timer() && jQuery.timers.push( timer ) ) {
		jQuery.fx.start();
	}
};

jQuery.fx.interval = 13;

jQuery.fx.start = function() {
	if ( !timerId ) {
		timerId = setInterval( jQuery.fx.tick, jQuery.fx.interval );
	}
};

jQuery.fx.stop = function() {
	clearInterval( timerId );
	timerId = null;
};

jQuery.fx.speeds = {
	slow: 600,
	fast: 200,
	// Default speed
	_default: 400
};

// Back Compat <1.8 extension point
jQuery.fx.step = {};

if ( jQuery.expr && jQuery.expr.filters ) {
	jQuery.expr.filters.animated = function( elem ) {
		return jQuery.grep(jQuery.timers, function( fn ) {
			return elem === fn.elem;
		}).length;
	};
}
jQuery.fn.offset = function( options ) {
	if ( arguments.length ) {
		return options === undefined ?
			this :
			this.each(function( i ) {
				jQuery.offset.setOffset( this, options, i );
			});
	}

	var docElem, win,
		elem = this[ 0 ],
		box = { top: 0, left: 0 },
		doc = elem && elem.ownerDocument;

	if ( !doc ) {
		return;
	}

	docElem = doc.documentElement;

	// Make sure it's not a disconnected DOM node
	if ( !jQuery.contains( docElem, elem ) ) {
		return box;
	}

	// If we don't have gBCR, just use 0,0 rather than error
	// BlackBerry 5, iOS 3 (original iPhone)
	if ( typeof elem.getBoundingClientRect !== core_strundefined ) {
		box = elem.getBoundingClientRect();
	}
	win = getWindow( doc );
	return {
		top: box.top + win.pageYOffset - docElem.clientTop,
		left: box.left + win.pageXOffset - docElem.clientLeft
	};
};

jQuery.offset = {

	setOffset: function( elem, options, i ) {
		var curPosition, curLeft, curCSSTop, curTop, curOffset, curCSSLeft, calculatePosition,
			position = jQuery.css( elem, "position" ),
			curElem = jQuery( elem ),
			props = {};

		// Set position first, in-case top/left are set even on static elem
		if ( position === "static" ) {
			elem.style.position = "relative";
		}

		curOffset = curElem.offset();
		curCSSTop = jQuery.css( elem, "top" );
		curCSSLeft = jQuery.css( elem, "left" );
		calculatePosition = ( position === "absolute" || position === "fixed" ) && ( curCSSTop + curCSSLeft ).indexOf("auto") > -1;

		// Need to be able to calculate position if either top or left is auto and position is either absolute or fixed
		if ( calculatePosition ) {
			curPosition = curElem.position();
			curTop = curPosition.top;
			curLeft = curPosition.left;

		} else {
			curTop = parseFloat( curCSSTop ) || 0;
			curLeft = parseFloat( curCSSLeft ) || 0;
		}

		if ( jQuery.isFunction( options ) ) {
			options = options.call( elem, i, curOffset );
		}

		if ( options.top != null ) {
			props.top = ( options.top - curOffset.top ) + curTop;
		}
		if ( options.left != null ) {
			props.left = ( options.left - curOffset.left ) + curLeft;
		}

		if ( "using" in options ) {
			options.using.call( elem, props );

		} else {
			curElem.css( props );
		}
	}
};


jQuery.fn.extend({

	position: function() {
		if ( !this[ 0 ] ) {
			return;
		}

		var offsetParent, offset,
			elem = this[ 0 ],
			parentOffset = { top: 0, left: 0 };

		// Fixed elements are offset from window (parentOffset = {top:0, left: 0}, because it is it's only offset parent
		if ( jQuery.css( elem, "position" ) === "fixed" ) {
			// We assume that getBoundingClientRect is available when computed position is fixed
			offset = elem.getBoundingClientRect();

		} else {
			// Get *real* offsetParent
			offsetParent = this.offsetParent();

			// Get correct offsets
			offset = this.offset();
			if ( !jQuery.nodeName( offsetParent[ 0 ], "html" ) ) {
				parentOffset = offsetParent.offset();
			}

			// Add offsetParent borders
			parentOffset.top += jQuery.css( offsetParent[ 0 ], "borderTopWidth", true );
			parentOffset.left += jQuery.css( offsetParent[ 0 ], "borderLeftWidth", true );
		}

		// Subtract parent offsets and element margins
		return {
			top: offset.top - parentOffset.top - jQuery.css( elem, "marginTop", true ),
			left: offset.left - parentOffset.left - jQuery.css( elem, "marginLeft", true )
		};
	},

	offsetParent: function() {
		return this.map(function() {
			var offsetParent = this.offsetParent || docElem;

			while ( offsetParent && ( !jQuery.nodeName( offsetParent, "html" ) && jQuery.css( offsetParent, "position") === "static" ) ) {
				offsetParent = offsetParent.offsetParent;
			}

			return offsetParent || docElem;
		});
	}
});


// Create scrollLeft and scrollTop methods
jQuery.each( {scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, function( method, prop ) {
	var top = "pageYOffset" === prop;

	jQuery.fn[ method ] = function( val ) {
		return jQuery.access( this, function( elem, method, val ) {
			var win = getWindow( elem );

			if ( val === undefined ) {
				return win ? win[ prop ] : elem[ method ];
			}

			if ( win ) {
				win.scrollTo(
					!top ? val : window.pageXOffset,
					top ? val : window.pageYOffset
				);

			} else {
				elem[ method ] = val;
			}
		}, method, val, arguments.length, null );
	};
});

function getWindow( elem ) {
	return jQuery.isWindow( elem ) ? elem : elem.nodeType === 9 && elem.defaultView;
}
// Create innerHeight, innerWidth, height, width, outerHeight and outerWidth methods
jQuery.each( { Height: "height", Width: "width" }, function( name, type ) {
	jQuery.each( { padding: "inner" + name, content: type, "": "outer" + name }, function( defaultExtra, funcName ) {
		// margin is only for outerHeight, outerWidth
		jQuery.fn[ funcName ] = function( margin, value ) {
			var chainable = arguments.length && ( defaultExtra || typeof margin !== "boolean" ),
				extra = defaultExtra || ( margin === true || value === true ? "margin" : "border" );

			return jQuery.access( this, function( elem, type, value ) {
				var doc;

				if ( jQuery.isWindow( elem ) ) {
					// As of 5/8/2012 this will yield incorrect results for Mobile Safari, but there
					// isn't a whole lot we can do. See pull request at this URL for discussion:
					// https://github.com/jquery/jquery/pull/764
					return elem.document.documentElement[ "client" + name ];
				}

				// Get document width or height
				if ( elem.nodeType === 9 ) {
					doc = elem.documentElement;

					// Either scroll[Width/Height] or offset[Width/Height] or client[Width/Height],
					// whichever is greatest
					return Math.max(
						elem.body[ "scroll" + name ], doc[ "scroll" + name ],
						elem.body[ "offset" + name ], doc[ "offset" + name ],
						doc[ "client" + name ]
					);
				}

				return value === undefined ?
					// Get width or height on the element, requesting but not forcing parseFloat
					jQuery.css( elem, type, extra ) :

					// Set width or height on the element
					jQuery.style( elem, type, value, extra );
			}, type, chainable ? margin : undefined, chainable, null );
		};
	});
});
// Limit scope pollution from any deprecated API
// (function() {

// The number of elements contained in the matched element set
jQuery.fn.size = function() {
	return this.length;
};

jQuery.fn.andSelf = jQuery.fn.addBack;

// })();
if ( typeof module === "object" && module && typeof module.exports === "object" ) {
	// Expose jQuery as module.exports in loaders that implement the Node
	// module pattern (including browserify). Do not create the global, since
	// the user will be storing it themselves locally, and globals are frowned
	// upon in the Node module world.
	module.exports = jQuery;
} else {
	// Register as a named AMD module, since jQuery can be concatenated with other
	// files that may use define, but not via a proper concatenation script that
	// understands anonymous AMD modules. A named AMD is safest and most robust
	// way to register. Lowercase jquery is used because AMD module names are
	// derived from file names, and jQuery is normally delivered in a lowercase
	// file name. Do this after creating the global so that if an AMD module wants
	// to call noConflict to hide this version of jQuery, it will work.
	if ( typeof define === "function" && define.amd ) {
		define( "jquery", [], function () { return jQuery; } );
	}
}

// If there is a window object, that at least has a document property,
// define jQuery and $ identifiers
if ( typeof window === "object" && typeof window.document === "object" ) {
	window.jQuery = window.$ = jQuery;
}

})( window );

(function (i) {
    var e = {undHash: /_|-/, colons: /::/, words: /([A-Z]+)([A-Z][a-z])/g, lowUp: /([a-z\d])([A-Z])/g, dash: /([a-z\d])([A-Z])/g, replacer: /\{([^\}]+)\}/g, dot: /\./}, l = function (a, b, c) {
        return a[b] !== undefined ? a[b] : c && (a[b] = {})
    }, j = function (a) {
        var b = typeof a;
        return a && (b == "function" || b == "object")
    }, m, k = i.String = i.extend(i.String || {}, {getObject: m = function (a, b, c) {
        a = a ? a.split(e.dot) : [];
        var f = a.length, d, h, g, n = 0;
        b = i.isArray(b) ? b : [b || window];
        if (f == 0)return b[0];
        for (; d = b[n++];) {
            for (g = 0; g < f - 1 && j(d); g++)d = l(d, a[g],
                c);
            if (j(d)) {
                h = l(d, a[g], c);
                if (h !== undefined) {
                    c === false && delete d[a[g]];
                    return h
                }
            }
        }
    }, capitalize: function (a) {
        return a.charAt(0).toUpperCase() + a.substr(1)
    }, camelize: function (a) {
        a = k.classize(a);
        return a.charAt(0).toLowerCase() + a.substr(1)
    }, classize: function (a, b) {
        a = a.split(e.undHash);
        for (var c = 0; c < a.length; c++)a[c] = k.capitalize(a[c]);
        return a.join(b || "")
    }, niceName: function (a) {
        return k.classize(a, " ")
    }, underscore: function (a) {
        return a.replace(e.colons, "/").replace(e.words, "$1_$2").replace(e.lowUp, "$1_$2").replace(e.dash,
            "_").toLowerCase()
    }, sub: function (a, b, c) {
        var f = [];
        c = typeof c == "boolean" ? !c : c;
        f.push(a.replace(e.replacer, function (d, h) {
            d = m(h, b, c);
            if (j(d)) {
                f.push(d);
                return""
            } else return"" + d
        }));
        return f.length <= 1 ? f[0] : f
    }, _regs: e})
})(jQuery);
(function (i) {
    var j = false, p = i.makeArray, q = i.isFunction, l = i.isArray, m = i.extend, s = i.String.getObject, n = function (a, c) {
        return a.concat(p(c))
    }, t = /xyz/.test(function () {
    }) ? /\b_super\b/ : /.*/, r = function (a, c, d) {
        d = d || a;
        for (var b in a)d[b] = q(a[b]) && q(c[b]) && t.test(a[b]) ? function (h, g) {
            return function () {
                var f = this._super, e;
                this._super = c[h];
                e = g.apply(this, arguments);
                this._super = f;
                return e
            }
        }(b, a[b]) : a[b]
    };
    clss = i.Class = function () {
        arguments.length && clss.extend.apply(clss, arguments)
    };
    m(clss, {proxy: function (a) {
        var c =
            p(arguments), d;
        a = c.shift();
        l(a) || (a = [a]);
        d = this;
        return function () {
            for (var b = n(c, arguments), h, g = a.length, f = 0, e; f < g; f++)if (e = a[f]) {
                if ((h = typeof e == "string") && d._set_called)d.called = e;
                b = (h ? d[e] : e).apply(d, b || []);
                if (f < g - 1)b = !l(b) || b._use_call ? [b] : b
            }
            return b
        }
    }, newInstance: function () {
        var a = this.rawInstance(), c;
        if (a.setup)c = a.setup.apply(a, arguments);
        if (a.init)a.init.apply(a, l(c) ? c : arguments);
        return a
    }, setup: function (a) {
        this.defaults = m(true, {}, a.defaults, this.defaults);
        return arguments
    }, rawInstance: function () {
        j =
            true;
        var a = new this;
        j = false;
        return a
    }, extend: function (a, c, d) {
        function b() {
            if (!j)return this.constructor !== b && arguments.length ? arguments.callee.extend.apply(arguments.callee, arguments) : this.Class.newInstance.apply(this.Class, arguments)
        }

        if (typeof a != "string") {
            d = c;
            c = a;
            a = null
        }
        if (!d) {
            d = c;
            c = null
        }
        d = d || {};
        var h = this, g = this.prototype, f, e, k, o;
        j = true;
        o = new this;
        j = false;
        r(d, g, o);
        for (f in this)if (this.hasOwnProperty(f))b[f] = this[f];
        r(c, this, b);
        if (a) {
            k = a.split(/\./);
            e = k.pop();
            k = g = s(k.join("."), window, true);
            g[e] =
                b
        }
        m(b, {prototype: o, namespace: k, shortName: e, constructor: b, fullName: a});
        b.prototype.Class = b.prototype.constructor = b;
        e = b.setup.apply(b, n([h], arguments));
        if (b.init)b.init.apply(b, e || n([h], arguments));
        return b
    }});
    clss.callback = clss.prototype.callback = clss.prototype.proxy = clss.proxy
})(jQuery);

(function (a) {
    var e = jQuery.cleanData;
    a.cleanData = function (b) {
        for (var c = 0, d; (d = b[c]) !== undefined; c++)a(d).triggerHandler("destroyed");
        e(b)
    }
})(jQuery);
(function (e) {
    var v = function (a, b, c) {
        var d, f = a.bind && a.unbind ? a : e(j(a) ? [a] : a);
        if (b.indexOf(">") === 0) {
            b = b.substr(1);
            d = function (i) {
                i.target === a && c.apply(this, arguments)
            }
        }
        f.bind(b, d || c);
        return function () {
            f.unbind(b, d || c);
            a = b = c = d = null
        }
    }, k = e.makeArray, w = e.isArray, j = e.isFunction, l = e.extend, q = e.String, r = e.each, x = Array.prototype.slice, y = function (a, b, c, d) {
        var f = a.delegate && a.undelegate ? a : e(j(a) ? [a] : a);
        f.delegate(b, c, d);
        return function () {
            f.undelegate(b, c, d);
            f = a = c = d = b = null
        }
    }, s = function (a, b, c, d) {
        return d ? y(a, d,
            b, c) : v(a, b, c)
    }, m = function (a, b) {
        var c = typeof b == "string" ? a[b] : b;
        return function () {
            a.called = b;
            return c.apply(a, [this.nodeName ? e(this) : this].concat(x.call(arguments, 0)))
        }
    }, z = /\./g, A = /_?controllers?/ig, t = function (a) {
        return q.underscore(a.replace("jQuery.", "").replace(z, "_").replace(A, ""))
    }, B = /[^\w]/, u = /\{([^\}]+)\}/g, C = /^(?:(.*?)\s)?([\w\.\:>]+)$/, n, o = function (a, b) {
        return e.data(a, "controllers", b)
    };
    e.Class("jQuery.Controller", {setup: function () {
        this._super.apply(this, arguments);
        if (!(!this.shortName || this.fullName ==
            "jQuery.Controller")) {
            this._fullName = t(this.fullName);
            this._shortName = t(this.shortName);
            var a = this, b = this.pluginName || this._fullName, c;
            e.fn[b] || (e.fn[b] = function (d) {
                var f = k(arguments), i = typeof d == "string" && j(a.prototype[d]), D = f[0];
                return this.each(function () {
                    var g = o(this);
                    if (g = g && g[b])i ? g[D].apply(g, f.slice(1)) : g.update.apply(g, f); else a.newInstance.apply(a, [this].concat(f))
                })
            });
            this.actions = {};
            for (c in this.prototype)if (!(c == "constructor" || !j(this.prototype[c])))if (this._isAction(c))this.actions[c] =
                this._action(c)
        }
    }, hookup: function (a) {
        return new this(a)
    }, _isAction: function (a) {
        return B.test(a) ? true : e.inArray(a, this.listensTo) > -1 || e.event.special[a] || p[a]
    }, _action: function (a, b) {
        u.lastIndex = 0;
        if (!b && u.test(a))return null;
        a = b ? q.sub(a, [b, window]) : a;
        b = w(a);
        var c = (b ? a[1] : a).match(C);
        return{processor: p[c[2]] || n, parts: c, delegate: b ? a[0] : undefined}
    }, processors: {}, listensTo: [], defaults: {}}, {setup: function (a, b) {
        var c = this.constructor;
        a = (typeof a == "string" ? e(a) : a.jquery ? a : [a])[0];
        var d = c.pluginName || c._fullName;
        this.element = e(a).addClass(d);
        (o(a) || o(a, {}))[d] = this;
        this.options = l(l(true, {}, c.defaults), b);
        this.called = "init";
        this.bind();
        return[this.element, this.options].concat(k(arguments).slice(2))
    }, bind: function (a, b, c) {
        if (a === undefined) {
            this._bindings = [];
            a = this.constructor;
            b = this._bindings;
            c = a.actions;
            var d = this.element;
            for (funcName in c)if (c.hasOwnProperty(funcName)) {
                ready = c[funcName] || a._action(funcName, this.options);
                b.push(ready.processor(ready.delegate || d, ready.parts[2], ready.parts[1], funcName, this))
            }
            var f =
                m(this, "destroy");
            d.bind("destroyed", f);
            b.push(function (i) {
                e(i).unbind("destroyed", f)
            });
            return b.length
        }
        if (typeof a == "string") {
            c = b;
            b = a;
            a = this.element
        }
        return this._binder(a, b, c)
    }, _binder: function (a, b, c, d) {
        if (typeof c == "string")c = m(this, c);
        this._bindings.push(s(a, b, c, d));
        return this._bindings.length
    }, _unbind: function () {
        var a = this.element[0];
        r(this._bindings, function (b, c) {
            c(a)
        });
        this._bindings = []
    }, delegate: function (a, b, c, d) {
        if (typeof a == "string") {
            d = c;
            c = b;
            b = a;
            a = this.element
        }
        return this._binder(a, c, d,
            b)
    }, update: function (a) {
        l(this.options, a);
        this._unbind();
        this.bind()
    }, destroy: function () {
        if (this._destroyed)throw this.constructor.shortName + " controller already deleted";
        var a = this.constructor.pluginName || this.constructor._fullName;
        this._destroyed = true;
        this.element.removeClass(a);
        this._unbind();
        delete this._actions;
        delete this.element.data("controllers")[a];
        e(this).triggerHandler("destroyed");
        this.element = null
    }, find: function (a) {
        return this.element.find(a)
    }, _set_called: true});
    var p = e.Controller.processors;
    n = function (a, b, c, d, f) {
        return s(a, b, m(f, d), c)
    };
    r("change click contextmenu dblclick keydown keyup keypress mousedown mousemove mouseout mouseover mouseup reset resize scroll select submit focusin focusout mouseenter mouseleave".split(" "), function (a, b) {
        p[b] = n
    });
    var h, E = function (a, b) {
        for (h = 0; h < b.length; h++)if (typeof b[h] == "string" ? a.constructor._shortName == b[h] : a instanceof b[h])return true;
        return false
    };
    e.fn.extend({controllers: function () {
        var a = k(arguments), b = [], c, d, f;
        this.each(function () {
            c = e.data(this,
                "controllers");
            for (f in c)if (c.hasOwnProperty(f)) {
                d = c[f];
                if (!a.length || E(d, a))b.push(d)
            }
        });
        return b
    }, controller: function () {
        return this.controllers.apply(this, arguments)[0]
    }})
})(jQuery);
(function () {
    var n = $.String, x = n.getObject, r = n.underscore, C = n.classize, w = $.isArray, y = $.makeArray, s = $.extend, j = $.each, l = function (a, b, c) {
        $.event.trigger(b, c, a, true)
    }, m = function (a, b, c, d, f, e, g) {
        if (typeof a == "string") {
            var h = a.indexOf(" ");
            a = h > -1 ? {url: a.substr(h + 1), type: a.substr(0, h)} : {url: a}
        }
        a.data = typeof b == "object" && !w(b) ? s(a.data || {}, b) : b;
        a.url = n.sub(a.url, a.data, true);
        return $.ajax(s({type: e || "post", dataType: g || "json", fixture: f, success: c, error: d}, a))
    }, o = function (a, b, c) {
        var d = r(a.shortName), f = "-" + d + (b ||
            "");
        return $.fixture && $.fixture[f] ? f : c || "//" + r(a.fullName).replace(/\.models\..*/, "").replace(/\./g, "/") + "/fixtures/" + d + (b || "") + ".json"
    }, D = function (a, b, c) {
        b = b || {};
        a = a.id;
        if (b[a] && b[a] !== c) {
            b["new" + n.capitalize(c)] = b[a];
            delete b[a]
        }
        b[a] = c;
        return b
    }, z = function (a) {
        return new (a || $.Model.List || Array)
    }, t = function (a) {
        return a[a.constructor.id]
    }, E = function (a) {
        var b = [];
        j(a, function (c, d) {
            if (!d["__u Nique"]) {
                b.push(d);
                d["__u Nique"] = 1
            }
        });
        return j(b, function (c, d) {
            delete d["__u Nique"]
        })
    }, A = function (a, b, c, d, f) {
        var e = $.Deferred(), g = [a.serialize(), function (k) {
            a[f || b + "d"](k);
            e.resolveWith(a, [a, k, b])
        }, function (k) {
            e.rejectWith(a, [k])
        }], h = a.constructor, i, p = e.promise();
        b == "destroy" && g.shift();
        b !== "create" && g.unshift(t(a));
        e.then(c);
        e.fail(d);
        if ((i = h[b].apply(h, g)) && i.abort)p.abort = function () {
            i.abort()
        };
        return p
    }, u = function (a) {
        return typeof a === "object" && a !== null && a
    }, q = function (a) {
        return function () {
            return $.fn[a].apply($([this]), arguments)
        }
    }, B = q("bind");
    q = q("unbind");
    ajaxMethods = {create: function (a) {
        return function (b, c, d) {
            return m(a || this._shortName, b, c, d, o(this, "Create", "-restCreate"))
        }
    }, update: function (a) {
        return function (b, c, d, f) {
            return m(a || this._shortName + "/{" + this.id + "}", D(this, c, b), d, f, o(this, "Update", "-restUpdate"), "put")
        }
    }, destroy: function (a) {
        return function (b, c, d) {
            var f = {};
            f[this.id] = b;
            return m(a || this._shortName + "/{" + this.id + "}", f, c, d, o(this, "Destroy", "-restDestroy"), "delete")
        }
    }, findAll: function (a) {
        return function (b, c, d) {
            return m(a || this._shortName, b, c, d, o(this, "s"), "get", "json " + this._shortName + ".models")
        }
    },
        findOne: function (a) {
            return function (b, c, d) {
                return m(a || this._shortName + "/{" + this.id + "}", b, c, d, o(this), "get", "json " + this._shortName + ".model")
            }
        }};
    jQuery.Class("jQuery.Model", {setup: function (a) {
        var b = this, c = this.fullName;
        j(["attributes", "validations"], function (f, e) {
            if (!b[e] || a[e] === b[e])b[e] = {}
        });
        j(["convert", "serialize"], function (f, e) {
            if (a[e] != b[e])b[e] = s({}, a[e], b[e])
        });
        this._fullName = r(c.replace(/\./g, "_"));
        this._shortName = r(this.shortName);
        if (c.indexOf("jQuery") != 0) {
            if (this.listType)this.list = new this.listType([]);
            j(ajaxMethods, function (f, e) {
                var g = b[f];
                if (typeof g !== "function")b[f] = e(g)
            });
            c = {};
            var d = "* " + this._shortName + ".model";
            c[d + "s"] = this.proxy("models");
            c[d] = this.proxy("model");
            $.ajaxSetup({converters: c})
        }
    }, attributes: {}, model: function (a) {
        if (!a)return null;
        if (a instanceof this)a = a.serialize();
        return new this(u(a[this._shortName]) || u(a.data) || u(a.attributes) || a)
    }, models: function (a) {
        if (!a)return null;
        var b = z(this.List), c = w(a), d = $.Model.List;
        d = d && a instanceof d;
        for (var f = (d = c ? a : d ? a.serialize() : a.data) ? d.length :
            null, e = 0; e < f; e++)b.push(this.model(d[e]));
        c || j(a, function (g, h) {
            if (g !== "data")b[g] = h
        });
        return b
    }, id: "id", addAttr: function (a, b) {
        var c = this.attributes;
        c[a] || (c[a] = b);
        return b
    }, convert: {date: function (a) {
        var b = typeof a;
        return b === "string" ? isNaN(Date.parse(a)) ? null : Date.parse(a) : b === "number" ? new Date(a) : a
    }, number: function (a) {
        return parseFloat(a)
    }, "boolean": function (a) {
        return Boolean(a === "false" ? 0 : a)
    }, "default": function (a, b, c) {
        b = x(c);
        var d = window;
        if (c.indexOf(".") >= 0) {
            c = c.substring(0, c.lastIndexOf("."));
            d = x(c)
        }
        return typeof b == "function" ? b.call(d, a) : a
    }}, serialize: {"default": function (a) {
        return u(a) && a.serialize ? a.serialize() : a
    }, date: function (a) {
        return a && a.getTime()
    }}, bind: B, unbind: q, _ajax: m}, {setup: function (a) {
        this._init = true;
        this.attrs(s({}, this.constructor.defaults, a));
        delete this._init
    }, update: function (a, b, c) {
        this.attrs(a);
        return this.save(b, c)
    }, errors: function (a) {
        if (a)a = w(a) ? a : y(arguments);
        var b = {}, c = this, d = function (e, g) {
            j(g, function (h, i) {
                if (h = i.call(c)) {
                    b[e] || (b[e] = []);
                    b[e].push(h)
                }
            })
        }, f = this.constructor.validations;
        j(a || f || {}, function (e, g) {
            if (typeof e == "number") {
                e = g;
                g = f[e]
            }
            d(e, g || [])
        });
        return $.isEmptyObject(b) ? null : b
    }, attr: function (a, b, c, d) {
        var f = C(a), e = "get" + f;
        if (b !== undefined) {
            f = "set" + f;
            e = this[a];
            var g = this, h = function (i) {
                d && d.call(g, i);
                l(g, "error." + a, i)
            };
            if (this[f] && (b = this[f](b, this.proxy("_updateProperty", a, b, e, c, h), h)) === undefined)return;
            this._updateProperty(a, b, e, c, h);
            return this
        }
        return this[e] ? this[e]() : this[a]
    }, bind: B, unbind: q, _updateProperty: function (a, b, c, d, f) {
        var e = this.constructor, g = e.attributes[a] ||
            e.addAttr(a, "string"), h = e.convert[g] || e.convert["default"], i = null, p = "", k = "updated.";
        d = d;
        var v = e.list;
        b = this[a] = b === null ? null : h.call(e, b, function () {
        }, g);
        this._init || (i = this.errors(a));
        g = [b];
        h = [a, b, c];
        if (i) {
            p = k = "error.";
            d = f;
            h.splice(1, 0, i);
            g.unshift(i)
        }
        if (c !== b && !this._init) {
            !i && l(this, p + a, g);
            l(this, k + "attr", h)
        }
        d && d.apply(this, g);
        if (a === e.id && b !== null && v)if (c) {
            if (c != b) {
                v.remove(c);
                v.push(this)
            }
        } else v.push(this)
    }, removeAttr: function (a) {
        var b = this[a], c = false, d = this.constructor.attributes;
        this[a] && delete this[a];
        if (d[a]) {
            delete d[a];
            c = true
        }
        !this._init && c && b && l(this, "updated.attr", [a, null, b])
    }, attrs: function (a) {
        var b, c = this.constructor, d = c.attributes;
        if (a) {
            c = c.id;
            for (b in a)b != c && this.attr(b, a[b]);
            c in a && this.attr(c, a[c])
        } else {
            a = {};
            for (b in d)if (d.hasOwnProperty(b))a[b] = this.attr(b)
        }
        return a
    }, serialize: function () {
        var a = this.constructor, b = a.attributes, c, d, f = {}, e;
        attributes = {};
        for (e in b)if (b.hasOwnProperty(e)) {
            c = b[e];
            d = a.serialize[c] || a.serialize["default"];
            f[e] = d.call(a, this[e], c)
        }
        return f
    }, isNew: function () {
        var a =
            t(this);
        return a === undefined || a === null || a === ""
    }, save: function (a, b) {
        return A(this, this.isNew() ? "create" : "update", a, b)
    }, destroy: function (a, b) {
        return A(this, "destroy", a, b, "destroyed")
    }, identity: function () {
        var a = t(this), b = this.constructor;
        return(b._fullName + "_" + (b.escapeIdentity ? encodeURIComponent(a) : a)).replace(/ /g, "_")
    }, elements: function (a) {
        var b = this.identity();
        if (this.constructor.escapeIdentity)b = b.replace(/([ #;&,.+*~\'%:"!^$[\]()=>|\/])/g, "\\$1");
        return $("." + b, a)
    }, hookup: function (a) {
        var b = this.constructor._shortName,
            c = $.data(a, "models") || $.data(a, "models", {});
        $(a).addClass(b + " " + this.identity());
        c[b] = this
    }});
    j(["created", "updated", "destroyed"], function (a, b) {
        $.Model.prototype[b] = function (c) {
            var d = this.constructor;
            b === "destroyed" && d.list && d.list.remove(t(this));
            c && typeof c == "object" && this.attrs(c.attrs ? c.attrs() : c);
            l(this, b);
            l(d, b, this);
            return[this].concat(y(arguments))
        }
    });
    $.fn.models = function () {
        var a = [], b, c;
        this.each(function () {
            j($.data(this, "models") || {}, function (d, f) {
                b = b === undefined ? f.constructor.List || null :
                    f.constructor.List === b ? b : null;
                a.push(f)
            })
        });
        c = z(b);
        c.push.apply(c, E(a));
        return c
    };
    $.fn.model = function (a) {
        if (a && a instanceof $.Model) {
            a.hookup(this[0]);
            return this
        } else return this.models.apply(this, arguments)[0]
    }
})(jQuery);
(function (a) {
    function h(d) {
        d = d || window[e][i];
        return d.replace(/^[^#]*#?(.*)$/, "$1")
    }

    var k, o = a.event.special, e = "location", i = "href", p = document.documentMode, q = /msie/i.exec(navigator.userAgent) && (p === undefined || p < 8), r = "onhashchange"in window && !q;
    a.hashchangeDelay = 100;
    o.hashchange = a.extend(o.hashchange, {setup: function () {
        if (r)return false;
        a(k.start)
    }, teardown: function () {
        if (r)return false;
        a(k.stop)
    }});
    k = function () {
        function d() {
            f = l = function (b) {
                return b
            };
            if (q) {
                j = a('<iframe src="javascript:0"/>').hide().insertAfter("body")[0].contentWindow;
                l = function () {
                    return h(j.document[e][i])
                };
                f = function (b, c) {
                    if (b !== c) {
                        c = j.document;
                        c.open().close();
                        c[e].hash = "#" + b
                    }
                };
                f(h())
            }
        }

        var m = {}, g, j, f, l;
        m.start = function () {
            if (!g) {
                var b = h();
                f || d();
                navigator.userAgent.match(/Rhino/) || function c() {
                    var s = h(), n = l(b);
                    if (s !== b) {
                        f(b = s, n);
                        a(window).trigger("hashchange")
                    } else if (n !== b)window[e][i] = window[e][i].replace(/#.*/, "") + "#" + n;
                    g = setTimeout(c, a.hashchangeDelay)
                }()
            }
        };
        m.stop = function () {
            if (!j) {
                g && clearTimeout(g);
                g = 0
            }
        };
        return m
    }()
})(jQuery);
(function () {
    var k = $.isArray, h = function (a) {
        return typeof a === "object" && a !== null && a
    }, l = $.makeArray, o = $.each, q = function (a, c, b) {
        if (a instanceof $.Observe)p([a], b._namespace); else a = k(a) ? new $.Observe.List(a) : new $.Observe(a);
        a.bind("change" + b._namespace, function (d) {
            var e = $.makeArray(arguments);
            d = e.shift();
            e[0] = c === "*" ? b.indexOf(a) + "." + e[0] : c + "." + e[0];
            $.event.trigger(d, e, b)
        });
        return a
    }, p = function (a, c) {
        for (var b, d = 0; d < a.length; d++)(b = a[d]) && b.unbind && b.unbind("change" + c)
    }, s = 0, j = null, t = function () {
        if (!j) {
            j =
                [];
            return true
        }
    }, g = function (a, c, b) {
        if (!a._init)if (j)j.push({t: a, ev: c, args: b}); else return $.event.trigger(c, b, a, true)
    }, u = 0, v = function () {
        var a = j.length, c = j.slice(0), b;
        j = null;
        u++;
        for (var d = 0; d < a; d++) {
            b = c[d];
            $.event.trigger({type: b.ev, batchNum: u}, b.args, b.t)
        }
    }, m = function (a, c, b) {
        a.each(function (d, e) {
            b[d] = h(e) && typeof e[c] == "function" ? e[c]() : e
        });
        return b
    };
    $.Class("jQuery.Observe", {init: function (a) {
        this._data = {};
        this._namespace = ".observe" + ++s;
        this._init = true;
        this.attrs(a);
        delete this._init
    }, attr: function (a, c) {
        if (c === undefined)return this._get(a); else {
            this._set(a, c);
            return this
        }
    }, each: function () {
        return o.apply(null, [this.__get()].concat(l(arguments)))
    }, removeAttr: function (a) {
        a = k(a) ? a : a.split(".");
        var c = a.shift(), b = this._data[c];
        if (a.length)return b.removeAttr(a); else {
            delete this._data[c];
            g(this, "change", [c, "remove", undefined, b]);
            return b
        }
    }, _get: function (a) {
        a = k(a) ? a : ("" + a).split(".");
        var c = this.__get(a.shift());
        return a.length ? c ? c._get(a) : undefined : c
    }, __get: function (a) {
        return a ? this._data[a] : this._data
    },
        _set: function (a, c) {
            var b = k(a) ? a : ("" + a).split(".");
            a = b.shift();
            var d = this.__get(a);
            if (h(d) && b.length)d._set(b, c); else if (b.length)throw"jQuery.Observe: set a property on an object that does not exist"; else if (c !== d) {
                b = this.__get().hasOwnProperty(a) ? "set" : "add";
                this.__set(a, h(c) ? q(c, a, this) : c);
                g(this, "change", [a, b, c, d]);
                d && p([d], this._namespace)
            }
        }, __set: function (a, c) {
            this._data[a] = c;
            a in this.constructor.prototype || (this[a] = c)
        }, bind: function () {
            $.fn.bind.apply($([this]), arguments);
            return this
        }, unbind: function () {
            $.fn.unbind.apply($([this]),
                arguments);
            return this
        }, serialize: function () {
            return m(this, "serialize", {})
        }, attrs: function (a, c) {
            if (a === undefined)return m(this, "attrs", {});
            a = $.extend(true, {}, a);
            var b, d = t();
            for (b in this._data) {
                var e = this._data[b], f = a[b];
                if (f === undefined)c && this.removeAttr(b); else {
                    if (h(e) && h(f))e.attrs(f, c); else e != f && this._set(b, f);
                    delete a[b]
                }
            }
            for (b in a) {
                f = a[b];
                this._set(b, f)
            }
            d && v()
        }});
    var r = jQuery.Observe("jQuery.Observe.List", {init: function (a, c) {
        this.length = 0;
        this._namespace = ".list" + ++s;
        this._init = true;
        this.bind("change",
            this.proxy("_changes"));
        this.push.apply(this, l(a || []));
        $.extend(this, c);
        this.comparator && this.sort();
        delete this._init
    }, _changes: function (a, c, b, d, e) {
        if (this.comparator && /^\d+./.test(c)) {
            var f = +/^\d+/.exec(c)[0], i = this[f], n = this.sortedIndex(i);
            if (n !== f) {
                [].splice.call(this, f, 1);
                [].splice.call(this, n, 0, i);
                g(this, "move", [i, n, f]);
                a.stopImmediatePropagation();
                g(this, "change", [c.replace(/^\d+/, n), b, d, e]);
                return
            }
        }
        if (c.indexOf(".") === -1)if (b === "add")g(this, b, [d, +c]); else b === "remove" && g(this, b, [e, +c])
    }, sortedIndex: function (a) {
        var c =
            a.attr(this.comparator), b = 0, d;
        for (d = 0; d < this.length; d++)if (a === this[d])b = -1; else if (c <= this[d].attr(this.comparator))return d + b;
        return d + b
    }, __get: function (a) {
        return a ? this[a] : this
    }, __set: function (a, c) {
        this[a] = c
    }, serialize: function () {
        return m(this, "serialize", [])
    }, splice: function (a, c) {
        var b = l(arguments), d;
        for (d = 2; d < b.length; d++) {
            var e = b[d];
            if (h(e))b[d] = q(e, "*", this)
        }
        if (c === undefined)c = b[1] = this.length - a;
        d = [].splice.apply(this, b);
        if (c > 0) {
            g(this, "change", ["" + a, "remove", undefined, d]);
            p(d, this._namespace)
        }
        b.length >
            2 && g(this, "change", ["" + a, "add", b.slice(2), d]);
        return d
    }, attrs: function (a, c) {
        if (a === undefined)return m(this, "attrs", []);
        a = a.slice(0);
        for (var b = Math.min(a.length, this.length), d = t(), e = 0; e < b; e++) {
            var f = this[e], i = a[e];
            if (h(f) && h(i))f.attrs(i, c); else f != i && this._set(e, i)
        }
        if (a.length > this.length)this.push(a.slice(this.length)); else a.length < this.length && c && this.splice(a.length);
        d && v()
    }, sort: function (a, c) {
        var b = this.comparator;
        [].sort.apply(this, b ? [function (d, e) {
            d = d[b];
            e = e[b];
            return d === e ? 0 : d < e ? -1 : 1
        }] : []);
        !c && g(this, "reset")
    }}), w = function (a) {
        return a[0] && $.isArray(a[0]) ? a[0] : l(a)
    };
    o({push: "length", unshift: 0}, function (a, c) {
        r.prototype[a] = function () {
            for (var b = w(arguments), d = c ? this.length : 0, e = 0; e < b.length; e++) {
                var f = b[e];
                if (h(f))b[e] = q(f, "*", this)
            }
            if (b.length == 1 && this.comparator) {
                this.splice(this.sortedIndex(b[0]), 0, b[0]);
                return this.length
            }
            e = [][a].apply(this, b);
            if (this.comparator && b.length > 1) {
                this.sort(null, true);
                g(this, "reset", [b])
            } else g(this, "change", ["" + d, "add", b, undefined]);
            return e
        }
    });
    o({pop: "length",
        shift: 0}, function (a, c) {
        r.prototype[a] = function () {
            var b = w(arguments), d = c && this.length ? this.length - 1 : 0;
            b = [][a].apply(this, b);
            g(this, "change", ["" + d, "remove", undefined, [b]]);
            b && b.unbind && b.unbind("change" + this._namespace);
            return b
        }
    });
    r.prototype.indexOf = [].indexOf || function (a) {
        return $.inArray(a, this)
    };
    $.O = function (a, c) {
        return k(a) || a instanceof $.Observe.List ? new $.Observe.List(a, c) : new $.Observe(a, c)
    }
})(jQuery);
(function (f) {
    var k = /^\d+$/, l = /([^\[\]]+)|(\[\])/g, i = /\+/g, m = /([^?#]*)(#.*)?$/;
    f.String = f.extend(f.String || {}, {deparam: function (d) {
        if (!d || !m.test(d))return{};
        var j = {};
        d = d.split("&");
        for (var c, g = 0; g < d.length; g++) {
            c = j;
            var a = d[g].split("=");
            if (a.length != 2)a = [a[0], a.slice(1).join("=")];
            var b = decodeURIComponent(a[0].replace(i, " "));
            a = decodeURIComponent(a[1].replace(i, " "));
            b = b.match(l);
            for (var e = 0; e < b.length - 1; e++) {
                var h = b[e];
                c[h] || (c[h] = k.test(b[e + 1]) || b[e + 1] == "[]" ? [] : {});
                c = c[h]
            }
            lastPart = b[b.length - 1];
            if (lastPart == "[]")c.push(a); else c[lastPart] = a
        }
        return j
    }})
})(jQuery);
(function (b) {
    var o = /\:([\w\.]+)/g, p = /^(?:&[^=]+=[^&]*)+/, t = function (a) {
        var c = [];
        j(a, function (d, e) {
            if (d === "className")d = "class";
            e && c.push(q(d), '="', q(e), '" ')
        });
        return c.join("")
    }, q = function (a) {
        return a.replace(/"/g, "&#34;").replace(/'/g, "&#39;")
    }, u = function (a, c) {
        for (var d = 0, e = 0; e < a.names.length; e++) {
            if (!c.hasOwnProperty(a.names[e]))return-1;
            d++
        }
        return d
    }, r = true, k = window.location, v = encodeURIComponent, w = decodeURIComponent, j = b.each, l = b.extend;
    b.route = function (a, c) {
        var d = [], e = a.replace(o, function (f, h) {
            d.push(h);
            return"([^\\/\\&]*)"
        });
        b.route.routes[a] = {test: new RegExp("^" + e + "($|&)"), route: a, names: d, defaults: c || {}, length: a.split("/").length};
        return b.route
    };
    l(b.route, {param: function (a) {
        var c, d = 0, e, f = a.route;
        delete a.route;
        f && (c = b.route.routes[f]) || j(b.route.routes, function (m, i) {
            e = u(i, a);
            if (e > d) {
                c = i;
                d = e
            }
        });
        if (c) {
            var h = l({}, a);
            f = c.route.replace(o, function (m, i) {
                delete h[i];
                return a[i] === c.defaults[i] ? "" : v(a[i])
            });
            var g;
            j(c.defaults, function (m, i) {
                h[m] === i && delete h[m]
            });
            g = b.param(h);
            return f + (g ? "&" + g : "")
        }
        return b.isEmptyObject(a) ?
            "" : "&" + b.param(a)
    }, deparam: function (a) {
        var c = {length: -1};
        j(b.route.routes, function (h, g) {
            if (g.test.test(a) && g.length > c.length)c = g
        });
        if (c.length > -1) {
            var d = a.match(c.test), e = d.shift(), f = (e = a.substr(e.length - (d[d.length - 1] === "&" ? 1 : 0))) && p.test(e) ? b.String.deparam(e.slice(1)) : {};
            f = l(true, {}, c.defaults, f);
            j(d, function (h, g) {
                if (g && g !== "&")f[c.names[h]] = w(g)
            });
            f.route = c.route;
            return f
        }
        if (a.charAt(0) !== "&")a = "&" + a;
        return p.test(a) ? b.String.deparam(a.slice(1)) : {}
    }, data: new b.Observe({}), routes: {}, ready: function (a) {
        if (a === false)
            r = false;
        try {
            if (a === true || r === true)s();
        } catch (e) {
//               console.log('jquery和requirejs冲突，使用try语法解决')
        }
        return b.route
    }, url: function (a, c) {
        return c ? "#!" + b.route.param(l({}, n, a)) : "#!" + b.route.param(a)
    }, link: function (a, c, d, e) {
        return"<a " + t(l({href: b.route.url(c, e)}, d)) + ">" + a + "</a>"
    }, current: function (a) {
        return k.hash == "#!" + b.route.param(a)
    }});
    b(function () {
        b.route.ready()
    });
    j(["bind", "unbind", "delegate", "undelegate", "attr", "attrs", "serialize", "removeAttr"], function (a, c) {
        b.route[c] = function () {
            return b.route.data[c].apply(b.route.data, arguments)
        }
    });
    var n, s = function () {
        var a =
            k.hash.substr(1, 1) === "!" ? k.hash.slice(2) : k.hash.slice(1);
        n = b.route.deparam(a);
        b.route.attrs(n, true)
    };
    b(window).bind("hashchange", s);
    b.route.bind("change", function (a) {
        var c;
        return function () {
            var d = arguments, e = this;
            clearTimeout(c);
            c = setTimeout(function () {
                a.apply(e, d)
            }, 1)
        }
    }(function () {
        k.hash = "#!" + b.route.param(b.route.serialize())
    }))
})(jQuery);

define("jquerymx", ["jquery"], function(){});

/**
 * @COPYRIGHT Shanghai RaxTone-Tech Co.,Ltd.
 * @Title:
 * @Description:
 * @author wangyonggang qq:135274859
 * @date 13-7-18 上午10:39
 * @version V1.0
 * Modification History:
 */
//history event controller using hash
define('historyController',['jquerymx'], function () {
        $.Controller("FlySharedHistory", {
        defaults: {
            ini: true
        }
    }, {
        init: function () {
        },
        //called when hash = #share
        share: function () {
            if (this.options.ini) {
                this.options.ini = false;
                return;
            }
            common.recoverEleState();
            mapHandler.recoverMapState();
        },
        //    todo only keep map init state, cancel comments if all states valid
        requestPath: function () {
            this.options.ini = false;
        },
        // listen for history changes
        "{window} hashchange": function (ev) {
            try {
                var hash = window.location.hash.slice(1);
                this[hash]();
            } catch (e) {
                console.log(e.stack)
                this.share()
            }
        }
    });
    return FlySharedHistory;
});
/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 1/11/13
 * Time: 7:04 PM
 * Use:
 */
/*todo 调试相关：
 *  localStorage['flyway_info']
 *  mapHandler.attr('curInfo', {
 lng:0,
 lat:0
 });
 mapHandler.curMarker.setVisible(true)
 requestPath.pushGPSLogLatLon()
 mapHandler.mapObj.setZoom(10)
 * */
define('controllerMap',['jquerymx'], function () {
    $.Controller('MapControl', {
        init: function () {
        },
        '#positioning touchstart': function (el) {
            el.addClass('active');
            if (!mapHandler.gpsState) {
                mapHandler.getNoGps();
                return;
            }
            mapHandler.mapObj.panTo(new AMap.LngLat(mapHandler.curInfo.lng, mapHandler.curInfo.lat));
        },
        '#positioning touchend': function (el) {
            el.removeClass('active');
        },
        '#positioning touchmove': function (el) {
            el.trigger('touchend');
        },
        '#positionLight touchstart': function () {
            mapHandler.getNoGps();
        },
        '#zoom_in touchstart': function (el) {
            if (!el.hasClass('gray')) {
                el.addClass('active');
            }
        },
        '#zoom_in touchmove': function (el) {
            el.trigger('touchend');
        },
        '#zoom_in touchend': function () {
            if (!scale.isMaxScale()) {
                var level = scale.level ? scale.level + 1 : mapHandler.mapObj.getZoom() + 1;
                scale.attr('level', level);
            }
        },
        '#zoom_out touchstart': function (el) {
            if (!el.hasClass('gray')) {
                el.addClass('active');
            }
        },
        '#zoom_out touchend': function () {
            if (!scale.isMinScale()) {
                var level = scale.level ? scale.level - 1 : mapHandler.mapObj.getZoom() - 1;
                scale.attr('level', level);
            }
        },
        '#zoom_out touchmove': function (el) {
            el.trigger('touchend');
        } ,
        setZoomBtnUi:function() {
            if (scale.isMaxScale()) {
                mapHandler.zoom_in.removeClass('active').addClass('gray');
            } else {
                mapHandler.zoom_in.removeClass('active');
                if (mapHandler.zoom_in.hasClass('gray')) {
                    mapHandler.zoom_in.removeClass('gray');
                }
            }
            if (scale.isMinScale()) {
                mapHandler.zoom_out.removeClass('active').addClass('gray');
            } else {
                mapHandler.zoom_out.removeClass('active');
                if (mapHandler.zoom_out.hasClass('gray')) {
                    mapHandler.zoom_out.removeClass('gray');
                }
            }
        }
    });
});

/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 8/5/13
 * Time: 1:28 PM
 * Use:
 */
/*
* 监听本地缓存文件是否更新, can't cache!
*
* @module no name
* */
define('cache',[], function () {
    function updateCache() {
        applicationCache.addEventListener('updateready', function (e) {
            applicationCache.swapCache();
            location.reload()
        }, false);
    }
    updateCache()
    require(['scripts/lib/mapApi.js'])
})
;
/**
 * Created with JetBrains WebStorm.
 * User: mac
 * Date: 13-1-13
 * Time: 下午9:25
 * To change this template use File | Settings | File Templates.
 */
define('mapUtil',['jquerymx'], function () {
    /**
     A utility that public model
     @class PublicModel
     @constructor
     **/
    $.Class('PublicModel', {
        /**
         The method is Determine whether the mobile device
         @method isMobileDev.
         @return {Boolean}
         **/
        isMobileDev: function () {
            var u = navigator.userAgent;
            return  /AppleWebKit.*Mobile/.test(u);
        },
        /**
         The method is Determine whether the ios device
         @method isIOS.
         @return {Boolean}
         **/
        isIOS: function () {
            return /(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)
        },
        /**
         The method is Determine whether the qq browser
         @method isQqBrowser.
         @return {Boolean}
         **/
        isQqBrowser: function () {
            return /QQBrowser/i.test(navigator.userAgent);
        },
        isNativeBrowserOfLenovo:function(){
          return /Lenovo/i.test(navigator.userAgent)
        },
        getOrientationProp: function () {
            var supportsOrientationChange = "onorientationchange" in window;
            var orientationEvent = supportsOrientationChange ? "orientationchange" : "resize";
            return orientationEvent;
        },
        // Simple JavaScript Templating
// by John Resig - http://ejohn.org/ - MIT Licensed
        /**
         The method is build string by tmpl
         @method buildEleStrByTmpl.
         @return {Function}
         **/
        buildEleStrByTmpl: function (str, data) {
            var cache = {};

            return (function template(str, data) {
                // Figure out if we're getting a template, or if we need to
                // load the template - and be sure to cache the result.
                var fn = !/\W/.test(str) ?
                    cache[str] = cache[str] ||
                        template(document.getElementById(str).innerHTML) :

                    // Generate a reusable function that will serve as a template
                    // generator (and which will be cached).
                    new Function("obj",
                        "var p=[],print=function(){p.push.apply(p,arguments);};" +

                            // Introduce the data as local variables using with(){}
                            "with(obj){p.push('" +

                            // Convert the template into pure JavaScript
                            str
                                .replace(/[\r\t\n]/g, " ")
                                .split("<%").join("\t")
                                .replace(/((^|%>)[^\t]*)'/g, "$1\r")
                                .replace(/\t=(.*?)%>/g, "',$1,'")
                                .split("\t").join("');")
                                .split("%>").join("p.push('")
                                .split("\r").join("\\'")
                            + "');}return p.join('');");

                // Provide some basic currying to the user
                return data ? fn(data) : fn;
            })(str, data);
        }
    });
    return PublicModel

});
/*!
 * iScroll v4.2.5 ~ Copyright (c) 2012 Matteo Spinelli, http://cubiq.org
 * Released under MIT license, http://cubiq.org/license
 */
(function(window, doc){
var m = Math,
	dummyStyle = doc.createElement('div').style,
	vendor = (function () {
		var vendors = 't,webkitT,MozT,msT,OT'.split(','),
			t,
			i = 0,
			l = vendors.length;

		for ( ; i < l; i++ ) {
			t = vendors[i] + 'ransform';
			if ( t in dummyStyle ) {
				return vendors[i].substr(0, vendors[i].length - 1);
			}
		}

		return false;
	})(),
	cssVendor = vendor ? '-' + vendor.toLowerCase() + '-' : '',

	// Style properties
	transform = prefixStyle('transform'),
	transitionProperty = prefixStyle('transitionProperty'),
	transitionDuration = prefixStyle('transitionDuration'),
	transformOrigin = prefixStyle('transformOrigin'),
	transitionTimingFunction = prefixStyle('transitionTimingFunction'),
	transitionDelay = prefixStyle('transitionDelay'),

    // Browser capabilities
	isAndroid = (/android/gi).test(navigator.appVersion),
	isIDevice = (/iphone|ipad/gi).test(navigator.appVersion),
	isTouchPad = (/hp-tablet/gi).test(navigator.appVersion),

    has3d = prefixStyle('perspective') in dummyStyle,
    hasTouch = 'ontouchstart' in window && !isTouchPad,
    hasTransform = vendor !== false,
    hasTransitionEnd = prefixStyle('transition') in dummyStyle,

	RESIZE_EV = 'onorientationchange' in window ? 'orientationchange' : 'resize',
	START_EV = hasTouch ? 'touchstart' : 'mousedown',
	MOVE_EV = hasTouch ? 'touchmove' : 'mousemove',
	END_EV = hasTouch ? 'touchend' : 'mouseup',
	CANCEL_EV = hasTouch ? 'touchcancel' : 'mouseup',
	TRNEND_EV = (function () {
		if ( vendor === false ) return false;

		var transitionEnd = {
				''			: 'transitionend',
				'webkit'	: 'webkitTransitionEnd',
				'Moz'		: 'transitionend',
				'O'			: 'otransitionend',
				'ms'		: 'MSTransitionEnd'
			};

		return transitionEnd[vendor];
	})(),

	nextFrame = (function() {
		return window.requestAnimationFrame ||
			window.webkitRequestAnimationFrame ||
			window.mozRequestAnimationFrame ||
			window.oRequestAnimationFrame ||
			window.msRequestAnimationFrame ||
			function(callback) { return setTimeout(callback, 1); };
	})(),
	cancelFrame = (function () {
		return window.cancelRequestAnimationFrame ||
			window.webkitCancelAnimationFrame ||
			window.webkitCancelRequestAnimationFrame ||
			window.mozCancelRequestAnimationFrame ||
			window.oCancelRequestAnimationFrame ||
			window.msCancelRequestAnimationFrame ||
			clearTimeout;
	})(),

	// Helpers
	translateZ = has3d ? ' translateZ(0)' : '',

	// Constructor
	iScroll = function (el, options) {
		var that = this,
			i;

		that.wrapper = typeof el == 'object' ? el : doc.getElementById(el);
		that.wrapper.style.overflow = 'hidden';
		that.scroller = that.wrapper.children[0];

		// Default options
		that.options = {
			hScroll: true,
			vScroll: true,
			x: 0,
			y: 0,
			bounce: true,
			bounceLock: false,
			momentum: true,
			lockDirection: true,
			useTransform: true,
			useTransition: false,
			topOffset: 0,
			checkDOMChanges: false,		// Experimental
			handleClick: true,

			// Scrollbar
			hScrollbar: true,
			vScrollbar: true,
			fixedScrollbar: isAndroid,
			hideScrollbar: isIDevice,
			fadeScrollbar: isIDevice && has3d,
			scrollbarClass: '',

			// Zoom
			zoom: false,
			zoomMin: 1,
			zoomMax: 4,
			doubleTapZoom: 2,
			wheelAction: 'scroll',

			// Snap
			snap: false,
			snapThreshold: 1,

			// Events
			onRefresh: null,
			onBeforeScrollStart: function (e) { e.preventDefault(); },
			onScrollStart: null,
			onBeforeScrollMove: null,
			onScrollMove: null,
			onBeforeScrollEnd: null,
			onScrollEnd: null,
			onTouchEnd: null,
			onDestroy: null,
			onZoomStart: null,
			onZoom: null,
			onZoomEnd: null
		};

		// User defined options
		for (i in options) that.options[i] = options[i];
		
		// Set starting position
		that.x = that.options.x;
		that.y = that.options.y;

		// Normalize options
		that.options.useTransform = hasTransform && that.options.useTransform;
		that.options.hScrollbar = that.options.hScroll && that.options.hScrollbar;
		that.options.vScrollbar = that.options.vScroll && that.options.vScrollbar;
		that.options.zoom = that.options.useTransform && that.options.zoom;
		that.options.useTransition = hasTransitionEnd && that.options.useTransition;

		// Helpers FIX ANDROID BUG!
		// translate3d and scale doesn't work together!
		// Ignoring 3d ONLY WHEN YOU SET that.options.zoom
		if ( that.options.zoom && isAndroid ){
			translateZ = '';
		}
		
		// Set some default styles
		that.scroller.style[transitionProperty] = that.options.useTransform ? cssVendor + 'transform' : 'top left';
		that.scroller.style[transitionDuration] = '0';
		that.scroller.style[transformOrigin] = '0 0';
		if (that.options.useTransition) that.scroller.style[transitionTimingFunction] = 'cubic-bezier(0.33,0.66,0.66,1)';
		
		if (that.options.useTransform) that.scroller.style[transform] = 'translate(' + that.x + 'px,' + that.y + 'px)' + translateZ;
		else that.scroller.style.cssText += ';position:absolute;top:' + that.y + 'px;left:' + that.x + 'px';

		if (that.options.useTransition) that.options.fixedScrollbar = true;

		that.refresh();

		that._bind(RESIZE_EV, window);
		that._bind(START_EV);
		if (!hasTouch) {
			if (that.options.wheelAction != 'none') {
				that._bind('DOMMouseScroll');
				that._bind('mousewheel');
			}
		}

		if (that.options.checkDOMChanges) that.checkDOMTime = setInterval(function () {
			that._checkDOMChanges();
		}, 500);
	};

// Prototype
iScroll.prototype = {
	enabled: true,
	x: 0,
	y: 0,
	steps: [],
	scale: 1,
	currPageX: 0, currPageY: 0,
	pagesX: [], pagesY: [],
	aniTime: null,
	wheelZoomCount: 0,
	
	handleEvent: function (e) {
		var that = this;
		switch(e.type) {
			case START_EV:
				if (!hasTouch && e.button !== 0) return;
				that._start(e);
				break;
			case MOVE_EV: that._move(e); break;
			case END_EV:
			case CANCEL_EV: that._end(e); break;
			case RESIZE_EV: that._resize(); break;
			case 'DOMMouseScroll': case 'mousewheel': that._wheel(e); break;
			case TRNEND_EV: that._transitionEnd(e); break;
		}
	},
	
	_checkDOMChanges: function () {
		if (this.moved || this.zoomed || this.animating ||
			(this.scrollerW == this.scroller.offsetWidth * this.scale && this.scrollerH == this.scroller.offsetHeight * this.scale)) return;

		this.refresh();
	},
	
	_scrollbar: function (dir) {
		var that = this,
			bar;

		if (!that[dir + 'Scrollbar']) {
			if (that[dir + 'ScrollbarWrapper']) {
				if (hasTransform) that[dir + 'ScrollbarIndicator'].style[transform] = '';
				that[dir + 'ScrollbarWrapper'].parentNode.removeChild(that[dir + 'ScrollbarWrapper']);
				that[dir + 'ScrollbarWrapper'] = null;
				that[dir + 'ScrollbarIndicator'] = null;
			}

			return;
		}

		if (!that[dir + 'ScrollbarWrapper']) {
			// Create the scrollbar wrapper
			bar = doc.createElement('div');

			if (that.options.scrollbarClass) bar.className = that.options.scrollbarClass + dir.toUpperCase();
			else bar.style.cssText = 'position:absolute;z-index:100;' + (dir == 'h' ? 'height:7px;bottom:1px;left:2px;right:' + (that.vScrollbar ? '7' : '2') + 'px' : 'width:7px;bottom:' + (that.hScrollbar ? '7' : '2') + 'px;top:2px;right:1px');

			bar.style.cssText += ';pointer-events:none;' + cssVendor + 'transition-property:opacity;' + cssVendor + 'transition-duration:' + (that.options.fadeScrollbar ? '350ms' : '0') + ';overflow:hidden;opacity:' + (that.options.hideScrollbar ? '0' : '1');

			that.wrapper.appendChild(bar);
			that[dir + 'ScrollbarWrapper'] = bar;

			// Create the scrollbar indicator
			bar = doc.createElement('div');
			if (!that.options.scrollbarClass) {
				bar.style.cssText = 'position:absolute;z-index:100;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);' + cssVendor + 'background-clip:padding-box;' + cssVendor + 'box-sizing:border-box;' + (dir == 'h' ? 'height:100%' : 'width:100%') + ';' + cssVendor + 'border-radius:3px;border-radius:3px';
			}
			bar.style.cssText += ';pointer-events:none;' + cssVendor + 'transition-property:' + cssVendor + 'transform;' + cssVendor + 'transition-timing-function:cubic-bezier(0.33,0.66,0.66,1);' + cssVendor + 'transition-duration:0;' + cssVendor + 'transform: translate(0,0)' + translateZ;
			if (that.options.useTransition) bar.style.cssText += ';' + cssVendor + 'transition-timing-function:cubic-bezier(0.33,0.66,0.66,1)';

			that[dir + 'ScrollbarWrapper'].appendChild(bar);
			that[dir + 'ScrollbarIndicator'] = bar;
		}

		if (dir == 'h') {
			that.hScrollbarSize = that.hScrollbarWrapper.clientWidth;
			that.hScrollbarIndicatorSize = m.max(m.round(that.hScrollbarSize * that.hScrollbarSize / that.scrollerW), 8);
			that.hScrollbarIndicator.style.width = that.hScrollbarIndicatorSize + 'px';
			that.hScrollbarMaxScroll = that.hScrollbarSize - that.hScrollbarIndicatorSize;
			that.hScrollbarProp = that.hScrollbarMaxScroll / that.maxScrollX;
		} else {
			that.vScrollbarSize = that.vScrollbarWrapper.clientHeight;
			that.vScrollbarIndicatorSize = m.max(m.round(that.vScrollbarSize * that.vScrollbarSize / that.scrollerH), 8);
			that.vScrollbarIndicator.style.height = that.vScrollbarIndicatorSize + 'px';
			that.vScrollbarMaxScroll = that.vScrollbarSize - that.vScrollbarIndicatorSize;
			that.vScrollbarProp = that.vScrollbarMaxScroll / that.maxScrollY;
		}

		// Reset position
		that._scrollbarPos(dir, true);
	},
	
	_resize: function () {
		var that = this;
		setTimeout(function () { that.refresh(); }, isAndroid ? 200 : 0);
	},
	
	_pos: function (x, y) {
		if (this.zoomed) return;

		x = this.hScroll ? x : 0;
		y = this.vScroll ? y : 0;

		if (this.options.useTransform) {
			this.scroller.style[transform] = 'translate(' + x + 'px,' + y + 'px) scale(' + this.scale + ')' + translateZ;
		} else {
			x = m.round(x);
			y = m.round(y);
			this.scroller.style.left = x + 'px';
			this.scroller.style.top = y + 'px';
		}

		this.x = x;
		this.y = y;

		this._scrollbarPos('h');
		this._scrollbarPos('v');
	},

	_scrollbarPos: function (dir, hidden) {
		var that = this,
			pos = dir == 'h' ? that.x : that.y,
			size;

		if (!that[dir + 'Scrollbar']) return;

		pos = that[dir + 'ScrollbarProp'] * pos;

		if (pos < 0) {
			if (!that.options.fixedScrollbar) {
				size = that[dir + 'ScrollbarIndicatorSize'] + m.round(pos * 3);
				if (size < 8) size = 8;
				that[dir + 'ScrollbarIndicator'].style[dir == 'h' ? 'width' : 'height'] = size + 'px';
			}
			pos = 0;
		} else if (pos > that[dir + 'ScrollbarMaxScroll']) {
			if (!that.options.fixedScrollbar) {
				size = that[dir + 'ScrollbarIndicatorSize'] - m.round((pos - that[dir + 'ScrollbarMaxScroll']) * 3);
				if (size < 8) size = 8;
				that[dir + 'ScrollbarIndicator'].style[dir == 'h' ? 'width' : 'height'] = size + 'px';
				pos = that[dir + 'ScrollbarMaxScroll'] + (that[dir + 'ScrollbarIndicatorSize'] - size);
			} else {
				pos = that[dir + 'ScrollbarMaxScroll'];
			}
		}

		that[dir + 'ScrollbarWrapper'].style[transitionDelay] = '0';
		that[dir + 'ScrollbarWrapper'].style.opacity = hidden && that.options.hideScrollbar ? '0' : '1';
		that[dir + 'ScrollbarIndicator'].style[transform] = 'translate(' + (dir == 'h' ? pos + 'px,0)' : '0,' + pos + 'px)') + translateZ;
	},
	
	_start: function (e) {
		var that = this,
			point = hasTouch ? e.touches[0] : e,
			matrix, x, y,
			c1, c2;

		if (!that.enabled) return;

		if (that.options.onBeforeScrollStart) that.options.onBeforeScrollStart.call(that, e);

		if (that.options.useTransition || that.options.zoom) that._transitionTime(0);

		that.moved = false;
		that.animating = false;
		that.zoomed = false;
		that.distX = 0;
		that.distY = 0;
		that.absDistX = 0;
		that.absDistY = 0;
		that.dirX = 0;
		that.dirY = 0;

		// Gesture start
		if (that.options.zoom && hasTouch && e.touches.length > 1) {
			c1 = m.abs(e.touches[0].pageX-e.touches[1].pageX);
			c2 = m.abs(e.touches[0].pageY-e.touches[1].pageY);
			that.touchesDistStart = m.sqrt(c1 * c1 + c2 * c2);

			that.originX = m.abs(e.touches[0].pageX + e.touches[1].pageX - that.wrapperOffsetLeft * 2) / 2 - that.x;
			that.originY = m.abs(e.touches[0].pageY + e.touches[1].pageY - that.wrapperOffsetTop * 2) / 2 - that.y;

			if (that.options.onZoomStart) that.options.onZoomStart.call(that, e);
		}

		if (that.options.momentum) {
			if (that.options.useTransform) {
				// Very lame general purpose alternative to CSSMatrix
				matrix = getComputedStyle(that.scroller, null)[transform].replace(/[^0-9\-.,]/g, '').split(',');
				x = +(matrix[12] || matrix[4]);
				y = +(matrix[13] || matrix[5]);
			} else {
				x = +getComputedStyle(that.scroller, null).left.replace(/[^0-9-]/g, '');
				y = +getComputedStyle(that.scroller, null).top.replace(/[^0-9-]/g, '');
			}
			
			if (x != that.x || y != that.y) {
				if (that.options.useTransition) that._unbind(TRNEND_EV);
				else cancelFrame(that.aniTime);
				that.steps = [];
				that._pos(x, y);
				if (that.options.onScrollEnd) that.options.onScrollEnd.call(that);
			}
		}

		that.absStartX = that.x;	// Needed by snap threshold
		that.absStartY = that.y;

		that.startX = that.x;
		that.startY = that.y;
		that.pointX = point.pageX;
		that.pointY = point.pageY;

		that.startTime = e.timeStamp || Date.now();

		if (that.options.onScrollStart) that.options.onScrollStart.call(that, e);

		that._bind(MOVE_EV, window);
		that._bind(END_EV, window);
		that._bind(CANCEL_EV, window);
	},
	
	_move: function (e) {
		var that = this,
			point = hasTouch ? e.touches[0] : e,
			deltaX = point.pageX - that.pointX,
			deltaY = point.pageY - that.pointY,
			newX = that.x + deltaX,
			newY = that.y + deltaY,
			c1, c2, scale,
			timestamp = e.timeStamp || Date.now();

		if (that.options.onBeforeScrollMove) that.options.onBeforeScrollMove.call(that, e);

		// Zoom
		if (that.options.zoom && hasTouch && e.touches.length > 1) {
			c1 = m.abs(e.touches[0].pageX - e.touches[1].pageX);
			c2 = m.abs(e.touches[0].pageY - e.touches[1].pageY);
			that.touchesDist = m.sqrt(c1*c1+c2*c2);

			that.zoomed = true;

			scale = 1 / that.touchesDistStart * that.touchesDist * this.scale;

			if (scale < that.options.zoomMin) scale = 0.5 * that.options.zoomMin * Math.pow(2.0, scale / that.options.zoomMin);
			else if (scale > that.options.zoomMax) scale = 2.0 * that.options.zoomMax * Math.pow(0.5, that.options.zoomMax / scale);

			that.lastScale = scale / this.scale;

			newX = this.originX - this.originX * that.lastScale + this.x,
			newY = this.originY - this.originY * that.lastScale + this.y;

			this.scroller.style[transform] = 'translate(' + newX + 'px,' + newY + 'px) scale(' + scale + ')' + translateZ;

			if (that.options.onZoom) that.options.onZoom.call(that, e);
			return;
		}

		that.pointX = point.pageX;
		that.pointY = point.pageY;

		// Slow down if outside of the boundaries
		if (newX > 0 || newX < that.maxScrollX) {
			newX = that.options.bounce ? that.x + (deltaX / 2) : newX >= 0 || that.maxScrollX >= 0 ? 0 : that.maxScrollX;
		}
		if (newY > that.minScrollY || newY < that.maxScrollY) {
			newY = that.options.bounce ? that.y + (deltaY / 2) : newY >= that.minScrollY || that.maxScrollY >= 0 ? that.minScrollY : that.maxScrollY;
		}

		that.distX += deltaX;
		that.distY += deltaY;
		that.absDistX = m.abs(that.distX);
		that.absDistY = m.abs(that.distY);

		if (that.absDistX < 6 && that.absDistY < 6) {
			return;
		}

		// Lock direction
		if (that.options.lockDirection) {
			if (that.absDistX > that.absDistY + 5) {
				newY = that.y;
				deltaY = 0;
			} else if (that.absDistY > that.absDistX + 5) {
				newX = that.x;
				deltaX = 0;
			}
		}

		that.moved = true;
		that._pos(newX, newY);
		that.dirX = deltaX > 0 ? -1 : deltaX < 0 ? 1 : 0;
		that.dirY = deltaY > 0 ? -1 : deltaY < 0 ? 1 : 0;

		if (timestamp - that.startTime > 300) {
			that.startTime = timestamp;
			that.startX = that.x;
			that.startY = that.y;
		}
		
		if (that.options.onScrollMove) that.options.onScrollMove.call(that, e);
	},
	
	_end: function (e) {
		if (hasTouch && e.touches.length !== 0) return;

		var that = this,
			point = hasTouch ? e.changedTouches[0] : e,
			target, ev,
			momentumX = { dist:0, time:0 },
			momentumY = { dist:0, time:0 },
			duration = (e.timeStamp || Date.now()) - that.startTime,
			newPosX = that.x,
			newPosY = that.y,
			distX, distY,
			newDuration,
			snap,
			scale;

		that._unbind(MOVE_EV, window);
		that._unbind(END_EV, window);
		that._unbind(CANCEL_EV, window);

		if (that.options.onBeforeScrollEnd) that.options.onBeforeScrollEnd.call(that, e);

		if (that.zoomed) {
			scale = that.scale * that.lastScale;
			scale = Math.max(that.options.zoomMin, scale);
			scale = Math.min(that.options.zoomMax, scale);
			that.lastScale = scale / that.scale;
			that.scale = scale;

			that.x = that.originX - that.originX * that.lastScale + that.x;
			that.y = that.originY - that.originY * that.lastScale + that.y;
			
			that.scroller.style[transitionDuration] = '200ms';
			that.scroller.style[transform] = 'translate(' + that.x + 'px,' + that.y + 'px) scale(' + that.scale + ')' + translateZ;
			
			that.zoomed = false;
			that.refresh();

			if (that.options.onZoomEnd) that.options.onZoomEnd.call(that, e);
			return;
		}

		if (!that.moved) {
			if (hasTouch) {
				if (that.doubleTapTimer && that.options.zoom) {
					// Double tapped
					clearTimeout(that.doubleTapTimer);
					that.doubleTapTimer = null;
					if (that.options.onZoomStart) that.options.onZoomStart.call(that, e);
					that.zoom(that.pointX, that.pointY, that.scale == 1 ? that.options.doubleTapZoom : 1);
					if (that.options.onZoomEnd) {
						setTimeout(function() {
							that.options.onZoomEnd.call(that, e);
						}, 200); // 200 is default zoom duration
					}
				} else if (this.options.handleClick) {
					that.doubleTapTimer = setTimeout(function () {
						that.doubleTapTimer = null;

						// Find the last touched element
						target = point.target;
						while (target.nodeType != 1) target = target.parentNode;

						if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA') {
							ev = doc.createEvent('MouseEvents');
							ev.initMouseEvent('click', true, true, e.view, 1,
								point.screenX, point.screenY, point.clientX, point.clientY,
								e.ctrlKey, e.altKey, e.shiftKey, e.metaKey,
								0, null);
							ev._fake = true;
							target.dispatchEvent(ev);
						}
					}, that.options.zoom ? 250 : 0);
				}
			}

			that._resetPos(400);

			if (that.options.onTouchEnd) that.options.onTouchEnd.call(that, e);
			return;
		}

		if (duration < 300 && that.options.momentum) {
			momentumX = newPosX ? that._momentum(newPosX - that.startX, duration, -that.x, that.scrollerW - that.wrapperW + that.x, that.options.bounce ? that.wrapperW : 0) : momentumX;
			momentumY = newPosY ? that._momentum(newPosY - that.startY, duration, -that.y, (that.maxScrollY < 0 ? that.scrollerH - that.wrapperH + that.y - that.minScrollY : 0), that.options.bounce ? that.wrapperH : 0) : momentumY;

			newPosX = that.x + momentumX.dist;
			newPosY = that.y + momentumY.dist;

			if ((that.x > 0 && newPosX > 0) || (that.x < that.maxScrollX && newPosX < that.maxScrollX)) momentumX = { dist:0, time:0 };
			if ((that.y > that.minScrollY && newPosY > that.minScrollY) || (that.y < that.maxScrollY && newPosY < that.maxScrollY)) momentumY = { dist:0, time:0 };
		}

		if (momentumX.dist || momentumY.dist) {
			newDuration = m.max(m.max(momentumX.time, momentumY.time), 10);

			// Do we need to snap?
			if (that.options.snap) {
				distX = newPosX - that.absStartX;
				distY = newPosY - that.absStartY;
				if (m.abs(distX) < that.options.snapThreshold && m.abs(distY) < that.options.snapThreshold) { that.scrollTo(that.absStartX, that.absStartY, 200); }
				else {
					snap = that._snap(newPosX, newPosY);
					newPosX = snap.x;
					newPosY = snap.y;
					newDuration = m.max(snap.time, newDuration);
				}
			}

			that.scrollTo(m.round(newPosX), m.round(newPosY), newDuration);

			if (that.options.onTouchEnd) that.options.onTouchEnd.call(that, e);
			return;
		}

		// Do we need to snap?
		if (that.options.snap) {
			distX = newPosX - that.absStartX;
			distY = newPosY - that.absStartY;
			if (m.abs(distX) < that.options.snapThreshold && m.abs(distY) < that.options.snapThreshold) that.scrollTo(that.absStartX, that.absStartY, 200);
			else {
				snap = that._snap(that.x, that.y);
				if (snap.x != that.x || snap.y != that.y) that.scrollTo(snap.x, snap.y, snap.time);
			}

			if (that.options.onTouchEnd) that.options.onTouchEnd.call(that, e);
			return;
		}

		that._resetPos(200);
		if (that.options.onTouchEnd) that.options.onTouchEnd.call(that, e);
	},
	
	_resetPos: function (time) {
		var that = this,
			resetX = that.x >= 0 ? 0 : that.x < that.maxScrollX ? that.maxScrollX : that.x,
			resetY = that.y >= that.minScrollY || that.maxScrollY > 0 ? that.minScrollY : that.y < that.maxScrollY ? that.maxScrollY : that.y;

		if (resetX == that.x && resetY == that.y) {
			if (that.moved) {
				that.moved = false;
				if (that.options.onScrollEnd) that.options.onScrollEnd.call(that);		// Execute custom code on scroll end
			}

			if (that.hScrollbar && that.options.hideScrollbar) {
				if (vendor == 'webkit') that.hScrollbarWrapper.style[transitionDelay] = '300ms';
				that.hScrollbarWrapper.style.opacity = '0';
			}
			if (that.vScrollbar && that.options.hideScrollbar) {
				if (vendor == 'webkit') that.vScrollbarWrapper.style[transitionDelay] = '300ms';
				that.vScrollbarWrapper.style.opacity = '0';
			}

			return;
		}

		that.scrollTo(resetX, resetY, time || 0);
	},

	_wheel: function (e) {
		var that = this,
			wheelDeltaX, wheelDeltaY,
			deltaX, deltaY,
			deltaScale;

		if ('wheelDeltaX' in e) {
			wheelDeltaX = e.wheelDeltaX / 12;
			wheelDeltaY = e.wheelDeltaY / 12;
		} else if('wheelDelta' in e) {
			wheelDeltaX = wheelDeltaY = e.wheelDelta / 12;
		} else if ('detail' in e) {
			wheelDeltaX = wheelDeltaY = -e.detail * 3;
		} else {
			return;
		}
		
		if (that.options.wheelAction == 'zoom') {
			deltaScale = that.scale * Math.pow(2, 1/3 * (wheelDeltaY ? wheelDeltaY / Math.abs(wheelDeltaY) : 0));
			if (deltaScale < that.options.zoomMin) deltaScale = that.options.zoomMin;
			if (deltaScale > that.options.zoomMax) deltaScale = that.options.zoomMax;
			
			if (deltaScale != that.scale) {
				if (!that.wheelZoomCount && that.options.onZoomStart) that.options.onZoomStart.call(that, e);
				that.wheelZoomCount++;
				
				that.zoom(e.pageX, e.pageY, deltaScale, 400);
				
				setTimeout(function() {
					that.wheelZoomCount--;
					if (!that.wheelZoomCount && that.options.onZoomEnd) that.options.onZoomEnd.call(that, e);
				}, 400);
			}
			
			return;
		}
		
		deltaX = that.x + wheelDeltaX;
		deltaY = that.y + wheelDeltaY;

		if (deltaX > 0) deltaX = 0;
		else if (deltaX < that.maxScrollX) deltaX = that.maxScrollX;

		if (deltaY > that.minScrollY) deltaY = that.minScrollY;
		else if (deltaY < that.maxScrollY) deltaY = that.maxScrollY;
    
		if (that.maxScrollY < 0) {
			that.scrollTo(deltaX, deltaY, 0);
		}
	},
	
	_transitionEnd: function (e) {
		var that = this;

		if (e.target != that.scroller) return;

		that._unbind(TRNEND_EV);
		
		that._startAni();
	},


	/**
	*
	* Utilities
	*
	*/
	_startAni: function () {
		var that = this,
			startX = that.x, startY = that.y,
			startTime = Date.now(),
			step, easeOut,
			animate;

		if (that.animating) return;
		
		if (!that.steps.length) {
			that._resetPos(400);
			return;
		}
		
		step = that.steps.shift();
		
		if (step.x == startX && step.y == startY) step.time = 0;

		that.animating = true;
		that.moved = true;
		
		if (that.options.useTransition) {
			that._transitionTime(step.time);
			that._pos(step.x, step.y);
			that.animating = false;
			if (step.time) that._bind(TRNEND_EV);
			else that._resetPos(0);
			return;
		}

		animate = function () {
			var now = Date.now(),
				newX, newY;

			if (now >= startTime + step.time) {
				that._pos(step.x, step.y);
				that.animating = false;
				if (that.options.onAnimationEnd) that.options.onAnimationEnd.call(that);			// Execute custom code on animation end
				that._startAni();
				return;
			}

			now = (now - startTime) / step.time - 1;
			easeOut = m.sqrt(1 - now * now);
			newX = (step.x - startX) * easeOut + startX;
			newY = (step.y - startY) * easeOut + startY;
			that._pos(newX, newY);
			if (that.animating) that.aniTime = nextFrame(animate);
		};

		animate();
	},

	_transitionTime: function (time) {
		time += 'ms';
		this.scroller.style[transitionDuration] = time;
		if (this.hScrollbar) this.hScrollbarIndicator.style[transitionDuration] = time;
		if (this.vScrollbar) this.vScrollbarIndicator.style[transitionDuration] = time;
	},

	_momentum: function (dist, time, maxDistUpper, maxDistLower, size) {
		var deceleration = 0.0006,
			speed = m.abs(dist) / time,
			newDist = (speed * speed) / (2 * deceleration),
			newTime = 0, outsideDist = 0;

		// Proportinally reduce speed if we are outside of the boundaries
		if (dist > 0 && newDist > maxDistUpper) {
			outsideDist = size / (6 / (newDist / speed * deceleration));
			maxDistUpper = maxDistUpper + outsideDist;
			speed = speed * maxDistUpper / newDist;
			newDist = maxDistUpper;
		} else if (dist < 0 && newDist > maxDistLower) {
			outsideDist = size / (6 / (newDist / speed * deceleration));
			maxDistLower = maxDistLower + outsideDist;
			speed = speed * maxDistLower / newDist;
			newDist = maxDistLower;
		}

		newDist = newDist * (dist < 0 ? -1 : 1);
		newTime = speed / deceleration;

		return { dist: newDist, time: m.round(newTime) };
	},

	_offset: function (el) {
		var left = -el.offsetLeft,
			top = -el.offsetTop;
			
		while (el = el.offsetParent) {
			left -= el.offsetLeft;
			top -= el.offsetTop;
		}
		
		if (el != this.wrapper) {
			left *= this.scale;
			top *= this.scale;
		}

		return { left: left, top: top };
	},

	_snap: function (x, y) {
		var that = this,
			i, l,
			page, time,
			sizeX, sizeY;

		// Check page X
		page = that.pagesX.length - 1;
		for (i=0, l=that.pagesX.length; i<l; i++) {
			if (x >= that.pagesX[i]) {
				page = i;
				break;
			}
		}
		if (page == that.currPageX && page > 0 && that.dirX < 0) page--;
		x = that.pagesX[page];
		sizeX = m.abs(x - that.pagesX[that.currPageX]);
		sizeX = sizeX ? m.abs(that.x - x) / sizeX * 500 : 0;
		that.currPageX = page;

		// Check page Y
		page = that.pagesY.length-1;
		for (i=0; i<page; i++) {
			if (y >= that.pagesY[i]) {
				page = i;
				break;
			}
		}
		if (page == that.currPageY && page > 0 && that.dirY < 0) page--;
		y = that.pagesY[page];
		sizeY = m.abs(y - that.pagesY[that.currPageY]);
		sizeY = sizeY ? m.abs(that.y - y) / sizeY * 500 : 0;
		that.currPageY = page;

		// Snap with constant speed (proportional duration)
		time = m.round(m.max(sizeX, sizeY)) || 200;

		return { x: x, y: y, time: time };
	},

	_bind: function (type, el, bubble) {
		(el || this.scroller).addEventListener(type, this, !!bubble);
	},

	_unbind: function (type, el, bubble) {
		(el || this.scroller).removeEventListener(type, this, !!bubble);
	},


	/**
	*
	* Public methods
	*
	*/
	destroy: function () {
		var that = this;

		that.scroller.style[transform] = '';

		// Remove the scrollbars
		that.hScrollbar = false;
		that.vScrollbar = false;
		that._scrollbar('h');
		that._scrollbar('v');

		// Remove the event listeners
		that._unbind(RESIZE_EV, window);
		that._unbind(START_EV);
		that._unbind(MOVE_EV, window);
		that._unbind(END_EV, window);
		that._unbind(CANCEL_EV, window);
		
		if (!that.options.hasTouch) {
			that._unbind('DOMMouseScroll');
			that._unbind('mousewheel');
		}
		
		if (that.options.useTransition) that._unbind(TRNEND_EV);
		
		if (that.options.checkDOMChanges) clearInterval(that.checkDOMTime);
		
		if (that.options.onDestroy) that.options.onDestroy.call(that);
	},

	refresh: function () {
		var that = this,
			offset,
			i, l,
			els,
			pos = 0,
			page = 0;

		if (that.scale < that.options.zoomMin) that.scale = that.options.zoomMin;
		that.wrapperW = that.wrapper.clientWidth || 1;
		that.wrapperH = that.wrapper.clientHeight || 1;

		that.minScrollY = -that.options.topOffset || 0;
		that.scrollerW = m.round(that.scroller.offsetWidth * that.scale);
		that.scrollerH = m.round((that.scroller.offsetHeight + that.minScrollY) * that.scale);
		that.maxScrollX = that.wrapperW - that.scrollerW;
		that.maxScrollY = that.wrapperH - that.scrollerH + that.minScrollY;
		that.dirX = 0;
		that.dirY = 0;

		if (that.options.onRefresh) that.options.onRefresh.call(that);

		that.hScroll = that.options.hScroll && that.maxScrollX < 0;
		that.vScroll = that.options.vScroll && (!that.options.bounceLock && !that.hScroll || that.scrollerH > that.wrapperH);

		that.hScrollbar = that.hScroll && that.options.hScrollbar;
		that.vScrollbar = that.vScroll && that.options.vScrollbar && that.scrollerH > that.wrapperH;

		offset = that._offset(that.wrapper);
		that.wrapperOffsetLeft = -offset.left;
		that.wrapperOffsetTop = -offset.top;

		// Prepare snap
		if (typeof that.options.snap == 'string') {
			that.pagesX = [];
			that.pagesY = [];
			els = that.scroller.querySelectorAll(that.options.snap);
			for (i=0, l=els.length; i<l; i++) {
				pos = that._offset(els[i]);
				pos.left += that.wrapperOffsetLeft;
				pos.top += that.wrapperOffsetTop;
				that.pagesX[i] = pos.left < that.maxScrollX ? that.maxScrollX : pos.left * that.scale;
				that.pagesY[i] = pos.top < that.maxScrollY ? that.maxScrollY : pos.top * that.scale;
			}
		} else if (that.options.snap) {
			that.pagesX = [];
			while (pos >= that.maxScrollX) {
				that.pagesX[page] = pos;
				pos = pos - that.wrapperW;
				page++;
			}
			if (that.maxScrollX%that.wrapperW) that.pagesX[that.pagesX.length] = that.maxScrollX - that.pagesX[that.pagesX.length-1] + that.pagesX[that.pagesX.length-1];

			pos = 0;
			page = 0;
			that.pagesY = [];
			while (pos >= that.maxScrollY) {
				that.pagesY[page] = pos;
				pos = pos - that.wrapperH;
				page++;
			}
			if (that.maxScrollY%that.wrapperH) that.pagesY[that.pagesY.length] = that.maxScrollY - that.pagesY[that.pagesY.length-1] + that.pagesY[that.pagesY.length-1];
		}

		// Prepare the scrollbars
		that._scrollbar('h');
		that._scrollbar('v');

		if (!that.zoomed) {
			that.scroller.style[transitionDuration] = '0';
			that._resetPos(400);
		}
	},

	scrollTo: function (x, y, time, relative) {
		var that = this,
			step = x,
			i, l;

		that.stop();

		if (!step.length) step = [{ x: x, y: y, time: time, relative: relative }];
		
		for (i=0, l=step.length; i<l; i++) {
			if (step[i].relative) { step[i].x = that.x - step[i].x; step[i].y = that.y - step[i].y; }
			that.steps.push({ x: step[i].x, y: step[i].y, time: step[i].time || 0 });
		}

		that._startAni();
	},

	scrollToElement: function (el, time) {
		var that = this, pos;
		el = el.nodeType ? el : that.scroller.querySelector(el);
		if (!el) return;

		pos = that._offset(el);
		pos.left += that.wrapperOffsetLeft;
		pos.top += that.wrapperOffsetTop;

		pos.left = pos.left > 0 ? 0 : pos.left < that.maxScrollX ? that.maxScrollX : pos.left;
		pos.top = pos.top > that.minScrollY ? that.minScrollY : pos.top < that.maxScrollY ? that.maxScrollY : pos.top;
		time = time === undefined ? m.max(m.abs(pos.left)*2, m.abs(pos.top)*2) : time;

		that.scrollTo(pos.left, pos.top, time);
	},

	scrollToPage: function (pageX, pageY, time) {
		var that = this, x, y;
		
		time = time === undefined ? 400 : time;

		if (that.options.onScrollStart) that.options.onScrollStart.call(that);

		if (that.options.snap) {
			pageX = pageX == 'next' ? that.currPageX+1 : pageX == 'prev' ? that.currPageX-1 : pageX;
			pageY = pageY == 'next' ? that.currPageY+1 : pageY == 'prev' ? that.currPageY-1 : pageY;

			pageX = pageX < 0 ? 0 : pageX > that.pagesX.length-1 ? that.pagesX.length-1 : pageX;
			pageY = pageY < 0 ? 0 : pageY > that.pagesY.length-1 ? that.pagesY.length-1 : pageY;

			that.currPageX = pageX;
			that.currPageY = pageY;
			x = that.pagesX[pageX];
			y = that.pagesY[pageY];
		} else {
			x = -that.wrapperW * pageX;
			y = -that.wrapperH * pageY;
			if (x < that.maxScrollX) x = that.maxScrollX;
			if (y < that.maxScrollY) y = that.maxScrollY;
		}

		that.scrollTo(x, y, time);
	},

	disable: function () {
		this.stop();
		this._resetPos(0);
		this.enabled = false;

		// If disabled after touchstart we make sure that there are no left over events
		this._unbind(MOVE_EV, window);
		this._unbind(END_EV, window);
		this._unbind(CANCEL_EV, window);
	},
	
	enable: function () {
		this.enabled = true;
	},
	
	stop: function () {
		if (this.options.useTransition) this._unbind(TRNEND_EV);
		else cancelFrame(this.aniTime);
		this.steps = [];
		this.moved = false;
		this.animating = false;
	},
	
	zoom: function (x, y, scale, time) {
		var that = this,
			relScale = scale / that.scale;

		if (!that.options.useTransform) return;

		that.zoomed = true;
		time = time === undefined ? 200 : time;
		x = x - that.wrapperOffsetLeft - that.x;
		y = y - that.wrapperOffsetTop - that.y;
		that.x = x - x * relScale + that.x;
		that.y = y - y * relScale + that.y;

		that.scale = scale;
		that.refresh();

		that.x = that.x > 0 ? 0 : that.x < that.maxScrollX ? that.maxScrollX : that.x;
		that.y = that.y > that.minScrollY ? that.minScrollY : that.y < that.maxScrollY ? that.maxScrollY : that.y;

		that.scroller.style[transitionDuration] = time + 'ms';
		that.scroller.style[transform] = 'translate(' + that.x + 'px,' + that.y + 'px) scale(' + scale + ')' + translateZ;
		that.zoomed = false;
	},
	
	isReady: function () {
		return !this.moved && !this.zoomed && !this.animating;
	}
};

function prefixStyle (style) {
	if ( vendor === '' ) return style;

	style = style.charAt(0).toUpperCase() + style.substr(1);
	return vendor + style;
}

dummyStyle = null;	// for the sake of it

if (typeof exports !== 'undefined') exports.iScroll = iScroll;
else window.iScroll = iScroll;

})(window, document);

define("iScroll", function(){});

(function(){

var MRoute = {};
MRoute.Conf = {
	"version":"3.1-beta-0229",
	server : "Server/route.php"
};

var Class = function() {
	//创建一个新类
    var cls = function() {
        if (arguments && arguments[0] != Class.isPrototype) {//第一个参数不为空函数时
            this["initialize"].apply(this, arguments);//构造函数
        }
    };
    var extended = {};
    var parent, initialize;
    for(var i=0, len=arguments.length; i<len; ++i) {
        if(typeof arguments[i] == "function") {
            //使第一个参数成为超类的基类
            if(i == 0 && len > 1) {
                initialize = arguments[i].prototype["initialize"];
                // 用户一个空函数替换initialize方法，因为我们不需要在此实例化。
                arguments[i].prototype["initialize"] = function() {};
                //确保新类有一个超类
                extended = new arguments[i];
                //还原原始的initialize方法
                if(initialize === undefined){
                    delete arguments[i].prototype["initialize"];
                }else{
                    arguments[i].prototype["initialize"] = initialize;
                }
            }
            //获得一个超类的原型
            parent = arguments[i].prototype;
        } else {
            //扩展原型
            parent = arguments[i];
        }
        extend(extended, parent);
    }
    cls.prototype = extended;
    return cls;
};

Class.isPrototype = function () {};
/**
 +------------------------------------------------------------------------------
 * 函数: extend
 * 复制源对象中所有所有属性到目标对象，以达到类继承的目的
 +------------------------------------------------------------------------------
 * 
 * > extend(destination, source);
 +------------------------------------------------------------------------------
 */
var extend = function(destination, source) {
    destination = destination || {};
    if(source) {
        for(var property in source) {
            var value = source[property];
            if(value !== undefined) {
                destination[property] = value;
            }
        }
        var sourceIsEvt = typeof window.Event == "function" && source instanceof window.Event;
        if(!sourceIsEvt && source.hasOwnProperty && source.hasOwnProperty('toString')) {
            destination.toString = source.toString;
        }
    }
    return destination;
};

/**
 +----------------------------------------------------------
 * 请求发送类
 +----------------------------------------------------------
 * @return Number
 +----------------------------------------------------------
 */
MRoute.MyResult = {};//请求结果缓存对象
MRoute["_xdc_"]  = function(rid,data){
	MRoute.MyResult[rid] = data;
};//查询结果缓存对象

MRoute["Request"] = function(url,func){
	var rid = Math.round(Math.random()*100000);
	var __script = document.getElementById(rid);
	if(__script){document.getElementsByTagName("head")[0].removeChild(__script);}
	__script = document.createElement("script");
	__script.id = rid;
	__script.type = "text/javascript";
	__script.src = url + "&cbk=MRoute._xdc_&rid="+rid;
	document.getElementsByTagName("head")[0].appendChild(__script);
	var __self = this;
	if (/msie/i.test(navigator.userAgent) && !/msie 9.0/i.test(navigator.userAgent)) {//IE
		__script.onreadystatechange = function (){
			if(this.readyState=="loaded" || this.readyState=="complete"){
				__self.ajaxResult();
			}
		}
	}else{//firefox,chrom etc.
		__script.onload = function (){
			__self.ajaxResult();
		};
		__script.onerror = function(){
            if(func){
                func(null);
            }
			//alert("搜索服务出现异常,请联系MapABC,感谢!\n\r"+url);
		};
	}
	
	this.ajaxResult = function(){
		if(MRoute.MyResult[rid]){//加载服务数据
			if(func){
				func(MRoute.MyResult[rid]);
			}
			document.getElementsByTagName("head")[0].removeChild(document.getElementById(rid));//删除JS文件
			MRoute.MyResult[rid] = null;
			delete MRoute.MyResult[rid];
		}else{
			//alert("搜索服务出现异常,请联系MapABC,感谢!\n\r"+url);
            if(func){
                func(MRoute.MyResult[rid]);
            }
		}
	}
};


var ONERADIAN = 57.29578;				          //一弧度对应的角度值
var LONG_DISTANCE = 39940.67;			          // 地球子午线长，单位：km
var LATI_DISTANCE = 40075.36;			          // 赤道长，单位：km
var LONG_DISTANCE_PER_DEGREE = LONG_DISTANCE / 360; // 纬度改变一度，对应经线的距离，单位：km
var LATI_DISTANCE_PER_DEGREE = LATI_DISTANCE / 360; //经度改变一度，对应纬线的距离，单位：km
var CoordFactor = 3600 * 64;

// 根据两点的经纬度坐标（单位为度），估算其距离（单位：km）
function GetMapDistance(sx, sy, ex, ey) {
    var meanlati = (sy + ey) / 2.0;
    var tmpdist = LATI_DISTANCE_PER_DEGREE * Math.sin((90.0 - meanlati) * Math.PI / 180.0);

    var longDist = (sx - ex) * tmpdist;
    var latiDist = (ey - sy) * LONG_DISTANCE_PER_DEGREE;

    return Math.sqrt(longDist * longDist + latiDist * latiDist);
}

function GetMapDistInMeter(sx, sy, ex, ey) {
    return Math.round(0.5 + 1000 * GetMapDistance(sx, sy, ex, ey));
}

// 计算两点构成的方向角，单位：弧度 0 -2*PI
function CalcMathAngle(fStartLon, fStartLat, fEndLon, fEndLat) {
    var fAngle = 0.0;
    if (fEndLon != fStartLon) {
        var ftmp = Math.cos((fEndLat + fStartLat) / (2 * ONERADIAN));
        var fAtan = (fEndLat - fStartLat) / (fEndLon - fStartLon) / ftmp;
        fAngle = Math.atan(fAtan);
        if (fEndLon - fStartLon < 0)
            fAngle += Math.PI;
        else if (fAngle < 0)
            fAngle += 2 * Math.PI;
    }
    else {
        if (fEndLat > fStartLat) {
            fAngle = Math.PI / 2;
        }
        else if (fEndLat < fStartLat) {
            fAngle = Math.PI / 2 * 3;
        }
        else if (fEndLat == fStartLat) {
            fAngle = 0;
        }
    }
    return fAngle;
}

function TestInfoLog(str){
    if(parent!= null && parent["logtest"]){
        parent["logtest"]["writeFile"](str);
    }
//    else{
//        console.log(str);
//    }
}

// 以正北为0度，角度按顺时针方向增长， 范围0-2*PI
function CalcGeoAngle(fStartLon, fStartLat, fEndLon, fEndLat)
{
    var fAngle = CalcMathAngle(fStartLon, fStartLat, fEndLon, fEndLat);

    fAngle = Math.PI * 5 / 2 - fAngle;
    if (fAngle > Math.PI * 2) {
        fAngle = fAngle - Math.PI * 2;
    }

    return fAngle;
}

// 计算两点构成的方向角，单位：角度 0 - 360
function CalcGeoAngleInDegree(fStartLon, fStartLat, fEndLon, fEndLat) {

    var fAngle = CalcGeoAngle(fStartLon, fStartLat, fEndLon, fEndLat);
    return Math.round(fAngle * 180 / Math.PI);
}



/*
 * 求一个点到一条线的距离，
 *@return 最小距离，及线上最近点坐标，以度为单位的浮点经纬度坐标
 */
function FindNearPt(startX, startY, endX, endY, PtAx, PtAy) {
    var fPtB0 = 0.0,
        fPtB1 = 0.0,
        dX = endX - startX,
        dY = endY - startY,
        dR = -(startY - PtAy) * dY - (startX - PtAx) * dX,
        dL = dX * dX + dY * dY,
        dPercent = 0;

    if (dR <= 0) {
        dPercent = 0;
        fPtB0 = startX;
        fPtB1 = startY;
    }
    else if (dR >= dL) {
        dPercent = 1;
        fPtB0 = endX;
        fPtB1 = endY;
    }
    else {
        dPercent = dR / dL;
        fPtB0 = startX + dPercent * dX;
        fPtB1 = startY + dPercent * dY;
    }

    return [fPtB0, fPtB1, dPercent];
}

MRoute.GeoUtils = {

    /// 计算2点间距离 单位米
    CalculateDistance:function (x1, y1, x2, y2) {
        var earthRadiu = 6378137.0;
        earthRadiu = earthRadiu / 1000;
        var lon1 = this.Deg2Rad(x1),
            lat1 = this.Deg2Rad(y1),
            lon2 = this.Deg2Rad(x2),
            lat2 = this.Deg2Rad(y2),
            deltaLat = lat1 - lat2,
            deltaLon = lon1 - lon2,
            step1 = Math.pow(Math.sin(deltaLat / 2), 2) + Math.cos(lat2) * Math.cos(lat1) * Math.pow(Math.sin(deltaLon / 2), 2),
            step2 = 2 * Math.atan2(Math.sqrt(step1), Math.sqrt(1 - step1));
        return Math.round(step2 * earthRadiu * 1000);
    },

    Deg2Rad:function (deg) {
        return deg * Math.PI / 180;
    },

    Rad2Deg:function (rad) {
        return rad * 180 / Math.PI;
    }
};

/// 道路状态
MRoute.RouteStatus = {
    Status_Unknown:0, // 道路状态未知。
    Status_Expedite:1, // 道路通畅。
    Status_Congested:2, // 道路缓行。
    Status_Blocked:3, // 道路阻塞严重。
    Status_EndStatus:4    // 结尾状态，不应该使用。
};


/// 导航状态

MRoute.NaviState = {
    NaviState_NULL:0,
    NaviState_Common:1,
    NaviState_Routing:2,
    NaviState_StartNavi:3
};

MRoute.CalcRouteType =
{
    CalcRouteType_NULL:0,       // 无定义
    CalcRouteType_Reroute:1,    // Reroute类型
    CalcRouteType_Command:2     // 正常算路类型
};

// 路径策略
MRoute.PathStrategy =
{
    Strategy_SPEED:0, // 速度优先
    Strategy_FEE:1, // 费用优先(不走收费路段最快道路)
    Strategy_DISTANCE:2, // 距离优先
    Strategy_TMC_FUEL_LEAST:3, // TMC省油
    Strategy_TMC_FAST:4, // TMC最快
    Strategy_NORMAL_ROAD:5, // 不走快速路(不包含高速路)
    Strategy_NATIONAL:6, // 国道优先
    Strategy_PROVINCIAL:7, // 省道优先
    Strategy_MULTI_NORM:9, // 多策略1 ：速度优先+费用优先+距离优先
    Strategy_MULTI_AUDI:10, // 多策略2（针对audi）：TMC最快 +TMC省油+速度优先+费用优先
    Strategy_MULTI_TB:11    // 多策略3： TMC最快 +速度优先
};

// 算路附加标记
MRoute.CalcFlag = {
    Flag_INVALID:0, // 初始化的无效数据
    Flag_STREET_NAME:0X00000001, // 道路名称?omit
    Flag_COORD_POS:0X00000002, // 坐标数据?omit
    Flag_DIST_LIMIT:0X00000004, // new 起点找路是否有距离的限制(超过50m则不进行算路)
    Flag_TMC:0X00000008, // 是否包含动态交通信息

    Flag_TIME_TMC:0X00000010, // new 旅行时间表示实际的旅行时间还是参考旅行时间(有tmc时有效)
    Flag_LOC_CODE:0X00000020, // 是否包含导航段的Lcode信息
    Flag_CROSSING:0X00000080, // 路口数据(保留)

    Flag_TARGET_INFO:0X00000100, // 目标信息
    Flag_FROM_CS:0X00000200, // 从Callcenter获取信息标示
    Flag_UTURN:0X00000400, // 是否允许调头
    Flag_PREVIEW:0X00000800, // 是否允许预览抽稀
    Flag_PROMPT_EFF:0X00001000, // new 是否提及提升效率

    Flag_STRAIGHT_GUIDE:0X00010000, // 距离大于2000m中间添加直行点
    Flag_INGNORE_LIGHT:0X00020000, // 忽略红绿灯(保留)?conflict
    Flag_DETAIL_ROAD_ATTR:0X00040000, // 详细道路属性?omit

    Flag_TRAFFIC_SAFETY:0X00100000, // 交通安全信息
    Flag_DYNAMIC_TRAFFIC:0X00200000, // 动态交通信息?omit
    Flag_COMPRESS_DATA:0X00400000, // 是否压缩数据
    Flag_USE_ALTERNATE:0X00800000, // 是否启用多条备选路径计算

    Flag_FRAG_DOWNLOAD:0X01000000, // new 是否启用分段下载
    Flag_MAIN_ASSIST:0X02000000, // new 是否启用主辅路双路径模式（此模式下其它多路径选项无效）
    Flag_NON_GUIDE_ROAD:0X10000000, // 是否启用非导航道路
    Flag_TRAFFIC_CALC:0X20000000, // 是否启用动态交通信息参与路径计算

    Flag_MULTI_ROUTE_CALC:0X40000000             // 是否启用多路经计算?omit
};

// 计算路径类型
MRoute.CalcType = {
    CalcType_NULL : -1,				// 无定义
    CalcType_Best : 0,				// 最优路径
    CalcType_High : 1,				// 快速路优先
    CalcType_Dist : 2,				// 距离优先
    CalcType_Norm : 3,				// 普通路优先
    CalcType_TMC : 4,				// 考虑实时路况的路线
    CalcType_Multi : 5				// 多路径
};

MRoute.Direction = {
    RouteDire_NULL:0, // 无效道路方向
    RouteDire_North:1, // 北向道路方向
    RouteDire_North_East:2, // 东北道路方向
    RouteDire_East:3, // 东向道路方向
    RouteDire_East_South:4, // 东南道路方向
    RouteDire_South:5, // 南方道路方向
    RouteDire_West_South:6, // 西南道路方向
    RouteDire_West:7, // 西方道路方向
    RouteDire_West_North:8    // 西北道路方向
};
// 请求路径状态
MRoute.RouteRequestState = {
    RouteRequestState_NULL : 0,				// 无定义
    RouteRequestState_Success : 1,			// 路径计算成功
    RouteRequestState_TimeOut : 2,			// 网络超时
    RouteRequestState_NetERROR : 3,			// 网络失败
    RouteRequestState_RequestParError : 4,	// 请求参数错误
    RouteRequestState_DataFormatError : 5,	// 返回数据格式错误
    RouteRequestState_StartNoRoad : 6,		// 起点周围没有道路
    RouteRequestState_StartOnWalkRoad : 7,	// 起点在步行街
    RouteRequestState_EndNoRoad : 8,		// 终点周围没有道路
    RouteRequestState_EndOnWalkRoad : 9,	// 终点在步行街
    RouteRequestState_ViaNoRoad : 10,		// 途经点周围没有道路
    RouteRequestState_ViaOnWalkRoad : 11	// 途经点在步行街
};

MRoute.PlayMode ={
    PlayMode_NULL:0,    //无效模式
    PlayMode_Common:1,  //正常模式
    PlayMode_Count:2    //数路口模式
};

MRoute.ProbeResult = {
    ProbeResult_NoGPS:0,  // can not sample GPS
    ProbeResult_Normal:1, // trigger with freqency condition, send to Server
    ProbeResult_Turning:2 // trigger with car is tuning, send to Server
};
MRoute.PicState = {
    Traffic_Pic_NULL:0,
    Traffic_Pic_Show:1,
    Traffic_Pic_Hide:2,
    Traffic_Pic_Change:3
};

MRoute.ConnectId = {
    CONNECTID_LOGON:0x1,
    CONNECTID_LOGOFF:0x2,
    CONNECTID_TRAFFIC:0x3,
    CONNECTID_PIC:0x4,
    CONNECTID_ROUTE:0x5
};


MRoute.RadioFlag = {
    FLAG_FORCE_UPLOAD:0x1,
    FLAG_REGION_BOARD:0x2,
    FLAG_NO_FILTER:0x4,
    FLAG_DESCRIPTION:0x8,
    FLAG_INCIDENT:0x10,
    FLAG_ASSIST_ROAD:0x20
};

/// 光柱方向
MRoute.ColorBarDirection = {
    ColorBarDirection_NULL:0,   /// 无定义
    ColorBarDirection_Vertical:1,   /// 垂直方向
    ColorBarDirection_Horizontal:2  /// 水平方向
};

MRoute.CameraType = {
    CameraType_Speed:0,     /// 测速
    CameraType_Monitor:1    /// 监控摄像
};

MRoute.PlayGrade = {
    PlayGrade_NULL:0,   /// 无效播报
    PlayGrade_Start:1,  /// 开始概要播报
    PlayGrade_After:2,  /// 过后音
    PlayGrade_Far:3,     /// 远距离提示
    PlayGrade_Mid:4,    /// 中距离提示
    PlayGrade_MMid:5,	// 最短预报
    PlayGrade_Near:6,    /// 近距离提示
    PlayGrade_Real_Time:7,  /// 实时播报
    PlayGrade_Arrive:8 /// 到达提示
};

///  网络请求状态
MRoute.NetRequestState = {
    NetRequestState_NULL:0,     /// 无定义
    NetRequestState_OK:1,   ///  请求成功
    NetRequestState_TimeOut:2,  /// 请求超时
    NetRequestState_Error:3     /// 错误
};

/// 网络请求类型
MRoute.NetType = {
    NetType_UDP_IP:1,   /// IP方式UDP
    NetType_TCP_IP:2,   /// IP方式TCP
    NetType_UDP_DN:3,   /// 域名方式UDP
    NetType_TCP_DN:4    /// 域名方式TCP
};

/// 位置匹配状态
MRoute.VPStatus = {
    VPStatus_OnRoute:0,     /// 在路径上
    VPStatus_OnLink:1,      /// 没有在路径上但在道路上
    VPStatus_Unreliable:2   /// 没有在道路上
};

// FormWay对应常量列表
MRoute.Formway = {
    Formway_Divised_Link : 1,			// 1 主路
    Formway_Cross_Link : 2,				// 2 复杂节点内部道路
    Formway_JCT : 3,					// 3 高架
    Formway_Round_Circle : 4,			//  4 环岛
    Formway_Service_Road : 5,			// 5 辅助道路
    Formway_Slip_Road : 6,				// 6 匝道
    Formway_Side_Road : 7,				// 7 辅路
    Formway_Slip_JCT : 8,				// 8 匝道
    Formway_Exit_Link : 9,				// 9 出口
    Formway_Entrance_Link : 10,			// 10 入口
    Formway_Turn_Right_LineA : 11,		// 11 右转专用道
    Formway_Turn_Right_LineB : 12,		// 12 右转专用道
    Formway_Turn_Left_LineA : 13,		// 13 左转专用道
    Formway_Turn_Left_LineB : 14,		//  14 左转专用道
    Formway_Common_Link : 15,			//  15 普通道路
    Formway_Turn_LeftRight_Line : 16,	// 16 左右转专用道
    Formay_Count : 17,
    Formway_ServiceJCT_Road : 53,		// 53 高架(?与3区别)
    Formway_ServiceSlip_Road : 56,		// 56 匝道(?与58区别)
    Formway_ServiceSlipJCT_Road : 58	// 58 匝道(?与56区别)
};

// RoadClass对应常量列表
MRoute.RoadClass = {
    RoadClass_Freeway : 0,			// 0 高速公路
    RoadClass_National_Road : 1,	// 1 国道
    RoadClass_Province_Road : 2,	// 2 省道
    RoadClass_County_Road : 3,		//  3 县道
    RoadClass_Rural_Road : 4,		// 4 乡公路
    RoadClass_In_County_Road : 5,	// 5 县乡村内部道路
    RoadClass_City_Speed_way : 6,	// 6 主要大街、城市快速道
    RoadClass_Main_Road : 7,		// 7 主要道路
    RoadClass_Secondary_Road : 8,	// 8 次要道路
    RoadClass_Common_Road : 9,		//  9 普通道路
    RoadClass_Non_Navi_Road : 10,	// 10 非导航道路
    RoadClass_Count : 11			// RoadClass的个数
};

// LinkType对应常量列表
MRoute.LinkType = {
    LinkType_Common : 0,	//  0 普通道路
    LinkType_Ferry : 1,		//  1 航道
    LinkType_Tunnel : 2,	//  2 隧道
    LinkType_Bridge : 3,	// 3 桥梁
    LinkType_Count : 4		// LinkType的个数
};




/// 转向图标宏定义

MRoute.DirIcon = {
    
    /// 无定义
    
    DirIcon_NULL:0,
    
    /// 自车图标
    
    DirIcon_Car:1,
    
    /// 左转图标
    
    DirIcon_Turn_Left:2,
    
    /// 右转图标
    
    DirIcon_Turn_Right:3,
    
    /// 左前方图标
    
    DirIcon_Slight_Left:4,
    
    /// 右前方图标
    
    DirIcon_Slight_Right:5,
    
    /// 左后方图标
    
    DirIcon_Turn_Hard_Left:6,
    
    /// 右后方图标
    
    DirIcon_Turn_Hard_Right:7,
    
    /// 左转掉头图标
    
    DirIcon_UTurn:8,
    
    /// 直行图标
    
    DirIcon_Continue:9,
    
    /// 到达途经点图标
    
    DirIcon_Way:10,
    
    /// 进入环岛图标
    
    DirIcon_Entry_Ring:11,
    
    /// 驶出环岛图标
    
    DirIcon_Leave_Ring:12,
    
    /// 到达服务区图标
    
    DirIcon_SAPA:13,
    
    /// 到达收费站图标
    
    DirIcon_TollGate:14,
    
    /// 到达目的地图标
    
    DirIcon_Destination:15,
    
    /// 进入隧道图标
    
    DirIcon_Tunnel:16
};


/// 导航类型

MRoute.NaviType = {
    
    /// 无效状态
    
    NaviType_NULL:0,
    
    /// GPS导航
    
    NaviType_GPS:1,
    
    /// 模拟导航
    
    NaviType_Emul:2
};


/// 播报等级

MRoute.PlayVoiceLeve = {
    
    /// 无效级别
    
    PlayVoiceLeve_NULL:0,
    
    /// 最高级别，用于播报必须马上播报的声音使用
    
    PlayVoiceLeve_RealTime:1,
    
    /// 紧急级别，一般用与导航指引播报
    
    PlayVoiceLeve_DGNavi:2,
    
    /// 一般级别，一般用与电子眼播报
    
    PlayVoiceLeve_DGCamere:3,
    
    /// 较低级别，一般用于路况播报
    
    PlayVoiceLeve_Radio:4
};


MRoute.AssistantAction = {
    
    /// 无辅助导航动作
    
    AssiAction_NULL:0x00,
    
    /// 进入主路
    
    AssiAction_Entry_Main:0x01,
    
    /// 进入辅路
    
    AssiAction_Entry_Side_Road:0x02,
    
    /// 进入高速
    
    AssiAction_Entry_Freeway:0x03,
    
    /// 进入匝道
    
    AssiAction_Entry_Slip:0x04,
    
    /// 进入隧道
    
    AssiAction_Entry_Tunnel:0x05,
    
    /// 进入中间岔道
    
    AssiAction_Entry_Center_Branch:0x06,
    
    /// 进入右岔路
    
    AssiAction_Entry_Right_Branch:0x07,
    
    /// 进入右岔路
    
    AssiAction_Entry_Left_Branch:0x08,
    
    /// 进入右转专用道
    
    AssiAction_Entry_Right_Road:0x09,
    
    /// 进入左转专用道
    
    AssiAction_Entry_Left_Road:0x0A,
    
    /// 进入中间道路
    
    AssiAction_Entry_Merge_Center:0x0B,
    
    /// 进入右侧道路
    
    AssiAction_Entry_Merge_Right:0x0C,
    
    /// 进入左侧道路
    
    AssiAction_Entry_Merge_Left:0x0D,
    
    /// 靠右行驶进入辅路
    
    AssiAction_Entry_Merge_Right_Sild:0x0E,
    
    /// 靠左行驶进入辅路
    
    AssiAction_Entry_Merge_Left_Sild:0x0F,
    
    /// 靠右行驶进入主路
    
    AssiAction_Entry_Merge_Right_MAIN:0x10,
    
    /// 靠左行驶进入主路
    
    AssiAction_Entry_Merge_Left_MAIN:0x11,
    
    /// 靠右行驶进入右转专用道
    
    AssiAction_Entry_Merge_Right_Right:0x12,
    
    ///
    
    AssiAction_Entry_Ferry:0x13,
    
    /// 沿当前道路行驶
    
    AssiAction_Along_Road:0x17,
    
    /// 沿辅路行驶
    
    AssiAction_Along_Sild:0x18,
    
    /// 沿主路行驶
    
    AssiAction_Along_Main:0x19,
    
    /// 到达出口
    
    AssiAction_Arrive_Exit:0x20,
    
    /// 到达服务区
    
    AssiAction_Arrive_Service_Area:0x21,
    
    /// 到达收费站
    
    AssiAction_Arrive_TollGate:0x22,
    
    /// 到达途经地
    
    AssiAction_Arrive_Way:35,
    
    /// 到达目的地的
    
    AssiAction_Arrive_Destination:0x24,
    
    /// 绕环岛左转
    
    AssiAction_Entry_Ring_Left:0x30,
    
    /// 绕环岛右转
    
    AssiAction_Entry_Ring_Right:0x31,
    
    /// 绕环岛直行
    
    AssiAction_Entry_Ring_Continue:0x32,
    
    /// 绕环岛右转
    
    AssiAction_Entry_Ring_UTurn:0x33,
    
    /// 小环岛不数出口
    
    AssiAction_Small_Ring_Not_Count:0x34,
    
    /// 到达复杂路口，走右边第一出口
    
    AssiAction_Right_Branch_1:0x40,
    
    /// 到达复杂路口，走右边第二出口
    
    AssiAction_Right_Branch_2:0x41,
    
    /// 到达复杂路口，走右边第三出口
    
    AssiAction_Right_Branch_3:0x42,
    
    /// 到达复杂路口，走右边第四出口
    
    AssiAction_Right_Branch_4:0x43,
    
    /// 到达复杂路口，走右边第五出口
    
    AssiAction_Right_Branch_5:0x44,
    
    /// 到达复杂路口，走左边第一出口
    
    AssiAction_Left_Branch_1:0x45,
    
    /// 到达复杂路口，走左边第二出口
    
    AssiAction_Left_Branch_2:0x46,
    
    /// 到达复杂路口，走左边第三出口
    
    AssiAction_Left_Branch_3:0x47,
    
    /// 到达复杂路口，走左边第四出口
    
    AssiAction_Left_Branch_4:0x48,
    
    /// 到达复杂路口，走左边第五出口
    
    AssiAction_Left_Branch_5:0x49,
    
    /// 辅助动作个数,一定要放最后一个
    
    AssistAction_Count:0x50
};

/// 道路速度限制 千米每小时

MRoute.LimitedSpeed = {
    LimitedSpeed_NULL:-1,
    LimitedSpeed_30:30,
    LimitedSpeed_40:40,
    LimitedSpeed_50:50,
    LimitedSpeed_60:60,
    LimitedSpeed_70:70,
    LimitedSpeed_80:80,
    LimitedSpeed_90:90,
    LimitedSpeed_100:100,
    LimitedSpeed_110:110,
    LimitedSpeed_120:120
};



/// 基本导航动作对应常量列表

MRoute.MainAction = {
    MainAction_NULL:0x0,            // 无基本导航动作
    MainAction_Turn_Left:0x1,       // 左转
    MainAction_Turn_Right:0x2,      // 右转
    MainAction_Slight_Left:0x3,     // 向左前方行驶
    MainAction_Slight_Right:0x4,    // 向右前方行驶
    MainAction_Turn_Hard_Left:0x5,  // 向左后方行驶
    MainAction_Turn_Hard_Right:0x6, // 向右后方行驶
    MainAction_UTurn:0x7,           // 左转调头
    MainAction_Continue:0x8,        // 直行
    MainAction_Merge_Left:0x9,      // 靠左
    MainAction_Merge_Right:0x0A,    // 靠右
    MainAction_Entry_Ring:0x0B,     // 进入环岛
    MainAction_Leave_Ring:0x0C,     // 离开环岛
    MainAction_Slow:0x0D,           // 减速行驶
    MainAction_Plug_Continue:0x0E,  // 插入直行（泛亚特有）
    MainAction_Count:0x0F
};

MRoute.OGGSound = {
    OGG_Distance_Kilometre_120:33, // 120公里
    OGG_Distance_Kilometre_110:32, // 110公里
    OGG_Distance_Kilometre_100:31, // 100公里
    OGG_Distance_Kilometre_90:30, // 90公里
    OGG_Distance_Kilometre_80:29, // 80公里
    OGG_Distance_Kilometre_70:28, // 70公里
    OGG_Distance_Kilometre_60:27, // 60公里
    OGG_Distance_Kilometre_50:26, // 50公里
    OGG_Distance_Kilometre_40:25, // 40公里
    OGG_Distance_Kilometre_30:24, // 30公里
    OGG_Distance_Kilometre_4:23, // 4公里
    OGG_Distance_Kilometre_3:22, // 3公里
    OGG_Distance_Kilometre_2:21, // 2公里
    OGG_Distance_Kilometre_1:20, // 1公里
    OGG_Distance_Meter_900:19, // 900米
    OGG_Distance_Meter_800:18, // 800米
    OGG_Distance_Meter_700:17, // 700米
    OGG_Distance_Meter_600:16, // 600米
    OGG_Distance_Meter_500:15, // 500米
    OGG_Distance_Meter_400:14, // 400米
    OGG_Distance_Meter_300:13, // 300米
    OGG_Distance_Meter_200:12, // 200米
    OGG_Distance_Meter_150:11, // 150米
    OGG_Distance_Meter_100:10, // 100米

    OGG_Along_Kilometre_35:160, // 前方有35公里以上顺行道路
    OGG_Along_Kilometre_15:161, // 前方有15公里以上顺行道路
    OGG_Along_Kilometre_5:162, // 前方有5公里以上顺行道路
    OGG_Along_All:163, // 请顺道路行驶，直到有新的导航提示
    OGG_Pass_SAPA:164, // 前方2公里有服务区，请适当休息

    OGG_MainAction_Turn_Left:200, //左转
    OGG_MainAction_Turn_Right:201, //右转
    OGG_MainAction_Left_Ahead:202, // 向左前方行驶
    OGG_MainAction_Right_Ahead:203, // 向右前方行驶
    OGG_MainAction_Left_Back:204, //向左后方行驶
    OGG_MainAction_Right_Back:205, //向右后方行驶
    OGG_MainAction_UTurn:206, // 左转掉头
    OGG_MainAction_Continue:207, // 直行
    OGG_MainAction_Merge_Left:208, // 靠左行驶
    OGG_MainAction_Merge_Right:209, // 靠右行驶
    OGG_MainAction_Pass_Ring:210, // 经过环岛
    OGG_MainAction_Exit_Ring:211, //驶出环岛
    OGG_MainAction_Slow:212, // 注意减速
    OGG_MainAction_Along_Road:214,

    OGG_MainAction_Entry_Ring:220, //进入环岛
    OGG_MainAction_FP_Exit_Ring:221, //前方请驶出环岛
    OGG_MainAction_Pass_Ring_Go:222, //经过环岛走
    OGG_MainAction_Slight_Left:223, //偏左转
    OGG_MainAction_Slight_Right:224, // 偏右转
    OGG_MainAction_Turn_Hard_Left:225, // 左后转
    OGG_MainAction_Turn_Hard_Right:226, // 右后转

    OGG_AssiAction_Entry_Main:300, // 进入主路
    OGG_AssiAction_Entry_Side_Road:301, // 进入辅路
    OGG_AssiAction_Entry_Freeway:302, // 进入高速路
    OGG_AssiAction_Entry_Slip:303, // 进入匝道
    OGG_AssiAction_Entry_Tunnel:304, // 进入隧道
    OGG_AssiAction_Entry_Center_Branch:305, // 进入中间岔路
    OGG_AssiAction_Entry_Right_Branch:306, // 进入右岔路
    OGG_AssiAction_Entry_Left_Branch:307, // 进入左岔路
    OGG_AssiAction_Entry_Right_Road:308, // 进入右转专用道
    OGG_AssiAction_Entry_Left_Road:309, // 进入左转专用道

    OGG_AssiAction_Entry_Center_Side_Road:310, //进入中间道路
    OGG_AssiAction_Entry_Right_Side_Road:311, //进入右侧道路
    OGG_AssiAction_Entry_Left_Side_Road:312, //进入左侧道路
    OGG_AssiAction_Along_Side:313, //沿辅路行驶
    OGG_AssiAction_Along_Main:314, //沿主路行驶
    OGG_AssiAction_Along_Right_Road:315, //沿右转专用道行驶

    OGG_AssiAction_Arrive_Exit:320, // 到达出口
    OGG_AssiAction_Arrive_Service_Area:321, // 到达服务区
    OGG_AssiAction_Arrive_TollGate:322, // 到达收费站
    OGG_AssiAction_Arrive_Way:323, // 到达途经点附近
    OGG_AssiAction_Arrive_Destination:324, // 到达目的地附近
    OGG_AssiAction_Arrive_Ferry:325, //到达轮渡码头附近
    OGG_AssiAction_Arrive_Ferry_Stop_Sound:326, //到达轮渡码头附近导航中断

    OGG_AssiAction_Front_Branck:327, //前方路口

    OGG_AssiAction_Left_Branch_1:335, // 走左数第一岔路
    OGG_AssiAction_Left_Branch_2:336, // 走左数第二岔路
    OGG_AssiAction_Left_Branch_3:337, // 走左数第三岔路
    OGG_AssiAction_Left_Branch_4:338, // 走左数第四岔路
    OGG_AssiAction_Left_Branch_5:339, // 走左数第五岔路
    OGG_AssiAction_Right_Branch_1:330, // 走右数第一岔路
    OGG_AssiAction_Right_Branch_2:331, // 走右数第二岔路
    OGG_AssiAction_Right_Branch_3:332, // 走右数第三岔路
    OGG_AssiAction_Right_Branch_4:333, // 走右数第四岔路
    OGG_AssiAction_Right_Branch_5:334, // 走右数第五岔路

    OGG_AssiAction_Exit_1:340, // 第一出口
    OGG_AssiAction_Exit_2:341, // 第二出口
    OGG_AssiAction_Exit_3:342, // 第三出口
    OGG_AssiAction_Exit_4:343, // 第四出口
    OGG_AssiAction_Exit_5:344, // 第五出口
    OGG_AssiAction_Exit_6:345, // 第六出口
    OGG_AssiAction_Exit_7:346, // 第七出口

    OGG_AssiAction_G0_Exit_1:347, // 走第一出口
    OGG_AssiAction_G0_Exit_2:348, // 走第二出口
    OGG_AssiAction_G0_Exit_3:349, // 走第三出口
    OGG_AssiAction_G0_Exit_4:350, // 走第四出口
    OGG_AssiAction_G0_Exit_5:351, // 走第五出口
    OGG_AssiAction_G0_Exit_6:352, // 走第六出口
    OGG_AssiAction_G0_Exit_7:353, // 走第七出口

    OGG_AssiAction_Pass_Exit_1:354, // 经过第一出口
    OGG_AssiAction_Pass_Exit_2:355, // 经过第二出口
    OGG_AssiAction_Pass_Exit_3:356, // 经过第三出口
    OGG_AssiAction_Pass_Exit_4:357, // 经过第四出口
    OGG_AssiAction_Pass_Exit_5:358, // 经过第五出口
    OGG_AssiAction_Pass_Exit_6:359, // 经过第六出口
    OGG_AssiAction_Pass_Exit_7:360, // 经过第七出口

    OGG_AssiAction_Road_1:370, // 第一路口
    OGG_AssiAction_Road_2:371, // 第二路口
    OGG_AssiAction_Road_3:372, // 第三路口
    OGG_AssiAction_Road_4:373, // 第四路口
    OGG_AssiAction_Road_5:374, // 第五路口
    OGG_AssiAction_Road_6:375, // 第六路口
    OGG_AssiAction_Road_7:376, // 第七路口
    OGG_AssiAction_Road_8:377, // 第八路口

    OGG_AssiAction_Pass_Road_1:380, // 经过第一路口
    OGG_AssiAction_Pass_Road_2:381, // 经过第二路口
    OGG_AssiAction_Pass_Road_3:382, // 经过第三路口
    OGG_AssiAction_Pass_Road_4:383, // 经过第四路口
    OGG_AssiAction_Pass_Road_5:384, // 经过第五路口
    OGG_AssiAction_Pass_Road_6:385, // 经过第六路口
    OGG_AssiAction_Pass_Road_7:386, // 经过第七路口
    OGG_AssiAction_Pass_Road_8:387, // 经过第八路口

    OGG_Then:400,       // 随后
    OGG_Forword:401,    // 前方
    OGG_Is:402,         // 是
    OGG_Target:403,     // 方向

    OGG_Please_At:404,  //请在
    OGG_Pass:405,       //经过
    OGG_Please:406,     //请

    OGG_Drive_Carefully:421,                // 请谨慎驾驶
    OGG_Have_Continuous_Camera:422,         // 有连续摄像
    OGG_Have_Speed_Camera:423,              // 有测速摄像
    OGG_Have_Surveillance_Camera:424,       // 有监控摄像

    OGG_POIType_Traffic_Accident:451,           // 发生交通事故
    OGG_POIType_Serious_Traffic_Accident:452,   // 发生严重交通事故
    OGG_POIType_Construct:453,                  // 占路施工
    OGG_POIType_Traffic_Control:454,            // 交通管制
    OGG_POIType_Move_Low:455,                   // 行驶缓慢
    OGG_POIType_Move_Fast:456,                  // 行驶畅通
    OGG_POIType_Traffic_JAM:457,                // 交通拥堵

    OGG_Navi_End:601,                           // 本次导航结束
    OGG_Reroute:602,                            // 重新计算路径
    OGG_Navi_Start:603,                         // 开始导航
    OGG_Stop_Navi:604,                          // 结束导航
    OGG_Dong:605,                               // 咚
    OGG_GPS_OK:606,                             // GPS信号正常
    OGG_Volum:607,                              // 这是当前音量
    OGG_Max_Volum:608,                          // 这是最大音量
    OGG_Power_Low:609,                          // 电力不足，请及时充电
    OGG_Receive_Destination:610,                // 收到下发目的地
    OGG_Exceed_Speed_Limt:611,                  // 您已超速
    OGG_Current_Road_SPeed_Limt:612,            // 当前道路限速
    OGG_Off_ROute:613                           // 你已经偏离了预设路线
};

/**
 +----------------------------------------------------------
 * 经纬度对象对象
 +----------------------------------------------------------
 * 
 +----------------------------------------------------------
 */
MRoute.LngLat = Class({
	//经度
	lng:0,
	//维度
	lat:0,
	/**
	 +------------------------------------------------------------------------------
	 * 构建经纬度坐标
	 +----------------------------------------------------------
	 * @param lng {Number}
	 * @param lat {Number}
	 +------------------------------------------------------------------------------
	 */
	"initialize":function(lng,lat){
		if(isNaN(lng)){throw new Error("AMap.LngLat<lng>参数无效:"+lng+"\r");}
		if(isNaN(lat)){throw new Error("AMap.LngLat<lat>参数无效:"+lat+"\r");}
		this.lng = Number(Number(lng).toFixed(8));
		this.lat = Number(Number(lat).toFixed(8));
	}

});

MRoute.TMCBarItem = Class({
    code:0,
    dist:0,
    state:0,
    "initialize":function(code, dist, state){
        this.code = code;
        this.dist = dist;
        this.state = state;
    }
});
/**
 +----------------------------------------------------------
 * 路径共有属性类。当一次请求多条路径时，存在一些路径的共有属性，为了减少冗余，这些属性统一存储，每条路径保存其应用。
 +----------------------------------------------------------
 * 已结束
 +----------------------------------------------------------
 */
MRoute.TmcInfo = Class({
	"initialize":function(){
		this.locationCode = 0;	// 动态交通信息位置编码
		this.locationDist = 0;	// 动态交通信息位置编码对应道路长度
		this.locationTime = 0;	// 行驶此段距离预计的时间。
	},
	/**
	 * 获取LocationCode。
	 * @deprecated 为了兼容保留此接口，但以后不建议再使用，可以使用 getLCode()替代。
	 * @return LocationCode对应的ID,低15位表示LCode，第16位表示方向，0为正向，1为反向。
	 * @author 周琦
	 */
	getLocationCode:function(){
		return this.locationCode;
	},
	
	/**
	 * 获取LocationCode。原始值是双字节表示的，最高位是符号位，需要转成相应的整型，在请求时用转化后的数值请求
	 * @return LocationCode对应的ID，如果是正向LocationCode，则返回值大于0，如果为负向LocationCode，返回值小于0。
	 */
	getLCode:function(){
		if((this.locationCode & 0x8000) == 0){
			return this.locationCode;
		}else{
			return -(this.locationCode & 0x7fff);
		}		
	},
	
	/**
	 * 获取此LocationCode对应的道路长度。
	 * @return 长度，单位：米。
	 */
	getLength:function(){
		return this.locationDist;
	},
	
	/**
	 * 获取此LocationCode路段所需的时间。
	 * @return 时间，单位：秒。
	 */
	getTime:function(){
		return this.locationTime;
	}
	
});
/**
 +----------------------------------------------------------
 * 路牌类型
 +----------------------------------------------------------
 * 已结束
 +----------------------------------------------------------
 */
MRoute.RoadSign = Class({
	_type : 0,
	_content : null,
	
	"initialize":function(){
		
	},
	
	/**
	 * 获取路牌类型。
	 * @return 返回路牌类型。
	 */
	getType:function(){
		return this._type;
	},
	
	/**
	 * 获取路牌内容。	
	 * @return 返回路牌内容。
	 */
	getContent:function(){
		return this._content;
	},
	
	/**
	 * 设置路牌类型
	 * @param type 路牌类型，目前的取值范围为1-7。
	 */
	setType:function(type){
		this._type = type;
	},
	
	/**
	 * 设置路牌内容。
	 * @param content 路牌内容，不能为null。
	 */
	setContent:function(content){
		if(content == null){
			throw Error("road signs cannot be null");
		}
		this._content = content;
	}
});

MRoute.PathDecode = Class({
	stream:0,
	paths : null,
	sharedSegs : null,
	sharedPathAttribute : null,
	
	"initialize":function(base64){
		var binary = this.decodebase64(base64);
		//将二进制解码
		this._decode_(binary);
		//console.log(this.paths);
	},
	/**
	 +----------------------------------------------------------
	 * BASE64解码数据为二进制
	 +----------------------------------------------------------
	 * @param input [base64]
	 * @return [binary]
	 +----------------------------------------------------------
	 */
	decodebase64 : function (input) {//base64解码
        var output = "",keyStr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="; 
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4, i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");  
        while (i < input.length) {  
            enc1 = keyStr.indexOf(input.charAt(i++));  
            enc2 = keyStr.indexOf(input.charAt(i++));  
            enc3 = keyStr.indexOf(input.charAt(i++));  
            enc4 = keyStr.indexOf(input.charAt(i++));  
            chr1 = (enc1 << 2) | (enc2 >> 4);  
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);  
            chr3 = ((enc3 & 3) << 6) | enc4;  
            output = output + String.fromCharCode(chr1);  
            if (enc3 != 64){
                output = output + String.fromCharCode(chr2);  
            }
            if(enc4 != 64){
            	output = output + String.fromCharCode(chr3);  
            }
        }
        return output;
    },
	/**
	 +----------------------------------------------------------
	 * 字节转文本
	 +----------------------------------------------------------
	 * @param buf 字节数组
	 * @param offset 起始值
	 * @param lenth 变化量
	 * @return [String] 文本 
	 +----------------------------------------------------------
	 */	
	byte2text:function(buf, offset, lenth){
		var arr = [],text=[];
		for(var i=offset;i<(offset+lenth);i++){
			text.push(String.fromCharCode(buf[i+1]<<8|(buf[i]&0xFF)));
			i++
		}
		return text.join("");
	},
	intbyte:function(i){
		return (i>127?i-256:i);
	},
	intshort:function(i){
		return (i>32767?i-65536:i);
	},
	/**
	 +----------------------------------------------------------
	 * 字节解码
	 +----------------------------------------------------------
	 * @param buf 字节数组
	 * @param offset 起始值
	 * @param offset 变化量
	 * @return [String] 文本 
	 +----------------------------------------------------------
	 */	
	_decode_:function(is){
		// 1 读取包头
		var i=0,header=[];
		while(i<8){//取8个字节
			header.push((is.charCodeAt(this.stream) & 0xff).toString());
			i++;this.stream++;
		}
		if(i<8){
			throw Error("Failed to read package header.");
		}
		// 1.1 获取数据包长度 3B
		var len = ((header[0] & 0xFF)) + ((header[1] & 0xFF) << 8) + ((header[2] & 0xFF) << 16);// 2846
		// 1.2 获取协议版本 1B,并检查是否支持
		if (!this.checkVersion(header[3] & 0xFF)){
			throw Error("Unsupported protocol.");
		}

		// 1.3 获得错误代码 1B
		var errorCode = header[4] & 0xFF;
		if (errorCode != 0){
			throw Error("Failed to resolve any path with error code:" + errorCode);
		}
		// 1.4 获得时间戳 2B
		var timestamp = ((header[5] & 0xFF)) + ((header[6] & 0xFF) << 8);
		
		// 1.5 获得控制信息 1B
		var ctrlflag = header[7] & 0xFF;
		// 至此，数据包头已经解析完成
		var spa = new MRoute.SharedPathAttribute();
		spa.timestamp = timestamp;
		spa.lineSimplification = (ctrlflag & 0x10) != 0;
		spa.hasDivideInfo = (ctrlflag & 0x20) != 0;
		this.sharedPathAttribute = spa;

		var cis = is;
		if ((ctrlflag & 0x8) != 0) {
			// 不支持zlib压缩
			throw Error("Compression is not unsupported.");
		}

		// idx记录解析的长度
		var idx = header.length;

		// 2 如果存在预览信息，则 解析预览信息
		if ((ctrlflag & 0x1) != 0) {
			// 如果含有上次解析的路径，则重置解码器
			if (this.paths != null){
				this.reset();
			}
			// 解析预览信息，累加解析长度
			idx += this.decodePreviewInfo(cis);
		}

		// 3 如果存在详细信息，则解析详细信息
		if ((ctrlflag & 0x2) != 0) {
			// 如果包含详细信息
			while (idx < len) {
				idx += this.decodeDetailInfo(cis);
			}
		}

		// 如果最终解析长度与包长度不一致，则解析失败
		if (idx != len){
			throw new DecodeException("Failed to decode,package length does not match.");
		}
		
		return this.paths;
	},
	/**
	 * 从路径数据流中解析出一条路径的预览信息。
	 * 
	 * @param is
	 *            路径数据流，必须从下个字节开始都是预览数据。
	 * @return 预览数据的长度。
	 * @throws IOException
	 *             读取流发生错误，抛出此异常。
	 * @throws DecodeException
	 *             如果路径数据存在问题，无法按其解析出路径，则抛出此异常。
	 * @throws NullPointerException
	 *             如果is为null，抛出此异常。
	 */
	decodePreviewInfo:function(is){
		if (is == null){
			throw Error("Input stream can not be null.");
		}
		// 1.1 计算预览包长度 2B
		var i=0,lenBuf=[];//value: -28,1
		while(i<2){//取2个字节
			lenBuf[i] = (is.charCodeAt(this.stream) & 0xff).toString();
			i++;this.stream++;
		}
		if (i<2) {
			throw Error("Failed to read the length of detail data.");
		}
		var packlens = ((lenBuf[0] & 0xFF)) + ((lenBuf[1] & 0xFF) << 8);//value: 372

		// 读取预览包的内容
		var idx = 0,j=0,buf=[], ite=0;
		while(j<(packlens-lenBuf.length)){//取n个字节
			buf[j] = (is.charCodeAt(this.stream) & 0xff).toString();
			j++;this.stream++;
		}
		if (j<(packlens-lenBuf.length)) {
			throw Error("Failed to read preview data.");
		}
		// 1.2 获取路径数目 1B
		var pathCount = buf[idx++] & 0xFF;
		if (pathCount == 0) {
			throw Error("Illegal preview data which has no path included.");
		}

		// 1.3 获取预览控制信息 1B
		var ctrlflag = buf[idx++] & 0xFF;
		
		// 1.4 获取终点信息
		if ((ctrlflag & 0x4) != 0) {
			idx += 32;
			var endlen = buf[idx++] & 0xFF;
			if (endlen > 0) {
				this.sharedPathAttribute.endPointName = this.byte2text(buf, idx, endlen*2);
				idx += endlen * 2;
			}
		}

		// 2.1 获取道路名称表长度 2B
		var namelens = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
		idx += 2;

		// 2.2 获取道路名称表地址,记录起始索引
		var nameidxs = idx;
		idx += namelens * 2;

		// 3.1 共用导航段数 2B
		var sharecount = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
		if (sharecount == 0) {
			throw Error("Illegal preview data which has no segment included.");
		}
		idx += 2;

		// 3.2 共用导航段信息
		var sharedSegs = [];
		for (var i = 0; i < sharecount; i++) {
			var seg = new MRoute.SharedSegmentAttribute();
			sharedSegs[i] = seg;
			var val;
			// 3.2.1 导航段行驶距离 2B
			val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;
			seg.passDist = (val & 0x8000) == 0 ? val : (val & 0x7FFF) << 5;

			// 3.2.2 导航段收费距离 2B
			val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;
			seg.tollDist = (val & 0x8000) == 0 ? val : (val & 0x7FFF) << 5;

			// 3.2.3 导航段名称+索引 1B + 2B
			var navilens = buf[idx++] & 0xFF;
			if (navilens > 0) {
				var naviidxs = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
				idx += 2;
				if (naviidxs < namelens){
					seg.roadName = this.byte2text(buf, nameidxs+naviidxs*2, navilens*2);
				}else{
					throw Error("Invalid name index");
				}
			}

			// 3.2.4 起点坐标 4B + 4B
			var x = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8) + ((buf[idx + 2] & 0xFF) << 16) + ((buf[idx + 3] & 0xFF) << 24);
			idx += 4;
			var y = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8) + ((buf[idx + 2] & 0xFF) << 16) + ((buf[idx + 3] & 0xFF) << 24);
			idx += 4;

			// 3.2.5 预览形状点
			if ((ctrlflag & 0x1) != 0) {
				val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
				idx += 2;

				var count = val & 0x1FFF,
					scale = val >> 13;

				var ltx = x,
					lty = y;

				seg.simpleCoor = [];
				for (var k = 0; k < count; k++) {
					val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
					idx += 2;
					ltx += this.intshort(val) << scale;
					
					val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
					idx += 2;
					lty += this.intshort(val) << scale;

					seg.simpleCoor[2 * k + 2] = ltx;// *
													// 20;这里没有将坐标转为3600000倍，以服务端为准.
					seg.simpleCoor[2 * k + 3] = lty;// * 20;
				}
			}else{
				seg.simpleCoor = [];
			}
			seg.simpleCoor[0] = x;// * 20;
			seg.simpleCoor[1] = y;// * 20;

			// 3.2.6 交通信息
			if ((ctrlflag & 0x2) != 0) {
				var size = buf[idx++] & 0xFF;
				if (size < 0) {
					throw Error("Illegal count of TMC records");
				} else if (size == 0) {
					var ltime = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
					idx += 2;
					seg.tmcTime = ltime * 10;
				} else {
					var unit0 = (buf[idx++] & 0xFF) * 10;
					var tmcinf = [];
					for (var k = 0; k < size; k++) {
						var lcode = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
						idx += 2;
						var ldist = buf[idx++] & 0xFF,
							ltime = buf[idx++] & 0xFF;
						ltime *= 10;

						var tmcitem = new MRoute.TmcInfo();
						tmcinf[k] = tmcitem;
						tmcitem.locationCode = lcode;
						tmcitem.locationDist = ldist * unit0;
						tmcitem.locationTime = ltime;
						seg.tmcTime += ltime;
					}
					seg.tmcRecords = tmcinf;
				}
			}
		}
		// 4.开始处理路径信息
		var paths = [];
		var mainsegcount = 0; // 主路径导航段个数
		var mainsegment = null;
		for (var i = 0; i < pathCount; i++) {
			var path = new MRoute.NaviPath();
			path.sharedPathAttribue = this.sharedPathAttribute;
			var val;
			// 4.1 获取策略与分组 1B
			val = buf[idx++] & 0xFF;
			path.group = val & 0x0F;
			path.strategy = (val & 0x70) >> 4;
			path.bestpath = (val & 0x80) != 0;
			// 获取分段信息
			if (path.sharedPathAttribue.hasDivideInfo) {
				path.bDivided = (buf[idx] & 0x01) != 0;
				path.detailSegmentCount = ((buf[idx] & 0xFE) >> 1) + ((buf[idx + 1] & 0xFF) << 7);
				idx += 2;

				// 下一个点信息
				var coorX = 0,coorY = 0;
				coorX = (buf[idx] & 0xFF) + ((buf[idx + 1] & 0xFF) << 8) + ((buf[idx + 2] & 0xFF) << 16) + ((buf[idx + 3] & 0xFF) << 24);
				idx += 4;
				coorY = (buf[idx] & 0xFF) + ((buf[idx + 1] & 0xFF) << 8) + ((buf[idx + 2] & 0xFF) << 16) + ((buf[idx + 3] & 0xFF) << 24);
				idx += 4;
				if (coorX != 0 && coorY != 0) {
					path.hasPointForNextRequest = true;
					path.nextPoint = new MRoute.NvPoint(coorX,coorY);
				}

			}
			paths[i] = path;
			
			
			// 4.2 获取结合点之前导航段个数 2B（非重合导航段个数）
			val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;
			var selfcount = val;

			// 4.3 获取结合点当前导航段索引 2B
			val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;
			var joinindex = val;

			var pathsegcount;
			if (i == 0) {
				// 主路径，总导航段个数等于非重合导航段个数
				mainsegcount = pathsegcount = selfcount;
			} else {
				if (joinindex > mainsegcount){
					throw Error("Illegal joint index");
				}
				pathsegcount = selfcount + mainsegcount - joinindex;
			}

			var navisegment = [];
			path.segments = navisegment;

			if (i == 0){
				mainsegment = navisegment;
			}
			// 4.4 解析结合点前的导航段
			for (var k = 0; k < selfcount; k++) {
				var navi = new MRoute.NaviSegment();
				navisegment.push(navi);

				navi.basicAction = buf[idx++] & 0xFF;
				navi.assistAction = buf[idx++] & 0xFF;
				var shareindex = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
				idx += 2;
				if (shareindex < sharecount){
					navi.sharedSegAttribute = sharedSegs[shareindex];
				}else{
					throw Error("Failed get shared segment attribute.");
				}
			}

			// 4.4 解析结合点后的导航段
			for (var k = selfcount; k < pathsegcount; k++) {
				navisegment[k] = mainsegment[joinindex + k - selfcount];
			}
		}

		idx += lenBuf.length;
		if (idx != packlens) {
			throw Error("Failed to decode preview data,length does not match");
		} else {
			// 统一更新成员
			this.sharedSegs = sharedSegs;
			this.paths = paths;
			this.onPreviewOk(); // 回调
		}
		return idx;
	},

	decodeDetailInfo:function(is){
		if (is == null){
			throw Error("Input stream can not be null.");
		}
		// 如果不存在预览信息，则无法解析详细信息
		if (this.paths == null){
			throw Error("Failed to decode detail info without preview info.");
		}
		// 1.1 获取详细导航段信息长度 2B
		var i=0,lenBuf=[];
		while(i<2){
			lenBuf[i] = (is.charCodeAt(this.stream) & 0xff).toString();
			i++;this.stream++;
		}
		if (i<2) {
			throw Error("Failed to read the length of detail data.");
		}
		var packlens = ((lenBuf[0] & 0xFF)) + ((lenBuf[1] & 0xFF) << 8);

		// 读取详细导航段的内容
		var idx = 0;
		var i=0,buf=[],ite=0;
		while(i<(packlens - lenBuf.length)){//取8个字节
			buf[i] = (is.charCodeAt(this.stream) & 0xff).toString();
			i++;this.stream++;
		}
		
		if (i<(packlens - lenBuf.length)) {
			throw Error("Failed to read detail data.");
		}

		// 1.2 导航段id 2B
		var segid = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
		idx += 2;

		// 1.3 路径id 1B
		var pathid = buf[idx++] & 0xFF;
		if (pathid >= this.paths.length){
			throw Error("Illegal path id.");
		}
		if (segid >= this.paths[pathid].segments.length){
			throw Error("Illegal segment id.");
		}
		var seg = this.paths[pathid].segments[segid]; // 定位到需要填充详细信息的导航段对象

		// 1.4 扩展位 1B
		var ctrlflag = buf[idx++] & 0xFF;

		// 1.5 路口背景图片+前景图片 2B+2B
		if ((ctrlflag & 0x8) != 0) {
			seg.backImage = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;
			seg.foreImage = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;
		}

		// 1.6 路口名称信息 1B + nB
		if ((ctrlflag & 0x20) != 0) {
			var namelens = buf[idx++] & 0xFF;
			if (namelens > 0) {
				seg.nodeName = this.byte2text(buf, idx, namelens * 2,"UTF-16LE");
				idx += namelens * 2;
			}
		}

		// 1.7 道路路牌信息 1B + nB
		if ((ctrlflag & 0x40) != 0) {
			var signlens = buf[idx++] & 0xFF;
			if (signlens > 0) {
				seg.signpost = this.byte2text(buf, idx, signlens * 2,"UTF-16LE");
				idx += signlens * 2;
			}
		}


		if ((ctrlflag & 0x4) != 0) {
			// 如果包含Link列表，则表明此导航段到目前为止还没有重复过

			// 2.1 link列表
			// 2.1.0 道路名称表 2B + nB
			var namelens = 0;
			if ((ctrlflag & 0x2) != 0) {
				namelens = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
				idx += 2;
			}

			var nameidxs = idx;
			idx += namelens * 2;

			// 2.1.1 Link堆个数
			var piles = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;

			// 2.2 获取link属性，并统计link总数，形状点数
			if (piles > 0) {
				var indexvalue = idx;
				var linkscount = 0;
				var pointcount = 1; // 必含起点
				// 每个Link堆对应一个共有属性
				var sharedSeg = seg.sharedSegAttribute;
				if (sharedSeg == null)
					throw Error("Failed to get shared segment attribute");
				sharedSeg.sharedLinkAttributes = [];

				// 初始化每个堆的共有属性及每个Link的属性
				for (var i = 0; i < piles; i++) {
					var attr = new MRoute.SharedLinkAttribute();
					sharedSeg.sharedLinkAttributes[i] = attr;

					// 2.2.1 共用信息 4B
					var val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8) + ((buf[idx + 2] & 0xFF) << 16) + ((buf[idx + 3] & 0xFF) << 24);
					idx += 4;

					attr.RoadClass = (val) & 0x0F;
					attr.Formway = (val >> 4) & 0x0F;
					attr.linkType = (val >> 8) & 0x03;
					attr.direction = ((val >> 10) & 0x01) != 0;
					attr.btoll = ((val >> 11) & 0x01) != 0;
					attr.cityRoad = (val >> 12) & 0x03;

					var linklens = (val >> 14) & 0x03F,
						linkidxs = (val >> 20) & 0xFFF;
					if (linklens > 0) {
						if (linkidxs == 0xFFF) {
							attr.linkName = sharedSeg.roadName;
						} else {
							attr.linkName = this.byte2text(buf, nameidxs + linkidxs * 2, linklens * 2,"UTF-16LE");
						}
					}

					// 2.2.1 link数量 1B
					var count = buf[idx++] & 0xFF;
					linkscount += count;
					for (var k = 0; k < count; k++) {
						var linkflag = buf[idx++] & 0xFF;
						var extendedFlag = 0;
						if ((linkflag & 0x80) != 0){ // 如果存在扩展控制信息
							extendedFlag = buf[idx++] & 0xFF;
						}

						if ((linkflag & 0x01) != 0){ // 路口车道 4B
							idx += 4;
						}
						if ((linkflag & 0x02) != 0){ // 转弯车道 4B
							idx += 4;
						}
						if ((linkflag & 0x04) != 0){ // 路牌信息 1B + n * 2B
							var signlens = buf[idx++] & 0xFF;
							idx += signlens * 2;
						}
						var cameraCount = 0; // 电子眼个数
						if ((linkflag & 0x10) != 0 && (linkflag & 0x80) != 0 && (extendedFlag & 0x01) != 0) {
							cameraCount = buf[idx++];
						} else if ((linkflag & 0x10) != 0) {
							cameraCount = 1;
						}
						if (cameraCount > 0){ // 电子眼信息 2B + 2B + B
							idx += 5 * cameraCount;
						}
						// if ((linkflag & 0x20) != 0) // 车道数目 1B
						// idx++;

						var ptvalue = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
						idx += 2;
						var ptcount = ptvalue & 0x3FFF;
						if ((ptvalue & 0x4000) != 0){
							idx += ptcount * 2;
						}else{
							idx += ptcount * 4;
						}
						pointcount += ptcount;
					}
				}

				// 2.3 生成详细坐标数组与link数组
				var detailCoor = [];

				// 初始化坐标起点
				var ltx = sharedSeg.simpleCoor[0];
				var lty = sharedSeg.simpleCoor[1];
				detailCoor[0] = ltx;
				detailCoor[1] = lty;
				var totalLink = [];

				// 处理link信息
				idx = indexvalue;
				var linksindex = 0;
				var pointindex = 1;
				for (var i = 0; i < piles; i++) {
					var linkAttr = sharedSeg.sharedLinkAttributes[i];
					// 2.3.1 共用信息 4B
					idx += 4;

					// 2.3.2 link数量 1B
					var count = buf[idx++] & 0xFF;

					// 2.3.3 处理每个Link
					for (var k = 0; k < count; k++) {
						var link0 = new MRoute.NaviLink();
						totalLink[linksindex++] = link0;
						link0.sharedAttribute = linkAttr;

						// 2.3.3.1 Link控制信息
						var linkflag = buf[idx++] & 0xFF;
						var extendedFlag = 0;
						if ((linkflag & 0x80) != 0){
							extendedFlag = buf[idx++] & 0xFF;
						}

						if ((linkflag & 0x01) != 0){ // 路口车道 4B
							link0.backLane = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8) + ((buf[idx + 2] & 0xFF) << 16) + ((buf[idx + 3] & 0xFF) << 24);
							idx += 4;
						}

						if ((linkflag & 0x02) != 0) // 转弯车道 4B
						{
							link0.foreLane = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8) + ((buf[idx + 2] & 0xFF) << 16) + ((buf[idx + 3] & 0xFF) << 24);
							idx += 4;
						}

						if ((linkflag & 0x04) != 0){ // 路牌信息 1B + n * 2B
							var signlens = buf[idx++] & 0xFF;
							link0.signpost = this.byte2text(buf, idx, signlens*2);
							idx += signlens * 2;
						}

						var cameraNum = 0; // 电子眼个数
						if ((linkflag & 0x10) != 0 && (linkflag & 0x80) != 0 && (extendedFlag & 0x01) != 0) {
							cameraNum = buf[idx++] & 0xFF;
						} else if ((linkflag & 0x10) != 0) {
							cameraNum = 1;
						}
						link0.cameraCount = cameraNum;

						if ((linkflag & 0x08) != 0){ // 服务区信息
							link0.atService = true;
						} else{
							link0.atService = false;
						}
						if ((extendedFlag & 0x02) != 0){ // 进入不同动态交通城市的标志
							link0.bIntoDiffCity = true;
						} else {
							link0.bIntoDiffCity = false;
						}
						if ((extendedFlag & 0x04) != 0){ // 复杂路口处的可播报标志
							link0.isNeedPlay = true;
						} else {
							link0.isNeedPlay = false;
						}
						if (cameraNum != 0){ // 电子眼信息 2B + 2B + B
							var cameras = [];
							link0.cameras = cameras;
							for (var curIndex = 0; curIndex < cameraNum; ++curIndex) {

								var camera = new MRoute.Camera();
								link0.cameras[curIndex] = camera;
								camera.x = this.intshort(((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8));
								idx += 2;
								camera.y = this.intshort(((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8));
								idx += 2;
								camera.type = buf[idx] & 0x0F;
								camera.speed = (buf[idx] & 0xF0) >> 4;
								idx++;
								camera.speed *= 10; // 将速度换算为kmph
							}
						}

						if ((linkflag & 0x20) != 0){ // 分叉路
							link0.mixFork = true;
						} else{
							link0.mixFork = false;
						}
						if ((linkflag & 0x40) != 0){ // 交通灯
							link0.trafficLight = true;
						} else{
							link0.trafficLight = false;
						}
						var ptvalue = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
						idx += 2;
						var ptcount = ptvalue & 0x3FFF;

						link0.detailCoor = detailCoor;
						if ((ptvalue & 0x8000) != 0){
							link0.begOffCoor = 2 * pointindex;
						}else{
							link0.begOffCoor = 2 * (pointindex - 1);
						}
						if ((ptvalue & 0x4000) != 0) {
							for (var n = 0; n < ptcount; n++, pointindex++) {
								var val;
								val = buf[idx++] & 0xFF;
								ltx += this.intbyte(val);

								val = buf[idx++] & 0xFF;
								lty += this.intbyte(val);
								detailCoor[2 * pointindex] = ltx;
								detailCoor[2 * pointindex + 1] = lty;
							}
						} else {
							for (var n = 0; n < ptcount; n++, pointindex++) {
								var val;
								val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
								idx += 2;
								ltx += this.intshort(val);

								val = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
								idx += 2;
								lty += this.intshort(val);

								detailCoor[2 * pointindex] = ltx;
								detailCoor[2 * pointindex + 1] = lty;
							}
						}
						link0.endOffCoor = 2 * pointindex;

						if ((linkflag & 0x10) != 0){ // 电子眼信息
						
							// 由于camera坐标是相对于本link起点的偏移坐标，需要进行处理
							for (var curIndex = 0; curIndex < link0.cameraCount; ++curIndex) {
								var camera = link0.cameras[curIndex];
								camera.x += detailCoor[link0.begOffCoor];
								camera.y += detailCoor[link0.begOffCoor + 1];
							}
						}
					}
				}
				sharedSeg.detailCoor = detailCoor;
				sharedSeg.links = totalLink;
			}
		}

		// 用户数据
		if ((ctrlflag & 0x10) != 0) {
			var userDataLen = 0;
			userDataLen = ((buf[idx] & 0xFF)) + ((buf[idx + 1] & 0xFF) << 8);
			idx += 2;
			if (userDataLen > 0) {
                seg.userData = [];
                var i= 0, ud = seg.userData;
                while(i<userDataLen){//取8个字节
                    ud[i] = buf[i+idx];
                    i++;
                }
//				seg.userData = new byte[userDataLen];
//				System.arraycopy(buf, idx, seg.userData, 0, userDataLen);
				idx += userDataLen;
			}
		}

		idx += lenBuf.length;
		if (idx != packlens) {
			throw Error("Failed to decode detail data,length does not match");
		} else {
			this.onSegmentOk(seg); // 回调
			return idx;
		}
	},

	checkVersion:function(ver) {
		switch (ver){
			case 1:
				return true;
			default:
				return false;
		}
	},

	/**
	 * 重置解码器。如果此前使用本类对象成功解析完一条路径的所有信息，然后又重新使用本对象的decode方法解析一条新路径的数据，
	 * 这时本解码器会自动先调用reset方法重置解码器。但如果上条路径未解析完或者解析中发生了错误，则不保证还以能用decode解析
	 * 出新路径，而需要调用者先调用reset重置解码器，或者新生成一个PathDecoder对象进行解析。因此，如果希望复用一个解码器进
	 * 行多个路径的解码，建议在每次解析完后调用reset方法重置解码器。但如果是对一条路径进行多次解析（例如先请求预览包，再
	 * 请求详细包，这时需要对两次下载的数据各调用一次decode），则不应该在之间调用reset。本方法没有同步，不保证线程安全，
	 * 调用者应自己注意在调用此方法时没有其他线程正在解析路径或访问解码器。
	 */
	reset:function() {
		this.onResetting();
		this.sharedSegs = null;
		this.sharedPathAttribute = null;
		this.paths = null;
	},

	/**
	 * 获取已解析的路径。可以在解析完一段预览数据包后，或者在另一线程访问此方法。
	 * 
	 * @return 如果已经可以获取预览信息，返回路径数组，否则返回null。
	 */
	getPaths:function(){
		return this.paths;
	},

	/**
	 * 获取指定策略的最佳路径。
	 * 
	 * @param strategy
	 *            路径策略。
	 * @return 如果找到这返回路径对象，如果没有找到或者路径未解析成功，则返回null
	 */
	getBestPath:function(strategy) {
		if (this.paths != null) {
			for (var i = 0; i < this.paths.length; i++) {
				var path = this.paths[i];
				if (path.getStrategy() == strategy && path.isBestPath()){
					return path;
				}
			}
		}
		return null;
	},

	/**
	 * 预览解析完成时的回调。本方法在接码线程中调用，执行完之前不会进行进一步解码。
	 */
	onPreviewOk:function() {

	},

	/**
	 * 当一个导航段解析完所有信息时的回调。本方法在接码线程中调用，执行完之前不会进行进一步解码。
	 * 
	 * @param seg
	 *            解析完成的导航段对象。
	 */
	onSegmentOk:function(seg) {

	},

	/**
	 * 解码器重置之前的回调。
	 */
	onResetting:function() {

	}	
});

/**
 +----------------------------------------------------------
 * 导航时间
 +----------------------------------------------------------
 * 已结束
 +----------------------------------------------------------
 */
MRoute.NaviTime = Class({
	speedTable : [90,60,50,40,30,30,60,45,35,30,20],
	time : Number.MAX_VALUE,

    /**
     * 用于求一个导航段或一组导航段的行驶时间， 单位：秒
     * @param seg
     */
	"initialize":function(seg){

        var links = seg.getLinks();//NaviLink[]
        // 遍历导航段中的Link，以速度最快的Link作为本导航段的速度。
        var maxSpeed = 1;
        for(var i =0; i < links.length; i++){
            var grade =  links[i].getRoadClass(),
                speed = this.speedTable[grade];
            if(speed > maxSpeed){
                maxSpeed = speed;
            }
        }
        maxSpeed = maxSpeed * 1000 ;
        this.time = (seg.getDistance() ) / maxSpeed; //+ maxSpeed -1
	},
	/**
	 * 根据语言输出时间字符串。
	 * @param lang 目前支持"cn"与"en",即中文与英文，否则输出""。
	 */
	toString:function(lang){
		var time = this.time;
        var ts,hour, minute;
		if(lang == "cn"){
			if(time < 60){
				return time + "分钟";
			}else{
				hour = time / 60;
				ts = hour + "小时";				 
				minute =  time % 60;
				if(minute > 0){
					ts +=  minute + "分钟";
				}
				return ts;
			}			
		}else if(lang == "en"){
			if(time < 60){
				return time <= 1 ? time + " minute" : time + " minutes";
			}else{
				hour = time / 60;
				ts = hour == 1 ? "1 hour" : hour + " hours";
				minute =  time % 60;
				if( minute > 0){
					ts += minute == 1 ? " 1 minute":" " + minute + " minutes";
				}			
				return ts;
			}
		}else{
			if(time < 60){
				return time + "分钟";
			}else{
				hour = time / 60;
				minute =  time % 60;
				return hour + "小时" + minute + "分钟";
			}
		}
	},
	
	/**
	 * 获取驾驶时间。
	 * @return 驾驶时间，单位：分钟。
	 */
	getTime:function(){
		return this.time;
	}
	
});

/**
 * 导航段共用属性类。当存在多条路径时，它们可能存在一些重复的导航段，而这些信息是多条路径
 * 共有的（包括长度，坐标点等），为了减少冗余，这些共用的导航段信息只保存一次，每条路径中
 * 的导航段仅保存其应用。本类只供本包内部使用，外部无法访问。
 * @author 周琦
 *
 */
MRoute.SharedSegmentAttribute = Class({
	
	direction : null,			//导航段方向
	// 预览中包含以下信息
	passDist : 0,				// 行驶距离
	tollDist : 0,				// 收费距离		
	roadName : null,			// 导航段名称
	simpleCoor : null,			// 抽稀道路坐标
	tmcRecords : null,			// 动态交通信息
	tmcTime : 0,				// TMC参考时间，单位秒。
	
	// 详细段中包含以下信息
	detailCoor : null,				// 详细道路坐标		
	sharedLinkAttributes : null,	// Link共有属性
	links : null,					// Link列表
	driveTime : null,				// 行驶时间
	
	"initialize":function(){
		
	},
	/// <summary>
	/// 根据DetailCoor算出来的经纬度值
	/// </summary>
	_detailCoorLngLat:[],
	/// <summary>
	/// 根据int 坐标计算出经纬度坐标
	/// </summary>
	GetDetailCoorLngLat:function(){
		if (this._detailCoorLngLat.length==0){
			this._detailCoorLngLat = [];
			for (var i = 0; i < this.detailCoor.length; i++){
				this._detailCoorLngLat[i] = this.detailCoor[i] / CoordFactor;
			}
		}
		return this._detailCoorLngLat;
	}
	
});

/**
 +----------------------------------------------------------
 * 导航段类，每条路径都是由多个导航段组成，每个导航段的结尾都存在导航动作，提示用户如何进入
 * 下一个导航段。
 +----------------------------------------------------------
 */
MRoute.NaviSegment = Class({
    // 以下属性是每条路径导航段独有的，即使其他路径也经过这个导航段，这些值也可能不同。其中，

    basicAction:0, // 导航基本动作
    assistAction:0, // 导航辅助动作
    backImage:-1, // 路口图片的背景图ID
    foreImage:-1, // 路口图片的前景图ID
    nodeName:null, // 路口名称
    signpost:null, // 路牌信息

    bDistUpdated:false, // 是否重算了seg 和 link长度信息

    //---------- diff with c++-----------------
    userData:null, // 用户数据 c not have
    sharedSegAttribute:null, /// Segment共有属性 c not have
    // -----------  move to sharedSegAttribute
//    PassDist : 0,                   /// 行驶距离
//    TollDist : 0,                   /// 收费距离
//    RoadName :null,                 /// 导航段名称
//    SimpleCoor :[],                 /// 抽稀道路坐标
//    DetailCoor :null,               /// 详细道路坐标
//    SharedLinkAttributes : null,    /// Link共有属性
//    Links : null,                   /// Link列表
//    DriveTime : null,               /// 行驶时间
//    _detailCoorLngLat : null,       /// 根据DetailCoor算出来的经纬度值
//    TmcRecords :null,               /// 动态交通信息
//    TmcTime :0,                     /// TMC参考时间，单位秒


    "initialize":function () {

    },

    /**
     * 获取指定位置的LinkId
     * @param  ptId   对应的形状点编号
     * @return {Number} 所求link编号
     */
    getLinkId:function (ptId) {
        var links = this.getLinks(),
            nextId = ptId + 1;
        if (links != null) {
            for (var i = 0; i < links.length; i++) {
                if (links[i].isContain(nextId)) {
                    return i;
                }
            }
            if (i == links.length) {
                return i - 1;
            }
        }
        return 0;
    },

    /**
     *
     * @param linkId 指定的link序号
     * @return {MRoute.NaviLink} 对应编号的link
     */
    getLink:function (linkId) {
        var links = this.getLinks();
        if (links != null && linkId < links.length && linkId >= 0) {
            return links[linkId];
        }
        return null;
    },

    getLinkAngle:function (linkId) {
        var selLink = this.getLink(linkId);
        if (!selLink) {
            return 0;
        }

        var start = selLink.getStartCoorIndex(),
            end = selLink.getEndCoorIndex(),
            cords = this.getDetailedCoors(),
            coLen = cords.length;
        if (end >= coLen) {
            end -= 2;
        }

        return CalcGeoAngleInDegree(cords[start], cords[start + 1], cords[end], cords[end - 1]);

    },

    /**
     *
     * @param linkId 当前link编号
     * @return {Number}从当前形状点始符合条件的RoadClass
     */
    calcRoadClass:function (linkId) {
        var eRoadClass = MRoute.RoadClass.RoadClass_Main_Road;

        var links = this.getLinks();
        for (var i = linkId; i < links.length; i++) {
            eRoadClass = links[i].getRoadClass();
            var eForm = links[i].getLinkForm();
            if (eForm != MRoute.Formway.Formway_Slip_Road
                && eForm != MRoute.Formway.Formway_JCT
                && eForm != MRoute.Formway.Formway_Exit_Link
                && eForm != MRoute.Formway.Formway_Entrance_Link
                && eForm != MRoute.Formway.Formway_Round_Circle) {
                break;
            }
        }

        return eRoadClass;
    },

    calcMixForkNum:function (linkId) {
        var num = 0,
            linkNum = this.getLinkCount();
        for (var i = linkId; i < linkNum; i++) {
            var link = this.getLink(i);
            if (link.hasMixFork()) {
                num++;
            }
        }

        return num;
    },

    calcForkInfo:function (ptId, stPoint) {
        var remainForkNum = 0,
            nearestForkDist = 0;

        var lastIndex = -1,
            startIndex = 0,
            linkNum = this.getLinkCount(),
            i = linkNum - 1;
        for (; i >= 0; i--) {
            var link = this.getLink(i);
            startIndex = link.getStartPtId();
            if (link.hasMixFork()) {
                remainForkNum++;
                lastIndex = i;
            }
            if (startIndex <= ptId) {
                break;
            }
        }

        if (lastIndex != -1) {
            var ptNum = this.getDetailedPointsCount(),
                endPtId;
            if (lastIndex == linkNum - 1) {
                endPtId = ptNum - 1;
            }
            else {
                var nextLink = this.getLink(lastIndex + 1);
                endPtId = nextLink.getStartPtId();
            }
            if (ptId < endPtId) {
                var coors = this.getDetailedCoorsLngLat(),
                    index = 2 * (ptId + 1);
                nearestForkDist += GetMapDistInMeter(stPoint.x, stPoint.y, coors[index], coors[index + 1]);
                for (i = ptId + 1; i < endPtId; i++) {
                    index = 2 * i;
                    nearestForkDist += GetMapDistInMeter(coors[index], coors[index + 1], coors[index + 2], coors[index + 3]);
                }
            }

        }

        return [remainForkNum, nearestForkDist];
    },

    /**
     * 计算指定点到seg终点的剩余距离
     * @param linkId  当前link编号
     * @param ptId    当前形状点编号
     * @param stPoint 指定点
     * @return {Number}
     */
    getRemainSegDist:function(linkId, ptId, stPoint){
        // 使用预先计算的link到seg终点的剩余距离，减少重复计算
        var link   = this.getLink(linkId);
        return this.getRemainLinkDist(linkId, ptId, stPoint) + link.getDistToExit();
    },

    /**
     * 计算指定点到link终点的剩余距离
     * @param linkId  当前link编号
     * @param ptId    当前形状点编号
     * @param stPoint 指定点
     * @return {Number}
     */
    getRemainLinkDist:function (linkId, ptId, stPoint) {
        var linkRemain = 0,
            curLink = this.getLink(linkId),
            clist = this.getDetailedCoorsLngLat(),
            endID = curLink.getEndCoorIndex() / 2,
            nextID = ptId + 1;

        if (nextID >= endID) {
            return linkRemain;
        }

        for (var i = nextID; i < endID - 1; i++) {
            var j = 2 * i;
            linkRemain += GetMapDistInMeter(clist[j], clist[j + 1], clist[j + 2], clist[j + 3]);
        }

        if (stPoint != null) {
            linkRemain += GetMapDistInMeter(stPoint.x, stPoint.y, clist[2 * nextID], clist[2 * nextID + 1]);
        }
        return linkRemain;
    },

    /**
     *
     * @param linkId  当前link编号
     * @return {Number}所求link行车时间估计，单位分钟
     */
    getLinkTime:function (linkId) {
        var segDist = this.getDistance();
        if (segDist > 0) {
            var segTime = this.getTmcTimeMinute();
            if (segTime <= 0) {
                segTime = this.getDriveTimeMinute();
            }

            var linkLen = this.getLinkLength(linkId);
            return Math.ceil(segTime * linkLen / segDist);
        }
        return 0;
    },

    /**
     *
     * @param linkId
     * @return {Number} link长度, 单位米
     */
    getLinkLength:function (linkId) {
        var link = this.getLink(linkId);
        return link.getDistance();
    },


    /**
     * 求当前link 中和已知点最近的形状点
     * @param fx        当前点经度
     * @param fy        当前点纬度
     * @param linkId    当前所在link
     * @return {Number}
     */
    calcNearestPtId:function (fx, fy, linkId) {
        var coors = this.getDetailedCoorsLngLat();
        var ptID = 0;
        var length = coors.length / 2;
        var minDist = Number.MAX_VALUE;
        var sId = 0, eId = length - 1;
        if (linkId >= 0 && linkId < this.getLinks().length) {
            var link = this.getLink(linkId);
            sId = link.getStartPtId();
            eId = link.getEndCoorIndex() / 2 - 1;
        }

        for (var i = sId; i < eId; i++) {
            var j = i * 2;
            var x1 = coors[j], y1 = coors[j + 1],
                x2 = coors[j + 2], y2 = coors[j + 3];

            // 计算点到线的投影点
            var res = FindNearPt(x1, y1, x2, y2, fx, fy);

            // 计算当前点到投影点之间的Map距离
            var nDistance = Math.round(1000 * GetMapDistance(fx, fy, res[0], res[1]));
            if (nDistance < minDist) {
                minDist = nDistance;
                ptID = i;
            }
        }

        return ptID;
    },

    /**
     *
     * @return {Number} 所含link数目
     */
    getLinkCount:function () {
        if (this.getLinks() == null) {
            return 0;
        }
        return this.getLinks().length;
    },

    /**
     * @param linkId 当前link
     * @return {string} 查找本导航段的下一路名
     */
    getNextRoadName:function (linkId) {
        var nextName = null;
        var links = this.getLinks();
        for (var i = linkId + 1; i < links.length; i++) {
            nextName = links[i].getLinkName();
            if (nextName != null && nextName.length > 0) {
                break;
            }
        }
        return nextName;
    },

    _getSharedSegAttribute_:function () {//SharedSegmentAttribute
        // assert sharedSegAttribute != null;
        return this.sharedSegAttribute;
    },

    // 下面一些方法解析完预览信息即可获得
    /**
     * 获取导航段结束进入下一导航段时的基本导航动作。
     * @return 基本导航动作，此信息预览解析后即可获得。
     */
    getBasicAction:function () {
        return this.basicAction;
    },


    /**
     * 获取导航段结束进入下一导航段时的辅助导航动作。
     * @return 辅助导航动作，此信息预览解析后即可获得。。
     */
    getAssistAction:function () {
        return this.assistAction;
    },

    /**
     * 获取导航段长度。
     * @return 整个导航段长度，单位：米，此信息预览解析后即可获得。。
     */
    getDistance:function () {
        if(!this.bDistUpdated){
            this.distUpdate();
        }

        return this._getSharedSegAttribute_().passDist;
    },

    /**
     * 获取导航段收费道路的长度。
     * @return 整个导航段收费道路长度，单位：米，此信息预览解析后即可获得。。
     */
    getTollDistance:function () {
        return this._getSharedSegAttribute_().tollDist;
    },

    /**
     * 获取导航段名称。
     * @return 如果导航段存在名称，则返回该名称，否则返回null。此信息预览解析后即可获得。。
     */
    getRoadName:function () {
        return this._getSharedSegAttribute_().roadName;
    },

    /**
     * 获取本导航段的预览坐标数组。此方法可以一次性获得原生坐标，无须生成NaviPoint对象，效率要远远高于对每个点调用getPreviewPoint()方法。
     * @return 预览点数组。因为每个坐标的X与Y各占一个int，所以数组的长度必然为偶数。 注意：只有当
     * NaviPath.hasLineSimplification()返回true时预览点才有作用，否则数组中只会包含每个导航段的起点。
     */
    getPreviewCoors:function () {
        return this._getSharedSegAttribute_().simpleCoor;
    },

    /**
     * 获取本导航段的预览点的个数。
     * @return 因为每个点两个坐标，所以应该为getPreviewCoors().length的一半。
     */
    getPreviewPointsCount:function () {
        var len = this.getPreviewCoors().length;
        // assert (len & 0x1) == 0;
        return len / 2;
    },

    /**
     * 获取本导航段的第index个预览点。
     * @param index 预览点索引，从0开始，小于getPreviewPointsCount()
     * @return 预览点对象。
     * @exception ArrayIndexOutOfBoundsException 如果index超出范围则抛出此异常。
     */
    getPriviewPoint:function (index) {
        var coors = this.getPreviewCoors();
        index *= 2;
        return new MRoute.NvPoint(coors[index], coors[index + 1]);
    },

    /**
     * 获取此导航段中TMC信息。
     * @return 如果存在TMC信息，则返回包含TMC记录数组，否则返回null；
     */
    getTmcInfo:function () {
        return this._getSharedSegAttribute_().tmcRecords;
    },


    /**
     * 获取此导航段服务端预计的行驶时间,方法只有在请求开启了TMC时才有效；
     * @return 导航段的行驶时间, 单位：秒
     */
    getTmcTime:function () {
        return this._getSharedSegAttribute_().tmcTime;
    },

    /**
     * 当服务端提供有tmc时间时采用tmc时间，反之采用本地估计时间
     * @return {Number} 估计的行驶时间，单位：分钟
     */
    getEstimateTime:function() {
        var time = this.getTmcTime() / 60;
        if(time == 0){
            time = this.getOrigDriveTime() / 60;
        }
        return time;
    },

    /**
     * 获取此导航段服务端预计的行驶时间,单位：分钟
     * @return {Number} 服务端提供的tmc时间转为分钟整数
     */
    getTmcTimeMinute:function () {
        return Math.ceil(this.getTmcTime() / 60);
    },

    /**
     * 获取导航段的行驶时间
     * @return {Number}驾驶时间，单位：秒
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用
     */
    getDriveTimeMinute:function () {
        var time = Number(this.getOrigDriveTime() / 60);
        return Math.ceil(time);
    },

    /**
     * 获取导航段的行驶时间
     * @return 驾驶时间, 精确浮点数值，单位：秒
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用
     */
    getOrigDriveTime:function () {
        this._checkHasDetailedInfo_();
        var driveTime = this._getSharedSegAttribute_().driveTime;

        if (driveTime == null) {
            var nvTime = new MRoute.NaviTime(this);
            this._getSharedSegAttribute_().driveTime = nvTime.getTime();
        }
        return  this._getSharedSegAttribute_().driveTime;
    },

    /**
     * 获取本导航段是否已经解析出详细导航信息。
     * 采用分段下载模式时,并非所有导航段都含有详细信息,所以,在获取详细信息之前,一定有用此方法来检查是否含有详细信息
     * @return 如果已经解析出详细信息，返回true，否则返回false。
     */
    _hasDetailedInfo_:function () {
        return this._getSharedSegAttribute_().links != null;
    },

    _checkHasDetailedInfo_:function () {
        if (!this._hasDetailedInfo_()) {
            throw Error("Detailed Info has not been resolved yet.需要解析出来本段的详细导航信息后调用");
        }
    },

    // 以下方法只有在解析完详细信息后方可调用：
    /**
     * 获取是否存在路口放大图。
     * @return 如果存在路口放大图则返回true，否则返回false。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    _hasCrossingImage_:function () {
        this._checkHasDetailedInfo_();
        return this.backImage != -1 && this.foreImage != -1;
    },

    /**
     * 获取是否存在用户数据。
     * @return 如果存在用户数据则返回true，否则返回false。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    _hasUserData_:function () {
        this._checkHasDetailedInfo_();
        return this.userData != null;
    },

    /**
     * 获取用户数据。
     * @return 如果用户数据则返回用户数据，否则返回null。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getUserData:function () {
        return this._hasUserData_() ? this.userData : null;
    },

    /**
     * 获取路口放大图背景图ID。
     * @return 如果存在路口放大图则返回背景图的ID，否则返回-1。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getBackgroundImage:function () {
        return this._hasCrossingImage_() ? this.backImage : -1;
    },

    /**
     * 获取路口放大图前景图的ID。
     * @return 如果存在路口放大图则返回前景图的ID，否则返回-1。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getForegroundImage:function () {
        return this._hasCrossingImage_() ? this.foreImage : -1;
    },

    /**
     * 获取路口名称。
     * @return 如果存在路口名称，则返回名称，如果不存在则返回null；
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getIntersectionName:function () {
        this._checkHasDetailedInfo_();
        return this.nodeName;
    },

    /**
     * 获取路牌名称。
     * @return 如果存在路牌，则返回路牌信息，如果不存在则返回null；
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getSignpost:function () {
        this._checkHasDetailedInfo_();
        return this.signpost;
    },

    /**
     * 获取数组化的路牌列表。
     * @return 如果存在路牌，则返回路牌信息列表，如果不存在则返回null；
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getRoadSigns:function () {
        var list = [];
        if (!this._hasDetailedInfo_()) {
            throw Error("Detailed Info has not been resolved yet.");
        }
        if (this.signpost == null || this.signpost.length <= 0) {
            return list;
        }
        var arrStr = this.signpost.split("::");
        if (arrStr.length == 0) {
            return list;
        }

        for (var i = 0; i < arrStr.length; i++) {
            var str = arrStr[i];
            if (str.length <= 1) {
                return list;
            }
            var ch = str.charAt(0);
            if (!/^[0-9A-Za-z]*$/.test(ch)) {
                return list;
            }

            var sign = new MRoute.RoadSign();
            if (/^[0-9]*$/.test(ch)) {//是否为数字
                sign.setType(parseInt(ch));
            } else if (/^[a-z]*$/.test(ch)) {//是否为小写字母
                sign.setType(ch.charCodeAt(0) - "a".charCodeAt(0) + 1);
            } else {//是否为大写字母
                sign.setType(ch.charCodeAt(0) - "A".charCodeAt(0) + 1);
            }
            sign.setContent(str.substring(1));
            list.push(sign);
        }
        return list;
    },

    /**
     * 获取本导航段下的Link集合。
     * @return link集合，一个导航段至少含有一个Link；
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getLinks:function () {
        this._checkHasDetailedInfo_();
        return this._getSharedSegAttribute_().links;
    },

    /**
     * 获取本导航段的详细坐标组。此方法可以一次性获得原生坐标，无须生成NaviPoint对象，效率要远远高于对每个点调用getDetailedPoint()方法。
     * @return 详细坐标点数组。每个坐标占两个int（X与Y各占一个int，它们分别等于经度与纬度乘以NaviPoint.coorFactor），数组长度必为偶数。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getDetailedCoors:function () {
        this._checkHasDetailedInfo_();
        return this._getSharedSegAttribute_().detailCoor;
    },

    /**
     * 获取本导航段的详细坐标点的个数。
     * @return 因为每个点两个坐标，所以应该为getDetailedCoors().length的一半。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     */
    getDetailedPointsCount:function () {
        var len = this.getDetailedCoors().length;
        return len / 2;
    },

    /**
     * 获取本导航段的第index个详细坐标点。
     * @param index 坐标点索引，从0开始，小于getDetailedPointsCount()。
     * @return 坐标点对象。
     * @throws Error 此方法只能在解析完详细信息后，即hasDetailedInfo()返回true时才能调用，
     * 如果在此之前调用会抛出此异常。
     * @exception ArrayIndexOutOfBoundsException 如果index超出范围则抛出此异常。
     */
    getDetailedPoint:function (index) {
        var coors = this.getDetailedCoors();
        index *= 2;
        if(index >=0 && index < coors.length-1){
            return new MRoute.NvPoint(coors[index], coors[index + 1]);
        }
        return null;
    },

    getPointAngle:function(ptId){
        if(ptId < 0){
            return 0;
        }
        var cords = this.getDetailedCoors(),
            start = ptId * 2,
            end = (ptId+1)*2;
        if(end >= cords.length){
            start = cords.length - 4;
            end = start + 2;
        }

        return CalcGeoAngleInDegree(cords[start], cords[start + 1], cords[end], cords[end - 1]);
    },

    /**
     * 取当前分段的前300米计算起始方向
     * @return {Number} 当前导航段起始方向
     */
    getStartDirection:function () {
        this._checkHasDetailedInfo_();

        var coords = this.getDetailedCoorsLngLat();
        var len = this.getDetailedPointsCount();

        var sx, sy, ex, ey;
        sx = coords[0];
        sy = coords[1];
        if (this.getDistance() > 300) {
            var dist = 0, id = 0;
            while (dist < 300 && id < coords.length - 4) {
                dist += GetMapDistInMeter(coords[id], coords[id + 1],
                    coords[id + 2], coords[id + 3]);
                id += 2;
            }
            ex = coords[id + 2];
            ey = coords[id + 3];
        }
        else {
            ex = coords[2 * len - 2];
            ey = coords[2 * len - 1];
        }

        var dAngle = CalcGeoAngle(sx, sy, ex, ey);
        return this._angleToDirection_(dAngle);

    },

    getWholeDirection:function () {
        this._checkHasDetailedInfo_();

        var coords = this.getDetailedCoorsLngLat();
        var len = this.getDetailedPointsCount();

        var sx, sy, ex, ey;
        sx = coords[0];
        sy = coords[1];
        ex = coords[2 * len - 2];
        ey = coords[2 * len - 1];

        var dAngle = CalcGeoAngle(sx, sy, ex, ey);
        return this._angleToDirection_(dAngle);
    },

    _angleToDirection_:function (dAngle) {
        if (dAngle > (15.0 / 8 * Math.PI) || dAngle < (1.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_North;
        }
        else if (dAngle > 1.0 / 8 * Math.PI && dAngle < (3.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_North_East;
        }
        else if (dAngle > 3.0 / 8 * Math.PI && dAngle < (5.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_East;
        }
        else if (dAngle > 5.0 / 8 * Math.PI && dAngle < (7.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_East_South;
        }
        else if (dAngle > 7.0 / 8 * Math.PI && dAngle < (9.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_South;
        }
        else if (dAngle > 9.0 / 8 * Math.PI && dAngle < (11.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_West_South;
        }
        else if (dAngle > 11.0 / 8 * Math.PI && dAngle < (13.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_West;
        }
        else if (dAngle > 13.0 / 8 * Math.PI && dAngle < (15.0 / 8 * Math.PI)) {
            return MRoute.Direction.RouteDire_West_North;
        }

        return MRoute.Direction.RouteDire_NULL;
    },



    /**
     * 用详细坐标重算segment的实际长度， 代替下载数据中给定的长度
     * 同时更新各link的长度，以及link终点到本导航段末端的剩余距离
     * @private
     */
    distUpdate:function() {
        var coors = this._getSharedSegAttribute_().GetDetailCoorLngLat(),
            dist = 0,
            sumDist = 0,
            linkId = 0,
            linkDist = 0,
            curLink = this.getLink(linkId),
            linkCount = this.getLinkCount(),
            linkIntegral = [],
            end = coors.length - 2;
        for (var i = 0; i < end; i += 2) {
            dist = GetMapDistInMeter(coors[i], coors[i + 1], coors[i + 2], coors[i + 3]);
            sumDist += dist;

            // 可能本link的起点并不是前一link的终点
            if(curLink.begOffCoor <= i){
                linkDist += dist;
            }

            if(curLink.endOffCoor == i + 4){
                curLink.setDistance(linkDist);
                linkIntegral.push(sumDist);
                linkId++;
                if(linkId < linkCount){
                    curLink = this.getLink(linkId);
                    linkDist = 0;
                }
            }
        }
        if(linkIntegral.length < linkCount){
            linkIntegral.push(sumDist);
        }

        for(i = 0; i < linkCount; i++){
            curLink = this.getLink(i);
            curLink.setDistToExit(sumDist - linkIntegral[i]);
        }

        this._getSharedSegAttribute_().passDist = sumDist;
        this.bDistUpdated = true;
    },

    /**
     * @return [Array]本导航段的详细经纬度坐标组
     */
    getDetailedCoorsLngLat:function () {
        this._checkHasDetailedInfo_();
        return this._getSharedSegAttribute_().GetDetailCoorLngLat();
    }

});
/**
 +----------------------------------------------------------
 * 导航点类型
 +----------------------------------------------------------
 * 已结束
 +----------------------------------------------------------
 */

MRoute.NvPoint = Class({
	coorFactor : 3600 * 64,
	x:0,
	y:0,
	
	"initialize":function(x,y){//设置坐标
		if(/^(-?[1-9][0-9]*|0)$/.test(x)){//整形
			this.x = x/this.coorFactor;
			this.y = y/this.coorFactor;
		}else{//浮点型
			this.x = x;
			this.y = y;
		}
	},
	/**
	 * 获取浮点经度。
	 * @return 经度，单位：度。
	 */
	getX:function(){
		return this.x;
	},

	/**
	 * 获取浮点纬度。
	 * @return 纬度，单位：度。
	 */
	getY:function(){
		return this.y;
	},
	
	/**
	 * 获取整形经度。
	 * @return 整形经度，为浮点经度的coorFactor倍。
	 */
	getIntX:function(){
		return Math.round(this.x * this.coorFactor);
	},
	
	/**
	 * 获取整形纬度。
	 * @return 整形纬度，为浮点纬度的coorFactor倍。
	 */
	getIntY:function(){
		return Math.round(this.y * this.coorFactor);
	}

});

MRoute["NaviPoint"] = MRoute.NvPoint;

/**
 +----------------------------------------------------------
 * 路径共有属性类。当一次请求多条路径时，存在一些路径的共有属性，为了减少冗余，这些属性统一存储，每条路径保存其应用。
 +----------------------------------------------------------
 */
MRoute.SharedPathAttribute = Class({
	
	timestamp : 0,				// 服务端计算路径的时间戳	
	endPointName : null,		// 终点名称
	lineSimplification : false,	// 是否含抽稀的预览点 
	hasDivideInfo : false,		//是否包含分段信息
	
	"initialize":function(){
		
	}
	
});
/**
 +----------------------------------------------------------
 * 导航路径。每个NaviPath对应一条导航路径。
 +----------------------------------------------------------
 * @return Number
 +----------------------------------------------------------
 */
MRoute.NaviPath = Class({


//    WORD m_nOverlapedSeg;							//记录与主路径Joint之后重叠的导航段个数

	"initialize":function(){
		// 以下属性非public，只有本包中的PathDecoder可以设置这些值，包外无法获取
        this.group = -1;								//路径组
        this.strategy = -1;								//路径策略
        this.totalDist = -1;							//整条路径的长度
        this.tollLength = -1;							//整条路径的收费长度
        this.detailSegmentCount = 0;					//启用分段下载时，详细导航段的个数
        this.bestpath = false;							//记录是否最佳路径
        this.bDivided = false;						//标志该路径是否经过了分段处理
        this.hasPointForNextRequest = false;			//标志是否有下一次请求时的起点信息
        this.nextPoint = null;							//下一次请求的

        this.segments = null;  							//本路径分段列表
        this.sharedPathAttribue = null; 				//本路径共有的属性
        this.driveTime = -1;
        this.nTmcTime = -1;

	},
	/**
	 * 获取路径的GroupID。此属性在单策略多路径，或多策略多路径时有效。每种策略都可能返回多条路径，它们的
	 * Group从0开始编号。
	 * @return 组号，每种策略的组号都从0开始编号。
	 */
	getGroup:function(){
		return this.group;
	},
	
	/**
	 * 获取路径的策略。
	 * @return	目前可能的值有：0.速度最快、1 费用最低、2距离最短、3耗油最少、4参考交通信息最快、5不走快速路、6国道优先、7省道优先
	 */
	getStrategy:function(){
		return this.strategy;
	},

	/**
	 * 判断是否本策略中的最佳路径。注意：此方法获得最佳路径并非多策略时的"推荐道路"（实际上，多策略时的最
	 * 佳路径始终是strategy=0的路径），而是在多路径时有效，这时每种策略都可能存在一条最好的路径。例如：当
	 * 策略为"推荐道路"时，仍然可能存在多条路径，但当中有一条是最好的。如果我们请求没有开启多路径，而是开
	 * 启了多策略，那么返回不同策略的3条路径，它们都是本策略中最好的。
	 * @return 如果是本策略多条路径中最好的路径，则返回true，否则返回false。如果没有开启多路径或者本种策
	 * 略只有一条路径，那么始终返回true。
	 */
	isBestPath:function(){
		return this.bestpath;
	},
	
	/**
	 * 获取服务器计算这条路径的时间戳。
	 * @return 时间戳。
	 */
	getTimeStamp:function(){
		// assert sharedPathAttribue != null;
		return this.sharedPathAttribue.timestamp;
	},
	
	/**
	 * 获取终端名称。
	 * @return 如果存在终点名称，则返回名称，否则返回null。
	 */
	getEndPointName:function(){
		// assert sharedPathAttribue != null;
		return this.sharedPathAttribue.endPointName;		
	},
	
	/**
	 * 获取路径是否经过抽稀。
	 * @return 如果服务端对预览形状点进行了抽稀，则返回true，否则返回false。
	 */
	isLineSimplified:function()
	{
		// assert sharedPathAttribue != null;
		return this.sharedPathAttribue.lineSimplification;
	},
	
	/**
	 * 返回本路径的导航段数组。
	 * @return 导航段数组，调用方不应该对其进行修改。
	 */
	getSegments:function(){
		return this.segments;
	},

    getSegmentByID:function (nIndex) {
        if (nIndex < 0) {
            return null;
        }
        var segments = this.getSegments();
        if (null == segments || segments.length <= nIndex) {
            return null;
        }
        return segments[nIndex];
    },

    /**
     * 获取导航段个数
     * @return {Number}
     */
    getSegmentCount:function(){
        return this.segments.length;
    },

    driveTime:-1,
    nTmcTime:-1,

	/**
	 * 返回本条道路的驾驶时间。
	 * @return {Number}驾驶时间。单位:秒
	 */
    getOrigDriveTime:function(){
        if(this.driveTime <= 0){
            var time = 0;
            var segments = this.getSegments();
            for(var i = 0; i < segments.length; i++){
                time += segments[i].getOrigDriveTime();
            }
            this.driveTime = time;
        }
        return this.driveTime;
    },

    /**
     * 获取取整后的驾驶时间，单位：秒
     * @return {Number}
     */
	getDriveTimeMinute:function(){
        return Math.ceil(this.getOrigDriveTime() / 60);
	},


    /**
     * 获取参考实时路况算得的行车时间，单位：秒
     * @return {Number}根据TMC估计出的行车时间
     */
    getTmcTime:function(){
        if(this.nTmcTime < 0){
            var time = 0;
            var segments = this.getSegments();

            for(var i = 0; i < segments.length; i++){
                var curT = segments[i].getTmcTime();
                if(curT == 0){
                    curT = segments[i].getOrigDriveTime();
                }
                time += curT;
            }
            this.nTmcTime = Math.round(time);
        }
        return this.nTmcTime;
    },

    /**
     * 返回以分钟计的tmc时间
     * @return {Number}
     */
    getTmcTimeMinute:function(){
        return Math.ceil(this.getTmcTime() / 60);
    },

    /**
     * 更新路径信息， 服务端给出的距离值不准确，用坐标重算一遍
     */
    updateRouteInfo:function(){
        var len = 0,
            segs = this.getSegments();
        for(var i = 0; i < segs.length; i++)
        {
            len += segs[i].getDistance();
        }
        this.totalDist = len;
    },
	
	/**
	 * 获取本路径的长度。
	 * @return 本路径长度，单位：米。
	 */
	getDistance:function(){

		if(this.totalDist <= 0){
            this.updateRouteInfo();
        }

		return this.totalDist;
	},
	
	/**
	 * 获取本路径收费路径长度。
	 * @return 本收费路径的长度，单位：米。
	 */
	getTollDistance:function(){
		if(this.tollLength >= 0){
			return this.tollLength;
		}
		var len = 0,
			segs = this.getSegments();
		for(var i=0;i<segs.length;i++ ){
			var seg = segs[i];
			len += seg.getTollDistance();			
		}
		this.tollLength = len;
		return len;
	},
	/**
	 * 获取本路径是否是分段路径,当分段下载时,对最后一段调用此方法会返回false;
	 * 此方法可以用来获取此段路径是否是全路径的最后一段
	 * @return 如果此分段是全路径的最后一段,返回false,否则返回true
	 */
	getIsDivided:function(){
		return this.bDivided;
	},
	/***
	 * 获得此路径的详细导航段数,只有分段下载时调用此方法返回的值才有意义
	 * @return 分段下载模式下(isDivided返回为true时),返回此路径的详细导航段个数,否则,返回0
	 */
	getDetailSegmentCount:function(){
		return this.detailSegmentCount;
	},
	/***
	 * 获取此路径中是否包含下一次请求的起点坐标信息，只在分段下载模式下有效
	 * @return 如果是分段下载模式，且此路径包含有效的下一次请求起点信息，则返回true,否则，返回false。
	 */
	hasPointInfoForNextRequest:function(){
		return this.hasPointForNextRequest;
	},
	/***
	 * 获取本路径下一次请求的起点信息，只在分段模式下有效
	 * @return 如果是分段下载模式，且存在下一次请求的起点信息，则返回下一个点的信息,否则，返回null
	 */
	getPointInfoForNextRequest:function(){
		if(this.hasPointInfoForNextRequest()){
			return this.nextPoint;
		}
		return null;
	},

    /**
     * 判别当前路段一定范围内是否拥堵
     * 两重判定：拥堵路段达到一定比例，时间较原来时间要长
     * @param segId         当前导航段
     * @param segRemainDist     当前导航段剩余距离
     * @param sId           起始查找位置
     * @param codeList      经过转换的locationCode列表
     * @param stateList     当前路况列表, 和codeList等长匹配
     * @return {Boolean}
     */
    isRouteBlocked:function(segId, segRemainDist, sId, codeList, stateList){
        var segs = this.getSegments(),
            curSeg = segs[segId],
            timePerDist = curSeg.getOrigDriveTime() / curSeg.getDistance(),
            driveLen = curSeg.getDistance() - segRemainDist,
            tmcRecords = curSeg.getTmcInfo(),
            timeSum = 0,
            newTimeSum = 0,
            distSum = 0,
            totalNum = 0,
            slowNum = 0,
            blockedNum = 0,
            listId = sId,
            bFind = false,
            i, code, curTime, curDist;

        // 遍历当前导航段剩余路段
        if(tmcRecords != null && tmcRecords.length > 0){
            for(i = 0; i <tmcRecords.length; i++){
                curDist = tmcRecords[i].getLength();
                if(distSum + curDist <= driveLen){
                    distSum += curDist;
                }
                else{
                    totalNum++;
                    //curTime = tmcRecords[i].getTime();
                    curTime = Math.round( timePerDist * curDist );
                    //处在剩余路段
                    code = tmcRecords[i].getLCode();
                    listId = this._getPos_(listId, code, codeList);
                    if(stateList[listId] == MRoute.RouteStatus.Status_Congested){
                        slowNum++;
                        curTime *= 2;
                    }
                    else if(stateList[listId] == MRoute.RouteStatus.Status_Blocked){
                        blockedNum++;
                        curTime *= 4;
                    }
                    if(!bFind){
                        bFind = true;
                        timeSum += Math.round(tmcRecords[i].getTime() * (distSum + curDist - driveLen)/curDist);
                        newTimeSum += Math.round(curTime *  (distSum + curDist - driveLen)/curDist);
                    }
                    else{
                        timeSum += tmcRecords[i].getTime();
                        newTimeSum += curTime;
                    }
                }
            }
        }
        else{
            curTime = Math.round(timePerDist * segRemainDist );
            timeSum +=  curTime;
            newTimeSum += curTime;
        }

        // 遍历剩余导航段，如timeSum已经足够大，则跳出
        for(var k = segId+1; k < segs.length; k++){
            tmcRecords = segs[k].getTmcInfo();
            timePerDist = segs[k].getOrigDriveTime() / segs[k].getDistance();
            if(tmcRecords != null && tmcRecords.length > 0){
                for(i = 0; i <tmcRecords.length; i++){
                    totalNum++;
                    //curTime = tmcRecords[i].getTime();
                    curTime = Math.round(timePerDist * tmcRecords[i].getLength() );
                    //处在剩余路段
                    code = tmcRecords[i].getLCode();
                    listId = this._getPos_(listId, code, codeList);
                    if(stateList[listId] == MRoute.RouteStatus.Status_Congested){
                        slowNum++;
                        curTime *= 2;
                    }
                    else if(stateList[listId] == MRoute.RouteStatus.Status_Blocked){
                        blockedNum++;
                        curTime *= 4;
                    }

                    timeSum += tmcRecords[i].getTime();
                    newTimeSum += curTime;
                }
            }
            else{
                curTime = Math.round(segs[k].getOrigDriveTime());
                timeSum +=  curTime;
                newTimeSum += curTime;
            }
            if(timeSum > 240 * 60){ // 4小时
                break;
            }
        }

        if(totalNum == 0){
            return false;
        }

        // 路况拥堵
        if( (slowNum + blockedNum)/totalNum > 0.35
            || slowNum /totalNum > 0.4
            || blockedNum /totalNum > 0.3)
        {
            // 剩余路段根据当前路况所需时间超出算路时估计的时间 30 分钟
            if(newTimeSum - timeSum > 30*60){
                return true;
            }
        }
        return false;
    },

    /**
     * 找到指定code 在数组中的位置编号
     * @param startId
     * @param code
     * @param codeList
     * @return {Number}
     * @private
     */
    _getPos_:function(startId, code, codeList){
        for(var i = startId; i < codeList.length; i++){
            if(codeList[i] == code){
                return i;
            }
        }
        // 处理未找到的情形，就本应用来说，不可能找不到
        return 0;
    },

    /**
     * 计算剩余TMC时间
     * @param segId
     * @param segRemainDist
     * @return {Number}
     */
    getRemainTMCTime:function(segId, segRemainDist){
        var i, timeRemain = 0,
            segs = this.getSegments();
        for(i = segId + 1; i < segs.length;i++ )
        {
            var seg = segs[i];
            timeRemain += seg.getTmcTime();
        }

        timeRemain += segs[segId].getTmcTime() *segRemainDist/ segs[segId].getDistance();

        return Math.round(timeRemain / 60);
    },

    /**
     * 获得整条路径的locCode（经转换），及对应的路段长度，各分段locCode起始位置
     * @returns [Array, Array, Array]
     */
    getLocCodeList:function(){
        var codeList = [], distList = [], idList = [];
        var segs = this.getSegments();
        var lastId, segDist, tmcDist;
        for(var i = 0; i < segs.length; i++){
            segDist = segs[i].getDistance();
            var tmcRecords = segs[i].getTmcInfo();
            if(tmcRecords != null && tmcRecords.length > 0){
                idList[i] = codeList.length;
                tmcDist = 0;
                for(var j = 0; j < tmcRecords.length;j++){
                    codeList.push(tmcRecords[j].getLCode());
                    distList.push(tmcRecords[j].getLength());
                    tmcDist += tmcRecords[j].getLength();
                }
                // adjust dist to keep equal
                if(tmcDist != segDist){
                    lastId = codeList.length - 1;
                    distList[lastId] += segDist - tmcDist;

                    //防范非法情况
                    if(distList[lastId] <= 0){
                        var tmp = 0, off = idList[i];
                        for(j = 0; j < tmcRecords.length - 1; j++){
                            distList[j+off] = Math.round(tmcRecords[j].getLength()*segDist / tmcDist);
                            tmp += distList[j+off];
                        }
                        distList[j+off] = segDist - tmp;
                    }
                }
            }
            else{
                lastId = codeList.length - 1;
                if(codeList.length > 0 && codeList[lastId] == 0){
                    idList[i] = lastId;
                    distList[lastId] += segDist;
                }
                else{
                    idList[i] = codeList.length;
                    codeList.push(0);
                    distList.push(segDist);
                }
            }
        }

        return [codeList, distList, idList];
    },

    /**
     * 计算当前路径剩余距离
     * @param nSegId
     * @param nPtId
     * @param stPoint
     * @return {Number}
     */
    getRemainRouteDist:function(nSegId, nPtId, stPoint){
        var routeRemain = 0,
            segs = this.getSegments();
        for(var i = nSegId + 1; i < segs.length;i++ )
        {
            var seg = segs[i];
            routeRemain += seg.getDistance();
        }

        var segRemain = 0,
            curSeg = segs[nSegId],
            nextID = nPtId + 1,
            length = curSeg.getDetailedPointsCount();

        if(nextID < length){
            var linkId = curSeg.getLinkId(nPtId);
            segRemain  = curSeg.getRemainSegDist(linkId, nPtId, stPoint);

        } else {
            // 不在本导航段，处于导航段间过渡带
            // 过渡带长度未计入路径长度，略去过渡带上点到下一导航段间的距离计算
        }

        routeRemain += segRemain;

        return routeRemain;
    },


    /**
     * 计算当前路径及当前分段的剩余距离和剩余时间, 单位分别为米 和 分钟
     * @param nSegId
     * @param nPtId
     * @param stPoint
     * @return [Array]
     */
    getRemainDistAndTime:function(nSegId, nPtId, stPoint)
    {
        var routeRemain = 0,
            routeRTime = 0,
            segs = this.getSegments();
        for(var i = nSegId + 1; i < segs.length;i++ )
        {
            var seg = segs[i];
            routeRemain += seg.getDistance();
            //routeRTime  += seg.getDriveTimeMinute();
            routeRTime += seg.getEstimateTime();
        }

        var segRemain = 0,
            curSeg = segs[nSegId],
            nextID = nPtId + 1,
            length = curSeg.getDetailedPointsCount();

        if(nextID < length){
            var linkId = curSeg.getLinkId(nPtId);
            segRemain  = curSeg.getRemainSegDist(linkId, nPtId, stPoint);

        } else {
            // 不在本导航段，处于导航段间过渡带
            // 过渡带长度未计入路径长度，略去过渡带上点到下一导航段间的距离计算
        }


        routeRemain += segRemain;

        //var segRemainTime = segs[nSegId].getDriveTimeMinute() * (segRemain/segs[nSegId].getDistance());
        var segRemainTime = segs[nSegId].getEstimateTime() * (segRemain/segs[nSegId].getDistance());
        routeRTime += segRemainTime;

        segRemainTime = Math.round(segRemainTime);
        routeRTime = Math.round(routeRTime);

        return [routeRemain, segRemain, routeRTime, segRemainTime];

    }


	
});

/**
 +----------------------------------------------------------
 * 共用Link属性。由于Link的颗粒度很小，有时后可能连续多个Link都拥有许多相同的属性，为了减少冗余，我们
 * 把这些易重复的属性提取出来，单独组成一个共用属性，如果多个Link都含有相同属性，则它们会引用同一个共
 * 有属性。本类型只供本包内部使用，外部无法访问。
 +----------------------------------------------------------
 */
MRoute.SharedLinkAttribute = Class({
	linkType:0,		// 连接类型，取值范围：0-3
	Formway:0,		// 道路类型，取值范围：0-10
    RoadClass:0,	// 道路等级，取值范围：0-16
	bCityRoad:0,	// 是否城市道路
	direction:0,	// 道路方向：true 双向，false 单向
	btoll:0,		// 是否收费
	linkName:null,		// 道路名称
	
	"initialize":function(){
		
	}
	
});
MRoute.NaviLink = Class({
    cameras:null, // 电子眼信息,Camera[]

    backLane:-1, // 背景车道信息
    foreLane:-1, // 前景车道信息（箭头）
    laneCount:0, // 车道数目

    bIntoDiffCity:false, // 进入不同动态交通城市的Link标志
    bNeedPlay:false, // 复杂路口处的可播报标志
    atService:false, // 是否在服务区
    mixFork:false, // 是否含分叉路
    trafficLight:false, // 是否含交通灯

    signpost:null, // 路牌信息,目前不支持在Link中的路牌，此字段一直为空

    detailCoor:null, // 详细道路坐标,int[]

    begOffCoor:0,    // 道路坐标开始下标
    endOffCoor:0,    // 道路坐标结束下标

    distToExit:0,
    distance:0,

    sharedAttribute:null, // Link的共用属性,SharedLinkAttribute

    //------ 缺乏的信息
//    BYTE  m_TrafficStatus;			// 记录最初Link的交通状态
//    WORD  m_nLocde;					// 当前Link对应的Lcode		//add by hrb
//    WORD  m_nTopTime;				    // 拓扑本身的旅行时间
//    WORD  m_nLinkTime;				// 路口的旅行时间
//    DWORD m_nLinkLen;				    // link 段长度

    "initialize":function () {

    },


    /**
     * 获取LinkType。
     * @return {Number} Link的类型，取值范围为：0-3
     * @exception NullPointerException 如果Link属性没有被赋值，则会抛出此异常。
     */
    getLinkType:function () {
        if (this.sharedAttribute == null) {
            throw Error("Attribute reference can not be null.");
        }
        return this.sharedAttribute.linkType;
    },


    /**
     * 获取Link所在道路的类型。
     * @return {Number} Link的Form way，取值范围为：0-16。
     * @exception NullPointerException 如果Link属性没有被赋值，则会抛出此异常。
     */
    getLinkForm:function () {
        if (this.sharedAttribute == null) {
            throw Error("Attribute reference can not be null.");
        }
        return this.sharedAttribute.Formway;
    },

    /**
     * 获取RoadClass
     * @return {Number} Road的类型
     * @exception NullPointerException 如果Link属性没有被赋值，则会抛出此异常。
     */
    getRoadClass:function () {
        if (this.sharedAttribute == null) {
            throw Error("Attribute reference can not be null.");
        }
        return this.sharedAttribute.RoadClass;
    },

    /**
     * 获取Link所在道路是否城市道路。
     * @return {Boolean} 如果是汽车双向路则返回true，单向路则返回false。
     * @exception NullPointerException 如果Link属性没有被赋值，则会抛出此异常。
     */
    isCityRoad:function () {
        if (this.sharedAttribute == null) {
            throw Error("Attribute reference can not be null.");
        }
        return this.sharedAttribute.bCityRoad;
    },
    /**
     * 获取Link所在道路是否收费。
     * @return {Boolean} 收费返回true，否则返回false。
     * @exception NullPointerException 如果Link属性没有被赋值，则会抛出此异常。
     */
    isToll:function () {
        if (this.sharedAttribute == null) {
            throw Error("Attribute reference can not be null.");
        }
        return this.sharedAttribute.btoll;
    },


    /**
     * 获取Link所在道路的名称。
     * @return {string} 如果Link所在道路存在名称，则返回该道路的名称；如果不存在名称，则返回null。
     * @exception NullPointerException 如果Link属性没有被赋值，则会抛出此异常。
     */
    getLinkName:function () {
        if (this.sharedAttribute == null) {
            throw Error("Attribute reference can not be null.");
        }
        return this.sharedAttribute.linkName;
    },

    /**
     * 给出点的索引，判定给定点是否位于本link段
     * @return {Boolean}
     */
    isContain:function (nPtId) {
        var Id = nPtId * 2;
        return Id >= this.begOffCoor && Id < this.endOffCoor;
    },

    /**
     * @return {Number}首点在segment中的坐标编号
     */
    getStartPtId:function () {
        return this.begOffCoor / 2;
    },

    /**
     * @return {Number} 尾点在segment中的坐标编号
     */
    getLastPtId:function(){
        return this.endOffCoor / 2 - 1;
    },

    setDistance:function(dist){
        this.distance = dist;
    },

    setDistToExit:function(dist){
        this.distToExit = dist;
    },

    getDistToExit:function(){
        return this.distToExit;
    },

    getDistance:function(){
        return this.distance;
    },

    /***
     * 获取此link上包含的电子眼信息个数
     * @return {Number} 返回该Link上包含的电子眼信息个数,如果没有电子眼信息,返回0
     */
    getCameraCount:function () {
        if (this.cameras == null) {
            return 0;
        }
        return this.cameras.length;
    },

    /**
     * 获取本Link中第idx个Camera对象,idx从0开始。
     * @return  {Boolean} 当本Link中存在摄像头时返回第idx个摄像头对象，不存在摄像头或idx不合法时返回null。
     */
    getCameras:function (idx) {
        if (idx) {
            if (idx < this.getCameraCount()) {
                return this.cameras[idx];
            }
        } else {
            if (this.cameras != null) {
                return this.cameras[0];
            }
        }
        return null;
    },
    /**
     * 获取本Link所在道路中是否存在服务区。
     * @return  {Boolean} 如果存在服务区则返回true，否则返回false。
     */
    isAtService:function () {
        return this.atService;
    },

    /**
     * 获取本Link是否含分叉路。
     * @return  {Boolean} 如果含分叉路则返回true，否则返回false。
     */
    hasMixFork:function () {
        return this.mixFork;
    },

    /**
     * 获取本Link结尾是否有交通灯。
     * @return  {Boolean} 如果有交通灯则返回true，否则返回false。
     */
    hasTrafficLight:function () {
        return this.trafficLight;
    },

    /**
     * 获取Link所在道路的车道数。
     * @return {Number} 车道数目。
     */
    getLaneCount:function () {
        return this.laneCount;
    },

    /**
     * 获取车道信息的背景。
     * @return {Number} 如果不存在则返回-1。
     */
    getBackgroundLane:function () {
        return this.backLane;
    },

    /**
     * 获取车道信息的前景转弯箭头。
     * @return {Number} 如果不存在则返回-1。
     */
    getForegroundLane:function () {
        return this.foreLane;
    },

    /**
     * 获取Link中的路牌信息。目前服务端未提供此信息，只提供导航段级的路牌。
     * @return {String} 如果不存在路牌则返回null；
     */
    getSignpost:function () {
        return this.signpost;
    },

    /**
     * 获取本Link坐标在导航段详细坐标数组的start index。
     * @return {Number} 由于本Link的坐标为本导航段坐标的一部分，因此可以通过此索引直接在导航段的详细坐标数组中获取本Link的坐标。
     */
    getStartCoorIndex:function () {
        return this.begOffCoor;
    },
    /**
     * 获取本Link坐标在导航段详细坐标数组的end index（ 注意：本Link不包含这个结束坐标）。
     * @return {Number} 坐标的结束索引。
     */
    getEndCoorIndex:function () {
        return this.endOffCoor;
    },


    /**
     * 获取本Link的详细坐标点的个数。
     * @return {Number} 因为每个点两个坐标，所以应该为总长一半。
     */
    getDetailedPointsCount:function () {
        var size = this.endOffCoor - this.begOffCoor;
        // assert size >= 0 && (size & 0x1) == 0;
        return size / 2;
    },

    /***
     * 获取该Link是否是进入不同动态交通城市的Link,主要用于跨城市的动态路径,当过了此Link时重新请求路径
     * @return {Boolean} 如果该Link的最后一个点进入了另一个动态交通城市,返回true,否则,返回false
     */
    isIntoDiffCityLink:function () {
        return this.bIntoDiffCity;
    },

    /***
     * 判断该Link的尾部是否位于复杂结点处,该方法主要用于客户端解决长时间没有播报的问题.
     * @return  {Boolean}  如果该Link的尾部位于复杂结点处,则返回true;否则,返回false
     */
    isNeedPlay:function () {
        return this.bNeedPlay;
    }



});


// +----------------------------------------------------------------------
// | MapABC WebRoute API
// +----------------------------------------------------------------------
// | Copyright (c) 2010 http://MapABC.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed AutoNavi MapABC
// +----------------------------------------------------------------------
// | Author: yhostc <yhostc@gmail.com>
// +----------------------------------------------------------------------

/**
 +----------------------------------------------------------
 * 
 +----------------------------------------------------------
 * 
 +----------------------------------------------------------
 */
MRoute.Camera = Class({
	
	type : -1,			
	x : 0,
	y : 0,
	speed : -1,
	
	
	"initialize":function(){
		
	},
	/**
	 * 获取摄像头类型。
	 * @return 摄像头类型。
	 */
	getCameraType:function(){
		return this.type;	
	},
	
	/**
	 * 获取摄像头的整形的坐标。
	 * @return 坐标。
	 */	
	getCoordinate:function(){
		return new MRoute.NvPoint(this.x,this.y);
	},
	
	/**
	 * 获取整形的经度。
	 * @return 整形经度，为浮点经度的NaviPoint.coorFactor倍。
	 */
	getIntX:function(){
		return this.x;
	},
	
	/**
	 * 获取整形的纬度。
	 * @return  整形纬度，为浮点纬度的NaviPoint.coorFactor倍。
	 */
	getIntY:function(){
		return this.y;
	},
	
	/***
	 * 获取该摄像头的限速信息(一般测速摄像头才有限速信息)
	 * @return	该摄像头的限速信息,单位:km/h,如果该摄像头没有限速信息,则返回0
	 */
	getSpeed:function(){
		return this.speed;
	}
	
});

/**
 +----------------------------------------------------------
 * 导航抓路
 +----------------------------------------------------------
 */

//MRoute.GPSInfo = Class({
//    fLongitude:0,       //经度
//    fLatitude:0,        //纬度
//    fElevation:0,       //海拔
//    fSpeed:0,           //速度
//    fDirection:0,       //方位
//    fDop:0,             //位置精度
//    nDate:0,            //日期
//    nTime:0,            //时间
//    bValid: false,      //有效性
//    nDistToRoad:0,      //到路径的距离
//
//    "initialize":function(){
//        this.fLongitude = 0;
//        this.fLatitude = 0;
//        this.fElevation = 0;
//        this.fSpeed = 0;
//        this.fDirection = 0;
//        this.nDate = 0;
//        this.nTime = 0;
//        this.bValid = false;
//        this.nDistToRoad = 0;
//    }
//});

MRoute.GPSContainer = Class({
    gpsList:[],
    lastGPS:null,
    invalidGPS:null,
    nInvalidNum:0,
    nLastTime:0,
    KEEP_LEN:5,
    MINI_SPEED:3, // GPS最小速度  0.8333米/秒  3Km/1h

    "initialize":function () {
    },

    /**
     * 判别gps数据是否有效，有效则保存到列表
     * @param newGps 新GPS信息
     * @return {Boolean} 是否成功加入gps列表
     */
    pushGPSInfo:function (newGps) {

        var bValid = true;
        if (this.gpsList == null || this.gpsList.length == 0) {
            this.lastGPS = newGps;
            this.gpsList.push(newGps);
        }
        else {
            if (this._CheckGPS_(newGps)) {
                this.nInvalidNum = 0;
                this.gpsList.push(newGps);
            }
            else {
                this.nInvalidNum++;
                this.invalidGPS = newGps;
                bValid = false;
            }
        }

        if (bValid) {
            this.nLastTime = Math.round(new Date().getTime() / 1000);
        }

        this._PruneList_();

        return bValid;
    },

    /**
     * 裁减列表，仅维护短列表
     * @private
     */
    _PruneList_:function () {
        if (this.gpsList.length > 90) {
            var newlist = [];
            var lastid = this.gpsList.length - 1;

            // 仅保留尾部元素
            newlist.push(this.gpsList[lastid - 4]);
            newlist.push(this.gpsList[lastid - 3]);
            newlist.push(this.gpsList[lastid - 2]);
            newlist.push(this.gpsList[lastid - 1]);
            newlist.push(this.gpsList[lastid]);

            this.gpsList = newlist;
        }
    },

    /**
     * 返回时间最近的有效GPS坐标
     * @param num 请求的坐标点数目
     * @return [Array] 按经纬度排列的最新GPS坐标，时间最近的在列表尾部
     */
    getRecentPt:function (num) {
        var list = [];

        var curTime = Math.round(new Date().getTime() / 1000);
        if (curTime - this.nLastTime > 60) {
            return list;
        }

        if (num <= 0 || this.gpsList == null) {
            return list;
        }
        num = Math.min(this.gpsList.length, num);

        var id = this.gpsList.length - num;
        for (var i = 0; i < num; i++) {
            list.push(this.gpsList[id].lon);
            list.push(this.gpsList[id].lat);
            id++;
        }

        return list;
    },

    getPtListWithAngle:function(num){
        var list = [];

        var curTime = Math.round(new Date().getTime() / 1000);
        if (curTime - this.nLastTime > 60) {
            return list;
        }

        if (num <= 0 || this.gpsList == null) {
            return list;
        }
        num = Math.min(this.gpsList.length, num);

        var id = this.gpsList.length - num;
        for (var i = 0; i < num; i++) {
            list.push({x:this.gpsList[id].lon, y:this.gpsList[id].lat, a:this.gpsList[id].track});
            id++;
        }

        return list;
    },

    /**
     * 判定数据是否合格
     * @param newGps 新gps数据
     * @return {Boolean}  数据是否合格
     * @private
     */
    _CheckGPS_:function (newGps) {

        //步骤一：如果与前一个无效点坐标一致，则直接过滤
        if (this.invalidGPS != null) {
            if (this.invalidGPS.lon == newGps.lon && this.invalidGPS.lat == newGps.lat) {
                return false;
            }
        }

        if (!this._CheckGPSSpeed_(newGps)) {//步骤二：如果速度小于3km/h，则过滤此点
            this.invalidGPS = newGps;
            return false;
        }

        if (!this._CheckGPSTime_(newGps)) {//步骤三：判断时间因素
            this.invalidGPS = newGps;
            return false;
        }

        this.lastGPS = newGps;
        return true;
    },

    /**
     * 判断速度是否合格
     * @param newGps 新gps数据
     * @return {Boolean} 速度是否满足要求
     * @private
     */
    _CheckGPSSpeed_:function (newGps) {
        return newGps.speed >= this.MINI_SPEED;
    },

    /**
     * 判断时间是否合格
     * @param newGps 新gps数据
     * @return {Boolean} 时间是否满足要求
     * @private
     */
    _CheckGPSTime_:function (newGps) {
        if (this.lastGPS == null) {
            return true;
        }
        var lastgps = this.lastGPS;
        if (lastgps.TimeEqual(newGps)) {//原则一：如果与前一点时间重合，则认为此点无效
            return false;
        }
        var nowLoc = newGps.GetLoc();
        var lastLoc = this.lastGPS.GetLoc();

        //计算两个GPS点的距离间隔，单位米
        var dDistance = MRoute.GeoUtils.CalculateDistance(nowLoc.x, nowLoc.y, lastLoc.x, lastLoc.y);
        if ((1e-5 > dDistance)) {
            return false;
        }

        //原则三：根据在正常行驶过程中(>10km/h),前后两点的时间间隔和距离计算速度，然后再跟GPS信息中的速度进行比较，
        //如果计算速度明显大于GPS速度则有可能是漂移点，过滤此点

        var time1 = Date.UTC(newGps.Year, newGps.Month, newGps.Day,
            newGps.Hour, newGps.Minute, newGps.Second) / 1000;
        var time0 = Date.UTC(lastgps.Year, lastgps.Month, lastgps.Day,
            lastgps.Hour, lastgps.Minute, lastgps.Second) / 1000;
        var nInterval = Number(time1.toFixed(0)) - Number(time0.toFixed(0));

        if (nInterval <= 3 && nInterval != 0)//如果时间间隔超过3秒则此条原则无效
        {

            var dSpeed = dDistance / nInterval * 3600;
            if ((newGps.speed > 10) && (dSpeed > newGps.speed * 2)) {
                //如果gps速度可靠，而计算速度大于gps指示速度的两倍
                //方向在原来稳定的情况下突然发生较大的变动(>30度)，则过滤该点
                if (this._CalcDirTrend_(5)) {
                    var diff = Math.abs(lastgps.track - newGps.track);
                    if (diff > 30 && diff < 330) {
                        return false;
                    }
                }
            }
        }
        return true;
    },

    _CalcDirTrend_:function (num) {
        if (this.gpsList.length < num || num < 3) {
            return false;
        }
        //判断原则：如果前后两点的方向角度之差在15度以内，则认为方向稳定
        var lastid = this.gpsList.length - 1;
        var start = Math.max(lastid - num, 0);
        for (var i = start; i < lastid - 1; i++) {
            var diff = Math.abs(this.gpsList[i].track - this.gpsList[i + 1].track);
            if (diff > 15 && diff < 345) {
                return false;
            }
        }

        return true;
    }

});


MRoute.VP = Class({

    NAVIRANGE_ONROUTE:50, // 在路上的距离范围 如果偏离了预设值则认为偏离,单位米
    OFFROUTE_MAXCOUNTER:5, // 偏离轨道的最大次数，超过本数量为偏离


    m_nOffCount:0, // 距离脱离路径次数阈值

    m_NaviLon:0, // 当前采用的匹配位置
    m_NaviLat:0,
    m_Percent:0,

    m_MatchLon:0, // 当前点匹配到的最近点
    m_MatchLat:0,

    m_CurSegID:0, // 当前导航段序号
    m_CurPtID:0, // 当前形状点序号
    m_CurLinkID:0, // 当前Link序号

    m_bReroute:false, //  是否自动重算路
    m_bProcessing:false, //  是否正在匹配

    segments:[], // 道路信息 NaviSegment[]
    m_pstFrame:null,
    m_carLoc:null, // 当前车位信息，VPLocation
    m_container:null, // gps数据管理及有效性检查工具

    "initialize":function (Frame) {
        this.m_pstFrame = Frame;
        this.m_container = new MRoute.GPSContainer();

        // new出来的自车车位采用无效值
        this.m_carLoc = new MRoute.VPLocation();
        this._resetVP_();
    },


    /**
     * 接收外部传入的GPS数据
     * @param stNmea
     */
    SetNmea:function (stNmea) {
        // 上一数据还没有处理完毕
        if (this.m_bProcessing) {
            return;
        }

        //进入匹配处理
        this.m_bProcessing = true;

        //omit 纠偏
        this._dealWithGPS_(stNmea);

        this.m_bProcessing = false;
    },

    bFirstMatch:false,

    _dealWithGPS_:function (gpsInfo) {
        // gps信息无效则不处理
        if (!gpsInfo.nValid) {
            this.m_pstFrame.OnSetValidGPS(false);
            return false;
        }

        this._setCarLoc_(gpsInfo);

        // 检查GPS有效性，如果无效，获得GPS坐标，也触发一次界面更新
        if (!this.m_container.pushGPSInfo(gpsInfo)) {
            this.m_pstFrame.OnCarLocationChange(false, false);
            return false;
        }

        var bSuc = this._matchProc_(gpsInfo.lon, gpsInfo.lat);
//        if (bSuc) {
//            this.PushProbeInfo(gpsInfo);
//        }

        // 只要gps信息实际有效就通知车位变更
        // 匹配后segid，ptid等会变化
        this.m_carLoc.nValid = 1;
        this.m_carLoc.nSegId = this.m_CurSegID;
        this.m_carLoc.nPtId = this.m_CurPtID;

        // 触发更新事件，匹配成功的点会传给DG
        this.m_pstFrame.OnCarLocationChange(true, bSuc);
        return bSuc;

    },

    PushProbeInfo:function (gpsInfo) {
        var info = new MRoute.ProbeInfo();

        info.BJYear = gpsInfo.Year;
        info.BJMonth = gpsInfo.Month;
        info.BJDay = gpsInfo.Day;
        info.BJHour = gpsInfo.Hour;
        info.BJMinute = gpsInfo.Minute;
        info.BJSecond = gpsInfo.Second;
        info.GpsLon = gpsInfo.lon;
        info.GpsLat = gpsInfo.lat;
        info.Speed = gpsInfo.speed;
        info.Angle = gpsInfo.track;

        var curSeg = this.segments[this.m_CurSegID],
            linkNum = curSeg.getLinkCount();

        info.nReliable = 1;
        info.bIsEndLinkOfSeg = !!((this.m_CurLinkID == linkNum - 1));
        info.ucSegNaviAction = curSeg.getBasicAction();
        info.MatchLat = this.m_NaviLat;
        info.MatchLon = this.m_NaviLon;

        this.m_pstFrame.OnPushProbeInfo(info);
    },

    /**
     * 通过该接口给VP对象设置路径信息
     * @param segments 被选路径的分段列表
     */
    SetRoute:function (segments) {
        // 注意：偏离原路reroute时会置空
        this._resetVP_();
        this.segments = segments;
        this.bFirstMatch = false;
    },


    /**
     * 执行路径匹配
     * @return {Boolean} 是否成功标志
     * @private
     */
    _matchProc_:function (gpsLon, gpsLat) {

        // 若reroute成功前，segments为空，不做匹配
        if (this.segments == null || this.m_CurSegID >= this.segments.length) {
            return false;
        }

        // 通过GPS点向导航线路做垂线,来确定当前位置
        // 更新位置量 m_CurSegID，m_CurPtID，m_NaviLon，m_NaviLat, m_Percent
        // 获得离路径最短距离
        var nMinDistance = this._updateCarLoc_(gpsLon, gpsLat);

        // 在确定了当前导航段内的坐标点序号后，确定当前坐标点序号所在的Link序号
        var curSeg = this.segments[this.m_CurSegID],
            linkId = curSeg.getLinkId(this.m_CurPtID),
            curLink = curSeg.getLink(linkId);

        // 求车在路线上的方向角
        this.m_carLoc.nAngle = this._calCarAngle_(this.segments, this.m_CurSegID, this.m_CurPtID);
        this.m_carLoc.eFormWay = curLink.getLinkForm();
        this.m_carLoc.eRoadClass = curLink.getRoadClass();

        this.m_CurLinkID = linkId; // 保存当前linkId信息

        if (nMinDistance >= this.NAVIRANGE_ONROUTE)    //如果偏离了预设路径
        {
            this.m_carLoc.eState = MRoute.VPStatus.VPStatus_OnLink;

            var linkType = curLink.getLinkType();
            if (linkType == MRoute.LinkType.LinkType_Tunnel)
                return false;

            TestInfoLog("TBT-VP-_matchProc_: deviate" + this.m_nOffCount + ",dist:" + nMinDistance);
            TestInfoLog("gpsLoc:" + gpsLon + "," + gpsLat + "," + "matchLoc:" + this.m_MatchLon + "," + this.m_MatchLat);

            this.m_nOffCount++;
            if (this.m_nOffCount < 5) {
                return false;
            }
            TestInfoLog("TBT-VP-_matchProc_: reroute");

            this.m_bReroute = true;
            this.m_pstFrame.OnReroute();
            return false;
        }
        else {
            this.m_nOffCount = 0;
        }

        if (!this.bFirstMatch) {
            this.bFirstMatch = true;
            TestInfoLog("TBT-VP-_matchProc_first match:" + (new Date()).getTime());
        }

        this.m_carLoc.eState = MRoute.VPStatus.VPStatus_OnRoute;
        // 转为DG使用的Geo坐标
        this.m_carLoc.dLon = this.m_NaviLon;
        this.m_carLoc.dLat = this.m_NaviLat;
        return true;
    },

    /**
     * 计算当前车的角度, 结合下一点求角度
     * @param segments
     * @param segId
     * @param ptId
     * @return {Number}
     * @private
     */
    _calCarAngle_:function (segments, segId, ptId) {

        if (segId >= segments.length) {
            segId = segments.length - 1;
        }

        var curSeg = segments[segId],
            coors = curSeg.getDetailedCoorsLngLat(),
            ptNum = curSeg.getDetailedPointsCount(),
            dLon1, dLat1, dLon2, dLat2, start;

        if (ptId == ptNum - 1) {
            if (segId == segments.length - 1) {
                // 最后一段一个点，和前一点组合求方向
                start = 2 * (ptId - 1);
                dLon1 = coors[start];
                dLat1 = coors[start + 1];
                dLon2 = coors[start + 2];
                dLat2 = coors[start + 3];
            }
            else {
                // 前几段最后一个点，结合下一段首点求方向
                dLon1 = coors[2 * ptId];
                dLat1 = coors[2 * ptId + 1];
                var nextSeg = segments[segId + 1];
                var nextCoors = nextSeg.getDetailedCoorsLngLat();
                dLon2 = nextCoors[0];
                dLat2 = nextCoors[1];
                // 如前后段衔接紧密，再朝后取一个点
                if(GetMapDistInMeter(dLon1, dLat1, dLon2, dLat2) < 3){
                    // 每个导航段至少含有两个点的经纬坐标
                    dLon2 = nextCoors[2];
                    dLat2 = nextCoors[3];
                }

            }
        }
        else {
            // 非本段最后一个点，和下一点配合求角度
            start = 2 * ptId;
            dLon1 = coors[start];
            dLat1 = coors[start + 1];
            dLon2 = coors[start + 2];
            dLat2 = coors[start + 3];
        }

        return CalcGeoAngleInDegree(dLon1, dLat1, dLon2, dLat2);
    },


    /**
     * 更新车位，并获得路径与gps的最短距离
     * @param gpsLon 当前gps经度
     * @param gpsLat 当前gps纬度
     * @return {Number} 路径与gps的最短距离
     * @private
     */
    _updateCarLoc_:function (gpsLon, gpsLat) {

        var arrSeg = this.segments,
            minDistance = 10000;

        if (arrSeg == null || this.m_CurSegID >= arrSeg.length) {
            return minDistance;
        }

        var nOldDistance = 0, //上一次计算的距离
            nLongerCount = 0, //远离的次数
            minSegmentNo = 0,
            minPointNo = 0,
            minDistX = this.m_NaviLon,
            minDistY = this.m_NaviLat,
            newPos = this.m_Percent,
            startSegId = this.m_CurSegID,
            startPtId = this.m_CurPtID;
        //首先判断当前位置和导航路径之间的相互关系
        //先从最简单的情况判断,假设GPS点始终在导航线路附近,并一直是顺着导航道路方向行驶,
        //通过GPS点向导航线路做垂线,来确定当前位置

        if (startPtId == 0 && startSegId > 0) {
            startSegId--;
            startPtId = arrSeg[startSegId].getDetailedPointsCount() - 2;
        }
        else if(startPtId > 0){
            startPtId --;
            //if(startPtId > 0) startPtId--;
        }

        while (true) {
            var seg = arrSeg[startSegId],
                coor = seg.getDetailedCoorsLngLat(),
                length = seg.getDetailedPointsCount(),
                end = length - 1;
            var nextSeg, nextCoor;
            if(startSegId < arrSeg.length-1){
                nextSeg = arrSeg[startSegId+1];
                nextCoor = nextSeg.getDetailedCoorsLngLat();
                end = length;
            }

            for (var i = startPtId; i < end; i++) {

                var j = i * 2,
                    x1, x2, y1, y2;
                if (i < length - 1) {
                    x1 = coor[j];
                    y1 = coor[j + 1];
                    x2 = coor[j + 2];
                    y2 = coor[j + 3];
                }
                else {
                    x1 = coor[j];
                    y1 = coor[j + 1];
                    x2 = nextCoor[0];
                    y2 = nextCoor[1];
                }

                var res = FindNearPt(x1, y1, x2, y2, gpsLon, gpsLat), // 计算点到线的投影点
                    ptBx = res[0],
                    ptBy = res[1],
                    percentPos = res[2];

                // 计算当前点到投影点之间的Map距离
                var nDistance = GetMapDistInMeter(gpsLon, gpsLat, ptBx, ptBy);

                /*****************************************************************************
                 *在比较GPS点与每条几何道路的距离的时候,
                 *如果每一次的距离都比前一次的距离要近,则说明在逐步接近最匹配的位置

                 *如果每一次的距离都比前一次的距离要远,则说明在逐步远离最匹配的位置,
                 *如果连续三条道路都是远离的趋势,则可停止比较
                 *****************************************************************************/

                // 记录下当前最短距离的位置
                if (nDistance <= minDistance) {
                    minPointNo = i;
                    minSegmentNo = startSegId;
                    minDistance = nDistance;
                    minDistX = ptBx;
                    minDistY = ptBy;
                    newPos = percentPos;
                }

                //判断前后两段距离的远近
                if (nOldDistance < nDistance) {
                    nLongerCount++;
                    //如果连续三条道路都是远离的趋势,则可停止比较
                    if (nLongerCount == 3) {
                            break;
                    }
                } else {
                    nLongerCount = 0;
                }

                nOldDistance = nDistance;

            }

            if (nLongerCount >= 3) //如果连续三条道路都是远离的趋势,则可停止比较
            {
                break;
            }

            startSegId++;
            startPtId = 0;
            if (startSegId == arrSeg.length) {
                break;
            }
        }

        this.m_MatchLon = minDistX;
        this.m_MatchLat = minDistY;

        if (this.m_CurSegID > minSegmentNo) {
            // 如果发现倒退不做更新
        } else if (this.m_CurSegID == minSegmentNo
            && (this.m_CurPtID > minPointNo || (this.m_CurPtID == minPointNo && this.m_Percent > newPos))) {
            // 防止两个形状点间的倒退
        } else {
            this.m_CurSegID = minSegmentNo;
            this.m_CurPtID = minPointNo;
            this.m_NaviLon = minDistX;
            this.m_NaviLat = minDistY;
            this.m_Percent = newPos;
        }

        return minDistance;
    },

    /**
     * 重置参数
     * @private
     */
    _resetVP_:function () {
        this.m_nOffCount = 0;
        this.m_bReroute = false;
        this.m_CurSegID = 0;
        this.m_CurPtID = 0;
        this.m_Percent = 0;
        this.m_CurLinkID = 0;
    },

    /**
     * 重置车位信息
     * @param gpsInfo
     * @private
     */
    _setCarLoc_:function (gpsInfo) {

        this.m_carLoc.nAngle = gpsInfo.track;
        this.m_carLoc.nSpeed = Math.round(gpsInfo.speed);
        this.m_carLoc.dLon = gpsInfo.lon;         // 置为GPS位置，不一定在路径上
        this.m_carLoc.dLat = gpsInfo.lat;

        // 置初值
        this.m_carLoc.nValid = 0;
//        this.m_carLoc.nSegId = 0;
//        this.m_carLoc.nPtId = 0;
//        this.m_carLoc.eState = MRoute.VPStatus.VPStatus_Unreliable;
//        this.m_carLoc.eRoadClass = MRoute.RoadClass.RoadClass_Count;
//        this.m_carLoc.eFormWay = MRoute.Formway.Formay_Count;
    },

    GetGpsList:function (num) {
        return this.m_container.getRecentPt(num);
    },

    GetGpsListWithAngle:function(num){
        return this.m_container.getPtListWithAngle(num);
    },

    GetVPLocation:function () {
        return this.m_carLoc.Clone();
    }
});
MRoute.CameraBuffer = Class({
	/// <summary>
	///  电子眼列表
	/// </summary>
	m_astItemList : [],
    CAMERA_BUFFER_SIZE:4,

	/// <summary>
	/// Buffer的开始下标
	/// </summary>
	m_dwStartIndex:0,
	/// <summary>
	///  Buffer中最后一个电子眼的导航段号
	/// </summary>
	m_dwEndSegNo:0,
	/// <summary>
	/// Buffer中最后一个电子眼所在的导航段中的编号
	/// </summary>
	m_dwEndLinkNo:0,
	/// <summary>
	/// 上次播放电子眼导航段剩余距离
	/// </summary>
	m_dwLastPlayRemainDist:Number.MAX_VALUE,
	/// <summary>
	/// 是否路径中最后一个电子眼已在Buffer中
	/// </summary>
	m_bAllInBuffer : false,//整条导航路径上的电子眼已经被查找过
    m_dwTotal:0,//当前buffer里面有效的电子眼数
		
	"initialize":function(){
		for(var i = 0; i< this.CAMERA_BUFFER_SIZE ;i++){
            var camera = new MRoute.CameraItem();
            this.m_astItemList.push(camera);
        }

	},
	Clear:function(){
        this.m_dwTotal = 0;
		this.m_dwStartIndex = 0;
		this.m_dwEndSegNo = 0;
		this.m_dwEndLinkNo = 0;
		this.m_dwLastPlayRemainDist = Number.MAX_VALUE;
		this.m_bAllInBuffer = false;

        for(var i = 0; i < this.CAMERA_BUFFER_SIZE ;i++){
            this.m_astItemList[i].clear();
        }
	}
});

MRoute.CameraItem = Class({
	/// <summary>
	/// 电子眼所在的导航段号
	/// </summary>
	m_dwSegeNo:0,		 
	/// <summary>
	/// 电子眼距离所在导航终点的距离
	/// </summary>
	m_dwDistance:0,		 
	/// <summary>
	/// 电子眼类型
	/// </summary>
	m_eCameraType:0,
	///// <summary>
	///// 电子眼的位置
	///// </summary>
	//m_stLocation:null,
	/// <summary>
	/// 电子眼播放状态
	/// </summary>
	m_ePlayed:0,//0,未播，1，已播
    m_nSpeed:0,
		
	"initialize":function(){
	},

    clear:function(){
        this.m_dwSegeNo = 0;
        this.m_dwDistance = 0;
        this.m_eCameraType = 0;
        this.m_ePlayed = 0;
        this.m_nSpeed = 0;

//        if(this.m_stLocation!= null){
//            this.m_stLocation.x = 0;
//            this.m_stLocation.y = 0;
//        }
    }


});

MRoute.DGNaviInfor = Class({

	eNaviType:0,            // 当前导航类型，1为模拟导航，2为GPS导航
    eTurnIcon:0,            // 转向图标
	curRoadName:"",         // 当前道路名称
	nextRoadName:"",        // 下条道路名称
	nSAPADist:-1,           // 距离最近服务区的距离，, 单位米，若为-1则说明距离无效，没有服务区
	nCameraDist:-1,         // 距离最近电子眼距离，, 单位米，若为-1则说明距离无效，没有电子眼
    nLimitedSpeed:0,        // 当前道路速度限制，单位公里/小时
	nRouteRemainDist:0,     // 路径剩余距离, 单位米
	nRouteRemainTime:0,     // 路径剩余时间，单位分钟
	nSegRemainDist:0,       // 当前导航段剩余距离, 单位米
	nSegRemainTime:0,       // 当前导航段剩余时间，单位分钟
	nCarDirection:0,        // 自车方向，0 - 360度
    fLongitude:0,           // 自车经度位置，浮点型
    fLatitude:0,            // 自车纬度位置，浮点型
	nCurSegIndex:0,         // 当前自车所在导航段编号
    nCurLinkIndex:0,        // 当前自车所在Link编号
    nCurPtIndex:0,          // 当前自车距离最近的形状点位编号
		
	"initialize":function(){
		
	},
	
	Clear:function(){
		this.curRoadName = null;
		this.nextRoadName = null;
        this.fLongitude = 0;
        this.fLatitude = 0;
		this.eNaviType = MRoute.NaviType.NaviType_NULL;
        this.eTurnIcon = MRoute.DirIcon.DirIcon_NULL;
		this.nLimitedSpeed = MRoute.LimitedSpeed.LimitedSpeed_NULL;
		this.nSAPADist = -1;
        this.nCameraDist = -1;
		this.nRouteRemainDist = 0;
		this.nRouteRemainTime = 0;
		this.nSegRemainDist = 0;
		this.nSegRemainTime = 0;
		this.nCarDirection = 0;
        this.nCurSegIndex = 0;
        this.nCurLinkIndex = 0;
        this.nCurPtIndex = 0;
	},

    getInfo:function(){
        var info = new Object();
        info["curRoadName"] = this.curRoadName;
        info["nextRoadName"] = this.nextRoadName;
        info["fLongitude"] = this.fLongitude;
        info["fLatitude"] = this.fLatitude;
        info["eNaviType"] = this.eNaviType;
        info["eTurnIcon"] = this.eTurnIcon;
        info["nLimitedSpeed"] = this.nLimitedSpeed;
        info["nSAPADist"] = this.nSAPADist;
        info["nCameraDist"] = this.nCameraDist;
        info["nRouteRemainDist"] = this.nRouteRemainDist;
        info["nRouteRemainTime"] = this.nRouteRemainTime;
        info["nSegRemainDist"] = this.nSegRemainDist;
        info["nSegRemainTime"] = this.nSegRemainTime;
        info["nCarDirection"] = this.nCarDirection;
        info["nCurSegIndex"] = this.nCurSegIndex;
        info["nCurLinkIndex"] = this.nCurLinkIndex;
        info["nCurPtIndex"] = this.nCurPtIndex;
        return info;
    }
});

MRoute.DGUtil = {

	/// <summary>
	/// 根据 基本动作和辅助动作来获取图片信息
	/// </summary>
	/// <param name="p"></param>
	/// <param name="p_2"></param>
	/// <returns></returns>
	GetNaviIcon:function(eMainAction, eAssiAction){
		var AssistantAction = MRoute.AssistantAction,
		DirIcon = MRoute.DirIcon,
		icon = null;
		switch (eAssiAction){
			case AssistantAction.AssiAction_Entry_Tunnel:
				icon = DirIcon.DirIcon_Tunnel;break;
			case AssistantAction.AssiAction_Arrive_Service_Area:
				icon = DirIcon.DirIcon_SAPA;break;
			case AssistantAction.AssiAction_Arrive_TollGate:
				icon = DirIcon.DirIcon_TollGate;break;
			case AssistantAction.AssiAction_Arrive_Way:
				icon = DirIcon.DirIcon_Way;break;
			case AssistantAction.AssiAction_Arrive_Destination:
				icon = DirIcon.DirIcon_Destination;break;
		}
		if(icon!=null){
			return icon;
		}
		var MainAction = MRoute.MainAction;
		switch(eMainAction){
			case MainAction.MainAction_Turn_Left:
				icon = DirIcon.DirIcon_Turn_Left;break;
			case MainAction.MainAction_Turn_Right:
				icon = DirIcon.DirIcon_Turn_Right;break;
			case MainAction.MainAction_Slight_Left:
			case MainAction.MainAction_Merge_Left:
				icon = DirIcon.DirIcon_Slight_Left;break;
			case MainAction.MainAction_Slight_Right:
			case MainAction.MainAction_Merge_Right:
				icon = DirIcon.DirIcon_Slight_Right;break;
			case MainAction.MainAction_Turn_Hard_Left:
				icon = DirIcon.DirIcon_Turn_Hard_Left;break;
			case MainAction.MainAction_Turn_Hard_Right:
				icon = DirIcon.DirIcon_Turn_Hard_Right;break;
			case MainAction.MainAction_UTurn:
				icon = DirIcon.DirIcon_UTurn;break;
			case MainAction.MainAction_Continue:
				icon = DirIcon.DirIcon_Continue;break;
			case MainAction.MainAction_Entry_Ring:
				icon = DirIcon.DirIcon_Entry_Ring;break;
			case MainAction.MainAction_Leave_Ring:
				icon = DirIcon.DirIcon_Leave_Ring;break;
			default:
				icon = DirIcon.DirIcon_Continue;break;
		}
		return icon;
	},

	GetLimitedSpeed:function(formWay, roadClass){
		var  m_nLimitedSpeed,
		LimitedSpeed = MRoute.LimitedSpeed;
		if (1 == formWay){ // 主路
			switch (roadClass){
				case 0: // 高速道路
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_120;
					break;
				case 1: // 国道
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_110;
					break;
				case 2: // 省道
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_90;
					break;
				case 6: // 城市快速路
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_100;
					break;
				case 7: // 主要道路
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_80;
					break;
				default:
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_NULL;
					break;
			}
		}else{ /// 非主路
			switch (roadClass)
			{
				case 0: // 高速道路
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_80;
					break;
				case 1: // 国道
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_70;
					break;
				case 2: // 省道
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_50;
					break;
				case 6: // 城市快速路
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_60;
					break;
				case 7: // 主要道路
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_50;
					break;
				default:
					m_nLimitedSpeed = LimitedSpeed.LimitedSpeed_NULL;
					break;
			}
		}
		return m_nLimitedSpeed;
	},
	GetIndexVoiceText:function(index){
		var txt = "",OGGSound = MRoute.OGGSound;
		switch (index){
			case OGGSound.OGG_Distance_Kilometre_120:
				txt = "一百二十公里";break;
			case OGGSound.OGG_Distance_Kilometre_110:
				txt = "一百一十公里";break;
			case OGGSound.OGG_Distance_Kilometre_100:
				txt = "一百公里";break;
			case OGGSound.OGG_Distance_Kilometre_90:
				txt = "九十公里";break;
			case OGGSound.OGG_Distance_Kilometre_80:
				txt = "八十公里";break;
			case OGGSound.OGG_Distance_Kilometre_70:
				txt = "七十公里";break;
			case OGGSound.OGG_Distance_Kilometre_60:
				txt = "六十公里";break;
			case OGGSound.OGG_Distance_Kilometre_50:
				txt = "五十公里";break;
			case OGGSound.OGG_Distance_Kilometre_40:
				txt = "四十公里";break;
			case OGGSound.OGG_Distance_Kilometre_30:
				txt = "三十公里";break;
			case OGGSound.OGG_Distance_Kilometre_4:
				txt = "四公里";break;
			case OGGSound.OGG_Distance_Kilometre_3:
				txt = "三公里";break;
			case OGGSound.OGG_Distance_Kilometre_2:
				txt = "两公里";break;
			case OGGSound.OGG_Distance_Kilometre_1:
				txt = "一公里";break;
			case OGGSound.OGG_Distance_Meter_900:
				txt = "九百米";break;
			case OGGSound.OGG_Distance_Meter_800:
				txt = "八百米";break;
			case OGGSound.OGG_Distance_Meter_700:
				txt = "七百米";break;
			case OGGSound.OGG_Distance_Meter_600:
				txt = "六百米";break;
			case OGGSound.OGG_Distance_Meter_500:
				txt = "五百米";break;
			case OGGSound.OGG_Distance_Meter_400:
				txt = "四百米";break;
			case OGGSound.OGG_Distance_Meter_300:
				txt = "三百米";break;
			case OGGSound.OGG_Distance_Meter_200:
				txt = "两百米";break;
			case OGGSound.OGG_Distance_Meter_100:
				txt = "一百米";break;
			case OGGSound.OGG_Along_Kilometre_35:
				txt = "前方有三十五公里以上顺行道路";break;
			case OGGSound.OGG_Along_Kilometre_15:
				txt = "前方有十五公里以上顺行道路";break;
			case OGGSound.OGG_Along_Kilometre_5:
				txt = "前方有五公里以上顺行道路";break;
			case OGGSound.OGG_Along_All:
				txt = "请顺道路行驶，直到有新的导航提示";break;
			case OGGSound.OGG_Pass_SAPA:
				txt = "前方2公里有服务区，请适当休息";break;
			case OGGSound.OGG_MainAction_Turn_Left:
				txt = "左转";break;
			case OGGSound.OGG_MainAction_Turn_Right://201
				txt = "右转";break;
			case OGGSound.OGG_MainAction_Left_Ahead:
				txt = "向左前方行驶";break;
			case OGGSound.OGG_MainAction_Right_Ahead:
				txt = "向右前方行驶";break;
			case OGGSound.OGG_MainAction_Left_Back:
				txt = "向左后方行驶";break;
			case OGGSound.OGG_MainAction_Right_Back:
				txt = "向右后方行驶";break;
			case OGGSound.OGG_MainAction_UTurn:
				txt = "左转掉头";break;
			case OGGSound.OGG_MainAction_Continue:
				txt = "直行";break;
			case OGGSound.OGG_MainAction_Merge_Left:
				txt = "靠左行驶";break;
			case OGGSound.OGG_MainAction_Merge_Right:
				txt = "靠右行驶";break;
			case OGGSound.OGG_MainAction_Pass_Ring:
				txt = "经过环岛";break;
			case OGGSound.OGG_MainAction_Exit_Ring:
				txt = "驶出环岛";break;
			case OGGSound.OGG_MainAction_Slow:
				txt = "注意减速";break;
			case OGGSound.OGG_MainAction_Along_Road:
				txt = "沿当前道路行驶";break;
			case OGGSound.OGG_MainAction_Entry_Ring:
				txt = "进入环岛";break;
			case OGGSound.OGG_MainAction_FP_Exit_Ring:
				txt = "前方请驶出环岛";break;
			case OGGSound.OGG_MainAction_Pass_Ring_Go:
				txt = "经过环岛走";break;
			case OGGSound.OGG_MainAction_Slight_Left:
				txt = "偏左转";break;
			case OGGSound.OGG_MainAction_Slight_Right:
				txt = "偏右转";break;
			case OGGSound.OGG_MainAction_Turn_Hard_Left:
				txt = "左后转";break;
			case OGGSound.OGG_MainAction_Turn_Hard_Right:
				txt = "右后转";break;
			case OGGSound.OGG_AssiAction_Entry_Main:
				txt = "进入主路";break;
			case OGGSound.OGG_AssiAction_Entry_Side_Road:
				txt = "进入辅路";break;
			case OGGSound.OGG_AssiAction_Entry_Freeway:
				txt = "进入高速路";break;
			case OGGSound.OGG_AssiAction_Entry_Slip:
				txt = "进入匝道";break;
			case OGGSound.OGG_AssiAction_Entry_Tunnel:
				txt = "进入隧道";break;
			case OGGSound.OGG_AssiAction_Entry_Center_Branch:
				txt = "进入中间岔路";break;
			case OGGSound.OGG_AssiAction_Entry_Right_Branch:
				txt = "进入右岔路";break;
			case OGGSound.OGG_AssiAction_Entry_Left_Branch:
				txt = "进入左岔路";break;
			case OGGSound.OGG_AssiAction_Entry_Right_Road:
				txt = "进入右转专用道";break;
			case OGGSound.OGG_AssiAction_Entry_Left_Road:
				txt = "进入左转专用道";break;
			case OGGSound.OGG_AssiAction_Entry_Center_Side_Road:
				txt = "进入中间道路";break;
			case OGGSound.OGG_AssiAction_Entry_Right_Side_Road:
				txt = "进入右侧道路";break;
			case OGGSound.OGG_AssiAction_Entry_Left_Side_Road:
				txt = "进入左侧道路";break;
			case OGGSound.OGG_AssiAction_Along_Side:
				txt = "沿辅路行驶";break;
			case OGGSound.OGG_AssiAction_Along_Main:
				txt = "沿主路行驶";break;
			case OGGSound.OGG_AssiAction_Along_Right_Road:
				txt = "沿右转专用道行驶";break;
			case OGGSound.OGG_AssiAction_Arrive_Exit:
				txt = "到达出口";break;
			case OGGSound.OGG_AssiAction_Arrive_Service_Area:
				txt = "到达服务区";break;
			case OGGSound.OGG_AssiAction_Arrive_TollGate:
				txt = "到达收费站";break;
			case OGGSound.OGG_AssiAction_Arrive_Way:
				txt = "到达途经点附近";break;
			case OGGSound.OGG_AssiAction_Arrive_Destination:
				txt = "到达目的地附近";break;
			case OGGSound.OGG_AssiAction_Arrive_Ferry:
				txt = "到达轮渡码头附近";break;
			case OGGSound.OGG_AssiAction_Arrive_Ferry_Stop_Sound:
				txt = "到达轮渡码头附近导航中断";break;
			case OGGSound.OGG_AssiAction_Front_Branck:
				txt = "前方路口";break;
			case OGGSound.OGG_AssiAction_Left_Branch_1:
				txt = "走左数第一岔路";break;
			case OGGSound.OGG_AssiAction_Left_Branch_2:
				txt = "走左数第二岔路";break;
			case OGGSound.OGG_AssiAction_Left_Branch_3:
				txt = "走左数第三岔路";break;
			case OGGSound.OGG_AssiAction_Left_Branch_4:
				txt = "走左数第四岔路";break;
			case OGGSound.OGG_AssiAction_Left_Branch_5:
				txt = "走左数第五岔路";break;
			case OGGSound.OGG_AssiAction_Right_Branch_1:
				txt = "走右数第一岔路";break;
			case OGGSound.OGG_AssiAction_Right_Branch_2:
				txt = "走右数第二岔路";break;
			case OGGSound.OGG_AssiAction_Right_Branch_3:
				txt = "走右数第三岔路";break;
			case OGGSound.OGG_AssiAction_Right_Branch_4:
				txt = "走右数第四岔路";break;
			case OGGSound.OGG_AssiAction_Right_Branch_5:
				txt = "走右数第五岔路";break;
			case OGGSound.OGG_AssiAction_Exit_1:
				txt = "第一出口";break;
			case OGGSound.OGG_AssiAction_Exit_2:
				txt = "第二出口";break;
			case OGGSound.OGG_AssiAction_Exit_3:
				txt = "第三出口";break;
			case OGGSound.OGG_AssiAction_Exit_4:
				txt = "第四出口";break;
			case OGGSound.OGG_AssiAction_Exit_5:
				txt = "第五出口";break;
			case OGGSound.OGG_AssiAction_Exit_6:
				txt = "第六出口";break;
			case OGGSound.OGG_AssiAction_Exit_7:
				txt = "第七出口";break;
			case OGGSound.OGG_AssiAction_G0_Exit_1:
				txt = "走第一出口";break;
			case OGGSound.OGG_AssiAction_G0_Exit_2:
				txt = "走第二出口";break;
			case OGGSound.OGG_AssiAction_G0_Exit_3:
				txt = "走第三出口";break;
			case OGGSound.OGG_AssiAction_G0_Exit_4:
				txt = "走第四出口";break;
			case OGGSound.OGG_AssiAction_G0_Exit_5:
				txt = "走第五出口";break;
			case OGGSound.OGG_AssiAction_G0_Exit_6:
				txt = "走第六出口";break;
			case OGGSound.OGG_AssiAction_G0_Exit_7:
				txt = "走第七出口";break;
			case OGGSound.OGG_AssiAction_Pass_Exit_1:
				txt = "经过第一出口";break;
			case OGGSound.OGG_AssiAction_Pass_Exit_2:
				txt = "经过第二出口";break;
			case OGGSound.OGG_AssiAction_Pass_Exit_3:
				txt = "经过第三出口";break;
			case OGGSound.OGG_AssiAction_Pass_Exit_4:
				txt = "经过第四出口";break;
			case OGGSound.OGG_AssiAction_Pass_Exit_5:
				txt = "经过第五出口";break;
			case OGGSound.OGG_AssiAction_Pass_Exit_6:
				txt = "经过第六出口";break;
			case OGGSound.OGG_AssiAction_Pass_Exit_7:
				txt = "经过第七出口";break;
			case OGGSound.OGG_AssiAction_Road_1:
				txt = "第一路口";break;
			case OGGSound.OGG_AssiAction_Road_2:
				txt = "第二路口";break;
			case OGGSound.OGG_AssiAction_Road_3:
				txt = "第三路口";break;
			case OGGSound.OGG_AssiAction_Road_4:
				txt = "第四路口";break;
			case OGGSound.OGG_AssiAction_Road_5:
				txt = "第五路口";break;
			case OGGSound.OGG_AssiAction_Road_6:
				txt = "第六路口";break;
			case OGGSound.OGG_AssiAction_Road_7:
				txt = "第七路口";break;
			case OGGSound.OGG_AssiAction_Road_8:
				txt = "第八路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_1:
				txt = "经过第一路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_2:
				txt = "经过第二路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_3:
				txt = "经过第三路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_4:
				txt = "经过第四路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_5:
				txt = "经过第五路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_6:
				txt = "经过第六路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_7:
				txt = "经过第七路口";break;
			case OGGSound.OGG_AssiAction_Pass_Road_8:
				txt = "经过第八路口";break;
			case OGGSound.OGG_Then:
				txt = "，随后";break;
			case OGGSound.OGG_Forword:
				txt = "前方";break;
			case OGGSound.OGG_Is:
				txt = "，是";break;
			case OGGSound.OGG_Target:
				txt = "方向";break;
			case OGGSound.OGG_Please_At:
				txt = "请在";break;
			case OGGSound.OGG_Pass:
				txt = "经过";break;
			case OGGSound.OGG_Please:
				txt = "请";break;
			case OGGSound.OGG_Drive_Carefully:
				txt = "，请谨慎驾驶";break;
			case OGGSound.OGG_Have_Continuous_Camera:
				txt = "有连续摄像";break;
			case OGGSound.OGG_Have_Speed_Camera:
				txt = "有测速摄像";break;
			case OGGSound.OGG_Have_Surveillance_Camera:
				txt = "有监控摄像";break;
			case OGGSound.OGG_POIType_Traffic_Accident:
				txt = "发生交通事故";break;
			case OGGSound.OGG_POIType_Serious_Traffic_Accident:
				txt = "发生严重交通事故";break;
			case OGGSound.OGG_POIType_Construct:
				txt = "占路施工";break;
			case OGGSound.OGG_POIType_Traffic_Control:
				txt = "交通管制";break;
			case OGGSound.OGG_POIType_Move_Low:
				txt = "行驶缓慢";break;
			case OGGSound.OGG_POIType_Move_Fast:
				txt = "行驶畅通";break;
			case OGGSound.OGG_POIType_Traffic_JAM:
				txt = "交通拥堵";break;
			case OGGSound.OGG_Navi_End:
				txt = "本次导航结束";break;
			case OGGSound.OGG_Reroute:
				txt = "重新计算路径";break;
			case OGGSound.OGG_Navi_Start:
				txt = "开始导航，";break;
			case OGGSound.OGG_Stop_Navi:
				txt = "结束导航";break;
			case OGGSound.OGG_Dong:
				txt = "咚";break;
			case OGGSound.OGG_GPS_OK:
				txt = "GPS信号正常";break;
			case OGGSound.OGG_Volum:
				txt = "这是当前音量";break;
			case OGGSound.OGG_Max_Volum:
				txt = "这是最大音量";break;
			case OGGSound.OGG_Power_Low:
				txt = "电力不足，请及时充电";break;
			case OGGSound.OGG_Receive_Destination:
				txt = "收到下发目的地";break;
			case OGGSound.OGG_Exceed_Speed_Limt:
				txt = "您已超速";break;
			case OGGSound.OGG_Current_Road_SPeed_Limt:
				txt = "当前道路限速";break;
			case OGGSound.OGG_Off_ROute:
				txt = "你已经偏离了预设路线";break;
			default:
				txt = "";break;
		}
		return txt;
	}
};

MRoute.NDG = Class({
    
    /// 判断导航段长短的阈值，决定了播报的策略（是否近接播报）
    PROXIMITY_DISTANCE:200,
    /// 判定抵达终点的距离门限
    WAY_ARRIVE_DIST:50,

    /// 高速、省道、国道对应的值
    cnActionDistTable:[
        [2000, 1000, 200 ],
        [ 1000, 500, 200 ],
        [ 99999999, 500, 200 ]//普通路的远中近距离播报
    ],
    cnForShowTable:[ 150, 100, 50 ],//实际中固定点播报的提前距离
    cnTwoVoiceDistance:[500, 200, 150],//两个导航声音的距离间隔，cn表示经验值，暂时不用
    cnCameraDistTable:[700, 500, 300],//电子眼显示的距离，根据不同的道路级别
    cnPassMinDistTable:[3000, 2000, 700],//许可过后音播报的导航段的最短剩余距离

    /// DG 触发 给界面的接口
    m_pstFrame:null,
    /// DG 触发 声音接口
    m_pstVoiceManager:null,//暂时没用到

    /// 要DG的道路
    naviPath:null,
    /// 要更新的导航信息
    naviInfor:null,

    // 起始车位，设定路径时给出
    startVPLocation:null,

    // 当前真实的车位，来自VP
    realVPLocation:null,

    // 当前使用的车位
    curVPLocation:null,

    /// 道路段的摄像头信息
    cameraBuffer:null,
    /// 道路段的服务区信息
    sapaBuffer:null,

    m_lastCrossSegId:-1,

    m_playToken:null,

    // 是否显示路口扩大图
    m_bCrossShowed:false,
    // 是否显示车道信息
    m_bLaneShowed:false,

    m_laneLinkId:0,     // 当前导航段下一个待显示车道信息的link段编号
    m_laneDistance:0,   // 对应link到 导航段末端路口的剩余距离

    /// 是否正在重播
    m_bManualPlay:false,
    /// 是否已开始导航
    m_bStartGPS:false,
    m_bStartEmul:false,

    /// 是否暂停导航
    m_bPauseGPS:false,
    m_bPauseEmul:false,

    /// 是否通知播报准备消息
    m_bNotifyPrepareVoice:false,//暂时无用
    /// 是否播报电子眼
    m_bPlayCamera:true,
    /// 播报准备时间
    m_iPrepareVoiceTime:2,//暂时无用
    /// 导航播报类型： 1简单，2详细（默认）
    m_eNaviPlayType:2,
    /// 模拟导航的速度
    m_iEmulatorSpeed:60,
    /// 旧导航号
    m_OldSegID:-1,
    /// 旧形状点号
    m_OldPtID:-1,
    /// 当前道路的FormWay
    m_eCurFormWay:0,//匝道，辅路
    /// 当前道路的道路级别号
    m_iCurGradNo:2,
    /// 当前道路的RoadClass
    m_eCurRoadClass:0,//与FormWay从不同属性角度描述道路
    /// 当前道路的LinkType
    m_eCurLinkType:0,

    // 模拟导航定时触发器
    emulatorTimer:null,

    "initialize":function (pstFrame, pstVoiceManager) {
        this.m_pstFrame = pstFrame;
        this.m_pstVoiceManager = pstVoiceManager;
        this.naviInfor = new MRoute.DGNaviInfor();
        this.cameraBuffer = new MRoute.CameraBuffer();
        this.sapaBuffer = new MRoute.SAPABuffer();
        this.m_playToken = new MRoute.PalyToken();
        this.InitDG();
    },
    
    /// 初始化导航的一些参数
    
    InitDG:function () {
        this.m_OldSegID = -1;
        this.m_OldPtID = -1;
        this.m_nArriveSegId = -1;

        this.m_bTargetPlayed = false;
        this.m_bNotifyPrepareVoice = false;

        this.m_eCurLinkType = 0;
        this.m_eCurFormWay = 0;
        this.m_eCurRoadClass = 0;
        this.m_iCurGradNo = 2;

        this.naviInfor.Clear();
        this.curVPLocation = null;

        this.m_eCurState_Far = 0;
        this.m_eCurState_Mid = 0;
        this.m_eCurState_Near = 0;
        this.m_eCurState_RealTime = 0;
        this.m_eStartSummaryPlayState = 0;
        this.m_eEndSummaryPlayState = 0;
        this.m_eAfterPass = 0;

        this.m_lastCrossSegId = -1;

    },

    
    /// 设置路径源
    /// <param name="naviPath">要导航的路径</param>
    /// <param name="iStartSeg">开始的路段</param>
    /// <param name="iStartPoint">在路段上的形状点</param>
    /// <param name="stStartLoc"></param>
    SetNaviRoute:function (naviPath, bStartHead, vpLocation) {
        this.naviPath = naviPath;

        this.realVPLocation = null;
        if(bStartHead){
            this.startVPLocation = this._getHeadLocation_();
        }
        else {
            this.startVPLocation = vpLocation.Clone();
        }

        this._initForRouteSuccess_(bStartHead);
    },

    _initForStartNavi_:function (bStartHead, vpLocation) {
        this.InitDG();

        this.cameraBuffer.Clear();
        this.sapaBuffer.Clear();

        var curSeg, iStartPoint;
        if (bStartHead) {
            iStartPoint = 0;
            curSeg = this.GetNaviSegment(0);
        }
        else {
            iStartPoint = vpLocation.nPtId;
            curSeg = this.GetNaviSegment(vpLocation.nSegId);
        }

        //初始化FormWay与RoadClass
        var linkId = curSeg.getLinkId(iStartPoint),
            curLink = curSeg.getLink(linkId);
        if (curLink != null) {
            this.m_eCurFormWay = curLink.getLinkForm();
            this.m_eCurLinkType = curLink.getLinkType();
        }

        this.m_eCurRoadClass = curSeg.calcRoadClass(linkId);
        this.m_iCurGradNo = this.FORMAT_GRADE(this.m_eCurRoadClass);

        if (!this._setStateToStartRoute_(bStartHead, vpLocation)) {//_setStateToStartRoute_始终返回true
            return false;
        }
    },

    _getHeadLocation_:function(){
        var vpLocation = new MRoute.VPLocation();
        var curseg = this.GetNaviSegment(0);
        if (curseg == null) {
            return false;
        }
        var clist = curseg.getDetailedCoorsLngLat();
        vpLocation.dLon = clist[0];
        vpLocation.dLat = clist[1];
        vpLocation.nSegId = 0;
        vpLocation.nPtId = 0;

        return vpLocation;
    },

    _setStateToStartRoute_:function (bStartHead, vpLocation) {

        this._hideInfo_();

        if (bStartHead) {
            this.curVPLocation = this._getHeadLocation_();
        }
        else {
            this.curVPLocation = vpLocation.Clone();
        }

        this._updateRemainDistAndTime_(this.curVPLocation.dLon, this.curVPLocation.dLat);

        //载入服务区信息
        this.loadSAPA();
        this.loadCamera();
        this._updateNaviInfo_(this.curVPLocation.dLon, this.curVPLocation.dLat);

        return true;
    },


    // need supply
    _initForRouteSuccess_:function (bStartHead) {
        var segs = this.naviPath.getSegments();
        if (segs == null || segs.length <= 0) {
            return false;
        }

        this.curVPLocation = this.startVPLocation;

        // omit 整理途径列表 途径点列表改由this.tbt维护

        // 初始导航需要发opening的提示，但自动ReRoute或切换道路后不提示opening
        if (this.m_pstFrame.GetRouteType() != MRoute.CalcRouteType.CalcRouteType_Reroute && bStartHead) {
            this.m_eStartSummaryPlayState = 0;
            if (this.getCurrentCarSpeed() <= 5)
            {
                this.playRouteReady();
            }
        }

        this.m_eCurState_Far = 0;//0 未播报
        this.m_eCurState_Mid = 0;
        this.m_eCurState_Near = 0;
        this.m_eCurState_RealTime = 0;
        this.m_eEndSummaryPlayState = 0;

        // 如有可播报信息则播报
        this.flushNaviSound();

        return true;
    },


    _updateDist_:function () {

        // 更新下一电子眼剩余距离
        var dist = -1;
        if (this.cameraBuffer.m_dwTotal > 0) {
            var id = this.cameraBuffer.m_dwStartIndex;
            dist = this.naviInfor.nRouteRemainDist - this.cameraBuffer.m_astItemList[id].m_dwDistance;
        }
        this.naviInfor.nCameraDist = dist;//下一电子眼剩余距离

        // 更新下一服务区剩余距离
        dist = -1;
        if (this.sapaBuffer.m_dwTotal > 0) {
            var curID = this.sapaBuffer.m_dwStartIndex;
            dist = this.naviInfor.nRouteRemainDist - this.sapaBuffer.m_astItemList[curID].m_dwDistance;
        }
        this.naviInfor.nSAPADist = dist;
    },


    
    /// 当VP变更时TBT调用该方法, 接口函数
    /// <param name="stLocation"></param>
    CarLocationChange:function (stLocation) {
        if (stLocation == null) {
            return;
        }

        // 记录位置
        this.realVPLocation = stLocation.Clone();

        // 暂停导航时，不做更新
        if (this.m_bPauseGPS) {
            return;
        }

        // 更新导航信息
        if (this.m_bStartGPS) {
            this.curVPLocation = this.realVPLocation;
            this.NaviProc(this.curVPLocation);
        }
    },

    _updateCarLoc_:function(stLocation){
        this._updateRemainDistAndTime_(stLocation.dLon, stLocation.dLat);

         // 更新naviinfo
        this._updateNaviInfo_(stLocation.dLon, stLocation.dLat);
    },

    NaviProc:function (stLocation) {

        //if (MRoute.VPStatus.VPStatus_OnRoute == stLocation.eState)
        {//在路上

            this._updateRemainDistAndTime_(stLocation.dLon, stLocation.dLat);
            // 通知自车位置发生变化
            this._notifyLocChange_(stLocation.nSegId, stLocation.nPtId);

            // 更新naviinfo
            this._updateNaviInfo_(stLocation.dLon, stLocation.dLat);

            if (0 == this.m_eStartSummaryPlayState)//未播报
            {
                if (this.m_pstVoiceManager.GetRemainTime() > 0){// 未播报完成
                    return true;
                }
                this.playStartSummary();
                this.m_eStartSummaryPlayState = 1;
            }


            //更新导航 //调用声音播放信息
            this.updateNavigation();

            // GPS导航时途经点抵达判定
            if (this.IsGPSNaving()) {
                this.judgeArrive();
            }

            // 设定重播，也是等待下一次位置更新后播报，是否有可能连播两次？
            // 等待车位更新后才能播报，会导致在没有有效gps的地方无法重播
            if (this.m_bManualPlay) {
                if (!this.m_bPlayed) {
                    this.playCurrent();
                    this.flushNaviSound();
                }
                this.m_bManualPlay = false;
            }
        }
    },

    /**
     * 设置模拟导航速度
     */
    setEmulatorSpeed:function (iEmulatorSpeed) {
        this.m_iEmulatorSpeed = iEmulatorSpeed;
    },

    /**
     * 是否播报电子眼
     */
    setEleyePrompt:function (bval) {
        this.m_bPlayCamera = bval;
    },

    setPrepareVoiceTime:function (val) {
        this.m_iPrepareVoiceTime = val;
    },

    setNaviPlayType:function (val) {
        this.m_eNaviPlayType = val;
    },

    /**
     * 通知调用者TBT抵达途径点
     */
    m_nArriveSegId:-1,
    m_bArriveNotifyed:false,
    judgeArrive:function () {
        var curSegId = this.naviInfor.nCurSegIndex;
        var curSeg = this.GetNaviSegment(curSegId);
        if (curSeg == null) {
            return;
        }

        // 已经路过而没有通知，补发通知
        if (this.m_nArriveSegId >= 0 && this.m_nArriveSegId < curSegId
            && !this.m_bArriveNotifyed) {
            this.m_pstFrame.ArriveWay(this.m_nArriveSegId);
            this.m_bArriveNotifyed = true;
        }

        // 当前到达途径点分段
        var action = curSeg.getAssistAction();
        if (action == MRoute.AssistantAction.AssiAction_Arrive_Way) {
            // 记录途径段编号，置为未通知状态
            if (this.m_nArriveSegId < curSegId) {
                this.m_nArriveSegId = curSegId;
                this.m_bArriveNotifyed = false;
            }

            // 剩余距离不多，发送通知，置为已通知状态
            // 虽然距离不靠谱，但太晚播报也不好，万一在途径点附近reroute...
            // 播报途径点挺准的，但未单列，否则播报加通知就ok了
            if (this.naviInfor.nSegRemainDist < this.WAY_ARRIVE_DIST && !this.m_bArriveNotifyed) {
                this.m_pstFrame.ArriveWay(curSegId);
                this.m_bArriveNotifyed = true;
            }
        }
    },

    _getRoadName_:function (stLocation) {
        //-----当前路段名称
        var curSegId = stLocation.nSegId,
            curSeg = this.GetNaviSegment(curSegId),
            linkId = curSeg.getLinkId(stLocation.nPtId),
            naviLink = curSeg.getLink(linkId),
            segments = this.naviPath.getSegments(),
            curName = naviLink.getLinkName(),
            nextName = "";

        if (curName == null || curName.length == 0 || curName == 0) {
            curName = "无名道路";
        }

        //----下一路段的名称
        if (curSegId == segments.length - 1 &&
            linkId >= curSeg.getLinkCount() - 2) { //最后一段
            nextName = "目的地";
        }
        else {
            // 显示较远部位的有名道路是否合理呢？
            // 查找本导航段的下一link路名
            nextName = curSeg.getNextRoadName(linkId);

            // 遍历之后的导航段确定名称
            if (nextName == null || nextName.length == 0) {
                for (var i = curSegId + 1; i < segments.length; i++) {
                    var seg = this.GetNaviSegment(i);
                    nextName = seg.getRoadName();
                    if (nextName != null && nextName.length > 0) {
                        break;
                    }
                }
            }

            // 仍未能获取有效名称
            if (nextName == null || nextName.length == 0  || nextName == 0) {
                nextName = "无名道路";
            }
        }

        this.naviInfor.curRoadName = curName;
        this.naviInfor.nextRoadName = nextName;

    },

    getRoadName:function (nSegId, nLinkId) {
        var curSeg = this.GetNaviSegment(nSegId);
        if (curSeg != null) {
            var curLink = curSeg.getLink(nLinkId);
            if (curLink != null) {
                return curLink.getLinkName();
            }
        }
        return null;
    },



    _notifyLocChange_:function (nSegId, nPtId) {

        if (-1 == this.m_OldSegID || nSegId > this.m_OldSegID) {
            this.segmentChange(nSegId, nPtId);
        }
        else if (nSegId == this.m_OldSegID) {
            if (nPtId != this.m_OldPtID) {
                this.shapePointChange(nPtId);
            }
        }

        // 分段，点位发生改变，需更新电子眼信息
        this.loadCamera();

        // 普通导航段数路口时机 1.未数过路口数 2. 范围小于等于中距离播报范围 3.中距离已经播报过
        if(this.m_nStartCountNum < 0
            && this.IsShortThanMiddle() && this.m_eCurState_Mid == 1)
        {
            this.countForkNum();
        }

        var curSeg = this.GetNaviSegment(nSegId);

        // 接近具有车道信息的link尾部时，显示车道信息
        // 注意该link比较短时，未抵达该link也开始显示
        if(!this.m_bLaneShowed && this.naviInfor.nSegRemainDist - this.m_laneDistance  <= 200 ){
            var laneLink = curSeg.getLink(this.m_laneLinkId);
            this.m_pstFrame.ShowLaneInfo(laneLink.getBackgroundLane(), laneLink.getForegroundLane());
            this.m_bLaneShowed = true;
        }

        var MinDist = 2000;
        if (this.naviInfor.nSegRemainDist < MinDist){
            var arrBack = [],
                arrFore = [],
                arrSegId = [],
                backInfo;
            if(this.m_lastCrossSegId < nSegId){
                backInfo = curSeg.getBackgroundImage();
                if(backInfo >= 0)
                {
                    arrBack.push(backInfo);
                    arrFore.push(curSeg.getForegroundImage());
                    arrSegId.push(nSegId);
                }

                this.m_lastCrossSegId = nSegId;
            }

            var dist = this.naviInfor.nSegRemainDist,
                id = nSegId+1,
                count = this.naviPath.getSegmentCount(),
                seg;
            while(id <= this.m_lastCrossSegId ){
                seg = this.GetNaviSegment(id);
                dist += seg.getDistance();
                id++;
            }

            while(id < count && dist < MinDist){
                seg = this.GetNaviSegment(id);
                var segDist = seg.getDistance();
                if(dist + segDist >= MinDist)
                {
                    break;
                }
                backInfo = seg.getBackgroundImage();
                if(backInfo >= 0)
                {
                    arrBack.push(backInfo);
                    arrFore.push(seg.getForegroundImage());
                    arrSegId.push(id);
                }

                this.m_lastCrossSegId = id;
                dist += segDist;
                id++;
            }

            if(arrBack.length > 0){
                this.m_pstFrame.CrossRequest(arrBack, arrFore, arrSegId);
            }
        }


        if(this.naviInfor.nSegRemainDist < 300 && !this.m_bCrossShowed){
            var backId = curSeg.getBackgroundImage(),
                foreId = curSeg.getForegroundImage();
            if(backId >= 0 && foreId >= 0){
                this.m_pstFrame.ShowCross(backId, foreId, this.naviInfor.nSegRemainDist);
                this.m_bCrossShowed = true;
            }
        }

    },



    IsShortThanMiddle:function(){
        var roadGrade = this.m_iCurGradNo;
        return this.naviInfor.nSegRemainDist
            <= (this.cnActionDistTable[roadGrade][1] + this.cnForShowTable[roadGrade]);
    },


    /**
     * 决定本段统一的信息播报标志位
     * @param eMainAction
     * @param eAssiAction
     * @private
     */
    _updatePlayToken_:function(eMainAction, eAssiAction){

        var stToken = this.m_playToken;
        stToken.m_bProximityToken = true;
        stToken.m_bTargetInfoToken = true;

        var curSegID = this.naviInfor.nCurSegIndex;
        if (curSegID >= this.naviPath.getSegmentCount() - 1) {
            stToken.m_bTargetInfoToken = false;
            stToken.m_bProximityToken = false;
            return;
        }

        if (eAssiAction == MRoute.AssistantAction.AssiAction_Arrive_Way
            || eAssiAction == MRoute.AssistantAction.AssiAction_Arrive_TollGate // 收费站
            ) {
            stToken.m_bTargetInfoToken = false;
            stToken.m_bProximityToken = false;
        }

        if (eAssiAction == MRoute.AssistantAction.AssiAction_Entry_Ferry
            || eAssiAction == MRoute.AssistantAction.AssiAction_Entry_Tunnel
            ) {
            stToken.m_bProximityToken = false;
        }

        if (eMainAction == MRoute.MainAction.MainAction_Entry_Ring) {
            stToken.m_bProximityToken = false;	// 进入环岛不播报近接提示
        }
    },



    _parseInfo_:function(info){
        var arrData = [], curLane;
        for(var i = 0; i < 8; i++){
            curLane = (info>>(4*i)) & 0xf;
            if( 15 == curLane ){
                break;
            }
            else if( 13 == curLane )
            {
                curLane = 0;
            }
            else if( 14 == curLane )
            {
                curLane = 11;
            }
            arrData[i] = curLane;
        }
        return arrData;
    },

    _isValidInfo_:function(backInfo, selectInfo){
        if( 0xffffffff == backInfo  || 0 >= backInfo || 0 >= selectInfo)
        {
            return false;
        }

        var arrBackInfo = this._parseInfo_(backInfo),
            arrSelInfo  = this._parseInfo_(selectInfo);
        if(arrBackInfo.length == 0 || arrSelInfo.length == 0){
            return false;
        }

        var firstSel = arrSelInfo[0];

        if(firstSel == 2 || firstSel == 4 || firstSel == 6 || firstSel == 7
            || firstSel == 9 || firstSel == 10 || firstSel == 11 || firstSel == 12 ){
            return false;  // 禁止原始选中状态为复杂车线
        }

        for(var k = 0; k < arrSelInfo.length; k++){
            if(firstSel != arrSelInfo[k]){
                return false; // 选择不同，出错返回
            }
        }

        return true;

    },

    /**
     * 更新车道信息，记录下一个要显示车道信息的link编号及其终点到导航段终点的距离
     * 将过滤无效车道信息的工作提前到DG中完成
     * @private
     */
    _updateLaneInfo_:function(){
        var curSeg = this.GetNaviSegment(this.curVPLocation.nSegId),
            linkCount = curSeg.getLinkCount(),
            startId = curSeg.getLinkId(this.curVPLocation.nPtId),
            tmpLink, back, select,
            bFind = false;
        for(var i = startId; i < linkCount; i++){
            tmpLink = curSeg.getLink(i);
            back = tmpLink.getBackgroundLane();
            select = tmpLink.getForegroundLane();
            if(this._isValidInfo_(back, select)) {
                this.m_laneLinkId = i;
                this.m_laneDistance = tmpLink.getDistToExit();
                bFind = true;
                break;
            }
        }

        if (!bFind){
            this.m_laneLinkId = linkCount - 1;
            this.m_laneDistance = -300;
        }
    },


    /// 导航段发生改变
    segmentChange:function (newSegId, newPtId) {

        this._hideInfo_();

        if (newSegId != 0) {
            this.m_eCurState_Far = 0;
            this.m_eCurState_Mid = 0;
            this.m_eCurState_Near = 0;
            this.m_eCurState_RealTime = 0;
            this.m_eAfterPass = 0;
        }

        this.m_laneLinkId = 0;
        this.m_laneDistance = 0;
        this._updateLaneInfo_();

        this.m_nStartCountNum = -1;
        this.m_nLastCountNum = -1;

        this.m_bTargetPlayed = false;
        this.m_OldSegID = newSegId;

        this.shapePointChange(newPtId); //触发形状点变化事件
        var curSeg = this.GetNaviSegment(newSegId),
            mainAction = curSeg.getBasicAction(),
            assistAction = curSeg.getAssistAction();

        if(mainAction == MRoute.MainAction.MainAction_Leave_Ring
            || this.m_eCurFormWay == MRoute.Formway.Formway_Round_Circle)
        {
            this.countForkNum();
        }

        // 更新本导航段是否播报某信息的统一标记
        this._updatePlayToken_(mainAction, assistAction);
        this.m_iCurGradNo = this._getRoadGrade_();


        if (2 == this.m_iCurGradNo) {
            this.m_eCurState_Far = 1;
        }
    },

    _getRoadGrade_:function(){

        var curSeg = this.GetNaviSegment(this.curVPLocation.nSegId),
            linkNum = curSeg.getLinkCount(),
            arrSum = [0,0,0],
            domainGrad = 2,
            tmpLink,eRoadClass, tmpGrade;
        for(var i = 0; i < linkNum; i++){
            tmpLink = curSeg.getLink(i);
            eRoadClass = tmpLink.getRoadClass();
            tmpGrade = this.FORMAT_GRADE(eRoadClass);
            arrSum[tmpGrade] += tmpLink.getDetailedPointsCount();
        }
        if(arrSum[1] > arrSum[domainGrad]) {
            domainGrad = 1;
        }
        if(arrSum[0] > arrSum[domainGrad]){
            domainGrad = 0;
        }

        return domainGrad;
    },

    
    ///  形状点发生改变
    shapePointChange:function (newPtId) {

        // m_eCurFormWay , m_eCurLinkType, m_eCurRoadClass, m_iCurGradNo计算
        var segID = this.curVPLocation.nSegId,
            curSeg = this.GetNaviSegment(segID),
            linkId = curSeg.getLinkId(newPtId),
            curLink = curSeg.getLink(linkId);
        this.m_eCurLinkType = curLink.getLinkType();

        if (this.m_bStartEmul) {
            this.m_eCurFormWay = curLink.getLinkForm();
            this.m_eCurRoadClass = curSeg.calcRoadClass(linkId);
        }
        else {
            this.m_eCurFormWay = this.curVPLocation.eFormWay;
            this.m_eCurRoadClass = this.curVPLocation.eRoadClass;
        }

        // 缺 sapabuff 更新信息
        this.collectSAPABuffer();
        if (!this.sapaBuffer.m_bCollectEnd && this.sapaBuffer.m_dwTotal == 0) {
            this.loadSAPA();
        }

        this.m_OldPtID = newPtId;

        if (linkId > this.m_laneLinkId) {
            if(this.m_bLaneShowed){
                this.m_pstFrame.HideLaneInfo();
                this.m_bLaneShowed = false;
            }
            this._updateLaneInfo_();
        }
    },

    FORMAT_GRADE:function (eRoadClass) {
        if (MRoute.RoadClass.RoadClass_Freeway == eRoadClass) {
            return 0;
        } else if (MRoute.RoadClass.RoadClass_City_Speed_way == eRoadClass) {
            return 1;
        } else {
            return 2;
        }
    },

    /**
     * 计算当前车的角度, 结合下一点求角度
     * @param segments
     * @param segId
     * @param ptId
     * @return {Number}
     * @private
     */
    _calCarAngle_:function (segments, segId, ptId) {

        if (segId >= segments.length) {
            segId = segments.length - 1;
        }

        var curSeg = segments[segId],
            coors = curSeg.getDetailedCoorsLngLat(),
            ptNum = curSeg.getDetailedPointsCount(),
            dLon1, dLat1, dLon2, dLat2, start;

        if (ptId == ptNum - 1) {
            if (segId == segments.length - 1) {
                // 最后一段一个点，和前一点组合求方向
                start = 2 * (ptId - 1);
                dLon1 = coors[start];
                dLat1 = coors[start + 1];
                dLon2 = coors[start + 2];
                dLat2 = coors[start + 3];
            }
            else {
                // 前几段最后一个点，结合下一段首点求方向
                dLon1 = coors[2 * ptId];
                dLat1 = coors[2 * ptId + 1];
                var nextSeg = segments[segId + 1];
                var nextCoors = nextSeg.getDetailedCoorsLngLat();
                dLon2 = nextCoors[0];
                dLat2 = nextCoors[1];
                // 如前后段衔接紧密，再朝后取一个点
                if(GetMapDistInMeter(dLon1, dLat1, dLon2, dLat2) < 3){
                    // 每个导航段至少含有两个点的经纬坐标
                    dLon2 = nextCoors[2];
                    dLat2 = nextCoors[3];
                }

            }
        }
        else {
            // 非本段最后一个点，和下一点配合求角度
            start = 2 * ptId;
            dLon1 = coors[start];
            dLat1 = coors[start + 1];
            dLon2 = coors[start + 2];
            dLat2 = coors[start + 3];
        }

        return CalcGeoAngleInDegree(dLon1, dLat1, dLon2, dLat2);
    },


    /// 获取指定的导航段
    /// <param name="nIndex"></param>
    /// <returns></returns>
    GetNaviSegment:function (nIndex) {
        return this.naviPath.getSegmentByID(nIndex);
    },


    PauseNavi:function (bSim) {
        // 当模拟导航处于开启状态， 只能暂停模拟导航
        if(this.m_bStartEmul)
        {
            if (bSim){
                this.m_bPauseEmul = true;
            }
        }
        else if(this.m_bStartGPS)
        {
            if(!bSim){
                this.m_bPauseGPS = true;
            }
        }
    },

    ResumeNavi:function (bSim) {
        if (this.m_bStartEmul)
        {
            if(bSim){
                this.m_bPauseEmul = false;
            }
        }
        else if(this.m_bStartGPS)
        {
            if(!bSim){
                this.m_bPauseGPS = false;
            }
        }
    },

    
    /// 开始模拟导航
    /// <returns></returns>
    StartNavi:function (IsGps) {
        // 启动之前必须设定好导航路径
        if (this.naviPath == null) {
            return false;
        }

        if (IsGps) {
            if(this.m_bStartGPS && !this.m_bPauseGPS){
                return true; //正在进行相应导航，则直接返回
            }

            this.m_bStartGPS = true;
            this.m_bPauseGPS = false;
            if (this.m_bStartEmul) {
                this.m_pstFrame.EndEmulatorNavi();
            }

        }
        else {

            if(this.m_bStartEmul && !this.m_bPauseEmul){
                return true; //正在进行相应导航，则直接返回
            }

            this.m_bStartEmul = true;
            this.m_bPauseEmul = false;
            if (this.m_bStartGPS) {
                this.m_bPauseGPS = true;
            }
        }

        var vpLocation = this.startVPLocation;
        if(this.realVPLocation != null){
            vpLocation = this.realVPLocation;
        }
        var bFromHead = true;
        if(vpLocation.nSegId != 0 || vpLocation.nPtId != 0){
            bFromHead = false;
        }
        this._initForStartNavi_(bFromHead, vpLocation);

        this.naviInfor.eNaviType = IsGps ?
            MRoute.NaviType.NaviType_GPS : MRoute.NaviType.NaviType_Emul;

        if (IsGps) {
            // 等待VP模块触发位置更新
        }
        else {
            if (this.emulatorTimer == null) {
                var self = this;
                this.emulatorTimer = window.setInterval(function () {
                    self.Timer_Tick();
                }, 500);
            }
        }
        return true;
    },


    Timer_Tick:function () {
        if (!this.m_bPauseEmul) {
            if (!this.EmulatorProc()) {
                // 通知frame，自发请求终止导航
                this.m_pstFrame.EndEmulatorNavi();
            }
        }
    },

    
    /// 停止模拟导航
    /// <returns></returns>
    StopEmulatorNavi:function () {

        if (!this.m_bStartEmul) { //如模拟导航未开始，退出
            return false;
        }

        this.m_bStartEmul = false;
        this.m_bPauseEmul = false;

        if (this.emulatorTimer) {
            window.clearInterval(this.emulatorTimer);
            this.emulatorTimer = null;
        }
        // 设为未播报状态
        this.InitDG();

        if(this.m_bStartGPS){ // 重新启动GPS导航
            this.m_bPauseGPS = false;

            if(this.realVPLocation != null){
                // 用匹配后的gps更新一次车位
                this.curVPLocation = this.realVPLocation;
                this._updateCarLoc_(this.curVPLocation);
            }
            else if(this.startVPLocation != null){
                this.curVPLocation = this.startVPLocation;
                this._updateCarLoc_(this.curVPLocation);
            }
        }

        this._hideInfo_();

        return true;
    },

    /// 停止GPS导航
    StopGPSNavi:function () {
        if (!this.m_bStartGPS) {
            return false;
        }

        if(this.m_bStartEmul){ // 如有模拟导航，请求终止模拟导航
            this.m_pstFrame.EndEmulatorNavi();
        }

        this.m_bStartGPS = false;
        this.m_bPauseGPS = false;
        this.realVPLocation = null;
        this._hideInfo_();
        // 设为未播报状态
        this.InitDG();
        return true;
    },

    _hideInfo_:function(){
        if(this.m_bCrossShowed){
            this.m_pstFrame.HideCross();
            this.m_bCrossShowed = false;
        }
        if(this.m_bLaneShowed){
            this.m_pstFrame.HideLaneInfo();
            this.m_bLaneShowed = false;
        }
    },

    INTERCEPT:function (ptStart, ptEnd, totalLen, cutLen) {
        if (cutLen < 0.00001) {
            return ptStart;
        }
        if (0 == totalLen || cutLen >= totalLen) {
            return ptEnd;
        }
        var dX = ptEnd.x - ptStart.x;
        var dY = ptEnd.y - ptStart.y;
        var longitude = Number(ptStart.x) + Number(dX * (cutLen / totalLen));
        var latitude = Number(ptStart.y) + Number(dY * (cutLen / totalLen));

        return new MRoute.NvPoint(longitude, latitude);
    },


    EmulatorProc:function () {

        //lock (vpCurrrentVPLocation){
        //如果不是模拟导航退出
        if (!this.m_bStartEmul ) {
            return false;
        }

        if (this.curVPLocation == null) {
            if(this.realVPLocation != null){
                this.curVPLocation = this.realVPLocation.Clone();
            }
            else{
                this.curVPLocation = this.startVPLocation.Clone();
            }
        }

        // 未播报模拟导航开始，则播报
        if (this.m_eStartSummaryPlayState == 0) {
            this.playStartSummary();
            this.m_eStartSummaryPlayState = 1;
        }


        var segCount = this.naviPath.getSegmentCount();
        var dwStepLength = Math.ceil(this.m_iEmulatorSpeed / 3.6),  //模拟导航步长
            newSegId = this.curVPLocation.nSegId,
            newPtId = this.curVPLocation.nPtId,
            curSeg  = this.GetNaviSegment(newSegId),
            ptList  = curSeg.getDetailedCoorsLngLat(),
            ptCount = curSeg.getDetailedPointsCount(),
            lastId  = ptCount - 1;

        // 符合模拟导航结束条件，则请求终止
        if (this.naviInfor.nRouteRemainDist <= 10
            || (this.curVPLocation.nSegId >= segCount - 1 && newPtId == lastId)) {
            this.m_pstFrame.EndEmulatorNavi();
            return true;
        }

        //计算当前自车位置到下一个形状点的距离

        var stStart, stEnd, newNvPt, nDistance, nextSeg;
        stStart = new MRoute.NvPoint(this.curVPLocation.dLon, this.curVPLocation.dLat);

        if (newPtId == lastId) {
            // 其实前面逻辑已保证非最后一个导航段
            if(newSegId < segCount -1){
                nextSeg = this.GetNaviSegment(newSegId + 1);
                stEnd = nextSeg.getDetailedPoint(0);
                nDistance = MRoute.GeoUtils.CalculateDistance(stStart.x, stStart.y, stEnd.x, stEnd.y);
                if (nDistance > dwStepLength) { //自车到下一形状点的距离比还需截取长度长，截取
                    newNvPt = this.INTERCEPT(stStart, stEnd, nDistance, dwStepLength);
                }
                else {   // 直接移到下一段起点
                    newPtId = 0;
                    newSegId += 1;
                    newNvPt = stEnd;
                }
            }
        }
        else {
            stEnd = new MRoute.NvPoint(ptList[2*(newPtId + 1)], ptList[2*(newPtId + 1) + 1]);
            nDistance = MRoute.GeoUtils.CalculateDistance(stStart.x, stStart.y, stEnd.x, stEnd.y);
            if (nDistance > dwStepLength) { //自车到下一形状点的距离比还需截取长度长，截取
                newNvPt = this.INTERCEPT(stStart, stEnd, nDistance, dwStepLength);
            }
            else {
                //自车到下一形状点的距离小于还需获取的距离，将自车移到下一形状点
                newNvPt = stEnd;
                newPtId = newPtId + 1;

                // 如果最后一个点和下一段起点距离太近，跳过本段最后一个点
                if(newPtId == lastId && newSegId < segCount -1){
                    nextSeg = this.GetNaviSegment(newSegId + 1);
                    var stFirst = nextSeg.getDetailedPoint(0);
                    nDistance = MRoute.GeoUtils.CalculateDistance(stEnd.x, stEnd.y, stFirst.x, stFirst.y);
                    if(nDistance < 3){
                        newPtId = 0;
                        newSegId +=1;
                        newNvPt = stFirst;
                    }
                }
            }
        }

        this.curVPLocation.dLon = newNvPt.getX();
        this.curVPLocation.dLat = newNvPt.getY();
        this.curVPLocation.nSegId = newSegId;
        this.curVPLocation.nPtId = newPtId;
        this.curVPLocation.nSpeed = this.m_iEmulatorSpeed; //km/h

        this.NaviProc(this.curVPLocation);
        //}
        return true;
    },

    m_nLinkRemainDist:0,

    _updateRemainDistAndTime_:function(x,y) {
        //------当前道路段剩余距离----全程剩余距离
        var nvpt = new MRoute.NvPoint(x, y),
            nSegId = this.curVPLocation.nSegId,
            nPtId = this.curVPLocation.nPtId,
            resArr = this.naviPath.getRemainDistAndTime(nSegId, nPtId, nvpt);
        this.naviInfor.nRouteRemainDist = Math.round(resArr[0]);
        this.naviInfor.nSegRemainDist = Math.round(resArr[1]);
        this.naviInfor.nRouteRemainTime = Math.round(resArr[2]);
        this.naviInfor.nSegRemainTime = Math.round(resArr[3]);

        var curSeg = this.GetNaviSegment(nSegId),
            linkId = curSeg.getLinkId(nPtId);
        this.m_nLinkRemainDist = curSeg.getRemainLinkDist(linkId, nPtId, nvpt);
    },

    _updateNaviInfo_:function (x, y) {

        var stLocation = this.curVPLocation,
            naviSeg = this.GetNaviSegment(stLocation.nSegId),
            linkId = naviSeg.getLinkId(stLocation.nPtId),
            naviLink = naviSeg.getLink(linkId);

        if (naviLink == null)
            return false;

        this._getRoadName_(stLocation);

        //-------路段限速
        this.naviInfor.nLimitedSpeed =
            MRoute.DGUtil.GetLimitedSpeed(naviLink.getLinkForm(), naviLink.getRoadClass());


        this.naviInfor.fLongitude = Number(x.toFixed(8));
        this.naviInfor.fLatitude = Number(y.toFixed(8));

        // 更新到最近的电子眼、服务区的距离
        this._updateDist_();

        // 获得转向图标
        this.naviInfor.eTurnIcon = MRoute.DGUtil.GetNaviIcon(naviSeg.getBasicAction(), naviSeg.getAssistAction());
        this.naviInfor.nCurSegIndex = stLocation.nSegId;
        this.naviInfor.nCurLinkIndex = linkId;
        this.naviInfor.nCurPtIndex = stLocation.nPtId;

        if (this.m_bStartEmul) {
            // 模拟导航时需要计算车位方向角
            var segments = this.naviPath.getSegments(),
                ptId = this.curVPLocation.nPtId,
                segId = this.curVPLocation.nSegId;
            this.naviInfor.nCarDirection = this._calCarAngle_(segments, segId, ptId);
            this.naviInfor.eNaviType = MRoute.NaviType.NaviType_Emul;

        }
        else {
            // gps导航时直接用vp算得结果
            this.naviInfor.nCarDirection = stLocation.nAngle;
            this.naviInfor.eNaviType = MRoute.NaviType.NaviType_GPS;
        }

        this.m_pstFrame.UpdateNaviInfor(this.naviInfor, this.m_nLinkRemainDist);//调用更新界面信息
        return true;

    },

    m_bPlayed:false,

    
    /// 更新位置
    
    /// <returns></returns>
    updateNavigation:function () {
        this.notifyPrepareVoice();

        if (this.playRouteInfo()) {
            var validCharacterLen = this.m_wStrTTSBufer.split(",").length,currentTime = new Date().getTime();
            this.endTimeofTTS = currentTime + this.timePerCharacter * (this.m_wStrTTSBufer.length - validCharacterLen + 1);
        }
        else if (this.playCamera()) {
            console.log("will play camera info,this.endTimeofTTS"+ this.endTimeofTTS);
            var cut = new Date().getTime();
            if(cut < this.endTimeofTTS)
                this.m_wStrTTSBufer = "";
        }
        else if (this.playSAPA()) {

        }

        //当前是最后一个导航段且距离目的地小于50M播放结束导航概要提示
        var rDistRemain = this.naviInfor.nRouteRemainDist;
        var curSegID = this.curVPLocation.nSegId;
        if (rDistRemain < 50 && 0 == this.m_eEndSummaryPlayState && curSegID == this.naviPath.getSegmentCount() - 1) {
            this.playEndSummary(); //播报结束到行概要提示
            // this.naviInfor.eNaviType
            if (this.IsGPSNaving()) {
                this.m_pstFrame.ArriveWay(-1);
            }
        }

        // 防止当前有播报内容，而设置重播，播报两次
        this.m_bPlayed = this.m_wStrTTSBufer.length > 0;
        this.flushNaviSound();
        return true;
    },
    
    /// 后期补充
    /// <returns></returns>
    notifyPrepareVoice:function () {
        if (!this.m_bNotifyPrepareVoice && this.m_iPrepareVoiceTime > 0) {
            var len = this.getNextSoundLength();
            if (len > 0 && len < this.m_iPrepareVoiceTime * this.getCurrentCarSpeed()) {
                this.m_bNotifyPrepareVoice = true;
                this.m_pstFrame.PrepareVoice();
                return true;
            }
        }
        return false;
    },

    getNextSoundLength:function () {
        var curSeg = this.GetNaviSegment(this.curVPLocation.nSegId);
        var leftSegDist = this.naviInfor.nSegRemainDist;
        if ((0 == this.m_eCurState_Far || this.m_iCurGradNo == 2)
            && 0 == this.m_eCurState_Mid
            && 0 == this.m_eCurState_Near
            && 0 == this.m_eCurState_RealTime
            && this.curVPLocation.nSegId > 0) {
            var dist = curSeg.getDistance();
            if (dist > leftSegDist && dist - leftSegDist < 50) {
                return 50 - (dist - leftSegDist);
            }
            else {
                return 0;
            }
        }

        var len = 0;
        var cameraBuf = this.cameraBuffer;
        if(cameraBuf.m_dwTotal > 0)
        {
            var nGrad = this.m_iCurGradNo;
            var itemId = cameraBuf.m_dwStartIndex;
            var nextLen = leftSegDist - cameraBuf.m_astItemList[itemId].m_dwDistance;
            nextLen -= this.cnCameraDistTable[nGrad] + this.cnForShowTable[nGrad];
            if(nextLen < len)
            {
                len = nextLen;
            }
        }
        return (len < 0) ? 0 : len;

    },



    getGuideDescribe:function(path, segID)
    {
        var strDescribe = "";
        if(path == null)
        {
            return strDescribe;
        }

        var selSeg = path.getSegmentByID(segID),
            nextSeg = path.getSegmentByID(segID+1);

        if(selSeg != null) {
            var roadName = selSeg.getRoadName(),
                nextName = "",
                segLen = selSeg.getDistance(),
                eMainAction = selSeg.getBasicAction(),
                eAssiAction = selSeg.getAssistAction();

            if(nextSeg!= null){
                nextName = nextSeg.getRoadName();
            }

            if(nextName == null || nextName.length == 0) {
                nextName = "无名道路";
            }

            if(roadName == null || roadName.length == 0) {
                roadName = "无名道路";
            }

            // 1：路名
            strDescribe += "沿";
            strDescribe += roadName;

            // 2: 里程
            strDescribe += "行驶";
            strDescribe += this._getLengthDescribe_(segLen);

            // 3：动作 + 下一段名称
            if(segID+1 == path.getSegmentCount()){
                strDescribe += "，到达目的地附近";
            }
            else{
                strDescribe +="，";
                strDescribe += this._getActionDescribe_(eMainAction, eAssiAction);
                if(eAssiAction == MRoute.AssistantAction.AssiAction_NULL
                    && 0 != roadName.localeCompare(nextName)){
                    strDescribe += "进入";
                    strDescribe += nextName;
                }
            }

        }

        return strDescribe;
    },

    _customActionDescribe_:function(voiceID) {
        var OGGSound = MRoute.OGGSound, str = "";
        switch (voiceID)
        {
            case OGGSound.OGG_MainAction_Left_Ahead:
                str = "向左前方";break;
            case OGGSound.OGG_MainAction_Right_Ahead:
                str = "向右前方";break;
            case OGGSound.OGG_MainAction_Left_Back:
                str = "向左后方";break;
            case OGGSound.OGG_MainAction_Right_Back:
                str = "向右后方";break;
            case OGGSound.OGG_MainAction_Merge_Left:
                str = "靠左";break;
            case OGGSound.OGG_MainAction_Merge_Right:
                str = "靠右";break;
            default :
                str = MRoute.DGUtil.GetIndexVoiceText(voiceID);
        }

        return str;

    },

    _getActionDescribe_:function(eMAction, eAAction){
        var str ="",
            mActId = this.getMainActionVoiceID(eMAction),
            dw = this.getAssiActionVoiceID(eMAction, eAAction),
            dwIDNum = dw[0],
            adwIDList = dw[1];

        // 主动作描述
        if (eAAction == MRoute.AssistantAction.AssiAction_Along_Main
            || eAAction == MRoute.AssistantAction.AssiAction_Along_Road
            || eAAction == MRoute.AssistantAction.AssiAction_Along_Sild) {
            this.addSoundStr(this._customActionDescribe_(mActId));
        }
        else {
            str += MRoute.DGUtil.GetIndexVoiceText(mActId);
        }

        // 辅动作描述
        for (var i = 0; i < dwIDNum; i++) {
            if (adwIDList[i] > 0) {
                str += MRoute.DGUtil.GetIndexVoiceText(adwIDList[i]);
            }
        }
        return str;
    },

    getCurrentCarSpeed:function () {
        return this.m_pstFrame.GetCarSpeed();
    },

    
    /// 过后音播报
    
    /// <returns></returns>
    playAfterPass:function () {
        if(this.m_eAfterPass > 0){
            return false;
        }

        if(this.naviInfor.nCurSegIndex == 0){
            return false;
        }

        var bPlayed = false,
            remainSegDist = this.naviInfor.nSegRemainDist,
            curSeg = this.GetNaviSegment(this.naviInfor.nCurSegIndex),
            curSegDist = curSeg.getDistance();

        if (this.m_eCurLinkType == MRoute.LinkType.LinkType_Tunnel) {
            bPlayed = this.playTunnelAfterPass();
        }

        if (!bPlayed) {
            if(this.naviInfor.nSegRemainDist < this.cnPassMinDistTable[this.m_iCurGradNo]){
                this.m_eAfterPass = 1;
                return false;
            }

            if (curSegDist - remainSegDist > 100) {
                this.playRandomDist(MRoute.PlayGrade.PlayGrade_After);
                return true;
            }
        }

        return bPlayed;
    },
    
    /// 进入隧道
    
    /// <returns></returns>
    playTunnelAfterPass:function () {

        var curSegID = this.naviInfor.nCurSegIndex,
            nCount = 0;

        if (this.m_eAfterPass == 0 && curSegID != 0) {
            var segments = this.naviPath.getSegments();
            for (var i = curSegID; i < segments.length - 1; i++) {
                var curSeg = this.GetNaviSegment(i),
                    linkNum = curSeg.getLinkCount(),
                    bInTunnel = true;
                for(var j = 0; j < linkNum; j++){
                    if(MRoute.LinkType.LinkType_Tunnel != curSeg.getLink(j).getLinkType()){
                        bInTunnel = false;
                        break;
                    }
                }

                if(!bInTunnel){
                    break;
                }

                var nextSeg = this.GetNaviSegment(i + 1),
                    nextLinkType = nextSeg.getLink(0).getLinkType();
                if (nextLinkType == MRoute.LinkType.LinkType_Tunnel) {
                    nCount++;
                    if (nCount == 1) {
                        this.addSoundStr("前方");
                    }
                    else {
                        this.addSoundStr("，");
                    }
                    this.addSound(MRoute.OGGSound.OGG_AssiAction_Road_1 + nCount-1);
                    this.playAction(curSeg.getBasicAction(), MRoute.AssistantAction.AssiAction_NULL, false);

                    if (nCount == 2) break;
                }
                else {
                    break;
                }
            }

            if (nCount > 0) {
                this.m_eAfterPass = 1;
                return true;
            }
        }

        return false;
    },

    playRouteInfo:function(){
        if(this.m_nStartCountNum > 0) //数路口模式
        {
            return this.playCountFork();
        }
        else
        {
            if(this.playCommonNavi())
            {
                this.m_eAfterPass = 1;
                return true;
            }
            else if(this.playAfterPass())
            {
                this.m_eAfterPass = 1;
                return true;
            }
        }
        return false;
    },


    /**
     * 环岛数路口播报
     */
    playCountRound:function () {
        if (this.m_nLastCountNum > 0) {
            this.addSound(MRoute.OGGSound.OGG_Pass);
            this.addSound(MRoute.OGGSound.OGG_AssiAction_Exit_1 + (this.m_nStartCountNum - this.m_nLastCountNum) - 1);
        }
        else {
            this.addSound(MRoute.OGGSound.OGG_MainAction_Exit_Ring);
            if (this.naviInfor.nSegRemainDist > 60 || this.m_nStartCountNum > 1) {
                this.addSound(MRoute.OGGSound.OGG_AssiAction_Front_Branck);
            }

            var playGrade = this.getPlayGrade();
            var bHaveProximity = this.playProximity(playGrade);
            if(!bHaveProximity && this.isplayTarget(playGrade)){
                this.playTarget();
            }

        }
    },

    /**
     * 普通路混淆路口播报
     */
    playCountCommon:function(){
        if (this.m_nLastCountNum > 0) {
            this.addSound(MRoute.OGGSound.OGG_MainAction_Continue);
            this.addSound(MRoute.OGGSound.OGG_Pass);
            if (this.m_iCurGradNo != 0
                || (this.m_eCurFormWay != MRoute.Formway.Formway_Divised_Link
                && this.m_eCurFormWay != MRoute.Formway.Formway_Slip_Road)) {
                this.addSound(MRoute.OGGSound.OGG_AssiAction_Road_1 + (this.m_nStartCountNum - this.m_nLastCountNum) - 1);
            }
            else {
                this.addSound(MRoute.OGGSound.OGG_AssiAction_Exit_1 + (this.m_nStartCountNum - this.m_nLastCountNum) - 1);
            }
        }
        else {
            this.addSound(MRoute.OGGSound.OGG_AssiAction_Front_Branck);
            var curSeg = this.GetNaviSegment(this.curVPLocation.nSegId);

            this.playAction(curSeg.getBasicAction(), curSeg.getAssistAction(), true);
            this.setPlayState();

            var playGrade = this.getPlayGrade();
            var bHaveProximity = this.playProximity(playGrade);
            if(!bHaveProximity && this.isplayTarget(playGrade)){
                this.playTarget();
            }
        }
    },

    playCountFork:function () {

        var segId = this.curVPLocation.nSegId,
            ptId = this.curVPLocation.nPtId,
            geoPt = {x:this.curVPLocation.dLon, y:this.curVPLocation.dLat},
            curSeg = this.GetNaviSegment(segId);

        var res = curSeg.calcForkInfo(ptId, geoPt),
            dwMixForkNum = res[0],
            dwRemainForkDis = res[1];

        var dwPlayNum = (dwMixForkNum > 0) ? dwMixForkNum - 1 : 0;
        // 如果距离最后一个路口太近，强制播报最后一个路口
        if(this.naviInfor.nSegRemainDist < 10){
            dwPlayNum = 0;
        }

        if(!this.m_bManualPlay && this.m_nLastCountNum == dwPlayNum){
            return false;
        }

        if ((dwRemainForkDis < 70 && dwMixForkNum > 0) || dwMixForkNum == 1) {
            this.m_nLastCountNum = dwPlayNum;
            if( this.m_eCurFormWay == MRoute.Formway.Formway_Round_Circle ) // 环岛路口播报
            {
                this.playCountRound();
            }
            else // 普通混淆路口播报
            {
                this.playCountCommon();
            }

            // 在确认音播报区内，屏蔽确认音播报
            if(this.naviInfor.nSegRemainDist < 60)
            {
                this.m_eCurState_RealTime = 1;
            }

            if (this.m_nLastCountNum == 0)
            {
                this.m_nStartCountNum = 0;
            }
            return true;
        }

        return false;
    },

    getPlayGrade:function(){
        var segDistRemain = this.naviInfor.nSegRemainDist,
            rDistRemain = this.naviInfor.nRouteRemainDist,
            nGrad = this.m_iCurGradNo;
        if (segDistRemain < this.cnActionDistTable[nGrad][0] + this.cnForShowTable[nGrad]
            && segDistRemain >= this.cnActionDistTable[nGrad][0] && 0 == this.m_eCurState_Far) {
            return MRoute.PlayGrade.PlayGrade_Far; // 远距离
        }
        else if (segDistRemain < this.cnActionDistTable[nGrad][1] + this.cnForShowTable[nGrad]
            && segDistRemain >= this.cnActionDistTable[nGrad][1] && 0 == this.m_eCurState_Mid) {
            return MRoute.PlayGrade.PlayGrade_Mid; // 中距离
        }
        else if (segDistRemain < this.cnActionDistTable[nGrad][2] + this.cnForShowTable[nGrad]
            && segDistRemain >= this.cnActionDistTable[nGrad][2] && 0 == this.m_eCurState_Near) {
            return MRoute.PlayGrade.PlayGrade_Near; // 近距离
        }
        else if ( rDistRemain > 50 + 100  && segDistRemain <= 80) {
            return MRoute.PlayGrade.PlayGrade_Real_Time; // 实时
        }
        return MRoute.PlayGrade.PlayGrade_NULL;
    },

    playCommonNavi:function () {
        var segDistRemain = this.naviInfor.nSegRemainDist,
            rDistRemain = this.naviInfor.nRouteRemainDist,
            curSegID = this.naviInfor.nCurSegIndex,
            segCount = this.naviPath.getSegmentCount(),
            nGrad = this.m_iCurGradNo;

        if (segDistRemain < this.cnActionDistTable[nGrad][0] + this.cnForShowTable[nGrad]
            && segDistRemain >= this.cnActionDistTable[nGrad][0] && 0 == this.m_eCurState_Far) {// 远距离播报
            this.playFixedDist(MRoute.PlayGrade.PlayGrade_Far);
            this.m_eCurState_Far = 1;
            this.m_eAfterPass = 1;
            return true;
        } else if (segDistRemain < this.cnActionDistTable[nGrad][1] + this.cnForShowTable[nGrad]
            && segDistRemain >= this.cnActionDistTable[nGrad][1] && 0 == this.m_eCurState_Mid) {//中距离播报
            // 向播放列表添加基本导航中距离播报
            this.playFixedDist(MRoute.PlayGrade.PlayGrade_Mid);
            this.m_eCurState_Mid = 1;
            this.m_eAfterPass = 1;
            return true;
        } else if (segDistRemain < this.cnActionDistTable[nGrad][2] + this.cnForShowTable[nGrad]
            && segDistRemain >= this.cnActionDistTable[nGrad][2] && 0 == this.m_eCurState_Near) {// 近距播报
            // 向播放列表添加基本导航近距离播报
            this.playFixedDist(MRoute.PlayGrade.PlayGrade_Near);
            this.m_eCurState_Near = 1;
            this.m_eAfterPass = 1;
            return true;
        } else if (segDistRemain < this.cnActionDistTable[nGrad][2] && (rDistRemain > 50 + 100 || curSegID < segCount - 1) && segDistRemain <= 80 && this.m_eCurState_RealTime == 0) {// 实时播报
            // 向播放列表添加基本导航实时播报
            this.playFixedDist(MRoute.PlayGrade.PlayGrade_Real_Time);
            this.m_eCurState_RealTime = 1;
            this.m_eAfterPass = 1;
            return true;
        }
        return false;
    },

    /**
     * 重新请求路径后的reroute信息播报
     */
    playRouteReady:function () {
        //TestInfoLog("TBT-DG-playRouteReady:" + (new Date()).getTime());

        this.addSoundStr("导航准备就绪，");
        var routeDist = this.naviPath.getDistance();
        if (routeDist > 0) {
            this.addSoundStr("全程");
            routeDist = this._lookUpDist_(MRoute.PlayGrade.PlayGrade_Start, routeDist);
            var str = this.getLengthString(routeDist);
            this.addSoundStr(str);
        }

        var routeTime = this.naviPath.getTmcTimeMinute();
        if (routeTime > 0) {
            this.addSoundStr(",大约需要");

            var nDay = 0;
            var nHours = Math.floor(routeTime / 60);
            var nMinutes = routeTime % 60;
            if (nHours > 24) {
                nDay = Math.floor(nHours / 24);
                nHours = nHours % 24;
            }

            if (nDay > 0) {
                this.addSoundStr(this.NumValueToString(nDay) + "天");
            }
            if (nHours > 0) {
                this.addSoundStr(this.NumValueToString(nHours) + "小时");
            }
            if (nMinutes > 0) {
                this.addSoundStr(this.NumValueToString(nMinutes) + "分钟");
            }
            this.addSoundStr("，");
        }

        var bHaveName = false;
        if (this.naviInfor.curRoadName != null && this.naviInfor.curRoadName.length > 0) {
            bHaveName = true;
            if (this.naviInfor.curRoadName.length == 4) {
                if (this.naviInfor.curRoadName == "无名道路") {
                    bHaveName = false;
                }
            }
        }

        if (bHaveName) {
            this.addSoundStr("请行驶到");
            this.addSoundStr(this.naviInfor.curRoadName);
        }
        else {
            this.addSoundStr("请行驶上路");
        }
        var curSeg = this.GetNaviSegment(this.curVPLocation.nSegId);
        var eDirect = curSeg.getStartDirection();
        if(eDirect != MRoute.Direction.RouteDire_NULL){
            this.addSoundStr(",随后");
            this.addSoundStr(this._directionDescribe_(eDirect));
        }

        return true;
    },

    _directionDescribe_:function(eDirect){
        var str = "";
        switch (eDirect) {
            case MRoute.Direction.RouteDire_North:
            {
                str = "向北行驶";
            }
                break;
            case MRoute.Direction.RouteDire_North_East:
            {
                str = "向东北方向行驶";
            }
                break;
            case MRoute.Direction.RouteDire_East:
            {
                str = "向东行驶";
            }
                break;
            case MRoute.Direction.RouteDire_East_South:
            {
                str = "向东南方向行驶";
            }
                break;
            case MRoute.Direction.RouteDire_South:
            {
                str = "向南行驶";
            }
                break;
            case MRoute.Direction.RouteDire_West_South:
            {
                str = "向西南方向行驶";
            }
                break;
            case MRoute.Direction.RouteDire_West:
            {
                str = "向西行驶";
            }
                break;
            case MRoute.Direction.RouteDire_West_North:
            {
                str = "向西北方向行驶";
            }
                break;
            default:
                break;
        }

        return str;

    },

    playSAPA:function () {
        if (this.sapaBuffer.m_dwTotal > 0) {
            var iDist = 5000;
            if (this.m_eCurRoadClass != MRoute.RoadClass.RoadClass_Freeway) {
                iDist = 1000;
            }
            var startId = this.sapaBuffer.m_dwStartIndex;
            var item = this.sapaBuffer.m_astItemList[startId];
            if (0 == item.m_ePlayed) {
                var realDist = this.naviInfor.nRouteRemainDist - item.m_dwDistance;
                if (realDist < iDist + this.cnForShowTable[0]) {
                    item.m_ePlayed = 1;
                    this.addSoundStr("前方");
                    if (this.m_eCurRoadClass == MRoute.RoadClass.RoadClass_Freeway){
                        if (realDist < iDist){
                            this.addSoundStr(this.getLengthString(realDist));
                        } else {
                            this.addSoundStr("五公里");
                        }
                    } else {
                        if (realDist < iDist) {
                            this.addSoundStr(this.getLengthString(realDist));
                        }
                        else {
                            this.addSoundStr("一公里");
                        }
                    }

                    this.addSoundStr("有服务区");
                    return true;
                }
            }
        }
        return false;
    },

    
    /// 载入道路段的服务区信息
    
    loadSAPA:function () {

        var Buf = this.sapaBuffer,
            itemId = (Buf.m_dwStartIndex + Buf.m_dwTotal) % Buf.SAPA_BUFFER_SIZE,
            segId  = Buf.m_dwEndSegNo,
            linkId = Buf.m_dwEndLinkNo, //自前次遍历的后一link开始遍历，该link编号可能不存在
            segments = this.naviPath.getSegments();

        for (; segId < segments.length; segId++) {
            var curSeg = segments[segId];
            var linkCount = curSeg.getLinkCount();
            for (; linkId < linkCount; linkId++) {
                var curLink = curSeg.getLink(linkId);

                //? 只有高速路上的服务区才播报
//                var eRoadClass = curLink.getRoadClass();
//                if (eRoadClass != MRoute.RoadClass.RoadClass_Freeway) {
//                    Buf.m_dwEndSegNo = segId;
//                    Buf.m_dwEndLinkNo = linkId;
//                    return true;
//                }

                if (curLink.isAtService()) {
                    var ptId = curLink.getLastPtId(),
                        pt = curSeg.getDetailedPoint(ptId);
                    Buf.m_astItemList[itemId].m_dwDistance = this.naviPath.getRemainRouteDist(segId, ptId, pt);
                    Buf.m_astItemList[itemId].m_dwSegeNo = segId;
                    Buf.m_astItemList[itemId].m_ePlayed = 0;

                    Buf.m_dwEndSegNo = segId;
                    Buf.m_dwEndLinkNo = linkId +1;//
                    Buf.m_dwTotal++;
                    itemId = (itemId + 1) % Buf.SAPA_BUFFER_SIZE;

                    if (Buf.m_dwTotal >= Buf.SAPA_BUFFER_SIZE) {
                        return true;
                    }
                }
            }
            linkId = 0;
        }

        Buf.m_bCollectEnd = true;
        return true;
    },


    playCamera:function () {
        this.collectCameraBuffer();//检查播报时电子眼是否已经被经过
        var Buf = this.cameraBuffer;

        if (0 == Buf.m_dwTotal) {    //Buffer中没有合适的电子眼
            return false;
        }

        var nGrad = this.m_iCurGradNo;
        var dwPlayNeedLength = this.cnCameraDistTable[nGrad] + this.cnForShowTable[nGrad];
        var dwNearestIndex = Buf.m_dwStartIndex;
        var cameraItem = Buf.m_astItemList[dwNearestIndex];


        if (this.naviInfor.nRouteRemainDist - cameraItem.m_dwDistance < dwPlayNeedLength
            && cameraItem.m_dwSegeNo == this.curVPLocation.nSegId
            && cameraItem.m_ePlayed == 0) {
            //当前距离满足电子眼播报
            cameraItem.m_ePlayed = 1;
            Buf.m_dwStartIndex = (dwNearestIndex + 1) % Buf.CAMERA_BUFFER_SIZE;
            Buf.m_dwTotal--;

            if (this.m_bPlayCamera) {
                if (cameraItem.m_eCameraType == MRoute.CameraType.CameraType_Speed) {
                    this.addSoundStr("前方有测速摄像，");
                    var speed = cameraItem.m_nSpeed;
//                    if (speed < 1 || speed > this.naviInfor.nLimitedSpeed) {
//                        speed = this.naviInfor.nLimitedSpeed;
//                    }

                    if (speed > 0) {
                        this.addSoundStr("限速");
                        this.addSoundStr(this.NumValueToString(speed));
                        this.addSoundStr("公里");
                        if (this.curVPLocation.nSpeed > speed) {
                            this.addSoundStr("，您已超速");
                        }
                    }
                    else {
                        this.addSoundStr("请谨慎驾驶");
                    }
                }
                else {
                    this.addSoundStr("前方有监控摄像，请谨慎驾驶");
                }
                return true;
            }
        }

        return false;
    },

    
    /// 载入道路段的摄像头信息
    loadCamera:function () {
        var Buf = this.cameraBuffer;
        if (Buf.m_bAllInBuffer) {
            return true;
        }

        // 回收播过的电子眼Item
        this.collectCameraBuffer();
        if (Buf.m_dwTotal >= 2) {//如果buffer中仍有2个有效的电子眼就不再继续查找
            return true;
        }
        //前方电子眼的查找
        var itemId = (Buf.m_dwStartIndex + Buf.m_dwTotal) % Buf.CAMERA_BUFFER_SIZE;
        var segId = Buf.m_dwEndSegNo;
        var linkId = Buf.m_dwEndLinkNo;
        var segments = this.naviPath.getSegments();
        for (; segId < segments.length; segId++) {
            var curSeg = segments[segId];
            var linkCount = curSeg.getLinkCount();
            for (; linkId < linkCount; linkId++) {//linkid 从零开始，每一个segment上的ptid linkid是连续的
                var curLink = curSeg.getLink(linkId);
                if (curLink.getCameraCount()) {
                    var camera = curLink.getCameras(0);
                    var nvPt = camera.getCoordinate();
                    var ptId = curSeg.calcNearestPtId(nvPt.x, nvPt.y, linkId);

                    var dist = this.naviPath.getRemainRouteDist(segId, ptId, nvPt);
                    if (Buf.m_dwLastPlayRemainDist <= dist) {
                        continue;
                    }

                    //if(Buf.m_dwLastPlayRemainDist - dist < this.PROXIMITY_DISTANCE)
                    if (Buf.m_dwLastPlayRemainDist - dist < this.cnCameraDistTable[0]) {
                        Buf.m_dwLastPlayRemainDist = dist;//已经在播报的经验距离范围之内不再添加
                        // 距离不合要求不添加
                    }
                    else {
                        Buf.m_dwLastPlayRemainDist = dist;
                        var cameraItem = Buf.m_astItemList[itemId];
                        cameraItem.m_dwSegeNo = segId;
                        cameraItem.m_eCameraType = camera.getCameraType();
                        cameraItem.m_ePlayed = 0;
                        cameraItem.m_dwDistance = dist;
                        cameraItem.m_nSpeed = camera.getSpeed();

                        Buf.m_dwTotal++;

                        Buf.m_dwEndSegNo = segId;
                        Buf.m_dwEndLinkNo = linkId + 1;

                        itemId = (itemId + 1) % Buf.CAMERA_BUFFER_SIZE;
                        if (Buf.m_dwTotal >= Buf.CAMERA_BUFFER_SIZE) {
                            return true;
                        }
                    }
                }
            }
            linkId = 0;
        }
        Buf.m_bAllInBuffer = true;
        return true;

    },

    // 将已经过的电子眼改为已播报状态，回收item以便记录将至的电子眼
    collectCameraBuffer:function () {
        //别名
        var Buf = this.cameraBuffer;
        var List = Buf.m_astItemList;
        var naviInfo = this.naviInfor;

        var index = Buf.m_dwStartIndex;
        var dwTestNum;
        for (dwTestNum = 0; dwTestNum < Buf.m_dwTotal; index = (index + 1) % Buf.CAMERA_BUFFER_SIZE, dwTestNum++) {
            if (List[index].m_dwSegeNo == naviInfo.nCurSegIndex) {
                if (naviInfo.nRouteRemainDist > List[index].m_dwDistance
                    && 0 == List[index].m_ePlayed) {
                    break;
                }
                else {
                    List[index].m_ePlayed = 1;
                }
            }
            else if (List[index].m_dwSegeNo < naviInfo.nCurSegIndex) {
                List[index].m_ePlayed = 1;
            }
            else {
                break; // 未到当前路段
            }
        }
        Buf.m_dwStartIndex = index;
       // if (Buf.m_dwTotal >= dwTestNum) {
            Buf.m_dwTotal -= dwTestNum;
       // }

    },

    collectSAPABuffer:function () {

        var Buf = this.sapaBuffer;

        var index = Buf.m_dwStartIndex;
        var dwTestNum = 0;
        for (; dwTestNum < Buf.m_dwTotal; index = (index + 1) % Buf.SAPA_BUFFER_SIZE, dwTestNum++) {
            if (Buf.m_astItemList[index].m_dwSegeNo == this.naviInfor.nCurSegIndex) {
                if (this.naviInfor.nRouteRemainDist > Buf.m_astItemList[index].m_dwDistance
                    && 0 == Buf.m_astItemList[index].m_ePlayed) {
                    break;
                }
                else {
                    Buf.m_astItemList[index].m_ePlayed = 1;
                }
            }
            else if (Buf.m_astItemList[index].m_dwSegeNo < this.naviInfor.nCurSegIndex) {
                Buf.m_astItemList[index].m_ePlayed = 1;
            }
            else {
                break;
            }
        }
        Buf.m_dwStartIndex = index;
        if (Buf.m_dwTotal >= dwTestNum) {
            Buf.m_dwTotal -= dwTestNum;
        }
    },

    getNaviInfo:function() {
        return this.naviInfor;
    },


    
    /// 播报开始导航概要提示
    
    playStartSummary:function () {
        this.m_bNotifyPrepareVoice = true;
        this.m_pstFrame.PrepareVoice();
        //this.loadCamera();

        if (this.m_pstFrame.GetRouteType() != MRoute.CalcRouteType.CalcRouteType_Reroute) {
            this.addSound(MRoute.OGGSound.OGG_Navi_Start);
        }else{
            //by TangJing
            this.loadCamera();
            var nGrad = this.m_iCurGradNo,dwPlayNeedLength = this.cnCameraDistTable[nGrad] + this.cnForShowTable[nGrad];
            var dwNearestIndex = this.cameraBuffer.m_dwStartIndex,cameraItem = this.cameraBuffer.m_astItemList[dwNearestIndex];
            if(this.naviInfor.nRouteRemainDist - cameraItem.m_dwDistance < dwPlayNeedLength
                && cameraItem.m_dwSegeNo == this.curVPLocation.nSegId
                && cameraItem.m_ePlayed == 0)
                cameraItem.m_ePlayed = 1;
        }
        this.playRandomDist(MRoute.PlayGrade.PlayGrade_Start);
        var validCharacterLen = this.m_wStrTTSBufer.split(",").length,currentTime = new Date().getTime();
        this.endTimeofTTS = currentTime + this.timePerCharacter * (this.m_wStrTTSBufer.length - validCharacterLen + 1);
        this.flushNaviSound();
        this.m_eStartSummaryPlayState = 1;

    },

    
    /// 播报结束导航概要提示
    
    playEndSummary:function () {
        this.addSound(MRoute.OGGSound.OGG_AssiAction_Arrive_Destination);
        this.addSound(MRoute.OGGSound.OGG_Navi_End);
        console.log("_initForRouteSuccess_: playEndSummary");
        this.flushNaviSound();
        this.m_eEndSummaryPlayState = 1;
    },



    /// !!!是否为GPS导航
    /// <returns></returns>
    IsGPSNaving:function () {
        return this.m_bStartGPS && !this.m_bPauseGPS;
    },
    /*
     #endregion
     #region 导航
     */

    /*
     #endregion
     #region 声音播报模块
     */
    
    /// 远距离播报状态
    
    m_eCurState_Far:null,
    
    /// 中距离播报状态
    
    m_eCurState_Mid:null,
    
    /// 近距离播报状态
    
    m_eCurState_Near:null,
    
    /// 确认音播报状态
    
    m_eCurState_RealTime:null,
    
    /// 开始导航播报状态
    
    m_eStartSummaryPlayState:null,
    
    /// 结束导航播报状态
    
    m_eEndSummaryPlayState:null,
    
    /// 过后音播报状态
    
    m_eAfterPass:null,
    m_bTargetPlayed:null,
    LEAST_DISTANCE_VOICE:100,
    
    /// 数路口开始路口数
    
    m_nStartCountNum:-1,
    m_nLastCountNum:-1,


    m_wStrTTSBufer:"", // TTS播报字符串缓存
    endTimeofTTS: 0, //本次播报结束的时间
    timePerCharacter: 270, //经验值，每个汉字播报需要的时间


    getEndTimeOfLastTTS:function(){
        return this.endTimeofTTS;
    },
    /// 添加声音
       /// <param name="oGGId"></param>
    addSound:function (oGGId) {
        if(oGGId < 0){
            return;
        }
        //如果是枚举类型，则转换
        var str = MRoute.DGUtil.GetIndexVoiceText(oGGId);
        if (this.m_wStrTTSBufer.length > 0) {
            this.m_wStrTTSBufer = this.m_wStrTTSBufer.concat(str);
        }
        else {
            this.m_wStrTTSBufer = str;
        }

    },

    addSoundStr:function (str) {
        if (this.m_wStrTTSBufer.length > 0) {
            this.m_wStrTTSBufer = this.m_wStrTTSBufer.concat(str);
        }
        else {
            this.m_wStrTTSBufer = str;
        }
    },

    /**
     * 随机距离播报
     * @param ePlayGrade    播报类别
     * @return {Boolean}    是否有播报内容
     */
    playRandomDist:function (ePlayGrade) {
        if (this.isNeedPlayLongRoad(this.m_iCurGradNo)) {
            this.addSoundStr("前方大约有");
            this.addSoundStr(this.getLengthString(this.naviInfor.nSegRemainDist));
            this.addSoundStr("顺行道路");
        } else {
            this.setPlayState();
            this.playFixedDist(ePlayGrade);
        }
        return true;
    },
    
    /// 设置播报状态 用来在随机距离播报时设置固定播报是否还需要播报
    
    setPlayState:function () {
        var remainDist = this.naviInfor.nSegRemainDist,
            eCurRoadClass = this.m_eCurRoadClass;
        if (remainDist < 100) {
            this.m_eCurState_Mid = 1;
            this.m_eCurState_Near = 1;
            this.m_eCurState_RealTime = 1;
        }
        else {
            if (eCurRoadClass == MRoute.RoadClass.RoadClass_Freeway) {
                if (remainDist < 3000) {
                    this.m_eCurState_Far = 1;
                    if (remainDist < 1000) {
                        this.m_eCurState_Mid = 1;
                        if (remainDist < 400) {
                            this.m_eCurState_Near = 1;
                        }
                    }
                }
            } else if (eCurRoadClass == MRoute.RoadClass.RoadClass_City_Speed_way) {
                if (remainDist < 2000) {
                    this.m_eCurState_Far = 1;
                    if (remainDist < 700) {
                        this.m_eCurState_Mid = 1;
                        if (remainDist < 400) {
                            this.m_eCurState_Near = 1;
                        }
                    }
                }
            } else {
                if (remainDist < 700) {
                    this.m_eCurState_Mid = 1;
                    if (remainDist < 400) {
                        this.m_eCurState_Near = 1;
                    }
                }
            }
        }
    },


    isplayTarget:function(ePlayGrade){
        return !(!this.m_playToken.m_bTargetInfoToken
            || this.m_bTargetPlayed
            || this.naviInfor.nSegRemainDist < this.cnActionDistTable[2][2]    // 剩余距离小于近距离播报不播报方面名称
            || ePlayGrade == MRoute.PlayGrade.PlayGrade_Real_Time
            || ePlayGrade == MRoute.PlayGrade.PlayGrade_Arrive);


    },

    isplayProximity:function(){
        if(!this.m_playToken.m_bProximityToken){
            return false;
        }
        // 和距离相关的判定
        return true;
    },

    /**
     * 固定距离播报
     * @param ePlayGrade    播报类别
     * @return {Boolean}    是否有播报内容
     */
    playFixedDist:function (ePlayGrade) {

        var segId = this.naviInfor.nCurSegIndex,
            curSeg = this.GetNaviSegment(segId);
        if (curSeg == null) {
            return false;
        }

        var baseAction = curSeg.getBasicAction(),
            assAction = curSeg.getAssistAction(),
            segRemainDist = this.naviInfor.nSegRemainDist;

        if (segRemainDist >= this.LEAST_DISTANCE_VOICE && this.m_eCurFormWay != MRoute.Formway.Formway_Round_Circle) {
            segRemainDist = this._lookUpDist_(ePlayGrade, segRemainDist);
            this.addSound(MRoute.OGGSound.OGG_Forword);
            this.addSoundStr(this.getLengthString(segRemainDist));
        }

        // 中距离时未数路口，数路口播报，孙文博反映，若不播报路口数，直接播报感觉突兀
        if (this.m_nStartCountNum < 0 && this.IsShortThanMiddle()) {
            this.countForkNum();
            if (this.m_nStartCountNum > 0)
            {
                this.addSound(MRoute.OGGSound.OGG_AssiAction_Road_1 + this.m_nStartCountNum - 1);
            }
        }

        // 播报基本和辅助动作
        if(this.m_playToken.m_bTargetInfoToken && baseAction != MRoute.MainAction.MainAction_NULL){
            this.playAction(baseAction, MRoute.AssistantAction.AssiAction_NULL, true);
        }
        else {
            this.playAction(baseAction, assAction, true);
        }

        var bHaveProximity = false;
        if (this.isplayProximity()) {
            bHaveProximity = this.playProximity(ePlayGrade);
        }
        var bplayTarget = this.isplayTarget(ePlayGrade);

        if (bplayTarget && !bHaveProximity) {
            if (this.getPlayGrade() != MRoute.PlayGrade.PlayGrade_NULL) {
                this.m_bTargetPlayed = true;
            }
            this.playTarget();
        }
        return true;
    },

    /**
     * 近接播报
     * @param ePlayGrade 播报级别
     * @return {Boolean}
     */
    playProximity:function (ePlayGrade) {

        var curSegId = this.naviInfor.nCurSegIndex,
            nextSeg = this.GetNaviSegment(curSegId + 1);
        if(nextSeg == null){
            return false;
        }

        if (nextSeg.getDistance() < this.PROXIMITY_DISTANCE) {
            var mainAction = nextSeg.getBasicAction(),
                assistAction = nextSeg.getAssistAction();
            this.addSoundStr("，随后");
            if (assistAction == MRoute.AssistantAction.AssiAction_Arrive_TollGate) {
                this.playAction(MRoute.MainAction.MainAction_NULL,
                    MRoute.AssistantAction.AssiAction_Arrive_TollGate, false);
            }
            else if (mainAction == MRoute.MainAction.MainAction_NULL) {
                this.playAction(mainAction, assistAction, false);
            }
            else if (mainAction == MRoute.MainAction.MainAction_Entry_Ring && ePlayGrade == MRoute.PlayGrade.PlayGrade_Far) {
                this.addSoundStr("经过环岛");
            }
            else {
                this.playAction(mainAction, MRoute.AssistantAction.AssiAction_NULL, false);
            }
            return true;
        }

        return false;

    },

    playTarget:function () {
        var segments = this.naviPath.getSegments();
        if (segments == null) {
            return false;
        }

        var segmentNum = segments.length,
            curSegID = this.naviInfor.nCurSegIndex,
            targetName = this.getTargetInfoData(curSegID),
            nextRoadName = null,
            curRoadName = this.getRoadName(curSegID, this.naviInfor.nCurLinkIndex);

        var curSeg = this.GetNaviSegment(curSegID);
        if ((curSegID >= segmentNum - 2)
            || (curSegID < segmentNum - 2 && curSeg.getBasicAction() == MRoute.MainAction.MainAction_Entry_Ring)) {
            // 接近最后一段或进入环岛
            nextRoadName = this.getRoadName(curSegID + 2, 0);
        }
        else {
            nextRoadName = this.getRoadName(curSegID + 1, 0);
        }

        if (targetName != null && targetName.length > 0) {
            this.addSoundStr("，是");
            this.addSoundStr(targetName);
            this.addSoundStr("方向");
            return true;
        } else if (nextRoadName != null && nextRoadName.length > 0 && nextRoadName != curRoadName) {
            this.addSoundStr("，进入");
            this.addSoundStr(nextRoadName);
            return true;
        }

        return false;

    },

    getTargetInfoData:function (dwSegNum) {
        var pwName = null;
        var pSegment = this.GetNaviSegment(dwSegNum);
        var Signs = pSegment.getRoadSigns();
        if (Signs != null && Signs.length > 0) {
            pwName = Signs[0].getContent();
//            for(var i = 1; i < Signs.length; i++){
//                pwName = pwName + Signs[i].getContent();
//            }
        }
        return pwName;
    },

    manualPlay:function () {
        if (this.m_bManualPlay) {
            return;
        }

        if(!this.m_bStartEmul && !this.m_bStartGPS) {
            return;
        }

        this.m_bManualPlay = true;
    },


    playCurrent:function () {

        if(this.m_pstVoiceManager.GetRemainTime() > 0){
            return false;
        }

        if (this.m_nStartCountNum > 0 && this.playCountFork())
        {
        }
        else
        {
            // 在固定距离播报范围内播报固定距离
            if (this.playCommonNavi())
            {
            }
            else
            {
                // 非固定距离，根据当前距离播报
                this.playRandomDist(MRoute.PlayGrade.PlayGrade_NULL);
            }
        }

        if(this.m_wStrTTSBufer.length > 0)
        {
            this.m_bManualPlay = false;
            console.log("_initForRouteSuccess_: playCurrent");
            this.flushNaviSound();
            return true;
        }
        return false;
    },

    calcManualGrade:function (bval) {
        var ePlayGrade = MRoute.PlayGrade.PlayGrade_NULL,
            nGrad = this.m_iCurGradNo,
            offset = this.cnForShowTable[nGrad],
            rSegDist = this.naviInfor.nSegRemainDist,
            rRouteDist = this.naviInfor.nRouteRemainDist;

        if (rSegDist >= this.cnActionDistTable[nGrad][0]) {
            //远距离播报
            if (bval) {
                if (rSegDist < this.cnActionDistTable[nGrad][0] + offset) {
                    ePlayGrade = MRoute.PlayGrade.PlayGrade_Far;
                }
            }
            else {
                ePlayGrade = MRoute.PlayGrade.PlayGrade_Far;
            }

        }
        else if (rSegDist >= this.cnActionDistTable[nGrad][1]) {
            //中距离播报
            if (bval) {
                if (rSegDist < this.cnActionDistTable[nGrad][1] + offset) {
                    ePlayGrade = MRoute.PlayGrade.PlayGrade_Mid;
                }
            }
            else {
                ePlayGrade = MRoute.PlayGrade.PlayGrade_Mid;
            }
        }
        else if (rSegDist >= this.cnActionDistTable[nGrad][2]) {
            //近距播报
            if (bval) {
                if (rSegDist < this.cnActionDistTable[nGrad][2] + offset) {
                    ePlayGrade = MRoute.PlayGrade.PlayGrade_Near;
                }
            }
            else {
                ePlayGrade = MRoute.PlayGrade.PlayGrade_Near;
            }
        }
        else if (rSegDist < this.cnActionDistTable[nGrad][2]) {
            var segCount = this.naviPath.getSegmentCount();
            if (rRouteDist > 50 + 100 || this.naviInfor.nCurSegIndex < segCount - 1) {
                // 即时播报
                var iSpeed = this.getCurrentCarSpeed();
                var iRealTimeDis = 50 + iSpeed;	// 处理Gps有1秒延迟的情况
                if (rSegDist <= iRealTimeDis) {
                    var dwNeedTime = this.m_pstVoiceManager.GetRemainTime();
                    var bCanPlay = true;
                    if (dwNeedTime == 0) {
                        dwNeedTime = this.m_pstVoiceManager.GetNoVoiceTime();
                        if (dwNeedTime < 1000) {
                            bCanPlay = false;
                        }
                    }
                    else {
                        bCanPlay = false;
                    }

                    if (rSegDist < 30) {
                        bCanPlay = true;
                    }

                    if (bCanPlay) {
                        ePlayGrade = MRoute.PlayGrade.PlayGrade_Real_Time;
                    }
                }
            }
            else if (this.naviInfor.nCurSegIndex >= segCount - 1) {
                if (rRouteDist < 50) {
                    ePlayGrade = MRoute.PlayGrade.PlayGrade_Arrive;//到达播报
                }
            }
        }

        return ePlayGrade;
    },

    /**
     * 播报动作
     * @param eMainAction           主导航动作
     * @param eAssistantAction      辅助导航动作
     * @param bCurrent              是否当前导航段
     */
    playAction:function (eMainAction, eAssistantAction, bCurrent) {

        var MAction = MRoute.MainAction,
            AAction = MRoute.AssistantAction;

        if(eMainAction == MAction.MainAction_Entry_Ring)
        {
            eAssistantAction = AAction.AssiAction_NULL;
        }
        else if(eMainAction == MAction.MainAction_Slow && eAssistantAction == AAction.AssiAction_NULL)
        {
            eMainAction = MAction.MainAction_NULL;
            eAssistantAction = AAction.AssiAction_Arrive_TollGate;
        }


        // 收费站先播辅助信息
        if (eAssistantAction == AAction.AssiAction_Arrive_TollGate) {
            this.playAssitAction(eMainAction, eAssistantAction, bCurrent);
            this.playMainAction(eMainAction, eAssistantAction, bCurrent);
        }
        else {
            this.playMainAction(eMainAction, eAssistantAction, bCurrent);
            this.playAssitAction(eMainAction, eAssistantAction, bCurrent);
        }

    },

    /**
     * 播报主要动作
     * @param eMAction      主导航动作
     * @param eAAction      辅助导航动作
     * @param bCurrent      是否当前导航段
     */
    playMainAction:function (eMAction, eAAction, bCurrent) {
        var MAction = MRoute.MainAction,
            AAction = MRoute.AssistantAction;

        if(MAction.MainAction_NULL == eMAction){
            return;
        }

        if(bCurrent){
            var bOnRoundStartPlay = false;
            var curSegID = this.naviInfor.nCurSegIndex;
            if (eMAction == MAction.MainAction_Leave_Ring && curSegID == 0) {
                bOnRoundStartPlay = true;
            }
            else if (eMAction == MAction.MainAction_Leave_Ring && curSegID > 0) {
                var curSeg = this.GetNaviSegment(curSegID - 1);
                if (curSeg == null) {
                    return;
                }

                if (curSeg.getBasicAction() != MAction.MainAction_Entry_Ring) {
                    bOnRoundStartPlay = true;
                }
            }
            if (bOnRoundStartPlay && this.m_nStartCountNum < 0) {
                this.countForkNum();
                var iExitNum = this.m_nStartCountNum;
                this.addSound(MRoute.OGGSound.OGG_Forword);
                this.addSound(iExitNum + MRoute.OGGSound.OGG_AssiAction_Exit_1 - 1);
            }
        }

        var dwVoiceID = this.getMainActionVoiceID(eMAction);
        if (eAAction == AAction.AssiAction_Along_Main
            || eAAction == AAction.AssiAction_Along_Road
            || eAAction == AAction.AssiAction_Along_Sild) {
            this.addSoundStr(this._customActionDescribe_(dwVoiceID));
        }
        else {
            this.addSound(dwVoiceID);
        }

    },

    countForkNum:function(){

        var curSegId = this.naviInfor.nCurSegIndex,
            curLinkId = this.naviInfor.nCurLinkIndex,
            curSeg = this.GetNaviSegment(curSegId);
        if (curSeg == null) {
            return;
        }

        this.m_nStartCountNum = curSeg.calcMixForkNum(curLinkId);
        if(this.m_nStartCountNum > 7)
            this.m_nStartCountNum = 7;

        // 只有一个路口，非环岛情形省略播报，因为不至于混淆
        if (this.m_nStartCountNum == 1 && this.m_eCurFormWay != MRoute.Formway.Formway_Round_Circle)
        {
            this.m_nStartCountNum = 0;
        }
    },

    /**
     * 获得主要动作的预录音号
     * @param eMAction 主导航动作
     * @return {Number} 预录音号
     */
    getMainActionVoiceID:function (eMAction) {
        if (MRoute.MainAction.MainAction_NULL == eMAction) {
            return -1;
        }
        else {
            return (MRoute.OGGSound.OGG_MainAction_Turn_Left + eMAction - 1);
        }
    },

    /**
     * 播报辅助动作
     * @param eMAction      主导航动作
     * @param eAAction      辅助导航动作
     * @param bCurrent      是否当前导航段
     */
    playAssitAction:function (eMAction, eAAction, bCurrent) {
        if (eMAction == MRoute.MainAction.MainAction_Entry_Ring && bCurrent) {
            var curSegID = this.naviInfor.nCurSegIndex;
            if (curSegID >= this.naviPath.getSegmentCount() - 2) {
                this.addSoundStr("，随后到达目的地附近");
            }
            else {
                var nextSeg = this.GetNaviSegment(this.naviInfor.nCurSegIndex + 1);
                if (nextSeg == null) {
                    return;
                }
                if (nextSeg.getAssistAction() == MRoute.AssistantAction.AssiAction_Arrive_Way) {
                    this.addSoundStr("，随后到达途经点附近");
                }
                else {
                    var iExitNum = nextSeg.calcMixForkNum(0);
                    if (iExitNum > 0) {
                        iExitNum = iExitNum > 7 ? 7 : iExitNum;
                        this.addSound(iExitNum + MRoute.OGGSound.OGG_AssiAction_G0_Exit_1 - 1);
                    }
                }
            }
        }
        else {
            if (eAAction != MRoute.AssistantAction.AssiAction_NULL) {
                var dw = this.getAssiActionVoiceID(eMAction, eAAction);
                var dwIDNum = dw[0], adwIDList = dw[1];
                for (var i = 0; i < dwIDNum; i++) {
                    if (adwIDList[i] != 0) {
                        this.addSound(adwIDList[i]);
                    }
                }
            }
        }
    },

    
    /// 获得辅助动作的预录音号
    /// <param name="eMAction">主要动作</param>
    /// <param name="eAAction">辅助动作</param>
    /// <param name="adwIDList">声音号列表</param>
    /// <returns>返回声音号数量</returns>
    getAssiActionVoiceID:function (eMAction, eAAction) {
        var dwIDNum = 0, adwIDList = [];
        if (MRoute.AssistantAction.AssiAction_NULL == eAAction) {
            return 0;
        }

        if (eAAction >= MRoute.AssistantAction.AssiAction_Arrive_Exit && eAAction <= MRoute.AssistantAction.AssiAction_Arrive_Destination) {
            adwIDList[dwIDNum] = (MRoute.OGGSound.OGG_AssiAction_Arrive_Exit + eAAction - MRoute.AssistantAction.AssiAction_Arrive_Exit);
            dwIDNum++;
        } else if (MRoute.AssistantAction.AssiAction_Entry_Ferry == eAAction) {
            adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Arrive_Ferry;
            dwIDNum++;
        } else if (MRoute.AssistantAction.AssiAction_Entry_Ring_Left == eAAction) {
            adwIDList[dwIDNum] = MRoute.OGGSound.OGG_MainAction_Turn_Left;
            dwIDNum++;
        } else if (MRoute.AssistantAction.AssiAction_Entry_Ring_Right == eAAction) {
            adwIDList[dwIDNum] = MRoute.OGGSound.OGG_MainAction_Turn_Right;
            dwIDNum++;
        } else if (MRoute.AssistantAction.AssiAction_Entry_Ring_Continue == eAAction) {
            adwIDList[dwIDNum] = MRoute.OGGSound.OGG_MainAction_Continue;
            dwIDNum++;
        } else if (MRoute.AssistantAction.AssiAction_Entry_Ring_UTurn == eAAction) {
            adwIDList[dwIDNum] = MRoute.OGGSound.OGG_MainAction_UTurn;
            dwIDNum++;
        } else if (eAAction >= MRoute.AssistantAction.AssiAction_Right_Branch_1 && eAAction <= MRoute.AssistantAction.AssiAction_Left_Branch_5) {
            adwIDList[dwIDNum] = (MRoute.OGGSound.OGG_AssiAction_Right_Branch_1 + eAAction - MRoute.AssistantAction.AssiAction_Right_Branch_1);
            dwIDNum++;
        } else if (eAAction >= MRoute.AssistantAction.AssiAction_Entry_Merge_Center && eAAction <= MRoute.AssistantAction.AssiAction_Entry_Merge_Left) {
            if (eMAction != MRoute.MainAction.MainAction_Continue) {
                adwIDList[dwIDNum] = MRoute.OGGSound.OGG_Then;
                dwIDNum++;
            }
            adwIDList[dwIDNum] = (MRoute.OGGSound.OGG_AssiAction_Entry_Center_Side_Road + eAAction - MRoute.AssistantAction.AssiAction_Entry_Merge_Center);
            dwIDNum++;
        } else if (eAAction >= MRoute.AssistantAction.AssiAction_Entry_Merge_Right_Sild && eAAction <= MRoute.AssistantAction.AssiAction_Entry_Merge_Right_Right) {
            switch (eAAction) {
                case MRoute.AssistantAction.AssiAction_Entry_Merge_Right_Sild:
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_Then;
                    dwIDNum++;
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Along_Side;
                    dwIDNum++;
                    break;
                case MRoute.AssistantAction.AssiAction_Entry_Merge_Left_Sild:
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_Then;
                    dwIDNum++;
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Along_Side;
                    dwIDNum++;
                    break;
                case MRoute.AssistantAction.AssiAction_Entry_Merge_Right_MAIN:
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_Then;
                    dwIDNum++;
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Along_Main;
                    dwIDNum++;
                    break;
                case MRoute.AssistantAction.AssiAction_Entry_Merge_Left_MAIN:
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_Then;
                    dwIDNum++;
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Along_Main;
                    dwIDNum++;
                    break;
                case MRoute.AssistantAction.AssiAction_Entry_Merge_Right_Right:
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Entry_Right_Side_Road;
                    dwIDNum++;
                    adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Along_Right_Road;
                    dwIDNum++;
                    break;
            }
        }
        else if (eAAction == MRoute.AssistantAction.AssiAction_Along_Sild) {
            adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Along_Side;
            dwIDNum++;
        } else if (eAAction == MRoute.AssistantAction.AssiAction_Along_Main) {
            adwIDList[dwIDNum] = MRoute.OGGSound.OGG_AssiAction_Along_Main;
            dwIDNum++;
        } else if (eAAction >= MRoute.AssistantAction.AssiAction_Entry_Main && eAAction <= MRoute.AssistantAction.AssiAction_Entry_Left_Road) {
            adwIDList[dwIDNum] = (MRoute.OGGSound.OGG_AssiAction_Entry_Main + eAAction - 1);
            dwIDNum++;
        }

        return [dwIDNum, adwIDList];
    },



    // 查表，返回播报距离
    _lookUpDist_:function (ePlayGrade, dist) {
        var nGrad = this.m_iCurGradNo;
        switch (ePlayGrade) {
            case MRoute.PlayGrade.PlayGrade_Far://远距离提示
                if (nGrad == MRoute.RoadClass.RoadClass_Province_Road) {
                    dist = this.cnActionDistTable[nGrad][1];
                }
                else {
                    dist = this.cnActionDistTable[nGrad][0];
                }
                break;

            case MRoute.PlayGrade.PlayGrade_Mid://中距离提示
                dist = this.cnActionDistTable[nGrad][1];
                break;

            case MRoute.PlayGrade.PlayGrade_Near://近距离提示
                dist = this.cnActionDistTable[nGrad][2];
                break;

            case MRoute.PlayGrade.PlayGrade_Start:
                if (dist > 1000) {
                    dist = Math.ceil(dist / 1000) * 1000;
                } else if (dist > 100) {
                    dist = Math.ceil(dist / 100) * 100;
                }
                else if (dist > 10) {
                    dist = Math.ceil(dist / 10) * 10;
                }
                break;
            default:
                break;
        }

        return dist;
    },
    
    /**
     * 将距离转化为字符串描述
     * @param dist
     * @return {String}
     */
    getLengthString:function (dist) {
        var str ="", iDis;
        if (dist > 950) {
            iDis = dist < 1000 ? 1 : Math.floor(dist / 1000);
            str = this.NumValueToString(iDis) + "公里";
            return str;
        }
        else {
            iDis = dist;
            if (iDis >= 100) {
                iDis = Math.round(dist / 100);
                iDis *= 100;
            }
            else if (iDis >= 10) {
                iDis = Math.round(dist / 10);
                iDis *= 10;
            }
            str = this.NumValueToString(iDis) + "米";
            return str;
        }
    },

    _getLengthDescribe_:function(dist){
        var str = "", iDis;
        if(dist > 1000){
            iDis = Math.floor(dist / 1000);
            var remain = dist % 1000;
            if(remain >= 100) {
                remain = Math.floor(remain / 100) * 0.1;
                iDis += remain;
            }
            str = iDis.toString() + "公里";
        } else {
            str = dist.toString() + "米";
        }

        return str;
    },

    NumValueToString:function (num, bval) {

        if (num > 9999 * 10000) {
            return "";
        }

        var bHaveH = false;
        if(arguments.length == 2){
            bHaveH = bval;
        }

        var acText = [], //字符串数组
            units = "",  //单位
            minNum = 100;

        if (num >= 10000) {//如果大于万值
            minNum = 10000;
            units = "万";
        } else if (num >= 1000) {//如果大于千值
            minNum = 1000;
            units = "千";
        } else if (num >= 100) {//如果大于百值
            minNum = 100;
            units = "百";
        } else if (num > 10) {//如果大于十值
            minNum = 10;
            units = "十";
        } else {
            minNum = 1;
        }

        var intPartCount = Math.floor(num / minNum);    //转换后的取整数值
        // 首位用“两”代替“二”  , 但首位是十位时不替换
        if (intPartCount == 2 && !bHaveH && (minNum != 10)) {
            acText.push("两" + units);
        }
        else {
            acText.push(this.NumberToChar(intPartCount) + units);
        }

        // 非首尾位置为0值，需播报一次“零” 如一千零五（十）
        var remainderCount = num - intPartCount * minNum;//取整后剩余值

        if(remainderCount > 0){
            // 非首尾位置为0值，需播报一次“零” 如一千零五（十）
            if (remainderCount < minNum / 10) {
                acText.push("零");
            }
            acText.push(this.NumValueToString(remainderCount, true));
        }
        return acText.join("");
    },

    NumberToChar:function (dwNum) {
        var s = "";
        switch (dwNum) {
            case 0:
                s = "零";
                break;
            case 1:
                s = "一";
                break;
            case 2:
                s = "二";
                break;
            case 3:
                s = "三";
                break;
            case 4:
                s = "四";
                break;
            case 5:
                s = "五";
                break;
            case 6:
                s = "六";
                break;
            case 7:
                s = "七";
                break;
            case 8:
                s = "八";
                break;
            case 9:
                s = "九";
                break;
            case 10:
                s = "十";
                break;
            default:
                s = "";
                break;
        }
        return s;
    },

    
    /// 判断短路段剩余距离是否可以播报
    
    /// <param name="iCurGradNo"></param>
    /// <returns></returns>
    isNeedPlayLongRoad:function (nGrad) {
        var dwLongDist = 0;
        if (nGrad == MRoute.RoadClass.RoadClass_Freeway) {
            dwLongDist = 35000;
        }
        else if (nGrad == MRoute.RoadClass.RoadClass_National_Road) {
            dwLongDist = 15000;
        }
        else {
            dwLongDist = 5000;
        }

        return dwLongDist < this.naviInfor.nSegRemainDist;



    },

    /**
     * 播放声音，播报后清空播报内容，以便下次播报
     */
    flushNaviSound:function () {
        if (this.m_wStrTTSBufer == null || this.m_wStrTTSBufer.length == 0) {
            return;
        }
        //this.m_pstVoiceManager.RealTimePlay(this.m_wStrTTSBufer, MRoute.PlayVoiceLeve.PlayVoiceLeve_DGNavi);
        // 通知FrameForDG ，后者又通知到FrameForTBT播放
        this.m_pstFrame.PlayNaviSound(this.m_wStrTTSBufer);
        this.m_wStrTTSBufer = "";
    }

});

MRoute.SAPABuffer = Class({
	/// <summary>
	/// 电子眼Buffer空间区域
	/// </summary>
	m_astItemList : [],
    m_dwStartIndex :0,
    SAPA_BUFFER_SIZE:4,
			
	/// <summary>
	/// Buffer中最后一个电子眼的导航段号
	/// </summary>
	m_dwEndSegNo:0,					
	/// <summary>
	/// Buffer中最后一个电子眼在她导航段中的编号
	/// </summary>
	m_dwEndLinkNo:0,
    m_bCollectEnd:false,
    m_dwTotal:0,

	"initialize":function(){
        for(var i = 0; i< this.SAPA_BUFFER_SIZE ;i++){
            var item = new MRoute.SAPAItem();
            this.m_astItemList.push(item);
        }
	},
	Clear:function(){
        this.m_dwTotal = 0;
		this.m_dwEndSegNo = 0;
		this.m_dwEndLinkNo = 0;
        this.m_dwStartIndex = 0;
        this.m_bCollectEnd = false;

        for(var i = 0; i < this.SAPA_BUFFER_SIZE ;i++){
            this.m_astItemList[i].clear();
        }
	}
});

MRoute.SAPAItem = Class({
	/// <summary>
	/// 服务区所在的导航段号
	/// </summary>
	m_dwSegeNo:0,	
	/// <summary>
	/// 服务区距离所在导航段结束点的距离
	/// </summary>
	m_dwDistance:0,
	/// <summary>
	/// 服务区的位置
	/// </summary>
	//m_stLocation:{},
	/// <summary>
	/// 服务区播放状态
	/// </summary>
	m_ePlayed:0,	

	"initialize":function(){
		
	},
    clear:function(){
        this.m_dwSegeNo = 0;
        this.m_dwDistance = 0;
        this.m_ePlayed = 0;
    }

});

MRoute.VPLocation = Class({

    dLon:0,                                    //  当前自车经度
    dLat:0,                                    //  当前自车纬度
    nAngle:0,                                  // 当前车辆的方向
	nSpeed:0,                                  // 当前自车速度

    nValid:0,                                  // GPS是否有效
    nSegId:0,                                  // 当前自车所在导航段
	nPtId:0,                                   // 当前自车所在形状点
    eState:0,                                  // 当前自车状态
    eFormWay:0,                                // 当前自车所在Link的FormWay
	eRoadClass:0,                              // 但前自车所在Link的RoadClass

    "initialize":function(){

    },
	// 克隆, 最好不包含引用对象，否则修改克隆体，被克隆者也发生改变
	Clone:function(){
		var vp = new MRoute.VPLocation();
		for(var i in this){
			if(typeof(i)!="function"){
				vp[i] = this[i];
			}
		}
		return vp;
	},

    getInfo:function(){
        var info = new Object();
        info["dLon"] = this.dLon;
        info["dLat"] = this.dLat;
        info["nAngle"] = this.nAngle;
        info["nSpeed"] = this.nSpeed;
//        info["nValid"] = this.nValid;
//        info["nSegId"] = this.nSegId;
//        info["nPtId"] = this.nPtId;
//        info["eState"] = this.eState;
//        info["eFormWay"] = this.eFormWay;
//        info["eRoadClass"] = this.eRoadClass;
        return info;
    }


});

MRoute.PalyToken = Class({
	/// <summary>
	/// 主要动作是否播报
	/// </summary>
	m_bMainActToken:true,
	/// <summary>
	/// 辅助动作是否播报
	/// </summary>
	m_bAssiActToken:true,
	/// <summary>
	/// 近接动作是否播报
	/// </summary>
	m_bProximityToken:true,
	/// <summary>
	/// 方面名称是否播报
	/// </summary>
	m_bTargetInfoToken:true,
		
	"initialize":function(){
		
	}
});

MRoute.CFrameForDG = Class({
    m_pstFrame:null,
	
	"initialize":function(pstFrame){
		this.m_pstFrame = pstFrame;
	},

	UpdateNaviInfor:function(dgInfo, linkRemain){
		this.m_pstFrame.m_pstFrame["UpdateNaviInfor"](dgInfo.getInfo());

        this.m_pstFrame.OnDGNaviInfoChanged(dgInfo, linkRemain);

	},

	EndEmulatorNavi:function(){
        this.m_pstFrame["StopEmulatorNavi"]();
		this.m_pstFrame.m_pstFrame["EndEmulatorNavi"]();
	},

	ArriveWay:function(nSegID){
        this.m_pstFrame.OnArriveWay(nSegID);
	},

    _parseInfo_:function(info){
        var arrData = [], curLane;
        for(var i = 0; i < 8; i++){
            curLane = (info>>(4*i)) & 0xf;
            if( 15 == curLane ){
                break;
            }
            else if( 13 == curLane )
            {
                curLane = 0;
            }
            else if( 14 == curLane )
            {
                curLane = 11;
            }
            arrData[i] = curLane;
        }
        return arrData;
    },

	ShowLaneInfo:function(dwBackInfo, dwSelectInfo){

        if( 0xffffffff == dwBackInfo  || 0 == dwBackInfo || 0 == dwSelectInfo)
        {
            return;
        }

        var arrBackInfo = this._parseInfo_(dwBackInfo);
        var arrSelInfo  = this._parseInfo_(dwSelectInfo);
        if(arrBackInfo.length == 0 || arrSelInfo.length == 0){
            return;
        }

        var arrSelFinal = [], firstSel = arrSelInfo[0];

        if(firstSel == 2 || firstSel == 4 || firstSel == 6 || firstSel == 7
            || firstSel == 9 || firstSel == 10 || firstSel == 11 || firstSel == 12 ){
            return ;  // 禁止原始选中状态为复杂车线
        }

        for(var k = 0; k < arrSelInfo.length; k++){
            if(firstSel != arrSelInfo[k]){
                return; // 选择不同，出错返回
            }
        }

        var bFound = false;
        for(var i = 0; i < arrBackInfo.length ;i++){
            if(arrBackInfo[i] == firstSel){
                break;
            }
            switch(arrBackInfo[i]){
                case 2:
                    if(0 == firstSel || 1 == firstSel){
                        bFound = true;
                    }
                    break;
                case 4:
                    if(0 == firstSel || 3 == firstSel){
                        bFound = true;
                    }
                    break;
                case 6:
                    if(1 == firstSel || 3 == firstSel){
                        bFound = true;
                    }
                    break;
                case 7:
                    if(0 == firstSel || 1 == firstSel || 3 == firstSel){
                        bFound = true;
                    }
                    break;
                case 9:
                    if(0 == firstSel || 5 == firstSel){
                        bFound = true;
                    }
                    break;
                case 10:
                    if(0 == firstSel || 8 == firstSel){
                        bFound = true;
                    }
                    break;
                case 11:
                    if(1 == firstSel || 5 == firstSel){
                        bFound = true;
                    }
                    break;
                case 12:
                    if(3 == firstSel || 5 == firstSel){
                        bFound = true;
                    }
                    break;
                default :
                    break;
            }

            if(bFound) break;

            arrSelFinal[i] = 15;
        }

        if(i < arrBackInfo.length){
            for(var j = 0; j < arrSelInfo.length; j++){
                arrSelFinal[i+j] = arrSelInfo[j];
            }

            // 保持数组长度一致
            while(arrSelFinal.length < arrBackInfo.length){
                arrSelFinal[arrSelFinal.length] = 15;
            }
            while(arrBackInfo.length < arrSelFinal.length){
                arrBackInfo[arrBackInfo.length] = 15;
            }
        }

		this.m_pstFrame.m_pstFrame["ShowLaneInfo"](arrBackInfo, arrSelFinal);
	},

	HideLaneInfo:function(){
		this.m_pstFrame.m_pstFrame["HideLaneInfo"]();
	},

	ShowCross:function(backId, foreId, segRemainDist){
		this.m_pstFrame.m_pstFrame["ShowCross"](backId, foreId, segRemainDist);
	},

    CrossRequest:function(arrBack, arrFore, arrSegId){
        this.m_pstFrame.m_pstFrame["CrossRequest"](arrBack, arrFore, arrSegId);
    },

	HideCross:function(){
		this.m_pstFrame.m_pstFrame["HideCross"]();
	},

	GetGPSIsValid:function(){
		return this.m_pstFrame.m_NaviStatus.GetValidGPS();
	},

	GetRouteType:function(){
        return this.m_pstFrame.m_NaviStatus.GetRouteCalcType();
	},

    GetCarSpeed:function(){
        //need discuss
        return this.m_pstFrame.OnGetCarSpeed();
    },

	PrepareVoice:function(){
	   // throw new NotImplementedException();
	},

	PlayNaviSound:function(strSound){
		this.m_pstFrame.m_pstFrame["PlayNaviSound"](0, strSound);
		return 0;
	}

});

MRoute.CVoiceManager = Class({
    m_pstFrame:null,
    m_dwVoiceStartTime:0,
    m_dwVoiceNeedTime:0,
    m_iPlayOneWordTime:50,

    "initialize":function(pstFrame){
        this.m_pstFrame = pstFrame;
    },

    SetPlayOneWordUseTime:function(nVal){
        this.m_iPlayOneWordTime = nVal;
    },

    RealTimePlay:function(eLevel, strSound){
        if(this.m_pstFrame)
        {
            var date = new Date();
            var dwCurTime = date.getTime();
            var len = strSound.length;
            // 上一条声音已播报完毕，可立即播报
            if((dwCurTime - this.m_dwVoiceStartTime) > this.m_dwVoiceNeedTime)
            {
                this.m_dwVoiceNeedTime = 0;
                this.m_dwVoiceStartTime = dwCurTime;
            }
//            else{
//                // 等上条播报完一秒后在播
//                var remainTime = this.m_dwVoiceNeedTime + this.m_dwVoiceStartTime - dwCurTime + 1000;
//            }
            this.m_dwVoiceNeedTime += len * this.m_iPlayOneWordTime;
            this.m_pstFrame.m_pstFrame["PlayNaviSound"](eLevel, strSound);

            return true;
        }

        return false;

    },

    GetRemainTime:function(){
        if(this.m_dwVoiceStartTime == 0)
        {
            return 0;
        }
        else
        {
            var date = new Date();
            var dwCurTime = date.getTime();
            if(dwCurTime - this.m_dwVoiceStartTime > this.m_dwVoiceNeedTime)
            {
                return 0;
            }
            else
            {
                return this.m_dwVoiceNeedTime - (dwCurTime - this.m_dwVoiceStartTime);
            }
        }
    },

    GetNoVoiceTime:function(){

        var date = new Date();
        var dwCurTime = date.getTime();
        if(this.m_dwVoiceStartTime == 0)
        {
            return dwCurTime;
        }
        else
        {
            if(dwCurTime - this.m_dwVoiceStartTime > this.m_dwVoiceNeedTime)
            {
                return (dwCurTime - this.m_dwVoiceStartTime) - this.m_dwVoiceNeedTime;
            }
            else
            {
                return 0;
            }
        }
    }

});

MRoute.CFrameForVP = Class({
	m_pstFrame:null,

	
	"initialize":function(){
	
	},
	
	CFrameForVP:function(pstFrame){
		this.m_pstFrame = pstFrame;
	},

	VehiclePositionChange:function(){
		//throw new NotImplementedException();
	},

    GetGpsList:function()
    {

    },

	SwitchRoad:function(bSwitch){
		//throw new NotImplementedException();
	},

	Reroute:function(){
		//throw new NotImplementedException();
	},

	GetIsCanMM:function(){
		//throw new NotImplementedException();
	},

	GetNaviLocation:function(stLocation){
		//throw new NotImplementedException();
	},

	GetLogKey:function(){
		//throw new NotImplementedException();
	},

	UpdatePCD:function(pData){
		//throw new NotImplementedException();
	}
});

MRoute.CNaviStatus = Class({

    m_iGPSGeoX:0, //GPS坐标X
    m_iGPSGeoY:0, //GPS坐标Y
    m_iTotalRouteDist:0,
    m_iTotalRemainDist:0, //总剩余里程
    m_iTotalRemainTime:0, //总估计剩余时间
    m_iSegmentNo:0, //当前段号
    m_iSegmentRemainDist:0, //分段剩余里程
    m_iSegmentRemainTime:0,
    m_iSimNaviSpeed:0, //模拟导航速度:0, 单位为米/秒
    m_iPlayOneWordUseTime:0, //播报每个字需要的时间:0, 单位为毫秒/字
    m_bStartEmulator:false, //是否开始模拟导航
    m_bStartNavi:false, //是否开始实际导航
    m_bPauseDG:false, // 是否暂停DG
    m_bValid:false, // GPS是否有效
    m_bSwitchMapStatus:false, //切换主辅路的状态
    m_bIsDTReady:false, //记录动态信息是否已经下
    m_bDrawDt:false, //是否绘制动态交通信息
    m_bTrafficRadio:false, //移动交通台功能
    m_bVoicePrompt:false, /// 语音提示 TRUE为详细提示，FALSE为简洁提示。默认值为FALSE
    m_bEleyePrompt:false, //电子眼提示  TRUE为提示，FALSE为不提示。默认值为TRUE
    m_bNetConnect:false, //网络是否连接  TRUE为连接，FALSE为未连接
    m_CalcRouteType:0,
    m_cNearRoad:"", //匹配的道路名称(导航过程中记载当前到道路的名称)
    m_cNextRoad:"", //导航过程中下一条道路的名称


    "initialize":function () {
        this.ResetAllMapStatus();
    },

    ResetAllMapStatus:function () {
        this.m_iGPSGeoX = 116.288948; // GPS坐标X
        this.m_iGPSGeoY = 39.983688; // GPS坐标Y

        this.m_iTotalRouteDist = 0; // 路径总里程
        this.m_iTotalRemainDist = 0; // 总的剩余里程
        this.m_iTotalRemainTime = 0; // 总的估计剩余时间

        this.m_iSegmentNo = -1; // 当前段号
        this.m_iSegmentRemainDist = 0;  //分段剩余里程

        this.m_iSimNaviSpeed = 60;
        this.m_iPlayOneWordUseTime = 50;

        this.m_CalcRouteType = MRoute.CalcRouteType.CalcRouteType_NULL;

        this.m_bStartEmulator = false;  //是否开始模拟导航
        this.m_bStartNavi = false;  //是否开始实际导航

        this.m_bPauseDG = false;  // 是否暂停DG

        this.m_bValid = false;  // GPS是否有效

        this.m_bSwitchMapStatus = false;

        this.m_bIsDTReady = false;

        this.m_bDrawDt = true;
        this.m_bTrafficRadio = true;
        this.m_bVoicePrompt = true;
        this.m_bEleyePrompt = true;
        this.m_bNetConnect = false;

        this.m_cNextRoad = "";
        this.m_cNearRoad = "";
    },

    SetGPSGeoX:function (iGPSGeoX) {
        this.m_iGPSGeoX = iGPSGeoX;
    },

    GetGPSGeoX:function () {
        return this.m_iGPSGeoX;
    },

    SetGPSGeoY:function (iGPSGeoY) {
        this.m_iGPSGeoY = iGPSGeoY;
    },

    GetGPSGeoY:function () {
        return this.m_iGPSGeoY;
    },

    SetTotalDist:function (iTotalDist) {
        this.m_iTotalRouteDist = iTotalDist;
    },

    GetTotalDist:function () {
        return this.m_iTotalRouteDist;
    },

    SetTotalRemainDist:function (iTotalRemainDist) {
        this.m_iTotalRemainDist = iTotalRemainDist;
    },

    GetTotalRemainDist:function () {
        return this.m_iTotalRemainDist;
    },

    SetTotalRemainTime:function (iTotalRemainTime) {
        this.m_iTotalRemainTime = iTotalRemainTime;
    },

    SetSegmentRemainTime:function (iSegRemainTime) {
        this.m_iSegmentRemainTime = iSegRemainTime;
    },

    GetSegmentRemainTime:function () {
        return this.m_iSegmentRemainTime;
    },

    GetTotalRemainTime:function () {
        return this.m_iTotalRemainTime;
    },

    SetSegmentRemainDist:function (iSegmentRemainDist) {
        this.m_iSegmentRemainDist = iSegmentRemainDist;
    },

    GetSegmentRemainDist:function () {
        return this.m_iSegmentRemainDist;
    },

    SetSegmentNo:function (iSegmentNo) {
        this.m_iSegmentNo = iSegmentNo;
    },

    GetSegmentNo:function () {
        return this.m_iSegmentNo;
    },

    SetSimNaviSpeed:function (iSimuNaviSpd) {
        if (iSimuNaviSpd > 200) {
            iSimuNaviSpd = 200;
        }
        this.m_iSimNaviSpeed = iSimuNaviSpd;
    },

    GetSimNaviSpeed:function () {
        return this.m_iSimNaviSpeed;
    },

    SetPlayOneWordUseTime:function (iUseTime) {
        this.m_iPlayOneWordUseTime = iUseTime;
    },

    GetPlayOneWordUseTime:function () {
        return this.m_iPlayOneWordUseTime;
    },

    SetValidGPS:function (bValidGPS) {
        this.m_bValid = bValidGPS;
    },

    GetValidGPS:function () {
        return this.m_bValid;
    },

    SetIsStartNavi:function (bStartNavi) {
        this.m_bStartNavi = bStartNavi;
    },

    GetIsStartNavi:function () {
        return this.m_bStartNavi;
    },

    SetIsStartEmulator:function (bStartEmulator) {
        this.m_bStartEmulator = bStartEmulator;
    },

    GetIsStartEmulator:function () {
        return this.m_bStartEmulator;
    },

    SetIsDgPause:function (bPause) {
        this.m_bPauseDG = bPause;
    },

    GetIsDgPause:function () {
        return this.m_bPauseDG;
    },

    SetSwitchRoadStatus:function (bSwitchRoadStatus) {
        this.m_bSwitchMapStatus = bSwitchRoadStatus;
    },

    GetSwitchRoadStatus:function () {
        return this.m_bSwitchMapStatus;
    },

    SetDTReady:function (bIsReady) {
        this.m_bIsDTReady = bIsReady;
    },

    GetDTReady:function () {
        return this.m_bIsDTReady;
    },

    SetDrawDt:function (bDrawDt) {
        this.m_bDrawDt = bDrawDt;
    },

    GetDrawDt:function () {
        return this.m_bDrawDt;
    },

    SetPlayTrafficRadio:function (bTrafficRadio) {
        this.m_bTrafficRadio = bTrafficRadio;
    },

    GetPlayTrafficRadio:function () {
        return this.m_bTrafficRadio;
    },

    SetVoicePrompt:function (btVoicePromt) {
        this.m_bVoicePrompt = btVoicePromt;
    },

    GetVoicePrompt:function () {
        return this.m_bVoicePrompt;
    },

    SetEleyePrompt:function (btEleyePrompt) {
        this.m_bEleyePrompt = btEleyePrompt;
    },

    GetEleyePrompt:function () {
        return this.m_bEleyePrompt;
    },

    SetNetStatus:function (bNetStatus) {
        this.m_bNetConnect = bNetStatus;
    },

    GetNetStatus:function () {
        return this.m_bNetConnect;
    },

    SetRouteCalcType:function (eCalcRouteType) {
        this.m_CalcRouteType = eCalcRouteType;
    },

    GetRouteCalcType:function () {
        return this.m_CalcRouteType;
    },

    SetNearRoad:function (pNearRoad) {
        this.m_cNearRoad = pNearRoad;
    },

    GetNearRoad:function () {
        return this.m_cNearRoad;
    },

    SetNextRoad:function (pNextRoad) {
        this.m_cNextRoad = pNextRoad;
    },

    GetNextRoad:function () {
        return this.m_cNextRoad;
    }
});

MRoute.RouteManager = Class({

    Paths:null,         //所有路径
    selectId:-1,
    navigateId:-1,
    "initialize":function(){
    },

    getRoutes:function(){
        return this.Paths;
    },

    getRouteNum:function(){
        if(this.Paths != null){
            return this.Paths.length;
        }
        return 0;
    },

    setRoutes:function(Paths){
        this.Paths = Paths;
        // 默认选中首条路径
        if(Paths != null && Paths.length > 0){
            this.selectId = 0;
        }
        else{
            this.selectId = -1;
        }

        this.navigateId = -1;
    },

    selectRoute:function(iRouteType){
        if (this.Paths != null && this.Paths.length > 0) {

            for (var i = 0; i < this.Paths.length; i++) {
                if (this.Paths[i].getStrategy() == iRouteType) {
                    this.selectId = i;
                    break;
                }
            }

            // 没找到对应路径 , 设为首条路径
            if(this.selectId < 0){
                this.selectId = 0;
            }
        }

        return this.getSelectRoute();
    },

    getSelectIndex:function(){
        return this.selectId;
    },

    getSelectRoute:function(){
        if(this.selectId >= 0){
            return this.Paths[this.selectId];
        }

        return null;
    },

    getNavigateIndex:function(){
        return this.navigateId;
    },

    getNaviRoute:function(){
        if(this.navigateId >= 0){
            return this.Paths[this.navigateId];
        }

        return null;
    },

    setNaviRoute:function(){
        if(this.selectId >= 0){
            this.navigateId = this.selectId;
        }
        else if(this.Paths != null && this.Paths.length > 0){
            this.navigateId = 0;
        }

        if(this.navigateId >= 0){
            return this.Paths[this.navigateId];
        }

        return this.getNaviRoute();
    }
});

MRoute.JsTMC = Class({


    pathManager:null,
    selectId:-1,
    selectPath:null,    // 当前选择路径
    carLon:0,           // 当前车位
    carLat:0,

    distList:[],        // 当前选择路径 locationCode 对应路段长度
    segmentStartId:[],  // 当前选择路径 各分段首个locationCode 对应的编号

    pathStartId:[],
    wholeCodeList:[],   // 全部路径locationCode列表
    wholeStateList:[],  // locationCode 对应路况

    timer:null,         // 触发计时器
    m_pstFrame:null,    // 外部支持类


    "initialize":function(pstFrame, manager){
        this.m_pstFrame = pstFrame;
        this.pathManager = manager;
    },


    routeUpdate:function(){
        // 重置路径
        this.selectId = -1;
        var paths = this.pathManager.getRoutes(),
            whList = [];

        if(paths != null && paths.length > 0){
            for(var i = 0; i < paths.length; i++){
                var res = paths[i].getLocCodeList();
                this.pathStartId[i] = whList.length;
                if(whList.length == 0){
                    whList = res[0];
                }
                else{
                    whList = whList.concat(res[0]);
                }
            }
        }
        this.wholeCodeList = whList;
        this.wholeStateList = [];
        if(paths != null){
            this.netRequest();
//            TestInfoLog("TBT-TMC-routeUpdate-code list:" + whList.toString());
        }

    },

    setCarLoc:function(x,y){
        this.carLon = x;
        this.carLat = y;
    },

    netRequest:function(){
        if(!this.m_pstFrame.m_NaviStatus.GetDrawDt()){
            return ;
        }

        // need supply 暂停导航时是否不必要更新tmc信息
        var codeList = this.wholeCodeList;
        if(codeList != null && codeList.length > 0){

            var url = "http://112.65.233.139/poiserve/MapABC-ASA-V3-0717/Server/trafficinfo.php";
            url += "?locs=";

            var bNext = false, num = 0;
            for(var i = 0; i < codeList.length;i++){
                // 只查询非0的locationCode对应路况
                if(codeList[i] != 0){
                    num++;
                    if(bNext){
                        url += ",";
                    }
                    url += codeList[i];
                    bNext = true;
                }
            }

            if(num == 0){// 防范整条路径都没有locationCode
                this.m_pstFrame.OnTMCReceived();
                return;
            }
            url += "&x=" + this.carLon + "&y=" + this.carLat;

            //发送请求
            this.m_pstFrame.OnNetRequest(2, url, null, null, true);
        }
    },

    isRouteBlocked:function(segId, segRemainDist){

        var naviId = this.pathManager.getNavigateIndex(),
            naviPath = this.pathManager.getNaviRoute();

        if(naviPath == null){
            return false;
        }

        var res = naviPath.getLocCodeList(),
            codeList = res[0],
            sId = res[2][segId],
            stateList = [],
            startId = this.pathStartId[naviId],
            endId = this.wholeStateList.length;
        if(naviId+1 < this.pathManager.getRouteNum()){
            endId = this.pathStartId[naviId+1];
        }

        // codeList 和 stateList等长
        for(var i = startId, id = 0; i < endId; i++, id++){
            stateList[id] = this.wholeStateList[i];
        }

        return naviPath.isRouteBlocked(segId, segRemainDist, sId, codeList, stateList);

    },

    isNavigate:function(){
        return this.m_pstFrame.IsNavigate();
    },

    receiveNetData:function(dataStream){

        var bSuc = this._decode_(dataStream);

        // 不论是否解析成功，都通知外部tmc数据已准备好，避免无tmc信息时无法告知外部路径已准备好
        this.m_pstFrame.OnTMCReceived();

        if(bSuc){
            this.m_pstFrame.OnTMCUpdate();
        }
        return bSuc;
    },

    getRoadStatus:function(locCode){
        for(var i = 0; i < this.wholeCodeList.length; i++){
            if(locCode == this.wholeCodeList[i])
            {
                return this.wholeStateList[i];
            }
        }
        return 0;
    },

    _updateSelect_:function(){
        this.selectId = this.pathManager.getSelectIndex();
        this.selectPath = this.pathManager.getSelectRoute();
        if(this.selectPath != null){
            var res = this.selectPath.getLocCodeList();
            this.distList  = res[1];
            this.segmentStartId = res[2];
        }
    },

    /**
     * 获取创建光柱所需信息
     * @param iStart        到路径起点的距离
     * @param len           要获取路况的路段长度
     * @return [Array, Array]      各段长度列表，各段路况列表
     */
    createTMCBar:function(iStart, len){

        var distList = [], stateList = [];

        // 状态数据是否查询到了
        if(!this.wholeStateList || this.wholeStateList.length == 0){
            TestInfoLog("TBT-TMC-createTMCBar: no state data!");
            return [distList,stateList];
        }

        if(this.selectId != this.pathManager.getSelectIndex()){
            this._updateSelect_();
        }

        if(this.selectPath != null){

            // 范围修正，限制在路长范围内
            var routeDist = this.selectPath.getDistance();
            if(iStart < 0){
                iStart = 0;
            }
            else if(iStart >= routeDist ){
                //TestInfoLog("TBT-TMC-createTMCBar: start location error!");
                iStart = routeDist - 1;
            }

            if(len < 0 || len + iStart > routeDist){
                len = routeDist - iStart;
            }

            var offset = this.pathStartId[this.selectId];
            var num = this.distList.length;
            if(this.wholeStateList.length > offset){

                var left = iStart,
                    segId = 0;
                //求当前导航段编号
                var segs = this.selectPath.getSegments();
                while(left > 0){
                    var segDist = segs[segId].getDistance();
                    if(left < segDist){
                        break;
                    }
                    left -= segDist;
                    segId++;
                }

                var i = this.segmentStartId[segId],
                    dist = 0;
                while(left > 0){
                    if(left < this.distList[i]){
                        dist = this.distList[i] - left;
                        distList.push(dist);
                        stateList.push(this.wholeStateList[i+offset]);
                        i++;
                        break;
                    }
                    left -= this.distList[i];
                    i++;
                }

                while(dist < len && i < num){
                    distList.push(this.distList[i]);
                    stateList.push(this.wholeStateList[i+offset]);
                    dist += this.distList[i];
                    i++;
                }

                if(dist > len){
                    var lastId = distList.length - 1;
                    distList[lastId] -= dist - len;
                }
            }
        }

        return [distList, stateList];
    },


    _decode_:function(data){

        if(data == null || data.length == 0){
            return false;
        }

        var arrStr = data.split(","),
            listLen = this.wholeCodeList.length,
            len = Math.min(arrStr.length, listLen),
            badNum = 0,
            arrVal = [];
        for(var k = 0; k < arrStr.length; k++){
            arrVal[k] = Number(arrStr[k]);
            if(isNaN(arrVal[k])){
                arrVal[k] = 0;
            }
            if(arrVal[k] == 0){
                badNum++;
            }
        }

        if(badNum*2 > arrStr.length){
            return false;
        }


        k = 0;
        this.wholeStateList = new Array(listLen);
        for(var i = 0; i < listLen; i++)
        {
            // locationCode 为0的直接赋0，其他的沿用查询结果
            if(this.wholeCodeList[i] == 0){
                this.wholeStateList[i] = 0;
            }
            else{
                this.wholeStateList[i] = arrVal[k];
                k++;

                // 剩余路段locationCode为0,未查询其状态
                if(k == len){
                    i++;
                    break;
                }
            }

        }

        for(; i < listLen; i++){
            this.wholeStateList[i] = 0;
        }

        return true;
    },

//    setNetRequestState:function(eState){
//
//    },

    start:function(){
        if(this.timer!= null){
            this.stop();
        }

        var self = this;
        this.timer = window.setInterval(function(){
            if(self.isNavigate()){
                self.netRequest();
            }

        }, 120000); //1000*60*2

    },

    stop:function(){
        if(this.timer){
            window.clearInterval(this.timer);
            this.timer = null;
        }
    }


});
MRoute.ProbeInfo = Class({
    BJYear:0, // GPS(BJ)时间－－年
    BJMonth:0, // GPS(BJ)时间－－月
    BJDay:0, // GPS(BJ)时间－－日
    BJHour:0, // GPS(BJ)时间－－时
    BJMinute:0, // GPS(BJ)时间－－分
    BJSecond:0, // GPS(BJ)时间－－秒

    GpsLat:0, // 纬度, 单位度 (正值为北纬, 负值为南纬)
    GpsLon:0, // 经度, 单位度 (正值为东经, 负值为西经)
    Speed:0, // 速度, 单位千米/时
    Angle:0, // 方向角, 单位度

    MatchLat:0,             // VP 匹配经纬度， 单位同上面的GPS经纬度是一致的
    MatchLon:0,

    nReliable:0,       // VP 匹配结果
    bIsEndLinkOfSeg:false, // 匹配link是否是当前导航段的最后一个link
    ucSegNaviAction:0,           // 当前导航段的导航段的动作

    "initialize":function () {

    },

    getDayTime:function(){
        return this.BJHour * 3600 + this.BJMinute * 60 + this.BJSecond;
    },

    match:function(info){
        if(Math.round(this.GpsLat* CoordFactor) == Math.round(info.GpsLat*CoordFactor)
            && Math.round(this.GpsLon * CoordFactor) == Math.round(info.GpsLon*CoordFactor)
            && Math.round(this.Angle*1000) == Math.round(info.Angle*1000)){
            return true;
        }
        return false;
    }
});

function uIntToStr(dwVal){
    var str = String.fromCharCode((dwVal & 0xFF000000) >>> 24);
    str += String.fromCharCode((dwVal&0x00FF0000)>>>16);
    str += String.fromCharCode((dwVal&0x0000FF00)>>>8);
    str += String.fromCharCode(dwVal&0x000000FF);
    return str;
}

function strToUInt(str){
    if(!str || str.length != 4){
        return 0;
    }
    return str.charCodeAt(0) * 0x1000000
        + str.charCodeAt(1) * 0x10000
        + str.charCodeAt(2) * 0x100
        + str.charCodeAt(3);
}

function uShortToStr(dwVal){
    var str = String.fromCharCode((dwVal&0x0000FF00)>>> 8);
    str += String.fromCharCode(dwVal&0x000000FF);
    return str;
}

function strToUShort(str){
    if(!str || str.length != 4){
        return 0;
    }
    return str.charCodeAt(0) * 256
        + str.charCodeAt(1);
}

function uLong64ToStr(llVal){
    var val = 0x100000000,
        high = Number((llVal / val).toFixed(0)),
        low = llVal % val;

    return uIntToStr(high) + uIntToStr(low);
}

var PROBE_VERSION= 1;
var CoFactor = 3600*256;
var GPS_INDEX_LIST_MAX = 39;
var TURNING_GPS_MAX=21;

MRoute.ProbeManager = Class({

    m_ip:0xac15025e, //服务器IP
    m_port:6901, //服务器端口
    m_idmode:1, // 0: 使用本地配置ID， 1： 使用健全后的ValidID；
    m_naviflag:0, //有路径才上传位置。 0：都上传、1：有路径才上传。
    m_frequency:60, //上传频率。[1 - 120 秒]

    m_pValidID:"00000000",

    // sample data
    m_pGpsArray:[],
    m_pSampleIndexList:[],
    m_GPSPosArrayForTurningJudge:[], // sample gps pos for turning judge

    m_State:0,  // state infor
    m_bNodeSign:false,
    m_bNavigation:false, // flag if VP match CCP to route

    m_eProbeResult:null,
    m_pData:null,

    m_TrafficRadio:null,

    "initialize":function(trafficRadio){
        this.m_TrafficRadio = trafficRadio;
        this.m_frequency = 60;
        this.m_pGpsArray = [];
    },

    SetUUID:function(uuid){
        this.m_pValidID = uuid;
    },

    SetSampleFrequency:function(freq){
        if(freq > 0){
            this.m_frequency = freq;
            var len = this.m_pGpsArray.length;
            if(len > freq){
                this.m_pGpsArray = this.m_pGpsArray.slice(0, len-freq);
            }
        }
    },



    GetProbePackageData:function(){
        var len = this.m_pGpsArray.length;
        if(len > 0){
            this._extractSample_();
            var listLen = this.m_pSampleIndexList.length,
                lastId = this.m_pSampleIndexList[listLen-1];
            this._setCarState_(this.m_pGpsArray[lastId]);
            // only sample 255B for latest 39 items
            var start = 0;
            if(listLen > GPS_INDEX_LIST_MAX){
                start = listLen - GPS_INDEX_LIST_MAX;
            }

            this.m_pData = this._probeInfoPacked_(start, listLen-1);
        }

        return null;

    },

    ProbeProc:function(probeInfo){
        if(this._probeInfoAnalyse_(probeInfo)){
            if(this._trigger_()){
                this._probeProcSub_();
                return true;
            }
        }
        return false;
    },

    _probeProcSub_:function(){
        // filter sample by speed
        this._extractSample_();

        var len = this.m_pSampleIndexList.length;

        if(len > GPS_INDEX_LIST_MAX){
            //	total data size of GPS_INDEX_LIST_MAX  items is bigger than 255B
            var packLen = 0;
            while(packLen < len){
                var start = packLen,
                    end = 0,
                    cutId;
                if(len - packLen > GPS_INDEX_LIST_MAX){
                    end = packLen + GPS_INDEX_LIST_MAX-1;
                }
                else {
                    end = len -1;
                }
                cutId = this.m_pSampleIndexList[end];

                this._setCarState_(this.m_pGpsArray[cutId]);
                this._probeInfoPacked_(start,end);

                // send by udp protocol
                this._probeInfoSendToSvr_();

                packLen += GPS_INDEX_LIST_MAX;
            }
        }
        else {
            this._setCarState_(this.m_pGpsArray[len-1]);
            this._probeInfoPacked_(0,len-1);

            // send by udp protocol
            this._probeInfoSendToSvr_();
        }

        this._probeInit_();

    },



    _probeInfoAnalyse_:function(probeInfo){
        var len = this.m_pGpsArray.length;
        if(len < this.m_frequency){
            if(len > 0 && probeInfo.match(this.m_pGpsArray[len-1])){
                return false;
            }

            if(probeInfo.speed > 127){
                probeInfo.speed = 127;
            }

            this.m_pGpsArray.push(probeInfo);
            if(probeInfo.speed > 7){
                this.m_GPSPosArrayForTurningJudge.push({x:probeInfo.GpsLon,y:probeInfo.GpsLat});

                if(this.m_GPSPosArrayForTurningJudge.length > 2 * TURNING_GPS_MAX){
                    this.m_GPSPosArrayForTurningJudge.splice(0,TURNING_GPS_MAX);
                }
            }
            return true;
        }
        return false;
    },

    _extractSample_:function(){
        var idList = [0],
            posArr = this.m_pGpsArray,
            posLen = posArr.length;
        this.m_pSampleIndexList = idList;

        if(posLen > 1){
            for(var i = 1; i < posLen-1; i++){
                var curSpeed = posArr[i].nSpeed,
                    preSpeed = posArr[i-1].nSpeed,
                    nextSpeed = posArr[i+1].nSpeed,
                    valid = false;

                if(idList.length > posLen-2){
                    break;
                }

                if(curSpeed >= 80 && (preSpeed < 80 || nextSpeed < 80)){
                    valid = true;
                }
                else if(curSpeed >= 40 && (preSpeed < 40 || nextSpeed < 40)){
                    valid = true;
                }
                else if(curSpeed >= 20 && (preSpeed < 20 || nextSpeed < 20)){
                    valid = true;
                }
                else if(curSpeed >= 10 && (preSpeed < 10 || nextSpeed < 10)){
                    valid = true;
                }
                else if(curSpeed >= 5 && (preSpeed < 5 || nextSpeed < 5)){
                    valid = true;
                }
                else{
                    this._reviseSampleIndexList_(i);
                }

                if(valid){
                    idList.push(i);
                }
            }
        }
        idList.push(posLen-1);
    },

    _reviseSampleIndexList_:function(index){
        var end = this.m_pSampleIndexList.length- 1,
            preId = this.m_pSampleIndexList[end];

        if(index - preId > 5){
            this.m_pSampleIndexList.push(index);
        }
        else if(index-preId > 2){
            var deltaX = (this.m_pGpsArray[index].GpsLon - this.m_pGpsArray[preId].GpsLon)*3600000,
                deltaY = (this.m_pGpsArray[index].GpsLat - this.m_pGpsArray[preId].GpsLat)*3600000,
                dist = Math.sqrt(deltaX*deltaX + deltaY*deltaY);
            if(dist > 323.4){
                this.m_pSampleIndexList.push(index);
            }
        }
    },

    _isTurning_:function(){
        var arrPos = this.m_GPSPosArrayForTurningJudge,
            posLen = arrPos.length;
        if(posLen > TURNING_GPS_MAX){
            var dA1 = CalcMathAngle(arrPos[posLen-TURNING_GPS_MAX].x,arrPos[posLen-TURNING_GPS_MAX].y,
                    arrPos[posLen-12].x, arrPos[posLen-12].y),
                dA2 = CalcMathAngle(arrPos[posLen-3].x,arrPos[posLen-3].y,
                    arrPos[posLen-2].x, arrPos[posLen-2].y),
                dA3 = CalcMathAngle(arrPos[posLen-2].x,arrPos[posLen-2].y,
                    arrPos[posLen-1].x, arrPos[posLen-1].y),
                diff1 = this._getDiff_(dA2,dA1),
                diff2 = this._getDiff_(dA3,dA1),
                diff3 = this._getDiff_(dA3,dA2);
            if(diff1 > Math.PI/3 && diff2 > Math.PI/3 && diff3 < Math.PI/4){
                return true;
            }
        }
        return false;
    },

    _getDiff_:function (d1, d2) {
        var diff = Math.abs(d1 - d2);
        if (diff > Math.PI) {
            diff = 2 * Math.PI - diff;
        }
        return diff;
    },

    _trigger_:function(){
        this.m_eProbeResult = MRoute.ProbeResult.ProbeResult_NoGPS;
        var len = this.m_pGpsArray.length;
        if(len > 1){
            var t1 = this.m_pGpsArray[0].getDayTime(),
                t2 = this.m_pGpsArray[len-1].getDayTime(),
                diffTime = t2 - t1;
            if(diffTime < 0){
                diffTime += 3600 * 24;
            }

            if(diffTime > this.m_frequency || len > this.m_frequency){
                this.m_eProbeResult = MRoute.ProbeResult.ProbeResult_Normal;
                this.m_GPSPosArrayForTurningJudge  = [];// reset gps pos list
                return true;
            }
            else if(this._isTurning_()){
                this.m_eProbeResult = MRoute.ProbeResult.ProbeResult_Turning;
                this.m_GPSPosArrayForTurningJudge  = [];
                return true;
            }
        }
        return false;
    },


    //? 如何将有符号数转为伪二进制字符串
    _probeInfoPacked_:function(start, end){

        var strBuf = uShortToStr(this.m_State); // state

        if(this.m_State & 0x80){ //uuid
            strBuf += this.m_pValidID;
        }

        if(this.m_State & 0x1000){
            var angle = Number((this.m_pGpsArray[end].nAngle/2 + 0.5).toFixed(0));
            strBuf += String.fromCharCode(angle);
        }

        /************************** current gps ******************************
         字段		大小（B）		说明						参考类型
         Latitude	4		当前浮动车的地理纬度，单位1/256秒	DWORD
         Longitude	4		当前浮动车的地理经度，单位1/256秒	DWORD
         Time		2		当前GPS采样的北京时间，单位秒		WORD
         Speed		1		当前GPS测位速度，单位km/h			BYTE
         **********************************************************************/
        var info = this.m_pGpsArray[end],
            res = this._formatData_(info),
            lat = res[0],
            lon = res[1],
            time = res[2],
            speed = res[3];

        strBuf += uIntToStr(lat) + uIntToStr(lon);
        // time
        var t1 = (time >= 43200) ? time- 43200 : time;
        strBuf += uShortToStr(t1);
        strBuf += String.fromCharCode(speed);

        // problem: 此处差值可正可负，如何转为字符串？
        /************************* offset gps ***s***************************
         字段		大小（B）		说明					参考类型
         Lat_off		2		GPS采样纬度偏移值，单位1/256秒	INT16
         Long_off	2		GPS采样经度偏移值，单位1/256秒	INT16
         Time_off	1		GPS时间偏移差，单位秒			BYTE
         Speed		1		GPS测位速度						BYTE
         *********************************************************************/
        for(var i = end-1; i >= start; --i){
            var id = this.m_pSampleIndexList[i],
                curRes = this._formatData_(this.m_pGpsArray[id]),
                latOff = curRes[0] - lat,
                lonOff= curRes[1] - lon,
                ttOff = curRes[2] - time,
                curSpeed = curRes[3];
            // omit
            // var tt = (INT8)ttOff;
            if(ttOff < -120){
                continue;
            }
            strBuf += uShortToStr(latOff) + uShortToStr(lonOff);
            strBuf += uShortToStr(ttOff);
            strBuf += String.fromCharCode(curSpeed);
        }

       //首位存储数据包大小
       strBuf = String.fromCharCode(strBuf.length+1) + strBuf;
       return strBuf;

    },

    _formatData_:function(info){
        var lat,
            lon,
            speed,
            time = info.getDayTime();
        // ？ lat ， lon
        if(info.nReliable){
            lat = Number((info.MatchLat*CoFactor).toFixed(0));
            lon = Number((info.MatchLon*CoFactor).toFixed(0));
        }
        else{
            lat = Number((info.GpsLat*CoFactor).toFixed(0));
            lon = Number((info.GpsLon*CoFactor).toFixed(0));
        }

        speed = info.Speed & 0x7f;
        speed |= (info.nReliable << 7) & 0x80;

        return [lat, lon, time, speed];
    },

    _probeInfoSendToSvr_:function(){
        if(this.m_TrafficRadio){
            this.m_TrafficRadio.UpdatePF(this.m_pData, this.m_eProbeResult);
        }
    },

    _setCarState_:function(pos){
        /******************************************************************************
         字段					大小（bit）			说明					参考类型
         State_Exist_ID			1	0x80	表示是否存在ID字段，默认为0
         0：无ID  1：有ID

         State_is_Navi			1	0x40	表示导航状态，默认为0
         0：非导航状态 1：导航状态

         State_is_TrfLgt			1	0x20	表示是否有红绿灯，默认为0
         0：有红绿灯 1：无红绿灯

         State_carriage			2 0x00| 0x08 | 0x10	表示车道位置，默认为00
         00：直行车道
         01：左转车道
         10：右转车道

         State_is_Empty			1	0x04	表示汽车是否空载，默认问0
         0:空载
         1:载客

         State_VP_Reliability	1	0x02	表示匹配可信度
         0：不可信
         1： 可信

         Reserved3				1	0x01	上下午
         ********************************************************************************/

        var state =  (PROBE_VERSION << 8) & 0x0f00; //四位版本号

        state |= 0x80;   // 有VaildID
        state |= 0x1000; // ADD_LAST_ANGLE

        if (pos.BJHour >= 12 )
        {
            state |= 0x1;
        }

        if (!this.m_bNodeSign)
            state |= 0x20;

        // judge the end point reliabe
        if (pos.nReliable)
            state |= 0x2;

        if(pos.nReliable  && pos.bIsEndLinkOfSeg)
        {
            var MA = MRoute.MainAction;
            state |= 0x40; // 是否导航状态
            switch(pos.ucSegNaviAction)
            {
                case MA.MainAction_Turn_Left:
                case MA.MainAction_Slight_Left:
                case MA.MainAction_Turn_Hard_Left:
                case MA.MainAction_UTurn:
                case MA.MainAction_Merge_Left:
                    state |= 0x8;
                    break;
                case MA.MainAction_Turn_Right:
                case MA.MainAction_Slight_Right:
                case MA.MainAction_Turn_Hard_Right:
                case MA.MainAction_Merge_Right:
                    state |= 0x10;
                    break;
                default:
                    // 直行
                    break;
            }
        }

        this.m_State = state;
    },


    _probeInit_:function(){
        this.m_pGpsArray = [];
        this.m_State = 0;
    }

});



MRoute.CFrameForTrafficRadio = Class({
    m_pstFrame:null,
    m_pIdMap:[],

    "initialize":function (pstFrame) {
        this.m_pstFrame = pstFrame;
        this.m_pIdMap = new Array(0, 0, 0, 0, 0, 0);
    },

    NetRequestHTTP:function (iConnectId, strUrl, strHead, strData, bGet) {
        this.m_pIdMap[iConnectId] = this.m_pstFrame.OnNetRequest(1, strUrl, strHead, strData, bGet);
    },

    ShowTrafficPanel:function (data, size) {
        this.m_pstFrame.m_pstFrame["ShowTrafficPanel"](data, size);
    },

    HideTrafficPanel:function () {
        this.m_pstFrame.m_pstFrame["HideTrafficPanel"]();
    },

    PlayNaviSound:function (type, str) {
        this.m_pstFrame.m_pstFrame["PlayNaviSound"](type, str);
    },

    NoticeRequestTrafficInfo:function () {
        this.m_pstFrame.OnRequestTrafficInfo();
    },

    GetPlayTrafficVoice:function () {
        return this.m_pstFrame.m_NaviStatus.GetPlayTrafficRadio();
    },

    GetShowTrafficPic:function () {
        // need supply
        return false;
        //return this.m_pstFrame.m_NaviStatus.GetPlayTrafficRadio();
    },

    GetInnerConnectId:function (cnId) {
        for (var i = 1; i < 6; i++) {
            if (this.m_pIdMap[i] == cnId) {
                return i;
            }
        }
        return 0;
    }


});

MRoute.JsTBT = Class({

    naviPath:null, // 当前导航路径
    selectPath:null, // 当前选中路径

    m_routeMgr:null,
    m_pstVoiceMgr:null,
    m_pstFrame:null,

    m_pstProbe:null,
    m_pstDG:null,
    m_pstVP:null,
    m_pstTMC:null,
    m_pstFrameForDG:null,
    m_pstTrafficRadio:null,
    m_pstFrameForTraffic:null,
    m_voiceManager:null,

    m_NaviStatus:null,
    m_eNaviState:MRoute.NaviState.NaviState_Common,
    m_eCalcType:null,

    m_bDataReady:false,
    m_bNotifyed:false, // 是否已通知路径准备情况
    m_bReroute:false,

    m_arrDest:[],
    m_curDestID:0,
    // CFrameForRP m_pstFrameForRP:null,
    // CFrameForTMC* m_pstFrameForTMC:null,
    // CFrameForTmcBar* m_pstFrameForTmcBar:null,
    // CFrameForTrafficRadio* m_pstFrameForTR:null,

    /**
     * 初始化, 必先于其他接口函数调用
     * @param TBTFrame      由用户实现的外部支持类的引用
     * @param strWorkPath   工作路径，TBT的一些配置文件等资料，以及输出信息将输出到此路径下
     * @param usrCode       用户码，从高德申请的到
     * @param usrBatch      用户码，从高德申请的到
     * @param deviceId      每个设备号必须唯一，可以是SIM卡号，也可以是设备唯一ID
     */
    "initialize":function (TBTFrame, strWorkPath, usrCode, usrBatch, deviceId) {
        if (null == TBTFrame /*|| null == strWorkPath*/) {
            return false;
        }
        // need supply
        this.m_pstFrame = TBTFrame;
        this.m_pstFrameForDG = new MRoute.CFrameForDG(this);
        this.m_voiceManager = new MRoute.CVoiceManager(this);
        this.m_pstDG = new MRoute.NDG(this.m_pstFrameForDG, this.m_voiceManager);
        this.m_pstVP = new MRoute.VP(this);
        this.m_NaviStatus = new MRoute.CNaviStatus();

        this.m_routeMgr = new MRoute.RouteManager();

        this.m_pstTMC = new MRoute.JsTMC(this, this.m_routeMgr);
        if (this.m_pstTMC != null) {
            this.m_pstTMC.start();
        }


        this.m_pstFrameForTraffic = new MRoute.CFrameForTrafficRadio(this);
        try {
            this.m_pstTrafficRadio = new MRoute.TrafficRadio(this.m_pstFrameForTraffic, usrCode, usrBatch, deviceId);
            this.m_pstProbe = new MRoute.ProbeManager(this.m_pstTrafficRadio);
        } catch (e) {
//            console.log('MRoute.TrafficRadio module needed if navigation functionality to supply')
        }

        // m_pRoute = new CTBTRoute();
        // m_pstVP->StartMapmatch();
        return true;
    },


    /**
     * 接口函数，不再使用TBT时用来释放它管理的内部资源
     * 调用后不可调用其他接口
     */
    "Destroy":function () {
        if (this.m_pstTMC != null) {
            this.m_pstTMC.stop();
            this.m_pstTMC = null;
        }
        this.m_pstFrame = null;
        this.m_pstDG = null;
        this.m_pstVP = null;
        this.m_pstFrameForDG = null;
        this.m_NaviStatus = null;
        this.m_routeMgr = null;
    },

    /**
     * 接口函数，调用此接口告知TBT当前的车辆位置
     * @param stLocation 车位所在经纬度，参见NavPoint定义
     */
    "SetCarLocation":function (stLocation) {
        this.m_NaviStatus.SetGPSGeoX(stLocation.x);
        this.m_NaviStatus.SetGPSGeoY(stLocation.y);
    },

    /**
     * 接口函数，设置模拟导航的速度
     * 在系统初始化时，以及模拟导航速度变化时调用此接口
     * @param iEmulatorSpeed 所设置的车速，单位公里/小时
     */
    "SetEmulatorSpeed":function (iEmulatorSpeed) {
        this.m_NaviStatus.SetSimNaviSpeed(iEmulatorSpeed);
        if (this.m_pstDG) {
            var speed = this.m_NaviStatus.GetSimNaviSpeed();
            this.m_pstDG.setEmulatorSpeed(speed);
        }
    },

    /**
     * 接口函数，设置是否播报电子眼
     * 在系统初始化时，以及电子眼播报设置变化时调用此接口，默认播报电子眼
     * @param iIsEleyePrompt 0 为不播报，1为播报
     */
    "SetEleyePrompt":function (iIsEleyePrompt) {
        var bval = iIsEleyePrompt ? true : false;
        this.m_NaviStatus.SetEleyePrompt(bval);
        this.m_pstDG.setEleyePrompt(bval);
    },

    /**
     * 接口函数，设置导航的播报类型
     * 在系统初始化时，以及播报类型设置变化时调用此接口，默认详细播报
     * @param iNaviType 播报类型，1 简单播报，2 详细播报
     */
    "SetNaviType":function (iNaviType) {
        if (iNaviType == 1) {
            this.m_NaviStatus.SetVoicePrompt(false);
        } else {
            this.m_NaviStatus.SetVoicePrompt(true);
        }
    },

    /**
     * 接口函数，设置TTS播报每个字需要的时间
     * 为了获得更好的播报效果，在导航前调用此接口来设置最准确的值
     * @param useTime 播报每个字需要的时间，单位为毫秒
     */
    "SetPlayOneWordUseTime":function (useTime) {
        this.m_NaviStatus.SetPlayOneWordUseTime(useTime);
        if (this.m_voiceManager != null) {
            this.m_voiceManager.SetPlayOneWordUseTime(useTime);
        }
    },

    /**
     * 接口函数，通知网络请求成功或失败
     * @param connectID 连接号，区分不同连接
     * @param eNetState 请求状态,参见MRoute.NetRequestState定义
     *        1    请求成功
     *        2    请求失败
     *        3    请求超时
     *        4    用户手动结束请求
     */
    m_eRPNetState:MRoute.NetRequestState.NetRequestState_NULL,
    "SetNetRequestState":function (connectID, eNetState) {
        //目前只有RP请求
        // need supply
        if (connectID == 0) {
            this.m_eRPNetState = eNetState;
        }
    },


    /**
     * 接口函数，选择路径
     * @param iRouteType 路径类型
     * @return {Number} 0-7 被选中道路的路径类型
     *                        若没有指定类型，则选中首条路径，并返回其类型
     *                  -1 没有任何道路可选
     */
    "SelectRoute":function (iRouteType) {
        this.selectPath = this.m_routeMgr.selectRoute(iRouteType);
        if (this.selectPath != null) {
            return this.selectPath.getStrategy();
        }
        return -1;
    },


    /**
     * 设定导航路径
     * @private
     */
    _setNaviRoute_:function () {
        if (this.m_eNaviState == MRoute.NaviState.NaviState_Routing) {    // 正在计算路径，直接返回
            return false;
        }
        this.naviPath = this.m_routeMgr.setNaviRoute();
        if (this.naviPath != null) {
            // 只在gps导航时修改算路类型为单一，模拟导航不会重算路？
            // 如果根据路况来，模拟导航也还是有可能reroute的
            // 请求单路径耗费流量小
            if (this.m_eCalcType == MRoute.CalcType.CalcType_Multi) {
                this.m_eCalcType = (this.naviPath.getStrategy() == MRoute.PathStrategy.Strategy_TMC_FAST) ?
                    MRoute.CalcType.CalcType_TMC : MRoute.CalcType.CalcType_Best;
            }

            return true;
        }
        return false;
    },

    /**
     * 将导航路径通知到各子模块
     * @private
     */
    _notifyNaviRoute_:function () {
        if (this.m_pstVP != null) {
            this.m_pstVP.SetRoute(this.naviPath.getSegments());
        }

        if (this.m_pstDG != null) {
//                var coorlist = this.GetNaviCoor();//用起点来代替GPS点
//                var pt = new MRoute.NaviPoint(coorlist[0], coorlist[1]);
            var vpl = new MRoute.VPLocation();
            vpl.nSegId = 0;
            vpl.nPtId = 0;
            vpl.dLon = this.m_NaviStatus.GetGPSGeoX();
            vpl.dLat = this.m_NaviStatus.GetGPSGeoY();

            this.m_pstDG.SetNaviRoute(this.naviPath, true, vpl);
        }

        if (this.m_pstTMC != null) {
            var firstSeg = this.naviPath.getSegmentByID(0),
                startPt = firstSeg.getDetailedPoint(0);
            this.m_pstTMC.setCarLoc(startPt.x, startPt.y);
        }

        if (this.m_pstTrafficRadio) {
            this.m_pstTrafficRadio.SetNaviRoute(this.naviPath);
        }

        var dist = this.naviPath.getDistance();
        this.m_NaviStatus.SetTotalDist(dist);

        this.m_eNaviState = MRoute.NaviState.NaviState_StartNavi;
    },

    OnArriveWay:function (nSegId) {

        // 基于顺序抵达，且一个分段只有一个途径点的假设
        var len = this.m_arrDest.length;
        if (this.m_curDestID < len) {
            this.m_arrDest[this.m_curDestID].IsArrived = true;
            this.m_curDestID++;
        }
        var id = this.m_curDestID;
        if (this.m_curDestID == len || nSegId < 0) {
            this["StopNavi"]();
            id = -1;
        }

        this.m_pstFrame["ArriveWay"](id);

    },

    bfirstChange:false,
    OnCarLocationChange:function (bValid, bMatched) {
        var carloc = this.m_pstVP.GetVPLocation();
        this.m_NaviStatus.SetValidGPS(true);
        if (!this.m_NaviStatus.GetIsStartEmulator()) {
            this.m_NaviStatus.SetGPSGeoX(carloc.dLon);
            this.m_NaviStatus.SetGPSGeoY(carloc.dLat);
        }

        if (bValid) {
            // 非gps导航状态，即使通知dg，dg也没有什么响应动作而是立即返回
            if (bMatched) {

//                if (!this.bfirstChange) {
//                    TestInfoLog("TBT-OnCarLocationChange-first loc changing:" + (new Date()).getTime());
//                }
                this.m_pstDG.CarLocationChange(carloc);
//                if (!this.bfirstChange) {
//                    this.bfirstChange = true;
//                    TestInfoLog("TBT-OnCarLocationChange-first loc changed:" + (new Date()).getTime());
//                }

            }

            // 只有有效点才通知外部车位信息
            this.m_pstFrame["CarLocationChange"](carloc.getInfo());
        }
    },

    OnPushProbeInfo:function (info) {
        if (this.m_pstProbe) {
            this.m_pstProbe.ProbeProc(info);
        }
    },

    OnGetCarSpeed:function () {
        if(this.m_NaviStatus.GetIsStartEmulator())
        {
            return this.m_NaviStatus.GetSimNaviSpeed();
        }
        var carLoc = this.m_pstVP.GetVPLocation();
        if (carLoc != null) {
            return carLoc.nSpeed;
        }
        return 0;
    },

    /**
     * 响应内部对象DG发出的重算路请求，转发请求给Frame
     */

    lastRerouteNotifyTime:0,  /// 最后一次通知外部reroute的时间
    OnReroute:function () {
        // 仅在gps导航进行中才reroute
        if (this.m_pstDG.IsGPSNaving()) {

            // 避免频繁发送reroute通知
            var curTime = (new Date()).getTime();
            if(curTime - this.lastRerouteNotifyTime > 15000){
                this.m_pstFrame["Reroute"]();
                this.lastRerouteNotifyTime = curTime;
            }
        }
    },

    OnSetValidGPS:function (bval) {
        this.m_NaviStatus.SetValidGPS(bval);
    },

    nLinkRemainDist:Number.MIN_VALUE,

    OnDGNaviInfoChanged:function (dgInfo, linkRemainDist) {

        this.nLinkRemainDist = linkRemainDist;
        var data = this.m_NaviStatus;
        data.SetTotalRemainDist(dgInfo.nRouteRemainDist);
        data.SetTotalRemainTime(dgInfo.nRouteRemainTime);
        data.SetSegmentRemainDist(dgInfo.nSegRemainDist);
        data.SetSegmentRemainTime(dgInfo.nSegRemainTime);
        data.SetSegmentNo(dgInfo.nCurSegIndex);
        if (dgInfo.eNaviType != MRoute.NaviType.NaviType_Emul) {
            data.SetGPSGeoX(dgInfo.fLongitude);
            data.SetGPSGeoY(dgInfo.fLatitude);
        }
    },


    OnTMCReceived:function () {
        if (!this.m_bNotifyed && this.m_bDataReady) {
            this._notifyReceiveState_(MRoute.RouteRequestState.RouteRequestState_Success);
        }
    },

    OnTMCUpdate:function () {
        // 先更新路况
        this.m_pstFrame["TMCUpdate"]();

        // 只有真正GPS导航时，才考虑静默算路
        if (this.m_NaviStatus.GetIsStartNavi() && !this.m_NaviStatus.GetIsStartEmulator()) {
            //如果当前车位在当前link对应的路口150m范围内则不进行重算，避免在路口突然提示用户转向
            if (this.nLinkRemainDist > 150) {
                if (this.m_pstTMC.isRouteBlocked(this.m_NaviStatus.GetSegmentNo(), this.m_NaviStatus.GetSegmentRemainDist())) {
                    this.m_pstFrame["RerouteForTMC"]();
                }
            }
        }

    },

    connectNum:0,
    usedConnectId:[],

    OnNetRequest:function (modelId, url, head, data, bGet) {
        var conId;
        if (this.usedConnectId.length > 0) {
            conId = this.usedConnectId.pop();
        }
        else {
            conId = this.connectNum;
            this.connectNum++;
        }
        this.m_pstFrame["NetRequestHTTP"](modelId, conId, url, head, data, bGet);
        return conId;

    },

    /**
     * 接口函数，开始GPS导航
     * @return {Boolean} 请求是否成功
     */
    "StartGpsNavi":function () {
        if (!this.m_bDataReady) {
            return false;
        }

        this.m_NaviStatus.SetIsStartNavi(true);
        if (this.m_eNaviState != MRoute.NaviState.NaviState_StartNavi) {
            if (this._setNaviRoute_()) {
                //TestInfoLog("TBT-StartGpsNavi:" + (new Date()).getTime());

                this.bfirstChange = false;

                this._notifyNaviRoute_();
            }
            else {
                this.m_NaviStatus.SetIsStartNavi(false);
                return false;
            }
        }


        this.m_pstDG.StartNavi(true);

        return true;

    },

    /**
     * 接口函数，开始模拟导航
     * @return {Boolean} 请求是否成功
     */
    "StartEmulatorNavi":function () {
        if (!this.m_bDataReady) {
            return false;
        }

        this.m_NaviStatus.SetIsStartEmulator(true);

        if (this.m_eNaviState != MRoute.NaviState.NaviState_StartNavi) {

            if (this._setNaviRoute_()) {
                this._notifyNaviRoute_();
            }
            else {
                this.m_NaviStatus.SetIsStartEmulator(false);
                return false;
            }
        }

        this.m_pstDG.StartNavi(false);

        return true;
    },

    /**
     * 接口函数，停止模拟导航
     * 路径信息仍然存在，可以再次导航
     */
    "StopEmulatorNavi":function () {

        this.m_pstDG.StopEmulatorNavi();

        // 同时不在gps导航状态 置为普通状态
        if (!this.m_NaviStatus.GetIsStartNavi()) {
            this.m_eNaviState = MRoute.NaviState.NaviState_Common;
        }

        this.m_NaviStatus.SetIsStartEmulator(false);
    },


    /**
     * 接口函数，暂停导航
     */
    "PauseNavi":function () {
        var bSim = true;
        if (this.m_pstDG.IsGPSNaving()) {
            bSim = false;
        }
        else if (!this.m_NaviStatus.GetIsStartEmulator()) {
            bSim = false;
        }

        this.m_pstDG.PauseNavi(bSim);
        //并不准确，标志变更后很有可能过一定时间才停止导航，非立即响应的
        this.m_NaviStatus.SetIsDgPause(true);
    },

    /**
     * 接口函数，恢复导航
     */
    "ResumeNavi":function () {
        var bSim = true;
        if (this.m_pstDG.IsGPSNaving()) {
            bSim = false;
        }
        else if (!this.m_NaviStatus.GetIsStartEmulator()) {
            bSim = false;
        }
        if (this.m_NaviStatus.GetIsDgPause()) {
            this.m_pstDG.ResumeNavi(bSim);
            this.m_NaviStatus.SetIsDgPause(false);
        }
    },

    /**
     * 接口函数，停止导航，不论是GPS还是Emulator导航
     * 路径被销毁，下次导航需要重新请求路径
     */
    "StopNavi":function () {

        if (this.m_pstDG != null) {
            if (this.m_NaviStatus.GetIsDgPause()) {
                this.m_pstDG.ResumeNavi();
            }
        }

        if (this.m_NaviStatus.GetIsStartNavi()) {
            this.m_pstDG.StopGPSNavi();
            this.m_NaviStatus.SetIsStartNavi(false);
        }

        if (this.m_NaviStatus.GetIsStartEmulator()) {
            this.m_pstDG.StopEmulatorNavi();
            this.m_NaviStatus.SetIsStartEmulator(false);
        }

        this.m_eNaviState = MRoute.NaviState.NaviState_Common;
        this._releasePath_();

    },

    _releasePath_:function () {

        if (this.m_pstTrafficRadio) {
            this.m_pstTrafficRadio.SetNaviRoute(null);
        }

        if (this.m_pstVP) {
            this.m_pstVP.SetRoute(null);
        }

        if (this.m_pstTMC) {
            this.m_pstTMC.routeUpdate();
        }

        if (this.naviPath || this.selectPath ) {
            this.naviPath = null;
            this.selectPath = null;
            this.m_pstFrame["RouteDestroy"]();	// 通知使用者路径删除
        }

        this.m_routeMgr.setRoutes(null);

        this.m_bDataReady = false;

    },

    lastSpeed:0,

    /**
     * 接口，接收外部gps信息
     * @param longitude 经度, 单位度
     * @param latitude  纬度, 单位度
     * @param speed     速度，单位公里/小时？
     * @param direction 方向，单位度，以正北为基准，顺时针增加
     * @param year      年
     * @param month     月
     * @param day       日
     * @param hour      时
     * @param minute    分
     * @param second    秒
     */
    "SetGPSInfo":function (longitude, latitude, speed, direction, year, month, day, hour, minute, second) {
        if (this.m_pstVP != null) {
            var gpsData = new MRoute.NmeaData();
            gpsData.lon = longitude;
            gpsData.lat = latitude;
            gpsData.speed = speed;
            gpsData.track = direction;
            gpsData.Year = year;
            gpsData.Month = month;
            gpsData.Day = day;
            gpsData.Hour = hour;
            gpsData.Minute = minute;
            gpsData.Second = second;

            this.m_pstVP.SetNmea(gpsData);
        }

        this.lastSpeed = speed;

    },

    /**
     * 请求路径
     * TBT要将请求结果状态通过SetRequestRouteState通知TBTFrame
     * @param eCalcType 路径类型，参见MRoute.CalcType
     *    0    最优路径
     *    1    快速路优先
     *    2    距离优先
     *    3    普通路优先
     *    4    考虑实时路况的路线
     *    5    多路径（一条考虑实时交通路况路线，一条最优路线（未考虑实时交通））
     * @param destList  []途径点及终点数组，含各点经纬度信息，参见NaviPoint
     * @return {Boolean}
     */
    "RequestRoute":function (eCalcType, destList) {
        if (destList == null) {
            return false;
        }

        destList = this._clearRepeated_(destList);
        var lastID = destList.length - 1;
        if (lastID < 0) return false;


        var startList = [];

        //如果当前GPS有效,则直接使用轨迹中最新三点
        if (this.m_NaviStatus.GetValidGPS()) {
            var arrPos = this.m_pstVP.GetGpsList(3);
            if (arrPos != null && arrPos.length > 0) {

                for (var i = 0; i < arrPos.length; i += 2) {
                    startList.push(new MRoute.NvPoint(arrPos[i], arrPos[i + 1]));
                }
            }
        }

        //没有gps点，用指定位置初始化
        if (startList.length == 0) {
            var sx = this.m_NaviStatus.GetGPSGeoX(),
                sy = this.m_NaviStatus.GetGPSGeoY();
            startList.push(new MRoute.NvPoint(sx, sy));
        }


        return this["RequestRouteHaveStart"](eCalcType, startList, destList);
    },

    _pointEqual_:function (pt1, pt2) {
        return Math.round(pt1.x * CoordFactor) == Math.round(pt2.x * CoordFactor)
            && Math.round(pt1.y * CoordFactor) == Math.round(pt2.y * CoordFactor);

    },

    _clearRepeated_:function (ptList) {
        if (ptList == null || ptList.length == 1) {
            return ptList;
        }

        var newList = [];
        newList.push(ptList[0]);

        var i = 1;
        while (i < ptList.length) {
            if (!this._pointEqual_(ptList[i - 1], ptList[i])) {
                newList.push(ptList[i]);
            }
            i++;
        }

        return newList;
    },

    /**
     * 接口函数，带起点的路径请求 // need supply
     * @param eCalcType  算路类型
     *      0 最优路径 1 快速路优先 2 距离优先 3 普通路优先 4 考虑TMC路况 5 一条TMC路径，一条最优路（无TMC）
     * @param startList  []起点数组，含各点经纬度信息，参见NaviPoint
     * @param destList  []途径点及终点数组，含各点经纬度信息，参见NaviPoint
     * @return {Boolean}
     */
    "RequestRouteHaveStart":function (eCalcType, startList, destList) {
        if(eCalcType > 5 || eCalcType < 0){
            eCalcType = 5;
        }
        if (startList == null || destList == null) {
            return false;
        }

        var i, j ;
        for(i = 0; i < startList.length; i++){
            startList[i].x = Number(startList[i].x);
            startList[i].y = Number(startList[i].y);
        }

        for(j = 0; j < destList.length; j++){
            destList[j].x = Number(destList[j].x);
            destList[j].y = Number(destList[j].y);
        }


        startList = this._clearRepeated_(startList);
        destList = this._clearRepeated_(destList);

        if (this.m_eNaviState == MRoute.NaviState.NaviState_Routing) {    // 正在计算路径，直接返回
            return false;
        }
        else if (this.m_eNaviState == MRoute.NaviState.NaviState_StartNavi) { // 已经开始导航，停止导航

            if (this.m_NaviStatus.GetIsStartNavi()) {
                this.m_pstDG.StopGPSNavi();
                this.m_NaviStatus.SetIsStartNavi(false);
            }

            if (this.m_NaviStatus.GetIsStartEmulator()) {
                this.m_pstDG.StopEmulatorNavi();
                this.m_NaviStatus.SetIsStartEmulator(false);
            }
        }

        this._releasePath_();

        // 此时应发送算路请求
        // 没有RP模块，请求代码暂时放在此处
        {
            var lastID = destList.length - 1;
            if (lastID < 0){
                return false;
            }

            var routeType = this._switchType_(eCalcType),
                dist = GetMapDistance(startList[0].x, startList[0].y, destList[0].x, destList[0].y),
                routeFlag = this._compositeFlag_(); //539361320;

            if(dist > 100){
                routeFlag = 539365416; //距离较远，则梯级算路，尽量选择高速路
            }

            if (startList.length == 1 && destList.length == 1 && this._pointEqual_(startList[0], destList[0])) {
                // 避免起止点相同
                return false;
            }

            var url = "http://112.65.233.139/poiserve/MapABC-ASA-V3-0717/Server/routenew1.php";

            // 起点
            url += "?xys=";
            for (i = 0; i < startList.length; i++) {
                url += startList[i].x + "," + startList[i].y + ";";
            }
            url += ";";

            // 途径点，终点
            for (j = 0; j < destList.length; j++) {
                url += destList[j].x + "," + destList[j].y;
                if (j != lastID) {
                    url += ";";
                }
            }
            url += "&type=" + routeType + "&flag=" + routeFlag;

            this.m_eNaviState = MRoute.NaviState.NaviState_Routing;

            //发送请求
            this.OnNetRequest(3, url, null, null, true);

            if (this.m_bReroute) {
                this.m_NaviStatus.SetRouteCalcType(MRoute.CalcRouteType.CalcRouteType_Reroute);
            }
            else {
                this.m_NaviStatus.SetRouteCalcType(MRoute.CalcRouteType.CalcRouteType_Command);
            }
        }

        this.m_eCalcType = eCalcType;
        var len = destList.length;
        this.m_arrDest = [];
        this.m_curDestID = 0;
        for (var n = 0; n < len; n++) {
            var node = new MRoute.DestNode;
            node.x = destList[n].x;
            node.y = destList[n].y;
            node.IsArrived = false;
            this.m_arrDest.push(node);
        }
        return true;
    },

    _compositeFlag_:function () {
        var dwFlag = MRoute.CalcFlag.Flag_DETAIL_ROAD_ATTR;
        dwFlag |= MRoute.CalcFlag.Flag_INGNORE_LIGHT;
        dwFlag |= MRoute.CalcFlag.Flag_DYNAMIC_TRAFFIC;
        dwFlag |= MRoute.CalcFlag.Flag_TRAFFIC_CALC;
        dwFlag |= MRoute.CalcFlag.Flag_TMC;
        dwFlag |= MRoute.CalcFlag.Flag_LOC_CODE;
        //dwFlag |= MRoute.CalcFlag.Flag_TIME_TMC;
        return dwFlag;
    },

    /**
     * 将内部算路类型转化为服务器路径请求类型
     * @param eCalcType
     * @return {Number} 发往服务器的路径请求类型
     * @private
     */
    _switchType_:function (eCalcType) {
        var nRouteType;
        switch (eCalcType) {
            case MRoute.CalcType.CalcType_Best:
            {
                nRouteType = 0;     //ROUTE_TYPE_PRIORITY_SPEED;
            }
                break;
            case MRoute.CalcType.CalcType_High:
            {
                nRouteType = 1;     //ROUTE_TYPE_PRIORITY_FEE;
            }
                break;
            case MRoute.CalcType.CalcType_Dist:
            {
                nRouteType = 2;     //ROUTE_TYPE_PRIORITY_DISTANCE;
            }
                break;
            case MRoute.CalcType.CalcType_TMC:
            {
                nRouteType = 4;     //ROUTE_TYPE_PRIORITY_TMC_FAST;
            }
                break;
            case MRoute.CalcType.CalcType_Norm:
            {
                nRouteType = 5;     //ROUTE_TYPE_PRIORITY_NORMAL_ROAD;
            }
                break;
            case MRoute.CalcType.CalcType_Multi:
            {
                nRouteType = 11;     //ROUTE_TYPE_PRIORITY_MULTI3;
            }
                break;

            default:
            {
                nRouteType = 0;     //ROUTE_TYPE_PRIORITY_SPEED;
            }
                break;
        }
        return nRouteType;
    },


    /**
     * 接口函数，负责接收解析各连接所请求到的数据
     * @param modelID  模块号：1 移动交通台，2 TMC，3 在线导航
     * @param connectID  连接编号
     * @param postStream 数据流
     */
    "ReceiveNetData":function (modelID, connectID, postStream) {
        if (modelID == 3) {
            this.m_eNaviState = MRoute.NaviState.NaviState_Common;
            this.m_bNotifyed = false;
            if (postStream == null) {
                this._notifyReceiveState_(MRoute.RouteRequestState.RouteRequestState_NetERROR);
                return;
            }

            try {
                var pd = new MRoute.PathDecode(postStream);
                if (pd == null) { // 创建对象失败的防范
                    this._notifyReceiveState_(MRoute.RouteRequestState.RouteRequestState_DataFormatError);
                    return;
                }

                var Paths = pd.getPaths();
                pd = null;

                this.m_routeMgr.setRoutes(Paths);
                this.selectPath = this.m_routeMgr.getSelectRoute();
                this.nLinkRemainDist = 0;

                if (Paths == null || Paths.length == 0) {
                    this._notifyReceiveState_(MRoute.RouteRequestState.RouteRequestState_DataFormatError);
                    return;
                }
                else {

                    // 更新route信息
                    for (var i = 0; i < Paths.length; i++) {
                        Paths[i].updateRouteInfo();
                    }

                    this.m_bDataReady = true;
                    if (!this.m_NaviStatus.GetDrawDt()) {
                        this._notifyReceiveState_(MRoute.RouteRequestState.RouteRequestState_Success);
                    }

                    if (this.m_pstTMC) {
                        var firstSeg = Paths[0].getSegmentByID(0),
                            startPt = firstSeg.getDetailedPoint(0);
                        this.m_pstTMC.setCarLoc(startPt.x, startPt.y);
                        this.m_pstTMC.routeUpdate();
                    }
                }
            }
            catch (err) {// 如果请求失败，PathDecode会抛出错误
                this._notifyReceiveState_(MRoute.RouteRequestState.RouteRequestState_NetERROR);
            }
        }
        else if (modelID == 2) {
            this.m_pstTMC.receiveNetData(postStream);
        }
        else if (modelID == 1) {
//            var innerId = this.m_pstFrameForTraffic.GetInnerConnectId(connectID);
//            this.m_pstTrafficRadio.receiveNetData(innerId, postStream);
            this._tParseTrafficRadio_(postStream);
        }
        this.usedConnectId.push(connectID);

    },
    /**
     * 接收Traffic请求到的信息结果，并且解析，周期是1min
     * @param postStream
     * @private
     */
    _tParseTrafficRadio_:function (postStream) {
        console.log("_tParseTrafficRadio_ content:"+postStream);
        if (postStream) {
            var strArr = postStream.split(";;;");
            if (strArr && strArr.length > 0) {
                if (strArr[0].length) {
                    if (new Date().getTime() > this.m_pstDG.getEndTimeOfLastTTS() && this.m_pstDG.getNaviInfo().nSegRemainDist >300 ) //todo,300是经验值
                        this.m_pstFrame["PlayNaviSound"](2, strArr[0]);
                }
                if (strArr[1].length) {
                    var id = Number(strArr[1]);
                    if (!isNaN(id)) {
                        this.m_pstFrame["ShowTrafficPanel"](id);
                    }
                }
            }
        }

    },

    _notifyReceiveState_:function (eState) {
        //TestInfoLog("TBT-_notifyReceiveState_:" + (new Date()).getTime());

        this.m_eNaviState = MRoute.NaviState.NaviState_Common;
        this.m_bNotifyed = true;

        // reroute状态，如成功接收到数据，立即重启导航
        if (eState == MRoute.RouteRequestState.RouteRequestState_Success && this.m_bReroute) {
            this.m_pstFrame["SetRequestRouteState"](0); //eState
            this.lastRerouteNotifyTime = 0; // reroute成功，则不在计数，以便下次reroute
            this.m_bReroute = false;
            this["StartGpsNavi"]();
        } else {
            this.m_pstFrame["SetRequestRouteState"](eState);
        }
    },

    /**
     *
     * @param driveTime
     * @param tmcTime
     * @return {Number} 驾驶时间估计值
     * @private
     */
    _getTime_:function (driveTime, tmcTime) {

        if (tmcTime < driveTime / 2) {// tmc 比最快限速时间短太多，则不可信
            return driveTime;
        }
        return tmcTime;
    },


    /**
     * 接口函数，响应外部调用，执行路径重算
     */
    "Reroute":function () {
        if (this.m_pstVP == null) {
            return;
        }

        // 更新目的地列表，废弃已到达点
        var newlist = [];
        var len = this.m_arrDest.length;
        for (var i = 0; i < len; i++) {
            if (!this.m_arrDest[i].IsArrived) {
                newlist.push(this.m_arrDest[i]);
            }
        }

        if (newlist.length > 0) {
            this.m_bReroute = true;
            this["RequestRoute"](this.m_eCalcType, newlist);
        }
    },

    /**
     * 接口函数，手动播报当前导航信息
     * 会视当前路况播报，不一定是前一条播报信息的重复
     * @return {Boolean}
     */
    "PlayNaviManual":function () {
        this.m_pstDG.manualPlay();
        return true;
    },


    /**
     * 接口函数，打开动态交通信息
     * 系统初始化完默认动态交通信息是打开的
     */
    "OpenTMC":function () {
        this.m_NaviStatus.SetDrawDt(true);
    },

    /**
     * 接口函数，关闭动态交通信息
     * 关闭动态交通信息后CreateTMCBar与GetRoadStatus将不能使用
     */
    "CloseTMC":function () {
        this.m_NaviStatus.SetDrawDt(false);
    },

    _tGetPredictPoint_:function () {
        var list = [],
            dist = this.m_NaviStatus.GetSegmentRemainDist(),
            path = this.naviPath,
            segNum = path.getSegmentCount(),
            curSegID = this.m_NaviStatus.GetSegmentNo(),
            curSeg = path.getSegmentByID(curSegID);

        if (!curSeg) {
            return list;
        }

        // 添加当前车位，当前seg终点
        list.push(this.m_NaviStatus.GetGPSGeoX());
        list.push(this.m_NaviStatus.GetGPSGeoY());
        var segPtNum = curSeg.getDetailedPointsCount(),
            Pt = curSeg.getDetailedPoint(segPtNum - 1);
        list.push(Pt.x);
        list.push(Pt.y);

        // 添加剩余segment的link中点
        for (var i = curSegID + 1; i < segNum; i++) {
            var seg = path.getSegmentByID(i),
                linkNum = seg.getLinkCount();
            for (var j = 0; j < linkNum; j++) {
                var link = seg.getLink(j),
                    startId = link.getStartPtId(),
                    linkPtNum = link.getDetailedPointsCount(),
                    middleId = Math.floor(startId + linkPtNum / 2);
                Pt = seg.getDetailedPoint(middleId);
                if (Pt != null) {
                    list.push(Pt.x);
                    list.push(Pt.y);
                }

            }
            dist += seg.getDistance();
            if (dist > 10000) {
                break;
            }
        }

        return list;
    },

    _tNeedRequestTraffic_:function () {
        if (!this.m_NaviStatus.GetPlayTrafficRadio()) {
            return false;
        }

        if (this.m_NaviStatus.GetIsStartNavi() || this.m_NaviStatus.GetIsStartEmulator()) {
            return this.m_NaviStatus.GetTotalRemainDist() >= 2000;
        }
        else {
            return this._getPath_().getDistance() >= 2000;
        }
    },

    OnRequestTrafficInfo:function () {

        var bSuc = false;
        if (this.IsNavigate()) {
            var xyList = this._tGetFrontPtList_();
            bSuc = this._tRequestTrafficRadio_(xyList);
        } else {
            if (this.m_pstVP && this.lastSpeed > 6) {
                var gpsList = this.m_pstVP.GetGpsListWithAngle(10);
                bSuc = this._tRequestWithoutRoute_(gpsList);
            }
        }

        return bSuc;
    },

    // 获得路径前方10公里范围内的预测点
    _tGetFrontPtList_:function () {
        var list = [],
            path = this.naviPath,
            segNum, curSegID, curSeg, dist, angle;

        if (!path) {
            return list;
        }

        segNum = path.getSegmentCount();
        if (this.m_NaviStatus.GetIsStartEmulator() || this.m_NaviStatus.GetIsStartNavi()) {
            var info = this.m_pstDG.getNaviInfo();
            curSegID = info.nCurSegIndex;
            dist = info.nSegRemainDist;
            //angle = info.nCarDirection;
            Pt = new MRoute.NvPoint(info.fLongitude, info.fLatitude);
        }
        else {
            curSegID = 0;
            dist = path.getSegmentByID(curSegID).getDistance();
            angle = -1;
        }

        curSeg = path.getSegmentByID(curSegID);
        if (!curSeg) {
            return list;
        }

        if (angle < 0) {
            //angle = curSeg.getPointAngle(0);
            Pt = curSeg.getDetailedPoint(0);
        }

        // 添加当前车位
        //list.push({x:Pt.x, y:Pt.y, a:angle});
        list.push({x:Pt.x, y:Pt.y});

        var segPtNum = curSeg.getDetailedPointsCount(),
            Pt = curSeg.getDetailedPoint(segPtNum - 1);
        // 添加当前seg终点
        //angle = curSeg.getPointAngle(segPtNum - 1);
        //list.push({x:Pt.x, y:Pt.y, a:angle});
        list.push({x:Pt.x, y:Pt.y});

        // 添加剩余segment的link中点
        for (var i = curSegID + 1; i < segNum; i++) {
            var seg = path.getSegmentByID(i),
                linkNum = seg.getLinkCount();
            for (var j = 0; j < linkNum; j++) {
                var link = seg.getLink(j),
                    startId = link.getStartPtId(),
                    linkPtNum = link.getDetailedPointsCount(),
                    middleId = Math.floor(startId + linkPtNum / 2);
                Pt = seg.getDetailedPoint(middleId);
                //angle = seg.getPointAngle(middleId);
                if (!(Pt == null /*|| angle == null*/)) {
                    //list.push({x:Pt.x, y:Pt.y, a:angle});
                    list.push({x:Pt.x, y:Pt.y});
                }

            }
            dist += seg.getDistance();
            if (dist > 10000) {
                break;
            }
        }

        return list;
    },

    // 非导航模式下
    _tRequestWithoutRoute_:function (ptList) {
        if (!this.m_NaviStatus.GetPlayTrafficRadio()) {
            return false;
        }

        var strUrl = "http://211.151.71.28:8888/aheadtraffic.php?xys=";
        if (ptList && ptList.length > 1) {
            var end = ptList.length;
            for (var i = 0; i < end; i++) {
                strUrl += ptList[i].x + "," + ptList[i].y + "," + ptList[i].a;
                if (i < end - 1) {
                    strUrl += ";";
                }
            }
        } else {
            return false;
        }

        //strUrl +="121.455669,31.223854,90;121.456098,31.223854,90";
        //strUrl +="116.303323,39.985025,90;116.303962,39.985021,90;116.304101,39.985041,90";

        strUrl += "&state=1632";

        this.OnNetRequest(1, strUrl, null, null, false);
        return true;
    },

    IsNavigate:function () {
        return this.m_NaviStatus.GetIsStartEmulator() || this.m_NaviStatus.GetIsStartNavi();
    },

    _tRequestTrafficRadio_:function (xyList) {

        var strUrl = "http://211.151.71.28:8888/navitraffic.php?xys=";
        if (xyList && xyList.length > 1) {
            var end = xyList.length;
            for (var i = 0; i < end; i++) {
                strUrl += xyList[i].x + "," + xyList[i].y;
                if (i < end - 1) {
                    strUrl += ",";
                }
            }
        } else {
            return false;
        }

        this.OnNetRequest(1, strUrl, null, null, false);
        return true;
    },

    /**
     * 接口函数，手动播报移动交通台信息
     * @return {Boolean}
     */
    "PlayTrafficRadioManual":function () {
        return this.OnRequestTrafficInfo();
    },


    /**
     * 接口函数，打开移动交通台功能, 系统初始化完默认路况是打开的
     */
    "OpenTrafficRadio":function () {
        this.m_NaviStatus.SetPlayTrafficRadio(true);
        if (this.m_pstProbe) {
            this.m_pstProbe.SetSampleFrequency(60);
        }
    },

    /**
     *  接口函数，关闭路况
     */
    "CloseTrafficRadio":function () {
        this.m_NaviStatus.SetPlayTrafficRadio(false);
        if (this.m_pstProbe) {
            this.m_pstProbe.SetSampleFrequency(120);
        }

    },

    /**
     * 按被选路径，导航路径，首条路径顺序 获取路径
     * @return {MRoute.NaviPath} 成功则返回一条路径，失败返回null
     * @private
     */
    _getPath_:function () {
        if (this.selectPath != null) {
            return this.selectPath;
        }
        else if (this.naviPath != null) {
            return this.naviPath;
        }

        return null;
    },

    /**
     * 获得当前路径的长度，单位米
     * @return {Number}
     */
    "GetRouteLength":function () {
        var path = this._getPath_();
        if (path != null) {
            return path.getDistance();
        }
        return 0;
    },

    /**
     * 获得指定导航段的导航描述信息
     * @param iSegIndex
     * @return {String}
     */
    "GetSegmentDescribe":function (iSegIndex) {
        var strDescribe = "";
        if (this.m_pstDG) {
            strDescribe = this.m_pstDG.getGuideDescribe(this.selectPath, iSegIndex);
        }
        return strDescribe;
    },

    /**
     * 接口函数，获得行程Guide列表
     * @return [Array] GuideItem数组,参见NaviGuideItem定义
     */
    "GetNaviGuideList":function () {
        var naviGuideList = [];
        var path = this._getPath_();
        if (path != null) {
            var segs = path.getSegments();
            if (segs != null) {
                for (var i = 0; i < segs.length; i++) {
                    var curSeg = segs[i];
                    var icon = MRoute.DGUtil.GetNaviIcon(curSeg.getBasicAction(), curSeg.getAssistAction());
                    var coords = curSeg.getDetailedCoorsLngLat(),
                        time = curSeg.getDriveTimeMinute(),
                        strName = segs[i].getRoadName();
                    if (strName == null){
                        strName = "无名道路";
                    }
                    var item = new MRoute["NaviGuideItem"](curSeg.getDistance(), time,
                        icon, coords[0], coords[1], strName);

                    naviGuideList.push(item);
                }
            }

        }

        return naviGuideList;
    },

    /**
     * 接口函数，获得当前路径的导航段个数
     * 只有在收到SetRequestRouteState发送的接收成功消息后可使用
     * @return {Number} 有路径返回当前导航路径的导航段个数，否则返回0
     */
    "GetSegmentNum":function () {
        var path = this._getPath_();
        if (path != null) {
            return path.getSegmentCount();
        }

        return 0;
    },

    /**
     * 接口函数，获得当前路径的旅行时长，单位分钟
     * @return {Number}
     */
    "GetRouteTime":function () {
        var path = this._getPath_();
        if (path != null) {
            return this._getTime_(path.getDriveTimeMinute(), path.getTmcTimeMinute());
        }

        return 0;
    },

    /**
     * 接口函数，获得一个导航段中Link的数量
     * @param iSegIndex 导航段编号，编号从0开始
     * @return {Number}
     */
    "GetLinkNum":function (iSegIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                return segments[iSegIndex].getLinkCount();
            }
        }

        return 0;
    },

    /**
     * 接口函数，获得一个导航段的旅行时间,单位：分钟
     * @param iSegIndex 导航段编号，编号从0开始
     * @return {Number}
     */
    "GetSegTime":function (iSegIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                return this._getTime_(segments[iSegIndex].getDriveTimeMinute(), segments[iSegIndex].getTmcTimeMinute());
            }
        }

        return 0;
    },

    /**
     * 接口函数，获得一个导航段的长度,单位：米
     * @param iSegIndex 导航段编号
     * @return {Number}
     */
    "GetSegLength":function (iSegIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                return segments[iSegIndex].getDistance();
            }
        }

        return 0;
    },

    /**
     * 接口函数，获得一个导航段的收费长度,单位：米
     * @param iSegIndex 导航段编号
     * @return {Number}
     */
    "GetSegChargeLength":function (iSegIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                return segments[iSegIndex].getTollDistance();
            }
        }

        return 0;
    },

    /**
     * 接口函数，获得一个导航段的LocationCode的数目
     * @param iSegIndex 导航段编号
     * @return {Number}
     */
    "GetSegLocationCodeNum":function (iSegIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var nslc = segments[iSegIndex].getTmcInfo();
                if (nslc != null) {
                    return nslc.length;
                }
            }
        }

        return 0;

    },

    /**
     * 接口函数，获得一个LocationCodeItem
     * @param iSegIndex 导航段编号
     * @param iLocIndex  code编号
     * @return {MRoute.LocationCodeItem} 参见LocationCodeItem定义
     */
    "GetSegLocationCode":function (iSegIndex, iLocIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var records = segments[iSegIndex].getTmcInfo();
                if (records != null && records.length > iLocIndex) {
                    return new MRoute["LocationCodeItem"](records[iLocIndex].getLocationCode(),
                        records[iLocIndex].getLength(),
                        records[iLocIndex].getTime());
                }
            }
        }

        return null;
    },

    /**
     * 接口函数，获得一个导航段的形状坐标点列表
     * 当前iSegIndex小于总导航个数时返回形状点数组，否则返回null
     * @param iSegIndex 要获取信息的导航段编号，编号从0开始
     * @return [Array]坐标信息列表 ，按经度，纬度，经度，纬度顺序排列
     */
    "GetSegCoor":function (iSegIndex) {
        var coorList = [];
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var coors = segments[iSegIndex].getDetailedCoorsLngLat();
                for (var i = 0; i < coors.length; i++) {
                    coorList.push(coors[i]);
                }
            }
        }
        return coorList;
    },

    /**
     * 接口函数，获得一个Link的形状坐标点列表
     * 输入参数正确返回列表，否则返回空列表
     * @param iSegIndex 要获取信息的导航段编号，编号从0开始
     * @param iLinkIndex 要获取信息的Link段编号，编号从0开始
     * @return [Array]坐标信息列表，按经度，纬度，经度，纬度顺序排列
     */
    "GetLinkCoor":function (iSegIndex, iLinkIndex) {
        var coorList = [];
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var link = segments[iSegIndex].getLink(iLinkIndex);
                if (link != null) {
                    var coors = segments[iSegIndex].getDetailedCoorsLngLat();
                    var sId = link.getStartCoorIndex(), eId = link.getEndCoorIndex();
                    for (var i = sId; i < eId; i++) {
                        coorList.push(coors[i]);
                    }
                }
            }
        }
        return coorList;
    },

    /**
     * 接口函数，获得一个Link的道路名称
     * @param iSegIndex  要获取信息的导航段编号，编号从0开始
     * @param iLinkIndex 要获取信息的Link段编号，编号从0开始
     * @return {string}
     */
    "GetLinkRoadName":function (iSegIndex, iLinkIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var link = segments[iSegIndex].getLink(iLinkIndex);
                if (link != null) {
                    return link.getLinkName();
                }
            }
        }

        return null;
    },


    /**
     * 接口函数，获得一个Link的长度，单位：米
     * @param iSegIndex 要获取信息的导航段编号，编号从0开始
     * @param iLinkIndex 要获取信息的Link段编号，编号从0开始
     * @return {Number}
     */
    "GetLinkLength":function (iSegIndex, iLinkIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                return segments[iSegIndex].getLinkLength(iLinkIndex);
            }
        }
        return 0;
    },


    /**
     * 接口函数，获得一个Link的旅行时长，单位：分钟
     * @param iSegIndex 要获取信息的导航段编号，编号从0开始
     * @param iLinkIndex 要获取信息的Link段编号，编号从0开始
     * @return {Number}
     */
    "GetLinkTime":function (iSegIndex, iLinkIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                return segments[iSegIndex].getLinkTime(iLinkIndex);
            }
        }
        return 0;
    },

    /**
     * 接口函数，获得一个Link的FormWay
     * @param iSegIndex 要获取信息的导航段编号，编号从0开始
     * @param iLinkIndex 要获取信息的Link段编号，编号从0开始
     * @return {Number} 枚举变量，参见MRoute.Formway
     */
    "GetLinkFormWay":function (iSegIndex, iLinkIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var link = segments[iSegIndex].getLink(iLinkIndex);
                if (link != null) {
                    return Number(link.getLinkForm());
                }
            }
        }

        return Number(MRoute.Formway.Formway_Divised_Link);
    },

    /**
     * 接口函数，获得一个Link的RoadClass
     * @param iSegIndex 要获取信息的导航段编号，编号从0开始
     * @param iLinkIndex 要获取信息的Link段编号，编号从0开始
     * @return {Number} 枚举变量，参见MRoute.RoadClass
     */
    "GetLinkRoadClass":function (iSegIndex, iLinkIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var link = segments[iSegIndex].getLink(iLinkIndex);
                if (link != null) {
                    return Number(link.getRoadClass());
                }
            }
        }

        return Number(MRoute.RoadClass.RoadClass_Non_Navi_Road);
    },

    /**
     * 接口函数，获得一个Link的LinkType
     * @param iSegIndex 要获取信息的导航段编号，编号从0开始
     * @param iLinkIndex 要获取信息的Link段编号，编号从0开始
     * @return {Number} 枚举变量，参见MRoute.LinkType
     */
    "GetLinkLinkType":function (iSegIndex, iLinkIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var link = segments[iSegIndex].getLink(iLinkIndex);
                if (link != null) {
                    return Number(link.getLinkType());
                }
            }
        }

        return Number(MRoute.LinkType.LinkType_Common);
    },
    "HasLinkLight": function (iSegIndex, iLinkIndex) {
        var path = this._getPath_();
        if (path != null) {
            var segments = path.getSegments();
            if (segments != null && segments.length > iSegIndex) {
                var link = segments[iSegIndex].getLink(iLinkIndex);
                if (link != null) {
                    return link.hasTrafficLight();
                }
            }
        }
        console.log('error')
//        return Number(MRoute.LinkType.LinkType_Common);
    },
    /**
     * 接口函数，获得一个路段的状态  // need supply
     * @param wLocCode 路段对应的LocationCode
     * @return {Number} 查询到的道路状态, 参见MRoute.RoadStatus
     */
    "GetRoadStatus":function (wLocCode) {

        if ((wLocCode & 0x8000) != 0)         //反向		最高位为1，反向
        {
            wLocCode = -(wLocCode & 0x7FFF);
        }
        //实时获取 tmc信息
        //m_pstTMC->GetRoadStatus( wLocCode,forward, stRoadStatus);
        //var stObj = new MRoute.RoadStatus();
        //return Number(stObj.eStatus);

        if (this.m_pstTMC != null) {
            return this.m_pstTMC.getRoadStatus(wLocCode);
        }
        return 0;

    },

    /**
     * 接口函数，创建一个光柱
     * @param iStart        到路径起点的距离
     * @param iLength           要获取路况的路段长度
     * @return [Array, Array]      各段长度列表，各段路况列表
     */
    "CreateTMCBar":function (iStart, iLength) {

        if (!this.m_NaviStatus.GetDrawDt()) {
            //TestInfoLog("TBT-CreateTMCBar: tmc forbid!");
            return null;
        }

        if (this.m_pstTMC != null) {
            return this.m_pstTMC.createTMCBar(iStart, iLength);
        }

        return null;
    }

});
MRoute["CTBT"] = MRoute.JsTBT;

MRoute.DestNode = Class(MRoute.NvPoint,{

    IsArrived : 0,      /// 是否到达
    //relatedSegId :0,    /// 关联分段号

	"initialize":function(){
		
	}

});

MRoute.NmeaData = Class({
    /// 浮点数，纬度, 单位度 (正值为北纬, 负值为南纬)
    lat:0,
    /// 浮点数，经度, 单位度 (正值为东经, 负值为西经)
    lon:0,
    /// 浮点数，海拔, 单位米
    altitude:0,
    /// 浮点数，速度, 单位千米/时
    speed:0,
    /// 浮点数，方向角, 单位度
    track:0,
    /// 浮点数，地磁变化, 单位度
    magVariation:0,
    /// 浮点数，位置精度参数
    pdop:0,
    /// 浮点数，水平精度参数
    hdop:0,
    /// 浮点数，垂直精度参数
    vdop:0,
    /// 浮点数，星空图卫星个数
    numSats:0,
    /// GPS定位质量
    FixedMode:0,
    /// GPS(BJ)时间－－年
    Year:0,
    /// GPS(BJ)时间－－月
    Month:0,
    /// GPS(BJ)时间－－日
    Day:0,
    /// GPS(BJ)时间－－时
    Hour:0,
    /// GPS(BJ)时间－－分
    Minute:0,
    /// GPS(BJ)时间－－秒
    Second:0,
    /// 前一次定位质量 0 无效点 1有效点 2修正点
    lastFixQuality:0,
    /// bool型，是否曾经定位成功过
    bEverValid:false,
    /// 定位成功与否的标志
    nValid:true,
    "initialize":function(){

    },

    GetLoc:function()
    {
        return new MRoute.NvPoint(this.lon, this.lat);
    },

    TimeEqual:function(np){
        if(this.Year == np.Year
            && this.Month == np.Month
            && this.Day == np.Day
            && this.Hour == np.Hour
            && this.Minute == np.Minute
            && this.Second == np.Second)
        {
            return true;
        }
        return false;

    }

});
MRoute["LocationCodeItem"] = Class({

    "code":0,
    "dist":0,
    "time":0,
   "initialize":function(code, dist, time){
       this["code"] = code;
       this["dist"] = dist;
       this["time"] = time;
	}
   
});
MRoute["NaviGuideItem"] = Class({
    "distance":0,         //当前分段路径长度, 单位：米
    "driveTime":0,        //当前分段行驶时间，单位：分钟
    "directionIcon":0,    //当前分段转向图标
    "roadName":"",        //路径名称
    "startLon":0,         //起始点经度
    "startLat":0,         //起始点纬度

    "initialize":function(dist, time, icon, lon, lat, name){
        this["distance"] = dist;
        this["driveTime"] = time;
        this["startLon"] = lon;
        this["startLat"] = lat;
        this["roadName"] = name;
        this["directionIcon"] = icon;
    }
});

MRoute.RoadStatus = Class({
    nSpeed : 0,		// 速度
    eStatus : 0,     // 状态
    "initialize":function(){
    }
});
window["MRoute"] = MRoute;

})();
define("webRoute", function(){});

/**
 * @class RequestPathFrame类
 * @construct RequestPathFrame
 */
$.Model('MapModel.RouteRequestFrame', {
    defaults: {
        iGpsCount: 0,
        isRequestPath: false,
        tbt: null,
        remain_metre: Infinity,
        tbt_remain_miniute: Infinity,
        routeType: 5, //多路径请求
        tmcType: 4,
        linksData0: null,
        linksData4: null
    }
}, {
    /**
     Method for automatic call instantiated
     @method init.
     **/
    init: function (config) {
        if (typeof  config === 'undefined') {
            return;
        }
        this.callback = config.callback;
        this.failCallback = config.failCallback;
        this.tbt = new MRoute.CTBT(this, "");
    },
    /**
     Method for switch elements of loading icon_request_path effect and isRequestPath attr
     @method triggerRequestEvent.
     **/
    triggerRequestEvent: function () {
        this.toggleLoadingEffect();
        this.attr('isRequestPath', true);
    },
    /**
     Method for switch elements of loading map_layer effect
     @method toggleLoadingEffect.
     **/
    toggleLoadingEffect: function () {
        $('#loading').toggleClass('hidden');
        $('#map_layer').toggleClass('map_layer');
    },
    /**
     Method for recoverRequestState
     @method recoverRequestState.
     **/
    recoverRequestState: function () {
        this.attr('isRequestPath', false);
        this.linksData0 = this.linksData4 = null;
    },
    /**
     * 创建一个光柱
     * 当前路径有动态信息则返回分段路况信息
     * @return [Array1,Array2],Array1数组指示分段路长，Array2数组指示分段路况
     */
    getSomeLenRouteTraffic: function (iType) {
        this.tbt.SelectRoute(iType)
        return this.tbt.CreateTMCBar(0, this.getRouteLength(iType));
    },


    /**
     * 获得一个导航段的旅行时间,单位分钟，向上取整
     * @param iSegIndex 导航段编号，编号从0开始
     * @return {Number}
     */
    getNavSegTime: function (iSegInd) {
        return this.tbt.GetSegTime(iSegInd);
    },
    /**
     * 获得一个导航段的长度,单位：米，向上取整
     * @param iSegIndex 导航段编号
     * @return {Number}
     */
    getNavSegLength: function (iSegIndex) {
        return this.tbt.GetSegLength(iSegIndex);
    },
    /**
     Method for set request route type
     @method setRequestRouteType.
     * @param iType 导航段路径类型
     **/
    setRequestRouteType: function (iType) {
        this.tbt.SelectRoute(iType);
    },
    /**
     Method for get route length
     @method getRouteLength.
     * @param iType 导航段路径类型
     * @return {Number}
     **/
    getRouteLength: function (iType) {
        this.tbt.SelectRoute(iType);
        return this.tbt.GetRouteLength();
    },
    /**
     Method for get route time
     @method getRouteTime.
     * @param iType 导航段路径类型
     * @return {Number}
     **/
    getRouteTime: function (iType) {
        this.tbt.SelectRoute(iType);
        return this.tbt.GetRouteTime();
    },
    getLightsByLinks: function (i, n) {
        if (this.tbt.HasLinkLight(i, n)) {
            this['linksData' + this.curType].numLight++;
        }
    },
    getMainAndSecondaryRoads: function (strMainRoad, roadClass) {
        if (String(strMainRoad).indexOf(roadClass) !== -1) {
            this['linksData' + this.curType].numMainRoad++;
        }
        else {
            this['linksData' + this.curType].numSecondaryRoad++;
        }
    },

    getLinksData: function () {
        if (!this.isRequestPath) {
            return {};
        }
        if (this['linksData' + this.curType]) {
            return this['linksData' + this.curType];
        }
        this['linksData' + this.curType] = {
            numLight: 0,
            numSecondaryRoad: 0,
            numMainRoad: 0
        }
        var roadClass = 0,
            roadPreName = roadName = '',
        //            0,1,6,7 are all main roads
            strMainRoad=[0,1,6,7].join()
        for (var i = 0; i < this.tbt.GetSegmentNum(); i++) {
            for (var n = 0; n < this.tbt.GetLinkNum(i); n++) {
                var roadClass = this.tbt.GetLinkRoadClass(i, n),
                    roadName = this.tbt.GetLinkRoadName(i, n)
                this.getLightsByLinks(i, n);
                if (roadPreName == roadName) {
                    continue;
                }
                this.getMainAndSecondaryRoads(strMainRoad, roadClass);
                roadPreName = roadName;
            }
        }
        return this['linksData' + this.curType];
    },
    getGuideList: function (iRouteType) {
        this.tbt.SelectRoute(iRouteType);
        var data = this.tbt.GetNaviGuideList(),
            arr = [],
            index = 0,
            that = this;
        $.each(data, function (i, n) {
            var num = that.tbt.GetSegLocationCodeNum(i);
            if (num) {
                for (var k = 0; k < num; k++) {
                    var locationCode = that.tbt.GetSegLocationCode(i, k);
                    arr.push({
                        index: index,
                        lc: locationCode,
                        stus: that.tbt.GetRoadStatus(locationCode.code)
                    })
                }
            }
            index++
        })
        return arr;
    },
    _selectRouteType: function (iType) {
        this.tbt.SelectRoute(iType);
        this.curType = iType;
    },
    getRouteLights: function (iType) {
        this._selectRouteType(iType);
        return this.getLinksData().numLight;
    },
    getMainRoadNum: function (iType) {
        this._selectRouteType(iType);
        return this.getLinksData().numMainRoad;
    },
    getSecondaryRoadNum: function (iType) {
        this._selectRouteType(iType);
        return this.getLinksData().numSecondaryRoad;
    },
    /**
     Method for request path
     @method requestPath.
     * @param start 导航段路径起点
     * @param end 导航段路径终点
     **/
    requestPath: function (start, end) {
        this.tbt.SetCarLocation(new MRoute.NaviPoint(start.x, start.y));
        var pathState = this.tbt.RequestRoute(this.routeType, [ new MRoute.NaviPoint(
            end.x, end.y) ]);
    },
    /**
     Method for set gps info
     @method setGpsInfo.
     * @param curr 当前位置对象信息
     **/
    setGpsInfo: function (curr) {
        this.tbt.SetGPSInfo(curr.longitude, curr.latitude, curr.speed, curr.direction, curr.year, curr.month, curr.day, curr.hour, curr.minute, curr.second);
    },
    /**
     Method for start request
     @method startRequest.
     * @param start 请求路径的起点
     * @param end 请求路径的终点
     **/
    startRequest: function (start, end) {
        this.requestPath(start, end);

    },
    /**
     Method for destroy route
     @method RouteDestroy.
     **/
    RouteDestroy: function () {

    },
    NetRequestHTTP: function (iModelID, iConnectID, strURL, strHead, strData, bGetMode) {
        var that = this;
        new NGIRoute.RouteRequest(strURL, function (postStream) {
            that.tbt.ReceiveNetData(iModelID, iConnectID, postStream);
        });
    },
//    todo specify current postion gps, no call current
    setCurPos: function () {
        mapHandler.attr('curInfo', {
            lng: 116.30603541739156,
            lat: 39.98010078106883
        });
    },
    /**
     * 使用log中的位置信息作为gps导航的位置来源
     * @return {Number}
     */
    pushGPSLogLatLon: function () {
        var that = this;
        logGPSId = 0;
        var timer = setInterval(function () {
            that.GPSTimer_Tick(arrGpsLog2);
        }, 10);
        return timer;
    },
    /**
     * 读取GPS log文件中的记录并推送给tbt
     * @param arrgps log数组
     */
    GPSTimer_Tick: function (arrgps) {
        if (logGPSId < arrgps.length) {
            var curr = arrgps[logGPSId];
            this.setGpsInfo(curr);
            logGPSId++;
        } else {
            logGPSId = 0;
        }
    },
    StartEmulator: function () {
    },
    UpdateNaviInfor: function (DGNaviInfor) {
    },
    PlayNaviSound: function (iType, SoundStr) {
    },
    ArriveWay: function (iWayID) {

    },
    /**
     The method is called when the position changes
     @method CarLocationChange.
     * @param vpLocation 位置
     **/
    CarLocationChange: function (vpLocation) {
    },

    /**
     The method is set request route state
     @method SetRequestRouteState.
     * @param eState 返回的状态
     **/
    SetRequestRouteState: function (eState) {
        if (eState != 1) {
            this.failCallback();
            return;
        }
        this.callback();
    },
    CrossRequest: function (arrBack, arrFore, arrSegId) {
    },
    ShowCross: function (bgImageId, foreImageId, segRemainDist) {

    },
    HideCross: function () {

    },
    Reroute: function () {
    },
    RerouteForTMC: function () {
    },
    EndEmulatorNavi: function () {
    },
    TMCUpdate: function () {
    },
    ShowLaneInfo: function (iBackInfo, iSelectInfo) {
    },
    HideLaneInfo: function () {
    },
    ShowTrafficPanel: function (id) {
    },
    HideTrafficPanel: function () {
    },
    /*
     * This method is to get coords array
     @method getCoordsArray.
     @return {Array}
     */
    getCoordsArray: function () {
        var glist = this.tbt.GetSegmentNum(), path = [];
        for (var i = 0; i < glist; i++) {
            var coors = this.tbt.GetSegCoor(i);
            if (coors == null) {
                return;
            }
            var s = 0;
            for (var m = 0; m < coors.length - 1; m += 2) {
                path.push(mapHandler.generateLngLat(coors[m], coors[m + 1]));
            }
        }
        return path;
    },
    /*
     * This method is to get rapid path array
     @method getRapidPathInfo.
     @return {Obj}
     */
    getRapidPathInfo: function () {
        this.tbt.SelectRoute(4);
        return {
            path: this.getCoordsArray(),
            length: this.tbt.GetRouteLength(),
            time: this.tbt.GetRouteTime()
        };
    },
    /*
     * This method is to get rapid path array
     @method getNormalPathInfo.
     @return {Obj}
     */
    getNormalPathInfo: function () {
        this.tbt.SelectRoute(0);
        return {
            path: this.getCoordsArray(),
            length: this.tbt.GetRouteLength(),
            time: this.tbt.GetRouteTime()
        };
    }
});


NGIRoute = {};
NGIRoute.RouteRequestData = {};//请求结果缓存对象
NGIRoute["RouteRequestCB"] = function (rid, data) {
    NGIRoute.RouteRequestData[rid] = data;
};
NGIRoute["RouteRequest"] = function (url, func) {
    var rid = Math.round(Math.random() * 100000);
    var __script = document.getElementById(rid);
    if (__script) {
        document.getElementsByTagName("head")[0].removeChild(__script);
    }
    __script = document.createElement("script");
    __script.id = rid;
    __script.type = "text/javascript";
    __script.src = url + "&cbk=NGIRoute.RouteRequestCB&rid=" + rid;
    document.getElementsByTagName("head")[0].appendChild(__script);
    var __self = this;
    if (/msie/i.test(navigator.userAgent) && !/msie 9.0/i.test(navigator.userAgent)) {//IE
        __script.onreadystatechange = function () {
            if (this.readyState == "loaded" || this.readyState == "complete") {
                __self.ajaxResult();
            }
        }
    } else {//firefox,chrom etc.
        __script.onload = function () {
            __self.ajaxResult();
        };
        __script.onerror = function () {
            if (func) {
                func(null);
            }
        };
    }

    this.ajaxResult = function () {
        if (NGIRoute.RouteRequestData[rid]) {//加载服务数据
            if (func) {
                func(NGIRoute.RouteRequestData[rid]);
            }
            document.getElementsByTagName("head")[0].removeChild(document.getElementById(rid));//删除JS文件
            NGIRoute.RouteRequestData[rid] = null;
            delete NGIRoute.RouteRequestData[rid];
        } else {
            if (func) {
                func(NGIRoute.RouteRequestData[rid]);
            }
        }
    }
};

define("tbt", ["jquerymx","webRoute"], function(){});

/**
 network service module
 @class MapModel.Constant
 **/
$.Model('MapModel.Constant', {
    defaults: {
        SHARE_POS_METRIC: 33,
        //            grey, green, yellow, red
        pathColor: ['#999', '#32ca2e', '#ffa800', '#e9350b']
    }
}, {
    init: function () {

    },
//    todo to extract controller method
    recoverEleState: function () {
        $('#tabsContent tbody').remove();
        $('#route').css('visibility', 'hidden');
        $('#zoom_in, #zoom_out').css({top: ''});
        $('#positioning').css('visibility', 'visible');
        $("#path_info").css('visibility', 'hidden');
        $('#tmc_btn').show();
        $('#navi').show();
        navInfo.restorationIni();
        navInfo.showProgressBar();
        navControl.showAinav();
    }
});

/**
 地图操作类
 @class  mapHandler
 @extends MapModel.mapHandler
 * */
$.Model('MapModel.mapHandler', {
    defaults: {
        zooms: [3, 17],
        iniZoom: 16,
//todo setContent method no implemented, so no customize the infoWindow offset, reference to http://api.amap.com/Javascript/guide#overlay
        infoOffsetHorizon: 37,
        infoOffsetVertical: 68,
        arrowWidth: 25,
        arrowHeight: 12,
        strAddressMaxLen: 12,
        strNameMaxLength: 6,
        tmcLayerId: 'traffic_layer',
        shareInfo: {},
        curInfo: {},
        curDisplayPath: 4,
        northUp: true,
        gpsState: true,
        updateOverlays: false,
        shareTitle: "飞享位置"
    }
}, {

    init: function () {
        this.zoom_in = $('#zoom_in');
        this.zoom_out = $('#zoom_out');
        this.mapObj = null;
    },
    /**
     The method to set polyline order
     @method setPathPileOrder.
     @param type number
     **/
    setPathPileOrder: function (type) {
        if (drawPath.lines0.length == 0) {
            return;
        }
        drawPath.removePolylines();
        drawPath.drawPath();
    },
    promptUser: function (id) {
        util_common.promptUser(id);
    },
    getNoGps: function () {
        var id = 'no_get_gps';
        this.promptUser(id);
    },
    getNoPath: function () {
        var id = 'no_get_path';
        this.promptUser(id);
    },


    getShareLngLat: function () {
        var lng = this.shareInfo.lng,
            lat = this.shareInfo.lat;
        return {lng: lng, lat: lat};
    },
    showMap: function () {
        var _ret = this.getShareLngLat();
        this.generateMap(_ret);
    },
    changeCenterWhenZoomchange: function () {
        var mapObj = mapHandler.mapObj;
        if (location.hash == '#share') {
            mapObj.panTo(new AMap.LngLat(mapHandler.shareInfo.lng, mapHandler.shareInfo.lat));
        }
    },
    moveMapCenter: function () {
        this.changeCenterWhenZoomchange();
    },

    setMapPathFit: function () {
        var lngLat = {
            maxlng: Math.max(drawPath.getTmcData().maxLng, drawPath.getNormalData().maxLng, mapHandler.curInfo.lng, mapHandler.shareInfo.lng),
            maxlat: Math.max(drawPath.getTmcData().maxLat, drawPath.getNormalData().maxLat, mapHandler.curInfo.lat, mapHandler.shareInfo.lat),
            minlng: Math.min(drawPath.getTmcData().minLng, drawPath.getNormalData().minLng, mapHandler.curInfo.lng, mapHandler.shareInfo.lng),
            minlat: Math.min(drawPath.getTmcData().minLat, drawPath.getNormalData().minLat, mapHandler.curInfo.lat, mapHandler.shareInfo.lat)
        }
        var that = this;
        this.setPathFitView(function () {
            scale.attr('level', that.getZoom());
        }, lngLat);
    },
    setPathBounds: function (maxlng, maxlat, minlng, minlat, mapSpan, zoomOffset) {
        var southWest = new AMap.LngLat(maxlng, maxlat),
            northEast = new AMap.LngLat(minlng, minlat - mapSpan),
            bounds = new AMap.Bounds(southWest, northEast);
        this.mapObj.setBounds(bounds, zoomOffset);
    },
    hasGps: function () {
        return this.gpsState;
    },
    handleGpsState: function () {
        if (!mapHandler.hasGps()) {
            mapHandler.gpsState = true;
        }
    },
    changeState: function () {
        this.attr('gpsState', false);
    },
    addShareInfoWindow: function (lng, lat) {
        var strNameMaxLength = this.strNameMaxLength;
        var name = util_common.truncateStr(this.shareInfo.name, strNameMaxLength),
            address = '';

        if (this.shareInfo.address) {
            var maxLength = this.strAddressMaxLen;
            address = util_common.truncateStr(this.shareInfo.address, maxLength);
        }
        var info = this.buildInfowindowStr(name, address);
        var info = {
            isCustom: true,
            content: info,
            offset: new AMap.Pixel(this.infoOffsetHorizon, -this.infoOffsetVertical)
        };
        this.generateInfoWindow(info);
        this.infoPos = this.generateLngLat(lng, lat);
        /*this.openInfoWin();*/
        var that = this;
        this.mapObj.bind(this.inforWindow, 'open', function () {
            that.enableDragInfoWin.call(that);
        });
    },

    recoverMapState: function () {
        var mapObj = this.mapObj;
        mapObj.panTo(new AMap.LngLat(mapHandler.shareInfo.lng, mapHandler.shareInfo.lat));
        requestPath.recoverRequestState();
        mapObj.removeOverlays(['start_pos', 'end_pos']);
        drawPath.removePolylines();
        this.toggleMarker(true);
        this.attr('curDisplayPath', 4);
    },
    getDistance: function (end, start) {
        try {
            return this.mapObj.getDistance(new AMap.LngLat(end.lng, end.lat), new AMap.LngLat(start.lng, start.lat))
        } catch (e) {
            console.log(e)
        }
    },
    getSectionNodeCoord: function (prev, next, lenToPrev, len) {
        if (typeof prev === 'undefined') {
            prev = this.curInfo;
        }
        var prevLng = Number(prev.lng),
            prevLat = Number(prev.lat),
            nextLng = Number(next.lng),
            nextLat = Number(next.lat);
        var tempX = nextLng - prevLng,
            tempY = nextLat - prevLat;
        var lng = prevLng + (tempX * (lenToPrev / len)),
            lat = prevLat + (tempY * (lenToPrev / len));
        return new AMap.LngLat(lng, lat);
    }
});
/*
 *   poll gps
 *   @class  DevPosTracker
 *   @constructor
 * */
$.Model('DevPosTracker', {
        defaults: {
            currGPS: null,
            lastGPS: null,
            isPollGps: false,
            /**
             * @constant 轮询gps信息的参数设置
             * @default WatchGPS类的类属性，默认值
             */
            argPollGps: {
                enableHighAccuracy: false,
                /**
                 @description 1秒获取一个GPS点
                 */
                timeout: 1000,
                /**
                 @description 无条件重新获取GPS位置
                 */
                maximumAge: 0
            },
            errMsg: {
                '1': "位置服务被拒绝。",
                '2': "暂时获取不到位置信息。",
                '3': "获取信息超时。",
                'default': "未知错误。"
            }
        }
    },
    {
        init: function (config) {
            if (typeof config === 'undefined') {
                return;
            }
            this.callbackDisconnectGps = config.callbackDisconnectGps;
            this.tbt = config.tbt;
            var that = this;
            this.onSuccess = function (position) {
//                this.currGPS = position
                config.successCallback.call(that, position);
            };
            this.onError = function (error) {
                if (that.lastGPS == null) {
                    that.callbackDisconnectGps();
                    return;
                }
                that.currGPS = that.lastGPS;
                config.failCallback(error);
            };
        },
        generateGPS: function (position) {
            var gpsInfo = {};
            gpsInfo.longitude = position.coords.longitude;
            gpsInfo.latitude = position.coords.latitude;
            gpsInfo.speed = position.coords.speed * 3.6; //速度单位从m/s转换到km/h
            gpsInfo.direction = position.coords.heading;
            var date = new Date();
            date.setTime(position.timestamp);
            gpsInfo.year = date.getFullYear();
            gpsInfo.month = date.getMonth() + 1;
            gpsInfo.day = date.getDate();
            gpsInfo.hour = date.getHours();
            gpsInfo.minute = date.getMinutes();
            gpsInfo.second = date.getSeconds();
            return gpsInfo;

        },
        getCurrIniGps: function () {
            return {
                lng: this.currGPS.coords.longitude,
                lat: this.currGPS.coords.latitude
            };
        },
        getCurrEncapsulatedGps: function () {
            return this.currGPS;
        },

        getCurrGps: function (lngLat, position) {
            return  this.encapsulateGps(lngLat, position);
        },
        setCurrGpsNull: function () {
            this.currGPS = null;
        },
        encapsulateGps: function (lngLat, currGPS) {
            var position = currGPS;
            position.coords.longitude = lngLat.lng;
            position.coords.latitude = lngLat.lat;
            this.currGPS = this.generateGPS(position);
            this.lastGPS = this.currGPS;
            return this.currGPS;
        },
        handle_position: function (position) {
            var config = {
                lng: position.coords.longitude,
                lat: position.coords.latitude,
                altitude: position.coords.altitude
            };
        },

        pollGps: function () {
            var that = this;
            if (navigator.geolocation) {
                var watchGPS = navigator.geolocation.watchPosition(function (position) {
                    that.onSuccess(position);
                }, that.onError, that.argPollGps);
            }
            else {
                that.callbackDisconnectGps();
            }

            return watchGPS;
        }
    });
$.Model('MapModel.Scale', {
    defaults: {
        level: 0,
        maxLevel: 17,
        minLevel: 3
    }
}, {
    setLevel: function (newLevel) {
        return  newLevel == 2 || newLevel == 18 ? this.level : newLevel;
    },
    isScale: function () {
        return this.level <= this.maxLevel && this.level >= this.minLevel;
    },
    isMaxScale: function () {
        return this.level == 17;
    },
    isMinScale: function () {
        return this.level == 3;
    },
    updateMarker: function () {
        mapHandler.toggleMarker(false);
        var configStart = {
            lng: mapHandler.curInfo.lng,
            lat: mapHandler.curInfo.lat,
            id: 'start_pos',
            imgAddress: 'flynavi/resources/images/start_point.png',
            imgWidth: 41,
            imgHeight: 36
        }, configEnd = {
            lng: mapHandler.shareInfo.lng,
            lat: mapHandler.shareInfo.lat,
            id: 'end_pos',
            imgAddress: 'flynavi/resources/images/end_point.png',
            imgWidth: 41,
            imgHeight: 36
        };
        mapHandler.startMarker = mapHandler.addMarker(configStart);
        mapHandler.endMarker = mapHandler.addMarker(configEnd);
    }
});

$.Model('MapModel.ToggleEleState', {
        defaults: {
            SHARE_POS_METRIC: 33
        }
    }, {
        init: function () {

        },
        toggleEleAfterRequest: function () {
            $('.toolbar:first').css('visibility', 'visible');
            $('#positioning').css('visibility', 'hidden');
        }
    }
);
define("mapModel", ["mapUtil","iScroll","tbt"], function(){});

/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 7/5/13
 * Time: 11:51 AM
 * Use:
 */
/**
 A utility that mapHandler model
 @class mapHandler
 @constructor
 **/
MapModel.mapHandler('MapModel.mapHandler', {
    /**
     The method to init the map zoom level
     @method initMapZoom.
     @return {Number}
     **/
    initMapZoom: function () {
        var ratio = devicePixelRatio;
        if (ratio == 2) {
            return this.iniZoom = 13;

        }
        if (ratio == 1.5) {
            return this.iniZoom = 14;
        }
        return this.iniZoom = 15;
    },
    /**
     The method to set the map zoom level
     @method setZoom.
     @param zoom number
     **/
    setZoom: function (zoom) {
        this.mapObj.setZoom(zoom);
    },
    moveCurMarker: function () {
        var objGps = new AMap.LngLat(this.curInfo.lng, this.curInfo.lat);
        this.curMarker.setPosition(objGps);
    },
    rotateCurMarkerOrMap: function () {
        if (mapHandler.northUp) {
            mapHandler.setNorthDirctionUp(this.curInfo);
        }
        else {
            mapHandler.setCurOverlayDirectionUp({nCarDirection: this.curInfo.nAngle});
        }
    },
    bindScreenRotation: function () {
        if (!publicModel.isNativeBrowserOfLenovo()) {
            return;
        }
        var supportsOrientationChange = "onorientationchange" in window,
            orientationEvent = supportsOrientationChange ? "orientationchange" : "resize",
            that = this;

        window.addEventListener(orientationEvent, function () {
            var width = 0
            if (isNaN(window.orientation)) {
                width = Math.abs(window.orientation) == 90 ? width = $(window).width() : 'device-width'
            } else {
                width = screen.width > screen.height ? $(window).width() : 'device-width'
            }
            var content = ' width=' + width + ', initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'
            $('meta[name="viewport"]').attr('content', content)
        }, false);
    },
    /**
     The method to set the map rotation angle
     @method setCurOverlayDirectionUp.
     @param DGNaviInfor object
     **/
    setCurOverlayDirectionUp: function (DGNaviInfor) {
        var t = DGNaviInfor.nCarDirection;
        $('img[src="images/cur_position.png"]').css('-webkit-transform', 'rotate(' + t + 'deg)');
        //根据tbt返回的角度旋转地图
        this.mapObj.setRotation(-t);

    },
    /**
     The method to set cur_pos element state
     @method setNorthDirctionUp.
     @param DGNaviInfor object
     **/
    setNorthDirctionUp: function (DGNaviInfor) {
        $('img[src="images/cur_position.png"]').css('-webkit-transform', 'rotate(' + DGNaviInfor.angle + 'deg)');
    },

    //todo 最好使用api提供的show,hide方法，不兼容ios，等待高德解决
    /**
     The method to add tmc layer
     @method addTmcLayer.
     **/
    addTmcLayer: function () {
        if (!this.mapObj.getLayer('traffic_layer')) {
            var tmc = new AMap.TileLayer({
                id: this.tmcLayerId,
                zIndex: 2,
                detectRetina: true,
                getTileUrl: function (x, y, z) {
                    return "http://tm.mapabc.com/trafficengine/mapabc/traffictile?v=1.0&t=1&zoom=" + (17 - z) + "&x=" + x + "&y=" + y;
                }
            });
            //如果动态交通里的功能设定页面没有选择显示动态交通信息，则不添加交通图层，如果未设置过该选项，则本地变量未初始化
            this.mapObj.addLayer(tmc);
        }
    },
    addMarkerOverlay: function (marker) {
        this.mapObj.addOverlays(marker);
    }, /**
     The method to add marker
     @method addMarker.
     @param config object
     **/
    addMarker: function (config) {
        if (this.mapObj == null) {
            return;
        }
        var markerOption = {
            id: config.id,
            coord: this.generateLngLat(config.lng, config.lat),
            imgAddress: config.imgAddress,
            imgWidth: config.imgWidth,
            imgHeight: config.imgHeight
        };
        var marker = this.addIcon(markerOption);
        this.addMarkerOverlay(marker);
        return marker;
    },
    generateMarkerObj: function (markerOptions) {
        return new AMap.Marker(markerOptions);
    },
    generateMarkerOption: function (config) {
        var markerOptions = {},
            horizon = config.imgWidth / 2,
            vertical = config.imgHeight;
        //设置覆盖物标注点类型的图片url
        markerOptions.icon = new AMap.Icon({
            image: config.imgAddress,
            //size:图标所在区域长宽
            size: new AMap.Size(config.imgWidth, config.imgHeight)
        });
        //设置标注点类型覆盖物的id属性
        if (config.id) {
            //如果id重复，会自动删除过去添加的同值id覆盖物
            markerOptions.id = config.id;
        }
        markerOptions.position = config.coord;
        //对象相对于基点的偏移量。保证覆盖物图片中心位于基点中心
        markerOptions.offset = new AMap.Pixel(-horizon, -vertical);
        return markerOptions;
    }, /**
     The method to add icon
     @method addIcon.
     @param config object
     @return {Object}
     **/
    addIcon: function (config) {
        var markerOptions = this.generateMarkerOption(config);
        var marker = this.generateMarkerObj(markerOptions);
        return marker;
    },
    /**
     The method to build infowindow string
     @method buildInfowindowStr.
     @param name name
     @param address address
     @return {Object}
     **/
    buildInfowindowStr: function (name, address) {
        var classSet = '';
        if (address) {
            classSet = 'class="share_content_offset"';
        }
        return publicModel.buildEleStrByTmpl("share_ele", {
            classSet: classSet,
            shareTitle: this.shareTitle,
            name: name,
            address: address
        });
    },
    /**
     The method to obtain the map zoom level
     @method getZoom.
     @return {Number}
     **/
    getZoom: function () {
        return this.mapObj.getZoom();
    },
    /**
     The method to set path weight
     @method setPathWeight.
     @param strokeWeight number
     @param polyline object
     **/
    setPathWeight: function (strokeWeight, polyline) {
        var obj = polyline.getOptions();
        obj.strokeWeight = strokeWeight;
        var polyOption = new AMap.Polygon(obj);
        polyline.setOptions(polyOption);
    },
    /**
     The method to generate map
     @method generateMap.
     @param _ret object
     **/
    generateMap: function (_ret) {
        var mapOptions = {
            level: this.initMapZoom(),
            zooms: this.zooms,
            center: this.generateLngLat(_ret.lng, _ret.lat),
            jogEnable: false,
            touchZoom: true
        };
        if (window.devicePixelRatio >= 1.5) {
            mapOptions.defaultLayer = new AMap.TileLayer({
                detectRetina: true
            });
//        todo if set 17, it perhaps conflict to this.zooms, lead to zoom out the biggest level and zoom in no change at first time
            mapOptions.zooms = [3, 17];
        }
        this.mapObj = new AMap.Map('map_container', mapOptions);
        this.bindScreenRotation()
    },
    /**
     The method to remove tmc layer
     @method removeTmcLayer.
     **/
    removeTmcLayer: function () {
        this.mapObj.removeLayer(this.tmcLayerId);
    },
    /**
     The method to set infowindow draggable. there are no parent selectors in CSS, so js code needed
     @method enableDragInfoWin.
     **/
    enableDragInfoWin: function () {
        var $shareDiv = $('#share_div');
        $shareDiv.parent().css('pointer-events', 'none');
    },
    /**
     The method to handle zoom change event
     @method handleZoomChangeEve.
     @param mapObj object
     @param callback function
     **/
    handleZoomChangeEve: function (callback) {
        AMap.event.addListener(this.mapObj, 'zoomchange', callback);
    },
    /**
     The method to set map fitview
     @method setFitView.
     **/
    setFitView: function () {
        this.mapObj.setFitView();
    },
    setPathFitView: function (callback, lngLat) {
        var that = this;
        setTimeout(function () {
            var viewHeightPixel = new AMap.Pixel(0, $('#map_container').height() - $('#path_info').outerHeight()),
                containerPixel = new AMap.Pixel(0, $('#map_container').height()),
                northLngLat = mapHandler.mapObj.containTolnglat(viewHeightPixel),
                southLngLat = mapHandler.mapObj.containTolnglat(containerPixel),
                span = Math.abs(southLngLat.lat - northLngLat.lat);
            that.setPathBounds(lngLat.maxlng, lngLat.maxlat, lngLat.minlng, lngLat.minlat, span, 0);
            callback();
        },500);
        this.mapObj.setFitView();
    },
    /**
     The method to set map zoomout
     @method zoomOut.
     **/
    zoomOut: function () {
        this.mapObj.zoomOut();
    },
    /**
     The method to generate infowindow
     @method generateInfoWindow.
     @param info object
     **/
    generateInfoWindow: function (info) {
        this.inforWindow = new AMap.InfoWindow(info);
    },
    /**
     The method to generate lnglat object
     @method generateLngLat.
     @param lng number
     @param lat number
     @return {Object}
     **/
    generateLngLat: function (lng, lat) {
        return new AMap.LngLat(lng, lat);
    },
    /**
     The method to open infowindow
     @method openInfoWin.
     **/
    openInfoWin: function () {
        this.inforWindow.open(this.mapObj, this.infoPos);
    },
    /**
     The method to switch marker state
     @method toggleMarker.
     @param isVisibility Blooean
     **/
    toggleMarker: function (isVisibility) {
        $.each(mapHandler.mapObj.getOverlaysByType('marker'), function (i, n) {
            isVisibility ? n.show() : n.hide();
        })
    },
    correctPosition: function (lng, lat, callback) {
        AMap.MAjaxResult = {};
        AMap.MAjaxResult['correctPosition'] = {};
        var url = "http://restapi.amap.com/coordinate/simple?sid=15001&ia=1&xys=" + lng + "," + lat + "&resType=json&rid='correctPosition'&key=0aa17a679101794a2bc8979b3eb332a7";
        $.getScript(url, function () {
            var lnglat = {};
            lnglat.lng = lng;
            lnglat.lat = lat;
            if (AMap.MAjaxResult['correctPosition'].status == "E0") {
                lnglat.lng = AMap.MAjaxResult['correctPosition'].xys.split(',')[0];
                lnglat.lat = AMap.MAjaxResult['correctPosition'].xys.split(',')[1];
            }
            callback(lnglat);
        });
    }
});
define("mapHandler", ["jquerymx","mapModel"], function(){});

/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 7/3/13
 * Time: 2:44 PM
 * Use:
 */
define('map',['jquerymx'], function () {
    /**
     A utility that Navigation event controller
     @class Map
     @constructor
     **/
    $.Controller('Map', {
        /**
         Method for automatic call instantiated
         @method init.
         **/
        init: function () {
        },
        '#icon_request_path touchstart': function () {
            if (!mapHandler.hasGps()) {
                mapHandler.getNoGps();
                return;
            }
            if (mapHandler.curInfo.lng == mapHandler.shareInfo.lng && mapHandler.curInfo.lat == mapHandler.shareInfo.lat) {
                return;
            }
            requestPath.triggerRequestEvent();
        }
    });
    return Map;
})
;
/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 7/3/13
 * Time: 4:04 PM
 * Use:
 */
define('tab',['jquerymx'],function(){
    $.Controller('Tab', {
        init: function () {
        },
        "li touchend": function (el, ev) {
            var routeObj = this.options.routeObj;
            routeObj.attr('curDisplayPath', el.attr('data-tab'));
        },
        '.toolbar touchend': function () {
            $('#route').animate({top: '100%', height: '0.1%'}, 'slow', function () {
                $('#route').css('visibility', 'hidden');
            });
//        location.hash = "#requestPath";
        }
    });
    return Tab;
})
;
/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 7/3/13
 * Time: 4:07 PM
 * Use:
 */
define('link',['jquerymx'], function () {
    /**
     A utility that link controller
     @class Link
     @constructor
     **/
    $.Controller('Link',
        {
            /**
             Method for automatic call instantiated
             @method init.
             **/
            init: function () {
                this.isIOS = this.options.isIOS;
            },
            /**
             set link and download url
             @method setUrl.
             **/
            setUrl: function () {
                this.linkUrl = this.isIOS ? 'http://www.flynavi.cn/version/iphone.html' : 'http://www.flynavi.cn/version/android.html';
                this.downloadUrl = this.isIOS ? 'https://itunes.apple.com/cn/app/fei-lu-kuai-dao-hang/id570886583?mt=8' : 'http://www.flynavi.cn/d/1/flynavi.apk';
                $('.instructions a').attr('href', this.linkUrl);
                $('.download a').attr('href', this.downloadUrl);

            },
            '.download touchstart': function (el, ev) {
                el.find('img').css({
                    opacity: '0.7'
                });
            },
            '.download touchend': function (el, ev) {
                el.find('img').css({
                    opacity: '1'
                });
            }
        });
    return Link;
});
/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 7/4/13
 * Time: 5:31 PM
 * Use:
 */
define('networkDetect',['jquerymx'], function () {
    /**
     A utility that net service model
     @class netService
     @constructor
     **/
    $.Model('MapModel.netService', {
        /**
         * netService property description.
         * @property  prompt_no_net
         * @property  isJsApi
         * @type {Object}
         * @default ""
         */
        defaults: {
            //     todo prompt contents not update, it should include two conditions:
//     1, gps service not enabled
//     2, device or browers in the device not support to obtain gps info
            prompt_no_net: '亲，需要网络，快检查一下^^'
        }
    }, {
        /**
         Method for automatic call instantiated
         @method init.
         **/
        init: function () {

        },
        /**
         network status for chrome or safari(mobile environment) and browser's offline mode for firefox and ie
         @method isConnectLocalNet.
         @return {Boolean}
         **/
        isConnectLocalNet: function () {
            return navigator.onLine;
        },
        /**
         Whether the network connection
         @method isConnected.
         @return {Boolean}
         **/
        isConnected: function () {
            return this.hasJsApi() && this.isConnectLocalNet();
        },
        hasJsApi: function () {
            return typeof AMap !== 'undefined'
        },
        /**
         Pop-up boxes
         @method promptNoNet.
         **/
        promptNoNet: function () {
            alert(this.prompt_no_net);

        }
    });
});
/**
 * @COPYRIGHT Shanghai RaxTone-Tech Co.,Ltd.
 * @Title:
 * @Description:
 * @author wangyonggang qq:135274859
 * @date 13-1-11 下午12:14
 * @version V1.0
 * Modification History:
 */
define('tools',[ 'jquerymx'], function () {
    /**
     A utility that common model
     @class common
     @constructor
     **/
    $.Class.extend('Util.common', {},
        {
            /**
             The method is to conversion unit
             @method unitConversion.
             @param config object
             @return {Object}
             **/
            unitConversion: function (config) {
                var configUnit = {};
                try {
                    configUnit.length = this.unit_conversion(config.length, 1),
                        configUnit.time = this.formatMinute(config.time)
                }
                catch (e) {
                    configUnit.length = '' , configUnit.time = '';
                }
                return configUnit;
            },
            /**
             The method is to format time
             @method formatMinute.
             @param newM number
             @return {String}
             **/
            formatMinute: function (newM) {
                if (typeof newM !== 'undefined' && newM != Infinity) {
                    var minute = Math.round(newM);
                    if (minute < 61)
                        return minute + "分钟";
                    else {
                        var h = Math.floor(minute / 60);
                        var m = minute % 60;
                        return h + "小时" + m + "分钟";
                    }
                } else {
                    return '未知';
                }
            },
            /**
             The method is to conversion unit
             @method unit_conversion.
             @param m number
             @param decimal number
             @return {String}
             **/
            unit_conversion: function (m, decimal) {
                if (m == Infinity)
                    return "未知";
                if (m < 1000) {
                    if (m >= 1) {
                        return parseInt(m) + 'm';
                    } else {
                        return '1m';
                    }
                }
                else {
                    //number的字符串表示，不采用指数计数法，小数点后有固定的digics位数字。如果 必要，该数字会被舍入，也可以用0补足，以便它达到指定的长度。
                    var k = 0;
                    //如果大于等于100公里，不显示小数
                    if (m / 1000 >= 100) {
                        k = (m / 1000).toFixed(0);
                    }
                    else {
                        k = (m / 1000).toFixed(decimal);
                    }
                    return k + ' km';
                }

            },
            /**
             The method is to get dpi
             @method js_getDPI.
             @return {Array}
             **/
            js_getDPI: function () {
                var arrDPI = new Array();
                if (window.screen.deviceXDPI != undefined) {
                    arrDPI[0] = window.screen.deviceXDPI;
                    arrDPI[1] = window.screen.deviceYDPI;
                }
                else {
                    var tmpNode = document.createElement("DIV");
                    tmpNode.style.cssText = "width:1in;height:1in;position:absolute;left:0px;top:0px;z-index:99;visibility:hidden";
                    document.body.appendChild(tmpNode);
                    arrDPI[0] = parseInt(tmpNode.offsetWidth);
                    arrDPI[1] = parseInt(tmpNode.offsetHeight);
                    tmpNode.parentNode.removeChild(tmpNode);
                }
                return arrDPI;
            },
            /**
             The method is to parse url
             @method parseUrl.
             @param url string
             @return {Object}
             **/
            parseUrl: function (url) {
                var str = decodeURI(url),
                    reg = /.*\?(.*)/;
                var match = /.*\?(.*)/.exec(str);
                if (match == null) {
                    return null;
                }
                var arr = match[1].split('&'),
                    obj = {};
                $.each(arr, function (i, n) {
                    var arrItem = n.split('=');
                    obj[arrItem[0]] = arrItem[1];
                });
                return obj;

            },
            /**
             This method is to determine whether the air
             @method judgeVal.
             @param val object
             @return {Blooean}
             **/
            judgeVal: function (val) {
                return val != '' && val != 'undefined' && val != null;
            },
            /**
             This method is to truncate string
             @method truncateStr.
             @param str string
             @param maxLength number
             @return {String}
             **/
            truncateStr: function (str, maxLength) {

                if (str.length > maxLength) {
                    return str.slice(0, maxLength - 3) + '...';
                }
                return str;
            },
            /**
             This method is toset touch event
             @method setTouchEvent.
             @param elector string
             @param eventCallback function
             @param eventEndCallback function
             **/
            setTouchEvent: function (elector, eventCallback, eventEndCallback) {


                $(elector).on({
                    'touchstart': function () {
                        eventCallback.call(this);
                    },
                    'touchend': function () {
                        eventEndCallback.call(this);
                    },
                    'touchmove': function () {
                        $(elector).removeClass('active');
                    }/* ,
                     'mousedown':function () {
                     eventCallback.call(this);
                     },
                     'mouseup':function () {
                     eventEndCallback.call(this);
                     },
                     'mouseleave':function () {
                     eventEndCallback.call(this);
                     }*/
                });
            },
            /**
             This method is to get position
             @method getPos.
             @param obj object
             **/
            getPos: function (obj) {
                if (obj == null) {
                    return;
                }
                var pos = {"top": 0, "left": 0};
                if (obj.offsetParent) {
                    while (obj.offsetParent) {
                        pos.top += obj.offsetTop;
                        pos.left += obj.offsetLeft;
                        obj = obj.offsetParent;
                    }
                } else if (obj.x) {
                    pos.left += obj.x;
                } else if (obj.x) {
                    pos.top += obj.y;
                }
                return pos;
            },
            /**
             This method is to set animate ele visibility
             @method animateDisplayLayer.
             @param $ele object
             @param top number
             @param height number
             **/
             animateDisplayLayer: function ($ele, top, height) {
                $ele.stop(true, false).animate({top: top, height: height}, { speed: "slow", queue: false });
            },
            /**
             This method is to set swithc ele state
             @method promptUser.
             @param id string
             **/
            promptUser: function (id) {
                $('#' + id).removeClass('hidden');
                setTimeout(function () {
                    $('#' + id).addClass('hidden');
                }, 4000);
            }

        });
})
;
/**
 * @COPYRIGHT Shanghai RaxTone-Tech Co.,Ltd.
 * @Title:
 * @Description:
 * @author wangyonggang qq:135274859
 * @date 13-6-27 上午11:06
 * @version V1.0
 * Modification History:
 */




define('toolBar',['jquerymx'], function () {
    /**
     A utility that Toolbar event controller
     @class Toolbar
     @constructor
     **/

    $.Controller('Toolbar', {
        $route: $("#route"),
        tabsContent_table_content: $('#route .tabsContent_table_content'),
        scroll_first: $('#scroll_first'),
        scroll_second: $('#scroll_second'),
        scroll_first_table: $('#scroll_first table'),
        scroll_second_table: $('#scroll_second table'),
        mapHandle: null,
        /**
         Method for automatic call instantiated
         @method init.
         **/
        init: function () {
            this.mapHandle = this.options.mapHandle;
            this.infoHeight = $('#link_bar').height();
            this.headHeight = $('#route .header').height();
            this.theadHeight = $('#tabsContent thead:first').height();
        },
        /**
         Method for show route info
         @method showRouteInfo.
         **/
        showRouteInfo: function (routeObj) {
            if (this.tabsContent_table_content.find('tr').length == 0) {
                routeObj.attr('rout_type', 4);
                var $rapidRoute = routeObj.showRoadSegInfo();
                routeObj.attr('rout_type', 0);
                var $normalRoute = routeObj.showRoadSegInfo();
                this.scroll_first_table.append($rapidRoute);
                this.scroll_second_table.append($normalRoute);
            }
            this.$route.css({top: '100%', height: '0.1%', visibility: 'visible'});
            var endHeight = $(document.body).height() - this.infoHeight;

            util_common.animateDisplayLayer(this.$route, 0, endHeight);
            if (this.mapHandle.curDisplayPath == 4) {
                routeObj.attr('curDisplayPath', 'A');
            } else {
                routeObj.attr('curDisplayPath', 'B');
            }
        },
        /**
        set scroll ele height
         @method setScrollEleHeight.
         @param arr Array
         **/
        setScrollEleHeight:function(arr){
            var height = $(document.body).height();
            for(var i =0;i<arr.length;i++){
                height = height - arr[i];
            }
            this.scroll_first.height(height);
            this.scroll_second.height(height);
        },
        'span touchend': function (el, ev) {
//        location.hash = '#routeInfo';
            this.showRouteInfo(this.options.routeObj);
        }
    });

});
/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 7/4/13
 * Time: 5:22 PM
 * Use:
 */
/*路书页model*/
define('route',['jquerymx'], function () {
    /**
     A utility that switch route tab controller
     @class Route
     @constructor
     **/
    $.Model('Route', {
        defaults: {
            curDisplayPath: Infinity,
            route_tabs: $('#route_tabs'),
            tabsContent: $('#tabsContent'),
            $route: $("#route"),
            imgSrc: 'images/public/list/',
            totalWidth: 300,
            scroll_first: 'scroll_first',
            scroll_second: 'scroll_second',
            rapidRouteArea: $('#scroll_first table'),
            normalRouteArea: $('#scroll_second table'),
            rout_type: Infinity,
            scrollUpdated: false,
            scrollObj: {firstScroll: null, secondScroll: null}
        }
    }, {
        /**
         Method for automatic call instantiated
         @method init.
         **/
        init: function (config) {
            this.unit = config.unit || 'km/h';
            this.colorArr = config.arrTrafficCol;
            var firstScroll = new iScroll(this.scroll_first, {
                snap: false,
                hScrollbar: false,
                vScrollbar: false,
                useTransition: true,
                hScroll: false,
                bounce: false,
                zoom: false,
                momentum: true,
                onScrollMove: function () {

                },
                onScrollEnd: function () {

                }
            });
            var secondScroll = new iScroll(this.scroll_second, {
                snap: false,
                hScrollbar: false,
                vScrollbar: false,
                useTransition: true,
                hScroll: false,
                bounce: false,
                zoom: false,
                momentum: true,
                onScrollMove: function () {

                },
                onScrollEnd: function () {

                }
            });
            this.scrollObj = {
                firstScroll: firstScroll,
                secondScroll: secondScroll
            };
            Array.prototype.max = function () {   //最大值
                return Math.max.apply({}, this)
            };
            Array.prototype.min = function () {   //最小值
                return Math.min.apply({}, this)
            };
        },
        /**
         The method is called when the element scroll
         @method setScrollUpdated.
         * @param newCurDisplayPath the new value
         * @param success callback
         * @param error callback
         **/
        setScrollUpdated: function (newCurDisplayPath, success, error) {
            if (newCurDisplayPath) {
                var self = this;
                setTimeout(function () {
                    if (self.$route.is(":animated")) {
                        self.$route.stop(true, true);
                    }
                    self.scrollObj.firstScroll.refresh();
                    self.scrollObj.secondScroll.refresh();
                    self.scrollObj.firstScroll.scrollTo(0,0)
                    self.scrollObj.secondScroll.scrollTo(0,0)
                }, 100);
            }
        },
        /**
         The method is set current display path
         @method setCurDisplayPath.
         * @param newCurDisplayPath the new value
         * @param success callback
         * @param error callback
         **/
        setCurDisplayPath: function (newCurDisplayPath, success, error) {
            if (newCurDisplayPath == 'A' || newCurDisplayPath == 'B') {
                this.route_tabs.find(">[data-tab]").removeClass("active");
                this.route_tabs.find(">[data-tab='" + newCurDisplayPath + "']").addClass("active");
                this.tabsContent.find(">[data-tab]").removeClass("active");
                this.tabsContent.find(">[data-tab='" + newCurDisplayPath + "']").addClass("active");
                this.setScrollUpdated(true);
            } else {
                return 'A';
            }
        },
        /**
         The method shows road seginfo
         @method showRoadSegInfo.
         * @return {Object}
         **/
        showRoadSegInfo: function () {
//            var data = requestPath.getGuideList(this.rout_type);
//            return this.callback(data);
            requestPath.tbt.SelectRoute(this.rout_type);
            var data = {
                xmlStr: requestPath.tbt.GetNaviGuideList()
            };
            return this.callback(data.xmlStr);
        },
        /**
         This method returns an analytical results
         @method callback.
         * @param data a object
         * @return {Object}
         **/
        callback: function (data) {
            var imgArr = [], obj = {}, segArr = [], maxLength = 0, width = 0, len = data.length, $tr, $tbody = $('<tbody></tbody>');
            for (var i = 0; i < len; i++) {
                segArr.push(data[i].distance);
            }
            //找出最大值
            obj.maxLength = segArr.max();
            obj.ios = publicModel.isIOS();
            for (var i = 0; i < len; i++) {
                var list = data[i];
                var icon = list.directionIcon,
                    name = list.roadName || '无名道路';
                var distance = util_common.routeUnitConversion(list.distance, 1),
                    img = new Image();
                img.src = this.imgSrc + icon + '.png';
                imgArr.push(img);
                obj.width = segArr[i] / obj.maxLength * this.totalWidth * 2 / 3 + this.totalWidth / 3;
                obj.segLength = segArr[i];
                obj.i = i;
                obj.averageRate = this.returnFloat1(requestPath.getNavSegLength(i) / requestPath.getNavSegTime(i) / 1000 * 60);
                var $name = $('<p/>').html(name),
                    $route = $('<p/>').css({display: 'inline-block', 'float': 'left', margin: '0', padding: '0'}).html(this.routeGuide(obj)),
                    $distance = $('<p/>').css({display: 'inline-block', 'float': 'left', marginTop: '4px', marginLeft: '6px'}).html(distance);
                $tr = $('<tr><td></td><td ></td><td><span class="number">' + obj.averageRate + '</span><span class="unit">' + this.unit + '</span></td></tr>');
                $tr.find('td').eq(0).append(img);
                $tr.find('td').eq(1).append($name).append($route).append($distance);
                $tbody.append($tr);

            }
            $tbody.find('td:first-of-type>img').each(function (index, el) {
                if (typeof $(el).attr('src') == "undefined") {
                    $(el).attr('src', imgArr[index].src);
                }
            });
            return $tbody;
        },
        /**
         This method returns a number with a decimal
         @method returnFloat1.
         * @param value a Number
         * @return {Number}
         **/
        returnFloat1: function (value) {
            value = Math.round(parseFloat(value) * 10) / 10;
            if (value.toString().indexOf(".") < 0)
                value = value.toString() + ".0";
            return value;
        },
        /**
         This method returns an object about traffic light beam
         @method routeGuide.
         * @param obj a object
         * @return {Object}
         **/
        routeGuide: function (obj) {
            var linkWidth = 0,
                i = obj.i,
                lc = {},
                stus = 0,
                segLength = obj.segLength,
                width = obj.width,
                color = '',
                maxLength = obj.maxLength,
                innerEleWidth = 0,
                border = obj.ios ? '1px solid #000' : '2px solid #000';
            $p = $('<p/>').css({
                border: border,
                borderRadius: '3px',
                margin: '0',
                padding: '0',
                display: 'inline-block'
            });
            var num = requestPath.tbt.GetSegLocationCodeNum(i);
            if (!num) {
                innerEleWidth = segLength / maxLength * width;
                innerEleWidth = innerEleWidth < 50 ? 50 : innerEleWidth;
                color = this.colorArr[0];
                var $innerP = $('<p/>').css({
                    height: '6px',
                    display: 'inline-block',
                    width: innerEleWidth,
                    backgroundColor: color,
                    margin: '0',
                    padding: '0',
                    'float': 'left'
                });
                $p.append($innerP);
            }
            for (var k = 0; k < num; k++) {
                lc = requestPath.tbt.GetSegLocationCode(i, k);
                stus = requestPath.tbt.GetRoadStatus(lc.code);
                linkWidth = lc.dist;
                color = this.colorArr[stus];
                innerEleWidth = linkWidth / segLength * width;
                var $innerP = $('<p/>').css({
                    height: '6px',
                    display: 'inline-block',
                    width: innerEleWidth,
                    backgroundColor: color,
                    margin: '0',
                    padding: '0',
                    'float': 'left'
                });
                $p.append($innerP);
            }
            return $p;

        }
    });
});
/**
 * @COPYRIGHT Shanghai RaxTone-Tech Co.,Ltd.
 * @Title:
 * @Description:
 * @author wangyonggang qq:135274859
 * @date 13-7-16 下午1:46
 * @version V1.0
 * Modification History:
 */
define('toolsFlynavi',['tools'], function () {
    Util.common('Util.common', {
        /**
         The method is to conversion unit
         @method unit_conversion.
         @param m number
         @param decimal number
         @return {String}
         **/
        unit_conversion: function (m, decimal) {
            if (m == Infinity) {
                return "未知";
            }
            else {
                //number的字符串表示，不采用指数计数法，小数点后有固定的digics位数字。如果 必要，该数字会被舍入，也可以用0补足，以便它达到指定的长度。
                var k = 0;
                //如果大于等于100公里，不显示小数
                if (m / 1000 >= 100) {
                    k = (m / 1000).toFixed(0);
                }
                else {
                    k = (m / 1000).toFixed(1);
                }
                return k;
            }
        },
        routeUnitConversion: function (m, decimal) {
            if (m == Infinity)
                return "未知";
            if (m < 1000) {
                if (m >= 1) {
                    return parseInt(m) + '米';
                } else {
                    return '1米';
                }
            }
            else {
                //number的字符串表示，不采用指数计数法，小数点后有固定的digics位数字。如果 必要，该数字会被舍入，也可以用0补足，以便它达到指定的长度。
                var k = 0;
                //如果大于等于100公里，不显示小数
                if (m / 1000 >= 100) {
                    k = (m / 1000).toFixed(0);
                }
                else {
                    k = (m / 1000).toFixed(1);
                }
                return k + '千米';
            }
        }
    });
});
/**
 * @COPYRIGHT Shanghai RaxTone-Tech Co.,Ltd.
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 5/29/13
 * Time: 11:31 AM
 * Modified:   2013-6-27
 * Use:
 */
define('app',['historyController', 'controllerMap', 'cache', 'mapHandler', 'map', 'tab', 'link', 'networkDetect', 'toolBar', 'route', 'toolsFlynavi'], function () {
    var netService = new MapModel.netService();
    if (!netService.isConnected()) {
        netService.promptNoNet();
        return false;
    }
    util_common = new Util.common();
    var url = location.href.replace(/#.*$/, '');
    var parseUrl = util_common.parseUrl(url);

    publicModel = new PublicModel();
    scale = new MapModel.Scale();
    mapHandler = new MapModel.mapHandler();
    common = new MapModel.Constant();
    eleToggle = new MapModel.ToggleEleState()
    requestPath = new MapModel.RouteRequestFrame({
        callback: function () {
            location.hash = '#requestPath';
            var that = this;
            var tmcRouteLen = this.getRouteLength(4),
                normalRouteLen = this.getRouteLength(0),
                tmcRouteTraffic = that.getSomeLenRouteTraffic(4),
                normalRouteTraffic = that.getSomeLenRouteTraffic(0);
            var config = {
                tmcRouteLength: tmcRouteLen,
                tmcTime: that.getRouteTime(4),
                normalRouteLength: normalRouteLen,
                normalTime: that.getRouteTime(0),
                arrTmcTraffic: tmcRouteTraffic,
                arrNormalTraffic: normalRouteTraffic,
                arrTrafficCol: common.pathColor
            };
            require(['mapRouteView'],function(){

                setMapRouteView = new MapRouteView(config);
                setMapRouteView.displayData();
                require(['pathDrawing'], function () {
                    drawPath = new MapModel.PathDrawing({
                        mapObj: mapHandler.mapObj,
                        rapidInfo: that.getRapidPathInfo(),
                        normalInfo: that.getNormalPathInfo(),
                        tmcRouteTraffic: tmcRouteTraffic,
                        normalRouteTraffic: normalRouteTraffic,
                        pathColor: common.pathColor
                    });
                    drawPath.drawPath();
                    mapHandler.setMapPathFit();
                })
            })
            require(['raxtoneServer'], function () {
                requestRaxtone = new MapModel.netServiceRaxtone({
                    loginErrorCallback: navInfo.failMethod,
                    notSupportPrediction: navInfo.showNotSupportPrediction
                });
                requestRaxtone
                    .bind('sid', function (ev, newVal) {
                        this.requestRaxtoneRoutePre(newVal, 4, navInfo.requestTmcFail);
                    })
                    .bind('dataPrediction', function (ev, newVal) {
                        /**
                         bind handler if get prediction data

                         @param newVal {Object}
                         @example
                         Object {requestTime: 1374124220041, timeExtend10: 1490, timeExtend20: 1490}
                         get seconds: (new Date(1374124220041)).getSeconds()
                         get request type: this.getPlanType()
                         **/
//                        var newVal = {requestTime: 1374124220041, timeExtend10: 1490, timeExtend20: 1490};
                        if (this.getPlanType() == 4) {
                            navInfo.showTmcData(newVal);
                            var sid = requestRaxtone.getSid();
                            requestRaxtone.requestRaxtoneRoutePre(sid, 0, navInfo.requestNormalFail)
                        } else {
                            navInfo.showNormalData(newVal);
                        }
                    });
                requestRaxtone.requestRaxtoneLogin();
            })
            require(['controlNav', 'controlBar' ], function () {
                var toolbarNav = new ToolbarNav('.e-inav', {
                    mapHandle: mapHandler,
                    routeObj: routeObj
                }), arr = [];
                arr.push($('#link_bar').height());
                arr.push($('#route .header').height());
                arr.push($('#tabsContent thead:first').height());
                arr.push($('#route .route_info').height());
                toolbarNav.setScrollEleHeight(arr);
                if (typeof navControl == 'undefined') {
                    navControl = new NavControl($('#header'), {toolbarNav: toolbarNav});
                }
                navControl.showCinav();
            })
            scale.updateMarker();
            eleToggle.toggleEleAfterRequest();
            requestPath.toggleLoadingEffect();
        },
        failCallback: function () {
            requestPath.toggleLoadingEffect();
            this.attr('isRequestPath', false);
            if (!netService.isConnected()) {
                var id = 'no_get_net';
                util_common.promptUser(id);
                return;
            }
            //            todo ui toggle and param modification should seperate
            mapHandler.getNoPath();
        }
    });
    followDev = new DevPosTracker({
        successCallback: function (currGps) {
            var that = this;
//            var lngLat = this.getCurrIniGps();
            var lngLat={
                lng:currGps.coords.longitude,
                lat:currGps.coords.latitude
            };
            if (publicModel.isIOS()) {
                mapHandler.correctPosition(lngLat.lng, lngLat.lat, rectifyDeviation);
            } else {
                rectifyDeviation({
                    lng: lngLat.lng,
                    lat: lngLat.lat
                });
            }
            function rectifyDeviation(lngLat) {
                var currGPS = that.getCurrGps.call(that,lngLat,currGps);
                requestPath.attr('iGpsCount', requestPath.iGpsCount++);
                mapHandler.attr('curInfo', {
                    lng: currGPS.longitude,
                    lat: currGPS.latitude,
                    angle: currGPS.direction
                });
                that.setCurrGpsNull.call(that);
            }

            mapHandler.handleGpsState();
        },
        failCallback: function (err) {
            requestPath.attr('iGpsCount', this.iGpsCount++);
        },
        callbackDisconnectGps: function () {
            //            todo specify gps
            //            requestPath.setCurPos();
            mapHandler.changeState();
        },
        tbt: requestPath.tbt
    });
    (new Link($('.info'), {isIOS: publicModel.isIOS()})).setUrl();
    var mapController = new MapControl($('#mask_layer'));
    scale
        .bind('level', function (ev, newVal) {
//            todo     高德回复：目前在手机浏览器上的支持情况还不是特别理想。
//            to recovery if map's center change after scale but moveMapCenter to change for different conditions
         /*   mapHandler.moveMapCenter()*/
            if (scale.isScale()) {
                mapHandler.mapObj.setZoom(newVal);
            }
            mapController.setZoomBtnUi();
        });

    requestPath
        .bind('isRequestPath', function (ev, newItems) {
            if (!newItems) {
                return;
            }
            var start = {
                    x: mapHandler.curInfo.lng,
                    y: mapHandler.curInfo.lat
                },
                end = {
                    x: mapHandler.getShareLngLat().lng,
                    y: mapHandler.getShareLngLat().lat
                };
            this.startRequest(start, end);
        })
        .bind('iGpsCount', function () {
            this.setGpsInfo(followDev.getCurrEncapsulatedGps());
        });
    followDev.bind('isPollGps', function () {
        this.pollGps();
    });
    bindFocusEve = function (eleExclude) {
        $("*:not(" + eleExclude + ")").focus(function () {
            this.blur();
        });
    }
    return parseUrl
});

/**
 * FastDom
 *
 * Eliminates layout thrashing
 * by batching DOM read/write
 * interactions.
 *
 * @author Wilson Page <wilsonpage@me.com>
 */

;(function(fastdom){

  'use strict';

  // Normalize rAF
  var raf = window.requestAnimationFrame
    || window.webkitRequestAnimationFrame
    || window.mozRequestAnimationFrame
    || window.msRequestAnimationFrame
    || function(cb) { return window.setTimeout(cb, 1000 / 60); };

  // Normalize cAF
  var caf = window.cancelAnimationFrame
    || window.cancelRequestAnimationFrame
    || window.mozCancelAnimationFrame
    || window.mozCancelRequestAnimationFrame
    || window.webkitCancelAnimationFrame
    || window.webkitCancelRequestAnimationFrame
    || window.msCancelAnimationFrame
    || window.msCancelRequestAnimationFrame
    || function(id) { window.clearTimeout(id); };

  /**
   * Creates a fresh
   * FastDom instance.
   *
   * @constructor
   */
  function FastDom() {
    this.frames = [];
    this.lastId = 0;
    this.batch = {
      hash: {},
      read: [],
      write: [],
      mode: null
    };
  }

  /**
   * Adds a job to the
   * write batch and schedules
   * a new frame if need be.
   *
   * @param  {Function} fn
   * @api public
   */
  FastDom.prototype.read = function(fn, ctx) {
    var job = this.add('read', fn, ctx);
    var id = job.id;

    // Add this job to the read queue
    this.batch.read.push(job.id);

    // We should *not* schedule a new frame if:
    // 1. We're 'reading'
    // 2. A frame is already scheduled
    var doesntNeedFrame = this.batch.mode === 'reading'
      || this.batch.scheduled;

    // If a frame isn't needed, return
    if (doesntNeedFrame) return id;

    // Schedule a new
    // frame, then return
    this.scheduleBatch();
    return id;
  };

  /**
   * Adds a job to the
   * write batch and schedules
   * a new frame if need be.
   *
   * @param  {Function} fn
   * @api public
   */
  FastDom.prototype.write = function(fn, ctx) {
    var job = this.add('write', fn, ctx);
    var mode = this.batch.mode;
    var id = job.id;

    // Push the job id into the queue
    this.batch.write.push(job.id);

    // We should *not* schedule a new frame if:
    // 1. We are 'writing'
    // 2. We are 'reading'
    // 3. A frame is already scheduled.
    var doesntNeedFrame = mode === 'writing'
      || mode === 'reading'
      || this.batch.scheduled;

    // If a frame isn't needed, return
    if (doesntNeedFrame) return id;

    // Schedule a new
    // frame, then return
    this.scheduleBatch();
    return id;
  };

  /**
   * Defers the given job
   * by the number of frames
   * specified.
   *
   * If no frames are given
   * then the job is run in
   * the next free frame.
   *
   * @param  {Number}   frame
   * @param  {Function} fn
   * @api public
   */
  FastDom.prototype.defer = function(frame, fn, ctx) {

    // Accepts two arguments
    if (typeof frame === 'function') {
      ctx = fn;
      fn = frame;
      frame = 1;
    }

    var self = this;
    var index = frame - 1;

    return this.schedule(index, function() {
      self.run({
        fn: fn,
        ctx: ctx
      });
    });
  };

  /**
   * Clears a scheduled 'read',
   * 'write' or 'defer' job.
   *
   * @param  {Number} id
   * @api public
   */
  FastDom.prototype.clear = function(id) {

    // Defer jobs are cleared differently
    if (typeof id === 'function') {
      return this.clearFrame(id);
    }

    var job = this.batch.hash[id];
    if (!job) return;

    var list = this.batch[job.type];
    var index = list.indexOf(id);

    // Clear references
    delete this.batch.hash[id];
    if (~index) list.splice(index, 1);
  };

  /**
   * Clears a scheduled frame.
   *
   * @param  {Function} frame
   * @api private
   */
  FastDom.prototype.clearFrame = function(frame) {
    var index = this.frames.indexOf(frame);
    if (~index) this.frames.splice(index, 1);
  };

  /**
   * Schedules a new read/write
   * batch if one isn't pending.
   *
   * @api private
   */
  FastDom.prototype.scheduleBatch = function() {
    var self = this;

    // Schedule batch for next frame
    this.schedule(0, function() {
      self.batch.scheduled = false;
      self.runBatch();
    });

    // Set flag to indicate
    // a frame has been scheduled
    this.batch.scheduled = true;
  };

  /**
   * Generates a unique
   * id for a job.
   *
   * @return {Number}
   * @api private
   */
  FastDom.prototype.uniqueId = function() {
    return ++this.lastId;
  };

  /**
   * Calls each job in
   * the list passed.
   *
   * If a context has been
   * stored on the function
   * then it is used, else the
   * current `this` is used.
   *
   * @param  {Array} list
   * @api private
   */
  FastDom.prototype.flush = function(list) {
    var id;
    while (id = list.shift()) {
      this.run(this.batch.hash[id]);
    }
  };

  /**
   * Runs any read jobs followed
   * by any write jobs.
   *
   * @api private
   */
  FastDom.prototype.runBatch = function() {

    // Set the mode to 'reading',
    // then empty all read jobs
    this.batch.mode = 'reading';
    this.flush(this.batch.read);

    // Set the mode to 'writing'
    // then empty all write jobs
    this.batch.mode = 'writing';
    this.flush(this.batch.write);

    this.batch.mode = null;
  };

  /**
   * Adds a new job to
   * the given batch.
   *
   * @param {Array}   list
   * @param {Function} fn
   * @param {Object}   ctx
   * @returns {Number} id
   * @api private
   */
  FastDom.prototype.add = function(type, fn, ctx) {
    var id = this.uniqueId();
    return this.batch.hash[id] = {
      id: id,
      fn: fn,
      ctx: ctx,
      type: type
    };
  };

  /**
   * Runs a given job.
   *
   * Applications using FastDom
   * have the options of setting
   * `fastdom.onError`.
   *
   * This will catch any
   * errors that may throw
   * inside callbacks, which
   * is useful as often DOM
   * nodes have been removed
   * since a job was scheduled.
   *
   * Example:
   *
   *   fastdom.onError = function(e) {
   *     // Runs when jobs error
   *   };
   *
   * @param  {Object} job
   * @api private
   */
  FastDom.prototype.run = function(job){
    var ctx = job.ctx || this;
    var fn = job.fn;

    // Clear reference to the job
    delete this.batch.hash[job.id];

    // If no `onError` handler
    // has been registered, just
    // run the job normally.
    if (!this.onError) {
      return fn.call(ctx);
    }

    // If an `onError` handler
    // has been registered, catch
    // errors that throw inside
    // callbacks, and run the
    // handler instead.
    try { fn.call(ctx); } catch (e) {
      this.onError(e);
    }
  };

  /**
   * Starts of a rAF loop
   * to empty the frame queue.
   *
   * @api private
   */
  FastDom.prototype.loop = function() {
    var self = this;

    // Don't start more than one loop
    if (this.looping) return;

    raf(function frame() {
      var fn = self.frames.shift();

      // Run the frame
      if (fn) fn();

      // If no more frames,
      // stop looping
      if (!self.frames.length) {
        self.looping = false;
        return;
      }

      raf(frame);
    });

    this.looping = true;
  };

  /**
   * Adds a function to
   * a specified index
   * of the frame queue.
   *
   * @param  {Number}   index
   * @param  {Function} fn
   * @return {Function}
   */
  FastDom.prototype.schedule = function(index, fn) {

    // Make sure this slot
    // hasn't already been
    // taken. If it has, try
    // re-scheduling for the next slot
    if (this.frames[index]) {
      return this.schedule(index + 1, fn);
    }

    // Start the rAF
    // loop to empty
    // the frame queue
    this.loop();

    // Insert this function into
    // the frames queue and return
    return this.frames[index] = fn;
  };

  // We only ever want there to be
  // one instance of FastDom in an app
  fastdom = fastdom || new FastDom();

  /**
   * Expose 'fastdom'
   */

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = fastdom;
  } else if (typeof define === 'function' && define.amd) {
    define('fastdom',[],function(){ return fastdom; });
  } else {
    window['fastdom'] = fastdom;
  }

})(window.fastdom);

/**
 * @COPYRIGHT Shanghai RaxTone-Tech Co.,Ltd.
 * @Title:
 * @Description:
 * @author wangyonggang qq:135274859
 * @date 13-7-11 下午4:00
 * @version V1.0
 * Modification History:
 */
define('navInfo',['fastdom', 'jquerymx'], function (fastdom) {
    $.Controller('NaviInfo', {
            defaults: {
            }
        },
        {

            init: function () {
                this.$route_tmc = $('#path_info .route_tmc_container');
                this.$route_normal = $('#path_info .route_normal_container');
            },
            '.route_tmc_container touchend': function (el) {
                if (el.hasClass('unselect')) {
                    this.$route_normal.toggleClass('unselect select');
                    el.toggleClass('unselect select');
                    mapHandler.setPathPileOrder();
                }
            },
            '.route_normal_container touchend': function (el) {
                if (el.hasClass('unselect')) {
                    this.$route_tmc.toggleClass('unselect select');
                    el.toggleClass('unselect select');
                    mapHandler.setPathPileOrder();
                }
            },
            failMethod: function () {
                $('#path_info .loadingProgressBar:first img').attr('src', 'flynavi/resources/images/loading-b1.png');
                $('#path_info .loadingProgressBar:first span').text('加载失败！等会再试^^');
                $('#path_info .loadingProgressBar:last img').attr('src', 'flynavi/resources/images/loading-b1.png');
            },
            requestTmcFail: function () {
                $('#path_info .loadingProgressBar:first img').attr('src', 'flynavi/resources/images/loading-b1.png');
                $('#path_info .loadingProgressBar:first span').text('加载失败！等会再试^^');
            },
            requestNormalFail: function () {
                $('#path_info .loadingProgressBar:last img').attr('src', 'flynavi/resources/images/loading-b1.png');
            },
            showNotSupportPrediction: function () {
                $('#path_info .loadingProgressBar:first').hide();
                $('#path_info .notSupportPredictionTips').css('display', ' -webkit-box');
                $('#path_info .loadingProgressBar:last img').attr('src', 'flynavi/resources/images/loading-b1.png');
            },
            showProgressBar: function () {
                $('#path_info .loadingProgressBar:first img').attr('src', 'flynavi/resources/images/loading-a1.gif');
                $('#path_info .loadingProgressBar:last img').attr('src', 'flynavi/resources/images/loading-a1.gif');
                $('#path_info .loadingProgressBar:first span').text('加载中...');
                $('#path_info .loadingProgressBar').css('display', '-webkit-box');
                $('#path_info .prediction_model_container').css('display', 'none');
            },
            restorationIni: function () {
                if (this.$route_tmc.hasClass('unselect')) {
                    this.$route_tmc.toggleClass('select unselect');
                    this.$route_normal.toggleClass('select unselect');
                }
            },
            showTmcData: function (newVal) {
                if (typeof  newVal === 'undefined') {
                    return;
                }
                fastdom.write(function () {

                    $('#tmc_withTime_one').text(util_common.formatMinute(Math.round(newVal.timeExtend10 / 60)));
                    $('#tmc_withTime_two').text(util_common.formatMinute(Math.round(newVal.timeExtend20 / 60)));
                })
                $('.loadingProgressBar:first').hide();
                $('#path_info .prediction_model_container:first').show();
                var sid = requestRaxtone.getSid();
                requestRaxtone.requestRaxtoneRoutePre(sid, 0)
            },
            showNormalData: function (newVal) {
                if (typeof  newVal === 'undefined') {
                    return;
                }
                fastdom.write(function () {
                    $('#normal_withTime_one').text(util_common.formatMinute(Math.round(newVal.timeExtend10 / 60)));
                    $('#normal_withTime_two').text(util_common.formatMinute(Math.round(newVal.timeExtend20 / 60)));
                })
                $('.loadingProgressBar:last').hide();
                $('#path_info .prediction_model_container:last').show();
            }
        });
});
/**
 * @COPYRIGHT Shanghai RaxTone-Tech Co.,Ltd.
 * @Title:
 * @Description:
 * @author wangyonggang qq:135274859
 * @date 13-7-16 上午9:48
 * @version V1.0
 * Modification History:
 */
define('trafficLayer',['jquerymx'],function(){
    $.Controller('MaskLayer', {
        '#tmc_btn touchstart': function (el, ev) {
            /*  el.addClass('active');*/
            var $el=$(el);
            $el.data('press', 'press');
            if( $el.hasClass('active')){
                $el.css('background','url(flynavi/resources/images/public.png) -46px -179px');
            }else{
                $el.css('background','url(flynavi/resources/images/public.png) -46px -224px');
            }
        },
        '#tmc_btn touchend': function (el, ev) {
            var $el=$(el);
            if($el.hasClass('active')){
                $el.css('background','url(flynavi/resources/images/public.png) -1px -224px');
                $el.removeClass('active');
                mapHandler.removeTmcLayer()
            }else{
                $el.css('background','url(flynavi/resources/images/public.png)  0px -180px');
                $el.addClass('active');
                mapHandler.addTmcLayer()
            }
        }
    });
    return MaskLayer;
})

;
/**
 * Created with JetBrains WebStorm.
 * User: qcgm1978
 * Date: 6/27/13
 * Time: 3:45 PM
 * Use:
 */
require.config({
    baseUrl: 'scripts',
    paths: {
        mapModel: '../flynavi/app/model/map-model',
        controllerMap: '../flynavi/app/controller/controller_start',
        navInfo: '../flynavi/app/controller/controller_naviInfo',
        toolsFlynavi: '../flynavi/app/util/tools_flynavi',
        jquery: '../bower_components/jquery/jquery',
        jquerymx: '../bower_components/jquerymx/jquerymx',
        fastdom: '../bower_components/fastdom/index',
        tools: "util/tools",
        mapUtil: "util/mapUtil",
        tbt: 'lib/tbt',
        toolBar: 'controller/Toolbar',
        cache: 'util/cache',
        map: 'controller/Map',
        mapHandler: 'model/mapHandler',
        webRoute: 'lib/webroute',
        iScroll: '../bower_components/iScroll4.2.5/iscroll',
        app: 'app',
        tab: 'controller/Tab',
        link: 'controller/Link',
        pathDrawing: 'model/pathDrawing',
        route: 'model/routeInfo',
        mapRouteView: '../flynavi/app/model/route-view',
        networkDetect: 'model/networkCommunication',
        historyController: 'controller/historyController',
        trafficLayer: '../flynavi/app/controller/controller_maskerlayer',
        raxtoneServer: '../flynavi/app/model/networkCommunication-raxtone',
        controlNav: '../flynavi/app/controller/controller_navControl',
        controlBar: '../flynavi/app/controller/controller_toolbar',
        appFlyNavi: '../flynavi/app/app_flynavi'  ,
        sharePath:'../flynavi/app/controller/share-path'
    },
    shim: {
        mapModel: {
            deps: [ 'mapUtil', 'iScroll', 'tbt']
        },
        toolsFlynavi: {
            deps: ['tools']
        },
        jquerymx: {
//            change jquery dependency to  jqueryMigrate if needed
            deps: ['jquery']
        },
        toolBar: {
            deps: ['tools']
        },
        mapHandler: {
            deps: ['jquerymx', 'mapModel']
        },
        tbt: {
            deps: ['jquerymx', 'webRoute']
        }
    }
});

/**
 @param {Boolean|Null|Object} appRet
 the ret val of app module. false if no network connection, null if no shared data, object if shared data exists
 **/
require(['app', 'navInfo', 'trafficLayer'], function (appRet) {
    if (!appRet) {
        return;
    }
//todo loaded module generate global var so requireJs hasn't effect on avoiding global var
    mapHandler
        .bind('shareInfo', function (ev, newVal) {
            if (newVal == null) {
                return;
            }
            var configShare = {
                lng: this.getShareLngLat().lng,
                lat: this.getShareLngLat().lat,
                imgAddress: 'flynavi/resources/images/share_position.png',
                imgWidth: 53,
                imgHeight: 41
            };
            var height = $('body').height() - $('#header').height() - $('#link_bar').height();
            $('#map_container').height(height);
            this.showMap();
            this.shareMarker = this.addMarker(configShare);
            //this.addShareInfoWindow(this.getShareLngLat().lng, this.getShareLngLat().lat);
            $('#share_name').text('(' + util_common.truncateStr(mapHandler.shareInfo.name, 20) + ')');
            $('#share_address').text(mapHandler.shareInfo.address);
            this.handleZoomChangeEve(function () {
                scale.attr('level', mapHandler.mapObj.getZoom());
            });
        })
        .bind('curInfo', function (ev, newVal) {
            if (this.mapObj == null) {
                return;
            }
            if (this.mapObj && this.curMarker) {
                this.moveCurMarker();
            }
            else {
                var configCur = {
                    lng: this.curInfo.lng,
                    lat: this.curInfo.lat,
                    imgAddress: 'images/cur_position.png',
                    imgWidth: common.SHARE_POS_METRIC,
                    imgHeight: common.SHARE_POS_METRIC
                };
                this.curMarker = this.addMarker(configCur);
            }
            this.rotateCurMarkerOrMap();
        });
    bodyLoad();
    mapHandler.attr('shareInfo', appRet);
    //加载完body元素后切换启动页
    function bodyLoad() {
        $('#main').css('display', 'block');
        $('#start').css('display', 'none');
        setTimeout(function () {
            window.scrollTo(0, 1);
        }, 100);
    }

    bindFocusEve();
    location.hash = '#share';
    //定位按钮等待状态
    var position_interval = null;
    void function () {
        var num = 0
        if (/Android\s*2\.3/.exec(navigator.userAgent)) {
            $('#positionLight').css('-webkit-backface-visibility', 'visible');
            $('#path_info .prediction_model,#path_info .route_normal_container').css('-webkit-backface-visibility', 'visible')
            $('#navi').css('-webkit-backface-visibility', 'visible');
        }
        position_interval = setInterval(function () {
            /*填加自车位置后，隐藏正在定位按钮样式*/
            if (mapHandler.mapObj && mapHandler.curMarker) {
                positionStateEnd();
            }
            var angle = 45 * num;
            num++;
            $('#positionLight').css({
                '-webkit-Transform': 'rotate(' + angle + 'deg)'
            }, 200)
            if (num == 8) {
                num = 0;
            }
        }, 150);
    }();
    function positionStateEnd() {
        clearInterval(position_interval);
        $('#positionLight').removeClass('loading').hide();
    }

    new Map($('#navi'));
    navInfo = new NaviInfo($('#path_info'));
    var config = {
        unit: '千米/小时',
        arrTrafficCol: common.pathColor
    };
    routeObj = new Route(config);
    routeObj.attr('totalWidth', ($(document.body).width() - $('.tabsContent_table th').eq(0).width() - $('.tabsContent_table th').eq(2).width()) / 2);
    new Tab($('#route'), {routeObj: routeObj});
    $(window).fly_shared_history({
        routeObj: routeObj,
        toolbar: toolbar
    });

    new MaskLayer($('#mask_layer'));
    followDev.attr('isPollGps', true);
    if (/micromessenger/i.exec(navigator.userAgent)) {
        $.getScript('scripts/util/micro-share.js', function () {
            var contents = util_common.truncateStr(mapHandler.shareInfo.name) + '(' + mapHandler.shareInfo.address + ')';
            handleMicroMesseageSharing({
                contents: contents,
                img: "images/start-320-460.jpg"
            })
        })
    }
    require(['sharePath'])
    return true;
});
define("../flynavi/app/app_flynavi", function(){});

//@ sourceMappingURL=combination.js.map